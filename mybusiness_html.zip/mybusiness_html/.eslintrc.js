module.exports = {
    "extends": "eslint:recommended",
    env: {
      "browser": true,
    "node": true
     },
    rules: {
      "strict": "off",
   "react/react-in-jsx-scope": "off",
   "new-cap": "off",
   "no-console": "off",
   "no-unused-vars": [
     "warn",
     {
       "vars": "all",
       "args": "after-used",
       "ignoreRestSiblings": false,
       "varsIgnorePattern": "createElement"
     }
   ]
     },
};
