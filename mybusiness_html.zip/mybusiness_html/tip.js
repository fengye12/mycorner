(function () {
    var obj = {
        init: function () {
            this.appVersion = "7.0.0";
            this.basicVersion = "6.0.0";
            $('body').append(this.tpl());
            this.event();
        },
        // 销毁x
        destory: function () {
            this.$el.off('click');
        },
        //判断设备类型
        getUserAgent: function () {
            var u = navigator.userAgent;
            var ios = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/);
            var iPad = u.indexOf('iPad') > -1;
            var iPhone = u.indexOf('iPhone') > -1 || u.indexOf('Mac') > -1;
            if (ios || iPad || iPhone) {
                return true;
            } else {
                return false;
            }
        },
        //html模板
        tpl: function () {
            var html = [];
            var versionResult = this.cpr_version(this.appVersion, this.basicVersion);
            if (versionResult) {
                html = ['<div class="alertTip"><div style="position:relative"><img src="wdFail.png" alt="联系客服"/>',
                    '<a href="javascript:;" class="positionA contactBtnwd contactObj">',
                    '</a>',
                    '<a href="javascript:;" class="positionA  closeBtnwd closeObj" >',
                    '</a>',
                    '</div></div>'
                ]
            } else {
                html = ['<div class="alertTip"><div style="position:relative"><img src="wdUpdate.png" alt="软件更新"/>',
                    '<a href="javascript:;" class="positionA updateBtn" >',
                    '</a>',
                    '<a href="javascript:;" class="positionA contactBtn contactObj">',
                    '</a>',
                    '<a href="javascript:;" class="positionA closeBtn closeObj">',
                    '</a>',
                    '</div></div>'
                ]
            }
            return html.join('');
        },
        //版本比较
        cpr_version: function (a, b) {
            var _a = this.toNum(a),
                _b = this.toNum(b);
            if (_a >= _b) return true;
            else return false;
        },
        // 版本转化数值
        toNum: function (a) {
            var a = a.toString();
            var c = a.split('.');
            // var c=a.split(/\D/);
            var num_place = ["", "0", "00", "000", "0000"],
                r = num_place.reverse();
            for (var i = 0; i < c.length; i++) {
                var len = c[i].length;
                c[i] = r[len] + c[i];
            }
            var res = c.join('');
            return res;
        },
        //打点
        sendPoint: function () {

        },
        // dom事件
        event: function () {
            var $el = $('.alertTip');

            this.$el = $el;

            var that = this;
            //关闭弹窗
            $el.on('click', '.closeObj', function () {
                that.handlerClose && that.handlerClose();
            })
            // 更新软件
            $el.on('click', '.updateBtn', function () {
                that.handlerUpdate();
            })
            // 联系客服
            $el.on('click', '.contactObj', function () {
                that.handlerContact();
            })

        },
        //软件更新
        handlerUpdate: function () {
            if (this.getUserAgent()) {
                // console.log('appstore')
                window.location.href = "https://itunes.apple.com/us/app/998dian-wan-cheng/id1135278767?mt=8";
            } else {
                // console.log('Android URL')
                window.location.href = "http://mbdownload.998dw.net/998dwcPackage/android/DWC_GW.apk";//打开apk
            }
        },
        handlerContact: function () {
            console.log('联系客服')
        },
        handlerClose: function () {
            this.$el.remove();
            this.destory();
        }
    }
    // obj.init();
})();
var a=0;
var promise = new Promise(function(resolve, reject) {
 if (a==0){
   // console.log(resolve(a))
 resolve("iiiiiii");

 } else {
 reject("error");
 }
}).catch(function(err){
  console.log("catch");
 });

promise.then(function(value) {
  console.log(value)
 console.log('success')
 return {"p":"pppp"}

}, function(value) {
 // failure
 console.log('fail')
 console.log(value);


}).then(function(value) {
  console.log(value)
 console.log('success')

}, function(value) {
 // failure
 console.log('fail')
 console.log(value);


}).catch(function(err){
  console.log("catch");
  console.log("error");
 });



// 0.5秒后返回input*input的计算结果:
function multiply(input) {
    return new Promise(function (resolve, reject) {
        console.log('calculating ' + input + ' x ' + input + '...');
        setTimeout(resolve, 500, input * input);
    });
}

// 0.5秒后返回input+input的计算结果:
function add(input) {
    return new Promise(function (resolve, reject) {
        console.log('calculating ' + input + ' + ' + input + '...');
        setTimeout(resolve, 500, input + input);
    });
}

var p = new Promise(function (resolve, reject) {
    console.log('start new Promise...');
    resolve(123);
});

p.then(multiply)
 .then(add)
 .then(multiply)
 .then(add)
 .then(function (result) {
    console.log('Got value: ' + result);
});
