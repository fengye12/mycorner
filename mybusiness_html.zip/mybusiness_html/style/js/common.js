//模拟select
$(".selectedB").on('click', '.sel-wrap', function(event) {
  var listH = $("#mySelectS").find(".optionB").height();
  if ($(this).is(":hover")) {
    console.log($(".selectedB .optionB").not($(this).next('.optionB')))
    $(".selectedB .optionB").not($(this).next('.optionB')).hide(20);
    $(this).next('.optionB').slideToggle(20);
  }
  if ($(this).next(".selectedB").find(".optionB").css("display") != "none") {
    var offsetBottom = document.documentElement.clientHeight + $(document).scrollTop() - $(this).offset().top - $(this).height();
    if (offsetBottom < listH) {
      console.log($(this).height())
      $("#mySelectS").find(".optionB").css({
        "left": "0",
        "top": -listH
      })
    }
  }
  return false;
});

$("#ssselS").on('click', '.op-item', function(event) {
  $(this).closest('.selectedB').find('.selected-item').text($(this).text());
  if ($(this).text() == "所有类型") {
    $("#sssel").val(0)
  } else if ($(this).text() == "食品名称") {
    $("#sssel").val(1)
  } else if ($(this).text() == "商品条码") {
    $("#sssel").val(2)
  } else if ($(this).text() == "商标") {
    $("#sssel").val(5)
  } else if ($(this).text() == "生产厂家") {
    $("#sssel").val(3)
  }
  $(this).closest('.optionB').slideUp(20);
});
$("#ssmodeS").on('click', '.op-item', function(event) {
  $(this).closest('.selectedB').find('.selected-item').text($(this).text());
  if ($(this).text() == "模糊查询") {
    $("#ssmode").val(1)
  } else if ($(this).text() == "精准查询") {
    $("#ssmode").val(0)
  }
  $(this).closest('.optionB').slideUp(20);
});
document.onclick = function() {
  $(".optionB").hide();
};

var selectText = "20条/页";
$("#mySelectS").on('click', '.op-item', function(event) {
  $("#mySelectS").find('.selected-item').text($(this).text());
  if (selectText != $(this).text()) {
    pindex = 1;
    selectText = $(this).text();
    if ($(this).text() == "10条/页") {
      psize = 10;
    } else if ($(this).text() == "20条/页") {
      psize = 20;
    } else if ($(this).text() == "30条/页") {
      psize = 30;
    } else if ($(this).text() == "40条/页") {
      psize = 40;
    } else if ($(this).text() == "50条/页") {
      psize = 50;
    } else {}
    search(sssel, sskey, ssmode, cid, storage, ycountry, pindex, psize);
  }

  $(this).closest('.optionB').slideUp(20);
});
