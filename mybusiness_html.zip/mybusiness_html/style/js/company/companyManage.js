var a1="a11",a2="a1100";
getActiveN("a11", "a1100");//当前页标志
    // 分页相关
    var pindex=1, pcount=1000, psize=$("#pageCentS select").val()?$("#pageCentS select").val():"10";
    var pcent = new CentPage();
    var pTemplate = "";
    var activeNum=pcent.PageNum;
    var obj=$("#page");
    //分页active页码
      function getActive(obj,activeNum){
       $.each(obj.find('li'), function(index, val) {
        var nowNum=$(val).text()
          if(nowNum==activeNum){
            $(this).addClass("active")
          }else{
            $(this).removeClass("active")
          }
        });
        }
       //分页点击页码触发
    function CentPageOper(num){
      pindex=num;
      pTemplate = pcent.GetCentPage(pindex, pcount, psize);
      $("#page").html(pTemplate);
       getActive(obj,num);
    }
    // 分页select change事件
    function pageChange(objselect){
      objselect.change(function(){
        console.log($(this).val())
        psize=$(this).val();
        pTemplate = pcent.GetCentPage(1, 1000, psize);
        $("#page").html(pTemplate);
        getActive(obj,1)
      });
    }
        // 切换企业类型
     $("#ctype").select3({
      'animate':'slide',
        'value':"1",
        callback:function(obj){
          console.log(obj)
           // var obj=$("#ssselS select");
           //触发change事件
          changeCtype(obj);
        }
    });
function changeCtype(obj){
    obj.change(function(){
        if($(this).val()==0){

        }
      });
}
    //  $(function(){

    //初始化分页select3
        $("#pageCentS").select3({
        'animate':'slide',
          'value':"10",
          callback:function(obj){
            console.log(obj)
             // var obj=$("#ssselS select");
            pageChange(obj)
          }
      });
        // 初始化分页select3之后才能初始化分页模板
        pTemplate=pcent.GetCentPage(pindex, pcount, psize);
         $("#page").html(pTemplate);
        getActive(obj,activeNum);
    // })
