
    var a1="a11",a2="a1100";
    getActiveN("a11", "a1100");//当前页标志
    defaultSelect();
      // 营业执照提示
    $(".iconIfnfo").click(function(){
      $(".fillTip").show();
    });
    $(".fillTip .closeBtn").click(function(){
      $(".fillTip").hide();
    });
    //城市选择器
    $('.selectArea').areaSelection({
      animateFunction: "toggle",
      //动画效果
      callback: "",
      //回调函数
      province_code: "",
      //默认城市的code
      city_code: "",
      //默认城市的code
      area_code: "",
      //默认城市的code
      street_code: "",
      //默认城市的code
      callback: function() {
        console.log("callback")
      }
    });
      // 切换许可证类型
function defaultSelect(){
$(".permitType").select3({
'animate':'slide',
 'value':"1",
 callback:function(obj){
   console.log(obj)
    // var obj=$("#ssselS select");
    //触发change事件
   changePermitType(obj);
 }
});
}

//切换证件类型
function changePermitType(obj){

obj.change(function(){
console.log($(this))
if($(this).val()==0){
  var html='<div class="input-normal">'
  +'<label >生产许可证品种<em class="color-red">*</em></label>'
  +'<div class="textareaBox"><textarea name="" width="100%" height="80px"></textarea>'
  +'</div></div>'
  $(this).closest('.list').find('.permitItem').empty().append(html);
}else if($(this).val()==1){
  var html='<div class="input-normal">'
  +'<label >经营项目<em class="color-red">*</em></label>'
  +'<div class="textareaBox"><textarea name="" width="100%" height="80px"></textarea>'
  +'</div></div>'
  $(this).closest('.list').find('.permitItem').empty().append(html);
}else{
$(this).closest('.list').find('.permitItem').empty();
}

});
}
//日期选择
$(".inputDate input").jeDate({
    format:"YYYY-MM-DD",
    isTime:false,
    minDate:"2014-09-19 00:00:00"
})
     // 切换监管单位
      $("#fatherCom").select3({
       'animate':'slide',
         'value':"1",
         callback:function(obj){
           console.log(obj)
            // var obj=$("#ssselS select");
            //触发change事件
           // change(obj);
         }
     });
  // })
  //上传图片
  var imgPath=[];

  var upyun = new Upyun({});
  function upLoad(file){
    layer.msg('图片上传中，请稍后')
   upyun.upload({
     localPath: file,
     localName:file.name,
     success: function (res) {
      layer.closeAll();
      var picJson=JSON.parse(res);
      console.log(picJson);
      var imgurl=GetImageUrl(picJson.url);
      console.log(imgurl)
      imgPath.push(imgurl);
      $("#imgBox").append('<a href="javascript:void(0)" class="img-list" title="营业执照"><img src="'+imgurl+'" class="img" alt="营业执照"><img src="../style/image/delete-btn.png" class="img-delete"></a>');
      if(imgPath.length>2){
        $("#addIcon").hide();
      }
    },
    fail: function (errMsg) {
      layer.msg('图片上传失败')
    },
    complete: function () {
     console.log('complete')
   }
  })
  }
  // 删除图片
  var filesArray=[];
  $("#imgBox").on('click', '.img-delete', function(event) {
    var self=this;
    var deleteImg=$("#imgBox .img-delete");
    $.each(deleteImg, function(index, val) {
      if(val==self){
       $(self).closest('.img-list').remove();
       imgPath.del(index);
       console.log(imgPath);
       if(imgPath.length<3){
         $("#addIcon").show();
       }
       return false;
     }
   });
  });
