
  $(document).ready(function () {
    var textBookObj= document.getElementById("textBook");
      var height=textBookObj.offsetHeight;    //这样可以得到用js创建或者直接写出来的元素高度
      var clientHeight=$("html").height()-53-70;
      if(height>=clientHeight){
        $("#textBook").css({
          left: '0',
          right: '0',
          bottom:"88px",
          top:"53px",
          transform:"translate(0,0)",
          "-weblit-transform":"translate(0,0)"
        });
      }
      height=textBookObj.offsetHeight;
      // console.log(textBookObj.style.width);    //这样只能得到js设置的元素宽度
      $('#slimtest2').slimScroll({ size: '5px', height: height,color:'#999'});
  });
