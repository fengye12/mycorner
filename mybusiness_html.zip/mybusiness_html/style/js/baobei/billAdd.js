var a1="a13";var a2="a1303";
var c_id="",d_id="",user_id="",btarget="",jydate="",btype="",pjid="",pindex="1",psize="20";
var states=[];/**调交易对象搜索接口获取的交易对象**/
var lis="";/**选择类型的值**/
var photos=[];
/**页面加载**/
$(function() {
    getActiveN("a13","a1303");
    c_id=$.cookie("c_id");
    user_id=$.cookie("user_id");
 	jySearch(c_id,user_id,pindex,psize);
})

/**交易对象搜索接口**/
 function jySearch(c_id,user_id,pindex,psize) {
 	var keyval="";
 	keyval=$.trim($(".yourElement").val());
 	console.log("keyval:"+keyval);
 	var wxjson = new webjson("57"); //设置action值
 	wxjson.AddParam("c_id", c_id);
 	wxjson.AddParam("userid",user_id);
 	wxjson.AddParam("keyval", keyval);
 	wxjson.AddParam("keytype","0");
 	wxjson.AddParam("sptype","");
 	wxjson.AddParam("page_index", pindex);
 	wxjson.AddParam("page_size", psize);
 	WebRequestAsync(wxjson, jyData);
 }

 function jyData(res) {
 	var htmlJy="";
 	var data = GetOjson(json_parse(res));
 	console.log(data);
 	if(data.status == 0) {
 		for(var i = 0; i < data.param.length; i++) {
 			//jyid = data.param[i].jyid;
 			d_id = data.param[i].scid;//交易对象企业id
 			var cname1 = data.param[i].cname;//交易对象名称
 			console.log(cname1);
 			states.push(cname1);
 			console.log(states);
 		}
 		
 	} else if(data.status == 9) {
 		window.location.href = "index.html?loginOut=true";
 	}
 }

/**交易对象搜索**/
 $(".yourElement").click(function(){
 	$(".yourElement").autocomplete({
 		source: [states]
 	});
 	$(".xdsoft_autocomplete_dropdown").slideDown(5);
 	
})
/**选择类型下拉菜单**/
$(".jy-type").click(function(event){
	$(".selectType").slideDown(5);
})
$(".selI").click(function(event){
	$(".selectType").slideDown(5);
})
$(document).click(function(event){
	var st=$(".jy-type");
	var xad=$(".yourElement");
	if(!st.is(event.target)&& st.has(event.target).length === 0){
	$(".selectType").slideUp(1);
	}
	if(!xad.is(event.target)&& xad.has(event.target).length === 0){
	$(".xdsoft_autocomplete_dropdown").slideUp(1);
	}
})
$(".selectType li").click(function(){
	$(".selectType").slideUp(5);
	lis=$(this).text();
	$(".jy-type").val(lis);
	console.log(lis);
})


/**保存票据**/
function addBill(pjid,c_id,d_id,btype,user_id,btarget,jydate,photos){
	var wxjson = new webjson("18"); //设置action值
	//新增param键值
	wxjson.AddParam("pjid", "");
	wxjson.AddParam("c_id", c_id);
	wxjson.AddParam("d_id", d_id);
	wxjson.AddParam("btype", btype);
	wxjson.AddParam("user_id", user_id);
	wxjson.AddParam("btarget", btarget);
	wxjson.AddParam("jydate", jydate);
	wxjson.AddParam("photos", "");
	WebRequestAsync(wxjson, addBillList);
}
function addBillList(res) {
	var data = GetOjson(json_parse(res));
	console.log(data);
	if(data.status == 0) {	
		layer.msg('保存成功!'); 
// 	    setTimeout(function(){
//        window.location.href="bill-baobei.html";
//     },1000);
	} else if(data.status == 9) {
		//window.location.href = "index.html?loginOut=true";
	}else{
		layer.msg(data.info); 
	}
}

/**点击保存**/
$(".bgg").click(function(){
	//var btype=encodeURI($.trim($(".btype").val()));
	btype=$(".jy-type").val();
	if(btype=="采购报备"){
		btype="0";
	}else if(btype=="销售报备"){
		btype="1";
	}
	btarget=escape($.trim($(".yourElement").val()));
	jydate=$(".date").val();
	console.log("btype:"+btype,"btarget:"+btarget,"jydate:"+jydate,"d_id:"+d_id);
	var type1=$(".jy-type").val();
	if(type1=="请选择报备类型"){
	// if(type1=="请选择报备类型"||btarget==""||jydate==""){
		layer.msg('请选择报备类型');
	}else if(btarget==""){
		layer.msg('请输入交易对象');
	}else if(jydate==""){
		layer.msg('请选择交易日期');
	}else if(photos==""){
		layer.msg('请上传图片');
	}else{		
		addBill(pjid,c_id,d_id,btype,user_id,btarget,jydate,photos);
	}
})

/*新增交易对象addJyObj*/
	$("#addJyObj").on("click",function(){             
		var html='<div class="tipwarp">'+
		'<div class="tipContent">'+
		'<h4 class="h4-title mb20">单位信息</h4>'+
		'<div class="tip-init clearfix">'+
		'<div class="tip-fl">'+
		'<label class="label-text">营业执照</label>'+
		'<input type="text" value="" placeholder="请输入营业执照" class="input-box" />'+
		'</div>'+
		'</div>'+
		'<div class="tip-init clearfix">'+
		'<div class="tip-fl">'+
		'<label class="label-text">单位名称</label>'+
		'<input type="text" value="" placeholder="请输入单位名称" class="input-box" />'+
		'</div>'+
		'</div>'+
		'<div class="tip-init clearfix">'+
		'<div class="tip-fl">'+
		'<label class="label-text">单据号</label>'+
		'<input type="text" value="" placeholder="请输入单据号" class="input-box" />'+
		'</div>'+
		'</div>'+
		'<div class="tip-init img-cont clearfix">'+
		'<div class="tip-fl">'+
		'<label class="label-text">添加资质证件</label>'+
		'<a href="javascript:void(0)" class="img-list" title="检验合格证图片">'+
        '<img src="../style/image/bg2.png" class="img" alt="食品图片" />'+
        '<img src="../style/image/png-delete.png" class="img-delete" />'+
        '</a>'+
        '<a href="javascript:void(0)" class="img-list" title="检验合格证图片">'+
        '<img src="../style/image/bg2.png" class="img" alt="食品图片" />'+
        '<img src="../style/image/png-delete.png" class="img-delete" />'+
        '</a>'+
		'<a href="javascript:void(0);" class="fileInput"><input type="file" value="" class="img-add" /></a>'+
		'<span class="tip">请确保内容清晰、完整(最多3张)</span>'+
		'</div>'+
		'</div>'+
		'</div>'+
		'</div>'
		layer.open({
			type: 1
			,title: '添加交易对象'
			,content: html
			,area: ['640px', 'auto']
			,btn: ['保存','取消']
			,yes: function(){
				console.log('abc');
			}
			,btn2:function(){

			}
			,cancel: function(){ 
				//右上角关闭回调
				//return false 开启该代码可禁止点击该按钮关闭
			}
		});
	})
	$(".next-step").on("click",function(){
		$(".add-foodInfo").show();
	})

