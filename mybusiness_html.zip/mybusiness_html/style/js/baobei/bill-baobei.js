var a1="a15";var a2="a1500";
// 分页相关
    var pindex=1, pcount=1000, psize=$("#pageCentS select").val()?$("#pageCentS select").val():"10";
    var pcent = new CentPage();
    var pTemplate = "";
    var activeNum=pcent.PageNum;
    var obj=$("#page");
    //分页active页码
      function getActive(obj,activeNum){
       $.each(obj.find('li'), function(index, val) {
        var nowNum=$(val).text()
          if(nowNum==activeNum){
            $(this).addClass("active")
          }else{
            $(this).removeClass("active")
          }
        });
        }
       //分页点击页码触发
    function CentPageOper(num){
      pindex=num;
      pTemplate = pcent.GetCentPage(pindex, pcount, psize);
      $("#page").html(pTemplate);
       getActive(obj,num);
    }
    // 分页select change事件
    function pageChange(objselect){
      objselect.change(function(){
        console.log($(this).val())
        psize=$(this).val();
        pTemplate = pcent.GetCentPage(1, 1000, psize);
        $("#page").html(pTemplate);
        getActive(obj,1)
      });
    }
$(function(){
	getActiveN("a15","a1500");
	 //初始化分页select3
        $("#pageCentS").select3({
        'animate':'slide',
          'value':"10",
          callback:function(obj){
            console.log(obj)
             // var obj=$("#ssselS select");
            pageChange(obj);
          }
      });
        // 初始化分页select3之后才能初始化分页模板
        pTemplate=pcent.GetCentPage(pindex, pcount, psize);
         $("#page").html(pTemplate);
        getActive(obj,activeNum);
})
/**var a1="a13";var a2="a1303";
var c_id="",sskey="",bbtime="",jytime="",pjid="";
var photo = [];
var pindex = 1; //当前页
var psize = 20; //每页数据数量
var pcount = 0; //数据总数
var pcent = new CentPage();
autoH();**/
/**分页函数**/
/**function CentPageOper(spindex) {
	search(c_id,sskey,bbtime,jytime,spindex, psize);
}**/

/**搜索**/
/**function search(c_id,sskey,bbtime,jytime,spindex, psize){
	pindex = spindex;
	$("table tbody").children().remove();
	$("#mySelect").css("display","none");
	$("table tbody").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;'><img src='../style/image/load.gif' alt='' /></td></tr>");
	var wxjson = new webjson("8"); //设置action值
	//新增param键值
	wxjson.AddParam("c_id", c_id);
	wxjson.AddParam("sskey", sskey);
	wxjson.AddParam("bbtime",bbtime);
	wxjson.AddParam("jytime",jytime);
	wxjson.AddParam("page_index", pindex);
	wxjson.AddParam("page_size", psize);
	WebRequestAsync(wxjson,searchInfo);
}
function searchInfo(res){
	var html = "";
	var data = GetOjson(json_parse(res));
	console.log(data);
	pcount = data.paramcentcount;
	$(".total-num").html("共"+pcount+"条票据");
	var ps = pcent.GetCentPage(pindex, pcount, psize);
	$("#page").html(ps);
	if(data.status == 0) {
		if(pcount=="0"){
		 $("#mySelect").css("display","none");	
		}else{
		 $("#mySelect").css("display","block");	
		}
		for(var i = 0; i < data.param.length; i++){
			var bid=data.param[i].bid;
			var btype="",bstatus="";
			if(data.param[i].btype=="0"){
				btype="采购报备";
			}else if(data.param[i].btype=="1"){
				btype="销售报备";
			}
			if(data.param[i].bstatus=="0"){
				bstatus="待录入";
			}else if(data.param[i].bstatus=="1"){
				bstatus="完成";
			}else if(data.param[i].bstatus=="2"){
				bstatus="退回";
			}
			html += "<tr>";
			html += "<td class='hs'>" +data.param[i].bbtime +
			"</td><td class='hs'>" +btype +
			"</td><td class='hs'>" +data.param[i].btarget +
			"</td><td class='hs'>"+data.param[i].jytime+"</td>";
			if(bstatus=="退回"){
			   html +="<td class='rs'>"+bstatus+"</td>";
			}else{
			   html +="<td class='hs'>"+bstatus+"</td>";	
			}
            html +='<td><a href="#" class="ls" onclick="ck(this)">' + "<span style='display:none;'>" +
			   data.param[i].bid +'</span>查看</a></td>';
		    html += "</tr>";
	}
	$("table tbody").html(html);
	autoH();
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else {
		$("table tbody").html("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;font-size:14px;'>没有相关数据</td></tr>");
		$("#mySelect").css("display","none");
	}
}**/

/**点击查询调用此方法**/
/**$(".searchName").click(function(){
  pindex=1;
  sskey = $.trim($(".foodName").val());
  if(sskey == "食品名称/条码") {
	sskey = "";
 }
  bbtime="";
  jytime="";
  search(c_id,sskey,bbtime,jytime,pindex, psize);
})

//高级搜索点击事件
$("#confirBtn").click(function(){
	pindex="1";
	//报备日期验证bbDate
	var startDaobei = $("#bbDate").children("input.dateStart").val();
	var endDaobei = $("#bbDate").children("input.dateEnd").val();
	//交易日期验证jyDate
	var startJy = $("#jyDate").children("input.dateStart").val();
	var endJy = $("#jyDate").children("input.dateEnd").val();
    if(date1()) {
		if(startDaobei == "" && endDaobei == "") {
			bbtime = "";
			console.log(bbtime);
		} else {
			bbtime = startDaobei + "," + endDaobei;
			console.log(bbtime);
		}
		if(startJy == "" && endJy == "") {
			jytime = "";
			console.log(jytime);
		} else {
			jytime = startJy + "," + endJy;
			console.log(jytime);
		}
		console.log(checkBoxFormat($("#bblx")));
		sskey = $.trim($(".foodName").val());
		if(sskey == "食品名称/条码") {
			sskey = "";
		}
		console.log(sskey);
		search(c_id,sskey,bbtime,jytime,pindex, psize);
	};
})**/
/**页面加载**/
/**$(function() {
    getActiveN("a13","a1303");
    c_id=$.cookie("c_id");
    console.log(c_id);
    search(c_id,sskey,bbtime,jytime,pindex, psize);
    $.divselect("#mySelect","#inputmySelect");
	$("#mySelect li").on("click",function(){
		//切换每页显示的记录数
		if($("#inputmySelect").val() != psize){
			psize = $("#inputmySelect").val();
			pindex=1;
			search(c_id,sskey,bbtime,jytime,pindex, psize);
		}
	})**/
	/**回车键进行搜索**/
	/**$(".foodName").keydown(function(event){ 
      if(event.keyCode==13){ 
	  $(".searchName").click(); 
   } 
  })
})**/

/**点击查看弹框**/
/**function ck(tt){
	pjid=$(tt).children("span").text();
	console.log(pjid);
	layer.open({
			type: 1,
			title: '查看票据报备',
			shadeClose: true,
			shade: 0.5,
			area: ['640px', '410px'],
			content: '\<div class="warpperBoxD"><\/div><script> readBill();</script>'
			//btn: ['取消']
		});
}

/**读取票据**/
/**function readBill(){
	var wxjson = new webjson("21"); //设置action值
	//新增param键值
	wxjson.AddParam("pjid",pjid);
	WebRequestAsync(wxjson, billList);
}
function billList(res) {
	var btype="",btarget="",jydate="",bstatus="";
	var htmlList = "";
	var htmlImg="";
	var data = GetOjson(json_parse(res));
	console.log(data);
	console.log($(".imgDivD"));
	htmlList +="<div class='imgDivD'><div><span>票据类型</span><input type='text' class='btype' value='' readonly='readonly'/></div>"+
               "<div><span>交易对象</span><input type='text' class='btarget' value='' readonly='readonly'/></div>"+
               "<div><span>交易日期</span><input type='text' class='jydate' value='' readonly='readonly'/></div>"+
               "<div><span>状态</span><input type='text' class='bstatus' value='' readonly='readonly'/></div>"+
               "<div class='ckbill' style='height:80px;'><span>查看票据</span><a class='imagesD' style='cursor:default;'></a></div></div>";
	$(".warpperBoxD").html(htmlList);
	if(data.status == 0) {	
		for(var i = 0; i < data.param.length; i++) {
			photo = (data.param[i].photos).split(",");
			console.log(photo);
			if(data.param[i].btype=="0"){
			  btype = "采购报备";
			}else if(data.param[i].btype=="1"){
			  btype = "销售报备";
			}
			if(data.param[i].bstatus=="0"){
				bstatus="待录入";
			}else if(data.param[i].bstatus=="1"){
				bstatus="完成";
			}else if(data.param[i].bstatus=="2"){
				bstatus="退回";
			}
			btarget = data.param[i].btarget;
			jydate = data.param[i].jydate;
			if(bstatus=="退回"){
				$(".bstatus").addClass("rs");
			}else{
				$(".bstatus").removeClass("rs");
			}
			$(".btype").val(btype);
			$(".btarget").val(btarget);
			$(".jydate").val(jydate);
			$(".bstatus").val(bstatus);
			console.log(photo.length);
			if(photo.length>0){
			 for(var j = 0; j < photo.length; j++) {
				htmlImg += "<img src='" + photo[j] + "' style='cursor:pointer;width:80px;' onclick='ckImg(this)'>";
				console.log(htmlImg);
				$(".imagesD").html(htmlImg);
			}
			}else{
				$(".imagesD").html("<span style='font-size:14px;'>暂无</span>");
			}
		}
	} else if(data.status == 9) {
		window.location.href = "index.html?loginOut=true";
	}else{
		    $(".btype").val("");
			$(".btarget").val("");
			$(".jydate").val("");
			$(".bstatus").val("");
			$(".imagesD").html("<span style='font-size:12px;'>暂无</span>");
	}
}**/

/**点击查看图片**/
function ckImg(c){
	layer.open({
		type: 1,
		title: '查看票据',
		shadeClose: true,
		shade: 0.5,
		area: ['700px', '650px'],
		content: '\<div class="warpperBox"><\/div><script> photoB();</script>'
		//btn: ['取消']
	});
}

/**查看图片**/
function photoB(){
	var html="";
	  html += "<div class='imgDiv' style='width: 660px;height: 580px; margin:10px;border:none;'>" +
		"<ul class='images' style='list-style: none;display:none;'>";
	  /**for(var j = 0; j < photo.length; j++) {
			html += "<li><img src='" + photo[j] + "'></li>";
		}**/
		    html +="<li><img src='../style/image/addicon.png'></li>"+
		           "<li><img src='../style/image/addicon.png'></li>"+
		           "<li><img src='../style/image/addicon.png'></li>";
	        html +="</ul></div>";
	        $(".warpperBox").html(html);
			console.log("查看图片："+$(".images"))
			$(".images").viewer({
				inline: true
			});
		if(navigator.userAgent.indexOf("MSIE") > 0) {
			ie8test();
		}
}

/**点击新增按钮**/
$("#addNew").click(function(){
	$(".ewm").toggle();
})
$(".ewm>img").click(function(){
	$(".ewm").hide();
})
