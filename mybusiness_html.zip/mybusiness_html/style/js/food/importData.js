/*
* @Author: yangjy
* @Date:   2017-07-12 11:45:51
* @Last Modified time: 2017-08-19 19:24:51
*/
autoH();//左右高度自适应autoH();//左右高度自适应
var a1="a14",a2="a1401";//当前页代码
var sskey="";//用户输入的搜索关键字
// 分页相关
var pindex=1, pcount=800, psize=$("#pageCentS select").val()?$("#pageCentS select").val():"10";
var pcent = new CentPage();
var pTemplate = "";
var activeNum=pcent.pindex;
var obj=$("#page");
//分页active页码
function getActive(obj,activeNum){
	$.each(obj.find('li'), function(index, val) {
		var nowNum=$(val).text()
		if(nowNum==activeNum){
			$(this).addClass("active")
		}else{
			$(this).removeClass("active")
		}
	});
}
//分页点击页码触发
function CentPageOper(num){
    pindex=num;
    pTemplate = pcent.GetCentPage(pindex, pcount, psize);
    $("#page").html(pTemplate);
    getActive(obj,num);
    //foodManageList(sskey,pindex,psize)
}
// 分页select change事件
function pageChange(objselect){
    objselect.change(function(){
    	console.log($(this).val())
    	psize=$(this).val();
    	pTemplate = pcent.GetCentPage(1, pcount, psize);
    	$("#page").html(pTemplate);
    	getActive(obj,1)
    	//foodManageList(sskey,pindex,psize)
    });
}

$(function(){
	//foodManageList(sskey,pindex,psize);//调用食品列表
	//初始化分页select3
    $("#pageCentS").select3({
		'animate':'slide',
		'value':"10",
		callback:function(obj){
			console.log(obj)
         // var obj=$("#ssselS select");
			pageChange(obj)
    	}
	});
	// 初始化分页select3之后才能初始化分页模板
    pTemplate=pcent.GetCentPage(pindex, pcount, psize);
    $("#page").html(pTemplate);
    getActive(obj,1);

    //上传文件
    $("#fileup").change(function(){
    	var arr=$(this).val().split('\\');
    	var fileName=arr[arr.length-1];
    	var kzName=fileName.substring(fileName.lastIndexOf('.'));//文件扩展名
    	if(kzName !== ".xls" && kzName !== ".xlsx"){
    		$(this).parent().prev(".file-name").text("");
    		$(".tip").addClass("fileErr").text("请选择.xls或.xlsx类型的文件。");
    	}else{
    		$(this).parent().prev(".file-name").text(fileName);
    		$(".tip").removeClass("fileErr").text("选择excel文件前，请确保导入的数据项与标准模板的数据项要求一致");
    	}
    	
    })
    $("#importFile").click(function(){
    	if($(".file-name").text().length == 0){
    		$(".tip").addClass("fileErr").text("请选择文件再导入。");
    	}
    })

	getActiveN("a14", "a1401");//当前页标志	
})
	

