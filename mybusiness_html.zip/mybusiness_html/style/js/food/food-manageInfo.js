/*
* @Author: yangjy
* @Date:   2017-07-12 11:45:51
* @Last Modified time: 2017-08-19 19:24:51
*/
autoH();//左右高度自适应autoH();//左右高度自适应
var a1 = "a12",a2 = "a1200";//当前页代码
var imgBoxInfo=[];//食品图片
// 分页相关
var pindex=1, pcount=0, psize=$("#pageCentS select").val()?$("#pageCentS select").val():"10";
var pcent = new CentPage();
var pTemplate = "";
var activeNum=pcent.pindex;
var obj=$("#page");
//分页active页码
function getActive(obj,activeNum){
	$.each(obj.find('li'), function(index, val) {
		var nowNum=$(val).text()
		if(nowNum==activeNum){
			$(this).addClass("active")
		}else{
			$(this).removeClass("active")
		}
	});
}
//分页点击页码触发
function CentPageOper(num){
    pindex=num;
    pTemplate = pcent.GetCentPage(pindex, pcount, psize);
    $("#page").html(pTemplate);
    getActive(obj,num);
    //foodManageList(sskey,pindex,psize)
}
// 分页select change事件
function pageChange(objselect){
    objselect.change(function(){
    	console.log($(this).val())
    	psize=$(this).val();
    	pTemplate = pcent.GetCentPage(1, pcount, psize);
    	$("#page").html(pTemplate);
    	getActive(obj,1)
    	//foodManageList(sskey,pindex,psize)
    });
}

function getQueryString(name) {//获取url传递的参数：name为需要获取的参数名称
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var search = window.location.search.substr(1);
	var href = window.location.href;
	if(href.indexOf("?") >= 0) {
		search = href.substr(href.indexOf("?") + 1);
	}
	var r = search.match(reg);
	if(r != null) return unescape(r[2]);
	return null;
}
// if(!GetAddNew(getQueryString("pid"))){
// 	pid=getQueryString("pid");
// }
console.log("pc:"+getQueryString("pc"))
if(getQueryString("pc") == "1"){
	$(".btn-tab li").eq(1).addClass("current").siblings().removeClass("current");
	$(".food-pcInfo").show();
	$(".food-baseInfo").hide();
}
$(".btn-tab li").on("click",function(){

	$(this).addClass("current").siblings().removeClass("current");
	if($(this).index() == 0){
		$(".food-baseInfo").show();
		$(".food-pcInfo").hide();
	}else{

		$(".food-pcInfo").show();
		$(".food-baseInfo").hide();

	}
})

//上传图片
var imgPath=[];//上传图片
var upyun = new Upyun({});
function upLoad(file,type){//type:0食品图片,type=1批次检验合格证
	console.log("type:"+type);
	upyun.upload({
		localPath: file,
		localName:file.name,
		success: function (res) {
			var picJson=JSON.parse(res);
			console.log(picJson);
			console.log("success");
			var imgurl=GetImageUrl(picJson.url);
			var imgHtml="";
			if(type == "0"){
				imgBoxInfo.push(imgurl);
				imgHtml='<a href="javascript:void(0)" class="img-list imgDiv" title="图片">'+
				'<img src="'+imgurl+'" class="img" alt="图片" />'+
				'<img src="../style/image/delete-btn.png" class="img-delete" />'+
				'</a>'
				$(".imglistBox").append(imgHtml);
			}
			if(type == "1"){
				imgPath.push(imgurl);
				imgHtml='<a href="javascript:void(0)" class="img-list imgDiv" title="图片">'+
				'<img src="'+imgurl+'" class="img" alt="图片" />'+
				'<img src="../style/image/delete-btn.png" class="img-delete" />'+
				'</a>'
				$(".imgPcbox").append(imgHtml);
			}
			
		},
		fail: function (errMsg) {
			layer.msg('图片上传失败');
		},
		complete: function () {
			console.log('complete');
			console.log(imgBoxInfo);
			if(type=="0"){
				if(imgBoxInfo.length > 2){
					$(".foodFileInfo").css("display","none");
				}else{
					$(".foodFileInfo").css("display","");
				}
			}
			if(type=="1"){
				if(imgPath.length > 2){
					$(".pcFileInput").css("display","none");
				}else{
					$(".pcFileInput").css("display","");
				}
			}
			
		}
	})
}
//下拉框事件
function change1(obj){
	obj.change(function(){
		console.log($(this).val())
		if($(this).val() == "1"){
			$(".isBarcode").hide();
		}else{
			$(".isBarcode").show();
		}
	});
}
function change2(obj){
	obj.change(function(){
		console.log($(this).val())
		if($(this).val() == "1"){
			$(".isImport").show();
		}else{
			$(".isImport").hide();
		}
	});
}
function change3(obj){
	obj.change(function(){
		console.log($(this).val())
	});
}
$(function(){
	getActiveN("a12", "a1200");//当前页标志
	//初始化分页select3
    $("#pageCentS").select3({
		'animate':'slide',
		'value':"10",
		callback:function(obj){
			console.log(obj)
         // var obj=$("#ssselS select");
			pageChange(obj)
    	}
	});
	// 初始化分页select3之后才能初始化分页模板
    pTemplate=pcent.GetCentPage(pindex, pcount, psize);
    $("#page").html(pTemplate);
    getActive(obj,activeNum);

	$(".food-num").on("keyup",function(event){//验证粘贴的商品条码格式
		var event=event||window.event;
		foodNumYz($(this),event.keyCode);//参数为this对象,当前按键的keyCode值
	})
	$(".food-num").on("afterpaste",function(event){//验证粘贴的商品条码格式
		var event=event||window.event;
		foodNumYz($(this),event.keyCode);//参数为this对象,当前按键的keyCode值
	})
//	$(".food-num").on("focus",function(){
//		$(this).parents(".input-init").removeClass("errMsg").children(".errTip").remove();
//	})
//	$(".f-pname").on("focus",function(){
//		$(this).parents(".input-init").removeClass("errMsg").children(".errTip").remove();
//	})
	
	$(".tel").on("keyup",function(event){//验证粘贴的经销商联系方式
		var event=event||window.event;
		telYz($(this),event.keyCode);//参数为this对象,当前按键的keyCode值
	})
	$(".tel").on("afterpaste",function(event){//验证粘贴的经销商联系方式
		var event=event||window.event;
		telYz($(this),event.keyCode);//参数为this对象,当前按键的keyCode值
	})
	
	$("#ssselS").select3({
		'animate':'slide',
		'value':"5",
		callback:function(obj){
			console.log(obj)
                     // var obj=$("#ssselS select");
                     //触发change事件
            change1(obj);
        }
    });
	$("#ssselS2").select3({
		'animate':'slide',
		'value':"5",
		callback:function(obj){
			console.log(obj)
                     // var obj=$("#ssselS select");
                     //触发change事件
            change2(obj);
        }
    });
	$("#ssselS3").select3({
		'animate':'slide',
		'value':"5",
		callback:function(obj){
			console.log(obj)
                     // var obj=$("#ssselS select");
                     //触发change事件
            change3(obj);
        }
    });
	/*保存食品信息*/
	$("#foodBasicInfo").on("click",function(){
		var _this=$(this),flag=1;
		$(".errTip").remove();
		$(".input-init").removeClass("errMsg");
		$(".errContent").hide();
		if(Trim($(".f-barcode").val()).length == 0){
				//layer.msg('商品条码不能为空');
			if($(".f-barcode").parents("li").css("display") !== "none"){
				_this.attr("disabled",false);
				$(".f-barcode").parents(".input-init").addClass("errMsg");
				$(".errContent").show();
				$(".errContent").append('<p class="errTip"><img src="../style/image/error.png" alt="商品条码不能为空">商品条码不能为空</p>');
				flag=0;
			}
				
				//return false;
		}else if(Trim($(".f-barcode").val()).length != 8 && Trim($(".f-barcode").val()).length != 13){
			//layer.msg('商品条码格式不正确');
			_this.attr("disabled",false);
			$(".f-barcode").parents(".input-init").addClass("errMsg");
			$(".errContent").show();
			$(".errContent").append('<p class="errTip"><img src="../style/image/error.png" alt="商品条码格式不正确">商品条码格式不正确</p>');
			flag=0;
				//return false;
		}
		if(Trim($(".f-pname").val()).length == 0){
				//layer.msg('商品名称不能为空');
			_this.attr("disabled",false);
			$(".f-pname").parents(".input-init").addClass("errMsg");
			$(".errContent").show();
			$(".errContent").append('<p class="errTip"><img src="../style/image/error.png" alt="商品名称不能为空">商品名称不能为空</p>');
			flag=0;
				//return false;
					//alert("第"+n+'行商品名称不能为空');
		}
		console.log("flag:"+flag);
		if(flag == 0){
			return false;
		}

	})
	// 删除图片
	$(".imglistBox").on('click', '.img-delete', function(event) {
		var self=this;
		var deleteImg=$(".imglistBox .img-delete");
		$.each(deleteImg, function(index, val) {
			if(val==self){
				$(self).closest('.imgDiv').remove();
				imgPath.del(index);
				// filesArray.del(index);
				// console.log(filesArray);
				if(imgPath.length > 2){
					$(".foodFileInfo").css("display","none");
				}else{
					$(".foodFileInfo").css("display","");
				}
				return false;
			}
		});
	});
	//城市选择器----生产地址
    $('.proArea').areaSelection({
      animateFunction: "toggle",
      //动画效果
      callback: "",
      //回调函数
      province_code: "",
      //默认城市的code
      city_code: "",
      //默认城市的code
      area_code: "",
      //默认城市的code
      street_code: "",
      //默认城市的code
      callback: function() {
        console.log("callback")
      }
    });
    //城市选择器----经销商经营地址
    $('.importArea').areaSelection({
      animateFunction: "toggle",
      //动画效果
      callback: "",
      //回调函数
      province_code: "",
      //默认城市的code
      city_code: "",
      //默认城市的code
      area_code: "",
      //默认城市的code
      street_code: "",
      //默认城市的code
      callback: function() {
        console.log("callback")
      }
    });
	
	/*添加批次*/
	$("#addPc").on("click",function(){             
		var html='<div class="tipwarp add-pcTip">'+
		'<div class="tipContent">'+
		'<h3 class="h3-title">生产日期</h3>'+
		'<div class="errContent">'+
        //'<h4>请检查以下问题</h4>'+
        '</div>'+
		'<div class="input-init">'+
        '<label for="">生产日期<span class="color-red"> *</span></label>'+
        '<div class="inputstyle">'+
        '<input type="text" placeholder="选择时间" class="date pc-batch" maxlength="13" readonly />'+
        '</div>'+
        '</div>'+
        '<h3 class="h3-title">检验合格证</h3>'+
        '<div class="imgContent">'+
        '<p class="tipT">检验合格证（请确保内容清晰、完整,最多3张、5M以内）</p>'+
        '<div class="imglistBox imgPcbox">'+
        // '<a href="javascript:void(0)" class="img-list imgDiv" title="营业执照">'+
        // '<img src="http://meyoungpc.b0.upaiyun.com/shianyun_qy/2017/10/17/201710171507041568018376phone.png" class="img" alt="营业执照">'+
        // '<img src="../style/image/delete-btn.png" class="img-delete">'+
        // '</a>'+
        '</div>'+
        '<a href="javascript:void(0);" class="fileInput pcFileInput">'+
        '<input name="file" class="img-add" type="file" onchange="upLoad(this.files[0],1)">'+
        '</a>'+
        '</div>'+

		'</div>'+
		'</div>'
		layer.open({
			type: 1
			,title: '添加批次'
			,content: html
			,area: ['500px', '380px']
			,btnAlign: 'c'
			,btn: ['取消','保存']
			,yes: function(index, layero){
				
				
			}
			,btn2:function(index, layero){
				$(".errTip").remove();
				$(".input-init").removeClass("errMsg");
				$(".errContent").hide();
				if(Trim($(".pc-batch").val()).length == 0){
					//layer.msg('请选择生产日期');
					$(".pc-batch").parents(".input-init").addClass("errMsg");
					$(".add-pcTip .errContent").show();
					$(".add-pcTip .errContent").append('<p class="errTip"><img src="../style/image/error.png" alt="请选择生产日期">请选择生产日期</p>');
					return false;
				}
				return false;
			}
			,cancel: function(){ 
				//右上角关闭回调
				//return false 开启该代码可禁止点击该按钮关闭
			}
		});
		dateLoad();
		// 删除图片
		$(".imgPcbox").on('click', '.img-delete', function(event) {
			var self=this;
			var deleteImg=$(".imgPcbox .img-delete");
			$.each(deleteImg, function(index, val) {
				if(val==self){
					$(self).closest('.imgDiv').remove();
					imgPath.del(index);
					// filesArray.del(index);
					// console.log(filesArray);
					if(imgPath.length > 2){
						$(".pcFileInput").css("display","none");
					}else{
						$(".pcFileInput").css("display","");
					}
				return false;
				}
			});
		});
	})

})



