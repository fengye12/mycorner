/*
* @Author: yangjy
* @Date:   2017-07-12 11:45:51
* @Last Modified time: 2017-08-19 19:24:51
*/
autoH();//左右高度自适应autoH();//左右高度自适应
var a1 = "a12",a2 = "a1200";//当前页代码
var sskey="";//用户输入的搜索关键字
// 分页相关
var pindex=1, pcount=800, psize=$("#pageCentS select").val()?$("#pageCentS select").val():"10";
var pcent = new CentPage();
var pTemplate = "";
var activeNum=pcent.pindex;
var obj=$("#page");
//分页active页码
function getActive(obj,activeNum){
	$.each(obj.find('li'), function(index, val) {
		var nowNum=$(val).text()
		if(nowNum==activeNum){
			$(this).addClass("active")
		}else{
			$(this).removeClass("active")
		}
	});
}
//分页点击页码触发
function CentPageOper(num){
    pindex=num;
    pTemplate = pcent.GetCentPage(pindex, pcount, psize);
    $("#page").html(pTemplate);
    getActive(obj,num);
    //foodManageList(sskey,pindex,psize)
}
// 分页select change事件
function pageChange(objselect){
    objselect.change(function(){
    	console.log($(this).val())
    	psize=$(this).val();
    	pTemplate = pcent.GetCentPage(1, pcount, psize);
    	$("#page").html(pTemplate);
    	getActive(obj,1)
    	//foodManageList(sskey,pindex,psize)
    });
}

$(function(){
	//foodManageList(sskey,pindex,psize);//调用食品列表
	//初始化分页select3
    $("#pageCentS").select3({
		'animate':'slide',
		'value':"10",
		callback:function(obj){
			console.log(obj)
         // var obj=$("#ssselS select");
			pageChange(obj)
    	}
	});
	// 初始化分页select3之后才能初始化分页模板
    pTemplate=pcent.GetCentPage(pindex, pcount, psize);
    $("#page").html(pTemplate);
    getActive(obj,1);

	//$(".total-num").text("共"+pcount+"条");
	

	//搜索
	// $("#searchBtn").on("click",function(){
	// 	sskey=$(".foodName").val();//用户输入的搜索关键字
	//	if(sskey == "食品名称/条码"){
	//		sskey="";
	//	}
	// 	pindex=1;
	// 	foodManageList(sskey,pindex,psize);
	// })
	$(".foodName").on("keydown",function(event){//按下回车执行查询
	    var event=event || window.event;
	    if(event.keyCode == "13") {//判断如果按下的是回车键则执行下面的代码
	    	sskey=$(".foodName").val();//用户输入的搜索关键字
			pindex=1;
			if(sskey == "食品名称/条码"){
				sskey="";
			}
			//foodManageList(sskey,pindex,psize);
	    }
	})
	getActiveN("a12", "a1200");//当前页标志	
})
	

