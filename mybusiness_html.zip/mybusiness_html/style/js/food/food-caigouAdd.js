/*
* @Author: yangjy
* @Date:   2017-07-12 11:45:51
* @Last Modified time: 2017-09-03 19:24:51
*/
autoH();//左右高度自适应autoH();//左右高度自适应
var a1 = "a14",a2 = "a1401";//当前页代码

//上传图片
var imgPath=[];//上传图片
var upyun = new Upyun({});
function upLoad(file){
	console.log("type:"+type);
	upyun.upload({
		localPath: file,
		localName:file.name,
		success: function (res) {
			var picJson=JSON.parse(res);
			console.log(picJson);
			console.log("success");
			var imgurl=GetImageUrl(picJson.url);
			var imgHtml="";
			imgPath.push(imgurl);
			imgHtml='<a href="javascript:void(0)" class="img-list imgDiv" title="图片">'+
				'<img src="'+imgurl+'" class="img" alt="图片" />'+
				'<img src="../style/image/delete-btn.png" class="img-delete" />'+
				'</a>'
			$(".imglistBox").append(imgHtml);
			
			
		},
		fail: function (errMsg) {
			layer.msg('图片上传失败');
		},
		complete: function () {
			console.log('complete');
			console.log(imgPath);
			
			if(imgPath.length > 2){
				$(".fileInput").css("display","none");
			}else{
				$(".fileInput").css("display","");
			}
		}
	})
}

$(function(){
	getActiveN("a14", "a1401");//当前页标志

	// 删除图片
	$(".imglistBox").on('click', '.img-delete', function(event) {
		var self=this;
		var deleteImg=$(".imglistBox .img-delete");
		$.each(deleteImg, function(index, val) {
			if(val==self){
				$(self).closest('.imgDiv').remove();
				imgPath.del(index);
				// filesArray.del(index);
				// console.log(filesArray);
				if(imgPath.length > 2){
					$(".fileInput").css("display","none");
				}else{
					$(".fileInput").css("display","");
				}
			return false;
			}
		});
	});

})



