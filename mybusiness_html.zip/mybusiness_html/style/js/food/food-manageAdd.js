/*
* @Author: yangjy
* @Date:   2017-07-12 11:45:51
* @Last Modified time: 2017-08-19 19:24:51
*/
autoH();//左右高度自适应autoH();//左右高度自适应
var a1 = "a11",a2 = "a1100";//当前页代码
var imgBoxInfo=[];//食品图片
function foodManageInfoData(res){//获取食品信息数据
	var data = GetOjson(json_parse(res));
	if(data.status =="0"){
		$.each(data.param,function(i,item){
			var saveCond,symbol,photos="";
			if(item.saveCond == "0"){
				saveCond="常温存储";
			}else if(item.saveCond == "1"){
				saveCond="冷藏存储(1~10℃)";
			}else if(item.saveCond == "2"){
				saveCond="冷冻存储(-29~0℃)"
			}else{
				saveCond="";
			}
			if(item.symbol == "0"){
				symbol="预包装";
			}else{
				symbol="散装";
			}
			$("#country span").text(item.ycountry);
			$("#inputcountry").val(item.ycountry);//原产国
			$(".f-stnum").val(item.stnum);//商品或品牌
			$("#package span").text(symbol);
			$("#inputpackage").val(item.symbol);//包装方式
			$("#storage span").text(saveCond);
			$("#inputstorage").val(item.saveCond);//包装方式
			$(".f-pname").val(item.pname);//食品名称
			$(".f-shelflife").val(item.shelflife);//食品保质期
			$(".f-barcode").val(item.barcode);//商品条码
			$(".f-spec").val(item.spec);
			imgBoxInfo=[];
			if(item.photos.length > 0){
				photos=item.photos.split(",");
				var imgList="";
				for(var i=0;i<photos.length;i++){
					imgList='<a href="javascript:void(0)" class="img-list imgDiv" title="食品图片">'+
					'<img src="'+photos[i]+'" class="img" alt="食品图片" />'+
					'<img src="../style/image/delete-btn.png" class="img-delete" />'+
					'</a>'
					$(".imglistBox").append(imgList);
					imgBoxInfo.push(photos[i]);
				}
				if(imgBoxInfo.length > 2){
					$(".fileInput").css("display","none");
				}else{
					$(".fileInput").css("display","");
				}
			}

			// var html='<tr>'+
			// '<td class="hs">'+item.pname+'</td>'+
			// '<td class="hs">'+item.barcode+'</td>'+
			// '<td class="hs">'+item.originCountry+'</td>'+
			// '<td class="hs">'+item.stnum+'</td>'+
			// '<td class="hs">'+item.saveCond+'</td>'+
			// '<td class="hs">'+item.batchCount+'</td>'+
			// '<td class="hs"><a href="food-manageInfo.html?pid='+item.pid+'">编辑</a></td>'+
			// '</tr>';
			// $("#foodManageInfo").append(html);
		})

		autoH();
	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else{
		layer.msg(date.info);
	}
}

function foodManageInfo(){//请求食品信息
	var wxjson = new webjson("17"); //设置action值
	//新增param键值
	wxjson.AddParam("pid", pid);
	WebRequestAsync(wxjson, foodManageInfoData);
}

//上传图片
var imgPath=[];//上传图片
var upyun = new Upyun({});
function upLoad(file,type){//type:0食品图片,type=1批次检验合格证
	console.log("type:"+type);
	upyun.upload({
		localPath: file,
		localName:file.name,
		success: function (res) {
			var picJson=JSON.parse(res);
			console.log(picJson);
			console.log("success");
			var imgurl=GetImageUrl(picJson.url);
			var imgHtml="";
			imgBoxInfo.push(imgurl);
			imgHtml='<a href="javascript:void(0)" class="img-list imgDiv" title="图片">'+
				'<img src="'+imgurl+'" class="img" alt="图片" />'+
				'<img src="../style/image/delete-btn.png" class="img-delete" />'+
				'</a>'
			$(".imglistBox").append(imgHtml);


		},
		fail: function (errMsg) {
			layer.msg('图片上传失败');
		},
		complete: function () {
			console.log('complete');
			console.log(imgBoxInfo);

			if(imgBoxInfo.length > 2){
				$(".fileInput").css("display","none");
			}else{
				$(".fileInput").css("display","");
			}
		}
	})
}
//下拉框事件
function change1(obj){
	obj.change(function(){
		console.log($(this).val())
		if($(this).val() == "1"){
			$(".isBarcode").hide();
		}else{
			$(".isBarcode").show();
		}
	});
}
function change2(obj){
	obj.change(function(){
		console.log($(this).val())
		if($(this).val() == "1"){
			$(".isImport").show();
		}else{
			$(".isImport").hide();
		}
	});
}
function change3(obj){
	obj.change(function(){
		console.log($(this).val())
	});
}

$(function(){

	getActiveN("a12", "a1200");//当前页标志
	$(".food-num").on("keyup",function(event){//验证粘贴的商品条码格式
		var event=event||window.event;
		foodNumYz($(this),event.keyCode);//参数为this对象,当前按键的keyCode值
	})
	$(".food-num").on("afterpaste",function(event){//验证粘贴的商品条码格式
		var event=event||window.event;
		foodNumYz($(this),event.keyCode);//参数为this对象,当前按键的keyCode值
	})
	// $(".food-num").on("focus",function(){
	// 	$(this).parents(".input-init").removeClass("errMsg").children(".errTip").remove();
	// })
	// $(".f-pname").on("focus",function(){
	// 	$(this).parents(".input-init").removeClass("errMsg").children(".errTip").remove();
	// })

	$(".tel").on("keyup",function(event){//验证粘贴的经销商联系方式
		var event=event||window.event;
		telYz($(this),event.keyCode);//参数为this对象,当前按键的keyCode值
	})
	$(".tel").on("afterpaste",function(event){//验证粘贴的经销商联系方式
		var event=event||window.event;
		telYz($(this),event.keyCode);//参数为this对象,当前按键的keyCode值
	})

	$("#ssselS").select3({
		'animate':'slide',
		'value':"5",
		callback:function(obj){
			console.log(obj)
                     // var obj=$("#ssselS select");
                     //触发change事件
            change1(obj);
        }
    });
	$("#ssselS2").select3({
		'animate':'slide',
		'value':"5",
		callback:function(obj){
			console.log(obj)
                     // var obj=$("#ssselS select");
                     //触发change事件
            change2(obj);
        }
    });
	$("#ssselS3").select3({
		'animate':'slide',
		'value':"5",
		callback:function(obj){
			console.log(obj)
                     // var obj=$("#ssselS select");
                     //触发change事件
            change3(obj);
        }
    });



	/*保存食品信息*/
	$("#foodSave").on("click",function(){
		var _this=$(this),flag=1;
		$(".errTip").remove();
		$(".input-init").removeClass("errMsg");
		$(".errContent").hide();
		if(Trim($(".f-barcode").val()).length == 0){
				//layer.msg('商品条码不能为空');
			if($(".f-barcode").parents("li").css("display") !== "none"){
				_this.attr("disabled",false);
				$(".f-barcode").parents(".input-init").addClass("errMsg");
				$(".errContent").show();
				$(".errContent").append('<p class="errTip">商品条码不能为空</p>');
				flag=0;
			}

				//return false;
		}else if(Trim($(".f-barcode").val()).length != 8 && Trim($(".f-barcode").val()).length != 13){
			//layer.msg('商品条码格式不正确');
			_this.attr("disabled",false);
			$(".f-barcode").parents(".input-init").addClass("errMsg");
			$(".errContent").show();
			$(".errContent").append('<p class="errTip">商品条码格式不正确</p>');
			flag=0;
				//return false;
		}
		if(Trim($(".f-pname").val()).length == 0){
				//layer.msg('商品名称不能为空');
			_this.attr("disabled",false);
			$(".f-pname").parents(".input-init").addClass("errMsg");
			$(".errContent").show();
			$(".errContent").append('<p class="errTip">商品名称不能为空</p>');
			flag=0;
				//return false;
					//alert("第"+n+'行商品名称不能为空');
		}
		console.log("flag:"+flag);
		if(flag == 0){
			return false;
		}

	})


	// 删除图片
	$(".imglistBox").on('click', '.img-delete', function(event) {
		var self=this;
		var deleteImg=$(".imglistBox .img-delete");
		$.each(deleteImg, function(index, val) {
			if(val==self){
				$(self).closest('.imgDiv').remove();
				imgBoxInfo.del(index);
				// filesArray.del(index);
				// console.log(filesArray);
				if(imgBoxInfo.length > 2){
					$(".fileInput").css("display","none");
				}else{
					$(".fileInput").css("display","");
				}
				return false;
			}
		});
	});
	//城市选择器----生产地址
    $('.proArea').areaSelection({
      animateFunction: "toggle",
      //动画效果
      callback: "",
      //回调函数
      province_code: "",
      //默认城市的code
      city_code: "",
      //默认城市的code
      area_code: "",
      //默认城市的code
      street_code: "",
      //默认城市的code
      callback: function() {
        console.log("callback")
      }
    });
    //城市选择器----经销商经营地址
    $('.importArea').areaSelection({
      animateFunction: "toggle",
      //动画效果
      callback: "",
      //回调函数
      province_code: "",
      //默认城市的code
      city_code: "",
      //默认城市的code
      area_code: "",
      //默认城市的code
      street_code: "",
      //默认城市的code
      callback: function() {
        console.log("callback")
      }
    });

})
