//左侧导航html
var navHtml="<div class='header-nav'>"+
'<div class="switchCompany">'+
'<div id="triangle-up"></div>'+
'<ul>'+
'<li class="singleC">'+
' <p class="s_name">switchCompany</p>'+
'<span class="switch">切换</span>'+
'</li>'+
'<li class="singleC">'+
'<p class="s_name">switchCompany</p>'+
'<span class="switch">切换</span>'+
'</li>'+
'</ul>'+
'</div>'+
"<a href='javascript:void(0);' class='logo'>"+
"<img src='../style/image/logo.png' />"+
"</a>"+
"<a href='javascript:;' class='com-name relative' onclick='switchCompany()'><span></span>"+
"</a>"+
"<div class='right-num'>"+
"<img src='../style/image/dl.png'><span class='user-name'id='modefiy2'></span>"+
"<ul class='loginMessage'>"+
"<li id='modify'><a href='modifyInfo.html'>修改账号信息</a></li>"+
"<li id='login-out'>退出</li>"+
"</ul>"+
"</div>"+
"</div>"+
"<div class='left-nav'>"+
"<ul>"+
"<li class='list-title'>"+
"<i class='keyId'>a10</i>"+
"<a href='home.html' class='nav-title' id='sanjiao'><span class='sy'></span>首页</a>"+
"<ul class='list-cont'>"+
"<li style='height:0;line-height:1;'>"+
"<i class='keyId'>a1000</i>"+
"<a href='#' style='height:0;line-height:1;'><i></i></a>"+
"</li>"+
"</ul>"+
"</li>"+
"<li class='list-title'>"+
"<i class='keyId'>a11</i>"+
"<a href='companyManage.html' class='nav-title' ><span class='dp'></span>企业/店铺管理</a>"+
"<ul class='list-cont'>"+
"<li style='height:0;line-height:1;'>"+
"<i class='keyId'>a1100</i>"+
"<a href='#' style='height:0;line-height:1;'><i></i></a>"+
"</li>"+
"</ul>"+
"</li>"+
"<li class='list-title'>"+
"<i class='keyId'>a12</i>"+
"<a href='food-manageList.html' class='nav-title' ><span class='sp'></span>食品管理</a>"+
"<ul class='list-cont'>"+
"<li style='height:0;line-height:1;'>"+
"<i class='keyId'>a1200</i>"+
"<a href='#' style='height:0;line-height:1;'><i></i></a>"+
"</li>"+
"</ul>"+
"</li>"+
"<li class='list-title'>"+
"<i class='keyId'>a13</i>"+
"<a href='transaction-object.html' class='nav-title' ><span class='jy'></span>交易对象管理</a>"+
"<ul class='list-cont'>"+
"<li style='height:0;line-height:1;'>"+
"<i class='keyId'>a1300</i>"+
"<a href='#' style='height:0;line-height:1;'><i></i></a>"+
"</li>"+
"</ul>"+
"</li>"+
"<li class='list-title list-title-down'>"+
"<i class='keyId'>a14</i>"+
"<a href='javascript:void(0);' class='nav-title' ><span class='tz'></span>台账报备<i class='up-down'></i></a>"+
"<ul class='list-cont'>"+
"<li>"+
"<i class='keyId'>a1401</i>"+
"<a href='foodCaigou.html'>食品采购台账<i></i></a>"+
"</li>"+
"<li>"+
"<i class='keyId'>a1402</i>"+
"<a href='foodSales.html'>食品销售台账<i></i></a>"+
"</li>"+
"</ul>"+
"</li>"+
"<li class='list-title'>"+
"<i class='keyId'>a15</i>"+
"<a href='bill-baobei.html' class='nav-title' ><span class='pj'></span>票据报备</a>"+
"<ul class='list-cont'>"+
"<li style='height:0;line-height:1;'>"+
"<i class='keyId'>a1500</i>"+
"<a href='#' style='height:0;line-height:1;'><i></i></a>"+
"</li>"+
"</ul>"+
"</li>"+
"<li class='list-title'>"+
"<i class='keyId'>a16</i>"+
"<a href='management-record.html' class='nav-title' ><span class='jyba'></span>经营备案</a>"+
"<ul class='list-cont'>"+
"<li style='height:0;line-height:1;'>"+
"<i class='keyId'>a1600</i>"+
"<a href='#' style='height:0;line-height:1;'><i></i></a>"+
"</li>"+
"</ul>"+
"</li>"+
"<li class='list-title list-title-down'>"+
"<i class='keyId'>a17</i>"+
"<a href='javascript:void(0);' class='nav-title' ><span class='xx'></span>消息通知<i class='up-down'></i></a>"+
"<ul class='list-cont'>"+
"<li>"+
"<i class='keyId'>a1701</i>"+
"<a href='messageList.html'>系统消息<i></i></a>"+
"</li>"+
"<li>"+
"<i class='keyId'>a1702</i>"+
"<a href='administrMessage.html'>食药监通知<i></i></a>"+
"</li>"+
"<li>"+
"<i class='keyId'>a1703</i>"+
"<a href='suozhengList.html'>索证请求<i></i></a>"+
"</li>"+
"</ul>"+
"</li>"+
"</ul>"+
"</li>"+
"</ul>"+
"</div>"
// 写入导航
document.write(navHtml);
/**function comp(){  //读取单位列表
	var wxjson = new webjson("78");
	wxjson.AddParam("cname", '');
	wxjson.AddParam("license", '');
	wxjson.AddParam("raddress", '');
	wxjson.AddParam("c_type", '');
	wxjson.AddParam("page_index", '1');
	wxjson.AddParam("page_size", '1000');
	var res = WebRequest(wxjson);
	var data = GetOjson(json_parse(res));
	console.log(data)
	if(data.status == "9"){
	window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status == "0"){
		var html='';
		$(".switchCompany ul").empty();
		$.each(data.param, function(idx, obj) {
			html+= '<li class="singleC">'+
			' <p class="s_name">'+obj.cname+'</p>'+
			'<span class="switch"  data-id='+obj.info_status+' data-cid='+obj.c_id+' data-ctype='+obj.c_type+' data-license='+obj.license+' data-raddress='+obj.raddress+' data-cname="'+obj.cname+'">切换</span>'+
			'</li>'
		});
		$(".switchCompany ul").append(html);
		var $switch = $(".switchCompany ul .switch")
		$switch.click(function(){
			var n=$(this).data('id');//企业状态
			var cid=$(this).data('cid');//企业id
			var c_type=$(this).data('ctype');//企业id
			var license=$(this).data('license');//企业id
			var raddress=$(this).data('raddress');//企业id
			var cname=$(this).data('cname');//获取当前企业名称
			$.cookie('THE_SET_COMPANYNAME', cname, { path: '/' });
			comId(cid);
			if(n == '0'){
				window.location.href="editCompany.html";
			}else{
				$.cookie('c_id', cid, { expires: 30 });
				$.cookie('THE_SET_COMPANYNAME',cname, { expires: 30 });
				$.cookie('c_type', c_type, { expires: 30 });
				$.cookie('info_status',n, { expires: 30 });
				$.cookie('license', license, { expires: 30 });
				$.cookie('raddress', raddress, { expires: 30 });
				location.reload();
			}
		})
	}else if(data.status==1){
		return;
	}else if(data.status==9){
		window.location.href="login.html?loginOut=true";
	}else{
		layer.msg(data.info)
	}
}
function comId(cid){
	var wxjson = new webjson("8");
	wxjson.AddParam("c_id", cid);
	var res = WebRequest(wxjson);
	var data = GetOjson(json_parse(res));
	if (data.status == "9"){
		window.location.href="login.html";
		return;
	}else if(data.status == "0") {
		console.log(data.info);
	}else{
		console.log(data.info);
	}
}
function switchCompany(){
	$(".switchCompany").slideToggle(100);
	comp();
}**/

//当前导航选中
function getActiveN(paret,activeN){
	var listTitle=$('.left-nav .list-title');
	listTitle.each(function(index, el) {
		var test=$(this).find(".keyId").eq(0).text();
		if($(this).find(".keyId").eq(0).text()==paret){
			$(this).siblings().children(".nav-title").removeClass("down-active");
			$(this).children(".nav-title").addClass("down-active");
			$(this).children().find("i").removeClass("updown1");
			$(this).find(".list-cont a").removeClass("active");
			$(this).siblings().find(".list-cont a").removeClass("active");
			$(this).siblings().find(".list-cont").hide();
			console.log("paret:"+paret);
			if(paret=="a10"){
				$(this).find("span").css({"background-image":"url(../style/image/sy2.png)"});
			}
			if(paret=="a11"){
				$(this).find("span").css({"background-image":"url(../style/image/dp2.png)"});
			}
			if(paret=="a12"){
				$(this).find("span").css({"background-image":"url(../style/image/sp2.png)"});
			}
			if(paret=="a13"){
				$(this).find("span").css({"background-image":"url(../style/image/jy2.png)"});
			}
			if(paret=="a14"){
				$(this).find("span").css({"background-image":"url(../style/image/tz2.png)"});
			}
			if(paret=="a15"){
				$(this).find("span").css({"background-image":"url(../style/image/pj2.png)"});
			}
			if(paret=="a16"){
				$(this).find("span").css({"background-image":"url(../style/image/jyba2.png)"});
			}
			if(paret=="a17"){
				$(this).find("span").css({"background-image":"url(../style/image/xx2.png)"});
			}
			$(this).find(".list-cont .keyId").each(function(index, el) {
				console.log($(this).find(".list-cont .keyId"))
				var testt=$(this).text();
				if($(this).text()==activeN){
					$(this).closest('.list-cont').show();
					$(this).parent('.list-title').addClass("active");
					$(this).parent(".list-title").find("a").addClass("active-ys");
					$(this).parent().parent().parent('.list-title').addClass("active");
					$(this).parent().parent().parent('.list-title').find(".nav-title").addClass("active-ys");

					$(this).parent().parent().parent().children(".nav-title").find("i").addClass("updown1");
					$(this).parent().parent().parent().children(".nav-title").find("i").removeClass("up-down");
					$(this).next("a").css({"color":"#108cee"});
					$(this).parent().siblings("li").find("a").css({"color":"#3e3e3e"});

					$(this).parent().parent().siblings('.nav-title').parent(".list-title").addClass("active-yy");
					$(this).parents("ul").slideDown(100).children('li');
				}
			});
		}
	});
}

function autoH(){//自动左右高度
	$(".left-nav").css('height','100%');
	var deH=$(".left-nav").height()-80+'px';
	$(".left-nav").height(deH);
	// var warpcontent=document.getElementsByClassName("warp-content");
	var rightH=$(".warp-content")[0].offsetHeight;
	var leftH=parseInt($(".left-nav").height());
	if(parseInt($(".left-nav").height()) <= $(".warp-content")[0].offsetHeight){
		var h1=$(".warp-content")[0].offsetHeight+30+'px';
		$(".left-nav").height(h1);
	}
}

// 屏幕尺寸变化计算高度
$(window).resize(function() {
	autoH();
});

$(function(){
	autoH();
	if($.cookie('THE_SET_COMPANYNAME')){
	$(".com-name>span").text($.cookie('THE_SET_COMPANYNAME'))//从cookie中获取当前公司名称
}
	//存储用户名
	var user=$.cookie('THE_SET_USERNAME');
	if(user && user!="undefined"){
		$(".user-name").text(user)
	}else{
		$(".user-name").text("请重新登录")
	}
	// 右上角鼠标悬浮移除事件
	$(".right-num").on('mouseover', function(event) {
		$(".loginMessage").show();
	});
	$(".right-num").on('mouseout', function(event) {
		$(".loginMessage").hide();

	});
	//导航菜单点击事件
	$(".down-active").next("ul").show();
	$('.nav-title').click(function(){
		if($(this).siblings('ul').css('display')=='none'){
			$(this).parent('li').siblings('li').removeClass('inactives');
			$(this).addClass('down-active');
			$(this).parent().siblings('li').children('ul').css('display','none');
			$(this).parent().siblings('li').children('ul').siblings('a').removeClass('down-active');
			$(this).siblings('ul').slideDown(100).children('li');
			if($(this).children().hasClass('up-down')){
			   $(this).parent(".list-title").addClass("active");
			   $(this).parent(".list-title").addClass("active-yy");
			   $(this).parent("li").siblings(".list-title-down").removeClass("active");
			   $(this).parent("li").siblings(".list-title-down").removeClass("active-yy");
		      }
			if($(this).parents('li').siblings('li').children('ul').css('display')=='block'){
				$(this).parents('li').siblings('li').children('ul').parent('li').children('a').removeClass('down-active');
				$(this).parents('li').siblings('li').children('ul').slideUp(100);
			}
			if($(this).hasClass("active-ys")){
			  $(this).find("i").removeClass("up-down1");
			  $(this).find("i").addClass("updown1");
		   }
			if($(this).parent().siblings().find("a").hasClass("active-ys")){
		   	 $(this).parent().siblings().children(".active-ys").find("i").removeClass("updown1");
		   	 $(this).parent().siblings().children(".active-ys").find("i").removeClass("up-down");
		   	 $(this).parent().siblings().children(".active-ys").find("i").addClass("up-down1");
		   }
			$(this).parent(".list-title-down").addClass("active");
			$(this).parent(".list-title-down").addClass("active-yy");
			$(this).parent("li").siblings(".list-title-down").removeClass("active");
			$(this).parent("li").siblings(".list-title-down").removeClass("active-yy");
		}else{
			//控制自身变成向右箭头
			$(this).removeClass('down-active');
			//控制自身菜单下子菜单隐藏
			$(this).siblings('ul').slideUp(100);
			//控制自身子菜单变成向右箭头
			$(this).siblings('ul').children('li').children('ul').parent('li').children('a').addClass('inactives');
			//控制自身菜单下子菜单隐藏
			$(this).siblings('ul').children('li').children('ul').slideUp(100);

			//控制同级菜单只保持一个是展开的（向下箭头显示）
			$(this).siblings('ul').children('li').children('a').removeClass('down-active');
		   if(!$(this).hasClass("active-ys")){
		    $(this).parent(".list-title-down").removeClass("active");
		    $(this).parent(".list-title-down").removeClass("active-yy");
		   }
		   if($(this).hasClass("active-ys")){
		   	$(this).find("i").removeClass("updown1");
		   	$(this).find("i").removeClass("up-down");
		   	$(this).find("i").addClass("up-down1");
		   }

		}

	})

	//退出登录
	$("#login-out").click(function(){
//		var wxjson = new webjson("4");
//		var res = WebRequest(wxjson);
//		var data = GetOjson(json_parse(res));
//		if(data.status == "0"){
//			console.log(data.info);
//			window.location.href="index.html?loginOut=true";
//		}else{
//			alert(data.info);
//		}
	});


 //修改账户信息跳转
 $("#modify").on('click',function(event) {
 	//window.open("ModifyPersonalInformation.html?current1="+a1+"&current2="+a2,'_self')
 });


	if($("a.btn").length && $("a.btn").length > 0){//ie8浏览器隐藏导入按钮并给出相应提示
		var DEFAULT_VERSION = "8.0";
		var ua = navigator.userAgent.toLowerCase();
		var isIE = ua.indexOf("msie")>-1;
		var safariVersion;
		if(isIE){
			safariVersion =  ua.match(/msie ([\d.]+)/)[1];
			if(safariVersion <= DEFAULT_VERSION ){
		        // 跳转至页面1
		        $("a.btn").css("display","none");
		        alert("IE8及以下浏览器不支持导入功能，请升级IE或者切换chrome，firefox浏览器。");
		    }
		}
	}
})
