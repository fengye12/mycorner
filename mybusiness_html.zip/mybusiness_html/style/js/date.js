/**此方法设置日期的满足条件**/
function date(){
  //报备日期验证bbDate
  var startDaobei=$("#bbDate").children("input.dateStart").val();
  var endDaobei = $("#bbDate").children("input.dateEnd").val();
  //采购日期验证cgDate
  var startCg = $("#cgDate").children("input.dateStart").val();
  var endCg = $("#cgDate").children("input.dateEnd").val()

  if(startDaobei != "" && endDaobei != "" && new Date(startDaobei.replace(/-/g, "/")) > new Date(endDaobei.replace(/-/g, "/"))) {
    layer.open({
			title: '系统提示'
			,content: '报备开始日期不能大于结束日期!'
			,btn: ['确定']
			,yes: function(){
				layer.closeAll();
			}
		});
    return false;
   }else if(startCg != "" && endCg != "" && new Date(startCg.replace(/-/g, "/")) > new Date(endCg.replace(/-/g, "/"))) {
    layer.open({
			title: '系统提示'
			,content: '采购开始日期不能大于结束日期!'
			,btn: ['确定']
			,yes: function(){
				layer.closeAll();
			}
		});
      return false;
    }else{
      return true;
    }
}

/**此方法设置日期的满足条件**/
function date1(){
  //报备日期验证bbDate
  var startDaobei=$("#bbDate").children("input.dateStart").val();
  var endDaobei = $("#bbDate").children("input.dateEnd").val();
  //交易日期验证jyDate
  var startJy = $("#jyDate").children("input.dateStart").val();
	var endJy = $("#jyDate").children("input.dateEnd").val();

  if(startDaobei != "" && endDaobei != "" && new Date(startDaobei.replace(/-/g, "/")) > new Date(endDaobei.replace(/-/g, "/"))) {
    layer.open({
			title: '系统提示'
			,content: '报备开始日期不能大于结束日期!'
			,btn: ['确定']
			,yes: function(){
				layer.closeAll();
			}
		});
    return false;
   }else if(startJy != "" && endJy != "" && new Date(startJy.replace(/-/g, "/")) > new Date(endJy.replace(/-/g, "/"))) {
    layer.open({
			title: '系统提示'
			,content: '交易开始日期不能大于结束日期!'
			,btn: ['确定']
			,yes: function(){
				layer.closeAll();
			}
		});
      return false;
    }else{
      return true;
    }
}

function checkBoxFormat(warpBox){//格式化复选框提交方式，参数为当前一组复选框所在的父元素
  var checked=warpBox.find("input[type='checkbox']:checked");
  var check=warpBox.find("input[type='checkbox']");
  if(checked.length == check.length || checked.length == 0){
    return '';
  }else{
    var str='';
    $.each(check,function(i,item){
      if($(this).is(':checked')){
        str=str+i+',';
      }
    })
    str=str.substr(0,str.length-1)
    return str;
  }
}

function dateLoad(){//调用日期方法
  console.log($(".date"))
  $(".date" ).datepicker({
    dateFormat: 'yy-mm-dd',
    showOtherMonths: true,
    selectOtherMonths: true,
    showButtonPanel: true,
    showOn: "both",
    buttonImageOnly: true,
    buttonText: "",
    changeMonth: true,
    changeYear: true,
    maxDate:"d"
  });
}
function dateLoad1(){//调用日期方法
  $(".date1" ).datepicker({
    dateFormat: 'yy-mm-dd',
    showOtherMonths: true,
    selectOtherMonths: true,
    showButtonPanel: true,
    showOn: "both",
    buttonImageOnly: true,
    buttonText: "",
    changeMonth: true,
    changeYear: true
      });
}

function numberYz(th,e){//验证商品数量
  if(e != 8 && e != 37 && e != 38 && e != 39 &&  e != 40){
    var selPos=th.position();
    var vVal=th.val();
    var sVal=vVal;
    if(th.val().length==1){
      sVal=th.val().replace(/[^1-9]/g,'');
    }else{
      sVal=th.val().replace(/\D/g,'');
    }
    if(vVal != sVal){
      th.val(sVal);
      th.position(selPos-1);
    }

  }
}

function foodNumYz(th,e){//验证商品条码
  if(e != 8 && e != 37 && e != 38 && e != 39 &&  e != 40){
    var selPos=th.position();
    var vVal=th.val();
    var sVal="";
    sVal=th.val().replace(/[^\w]/ig,'');
    if(vVal != sVal){
      th.val(sVal);
      th.position(selPos-1);
    }
  }

}
function telYz(th,e){//联系方式^[\d-]*$  
  if(e != 8 && e != 37 && e != 38 && e != 39 &&  e != 40){
    var selPos=th.position();
    var vVal=th.val();
    var sVal=vVal;
    //if(th.val().length==1){
      sVal=th.val().replace(/[^0-9-]/g,'');
    //}else{
      //sVal=th.val().replace(/^[\D\-]/g,'');
    //}
    if(vVal != sVal){
      th.val(sVal);
      th.position(selPos-1);
    }

  }
}


/**日历设置**/
jQuery(function($){
  $.datepicker.regional['zh-CN'] = {
    clearText: '清除',
    clearStatus: '清除已选日期',
    closeText: '关闭',
    closeStatus: '不改变当前选择',
    prevText: '< 上月',
    prevStatus: '显示上月',
    prevBigText: '<<',
    prevBigStatus: '显示上一年',
    nextText: '下月>',
    nextStatus: '显示下月',
    nextBigText: '>>',
    nextBigStatus: '显示下一年',
    currentText: '今天',
    currentStatus: '显示本月',
    monthNames: ['一月','二月','三月','四月','五月','六月', '七月','八月','九月','十月','十一月','十二月'],
    monthNamesShort: ['一月','二月','三月','四月','五月','六月', '七月','八月','九月','十月','十一月','十二月'],
    monthStatus: '选择月份',
    yearStatus: '选择年份',
    weekHeader: '周',
    weekStatus: '年内周次',
    dayNames: ['星期日','星期一','星期二','星期三','星期四','星期五','星期六'],
    dayNamesShort: ['周日','周一','周二','周三','周四','周五','周六'],
    dayNamesMin: ['日','一','二','三','四','五','六'],
    dayStatus: '设置 DD 为一周起始',
    dateStatus: '选择 m月 d日, DD',
    dateFormat: 'yy-mm-dd',
    firstDay: 1,
    initStatus: '请选择日期',
    isRTL: false};
    $.datepicker.setDefaults($.datepicker.regional['zh-CN']);
  });

function resetForm(){//重置高级搜索选项
  $("input").val("")
  $("input[type='checkbox']:checked").removeAttr('checked', 'checked');
  $("input[type='checkbox']:checked").removeAttr('checked', 'checked');
}

$(function() {
  dateLoad();
  $("#reset").click(function() {//重置高级搜索选项
    resetForm();
  })
  $('#gjSearch').click(function(event){//高级搜索展开收起
    event.stopPropagation();
    if($('#gjBox').css('display')=='none'){
      $('#gjBox').slideDown(300);
      autoH();
      var l=$(".left-nav")[0].offsetHeight;
      var h=$(".warp-content")[0].offsetHeight+281;
      if(h>l){
        $(".left-nav").height(h)
      }
    }else{
      resetForm();
      $('#gjBox').slideUp(300);
    }
  })
});

