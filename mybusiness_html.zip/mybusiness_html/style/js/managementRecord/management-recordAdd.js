var a1="a16";var a2="a1600";
/**获取当前年月日**/
var myDate=new Date();
var year = myDate.getFullYear();//获取当前年
var yue = myDate.getMonth()+1;//获取当前月
var date = myDate.getDate();//获取当前日
var myTime=year+"年"+yue+"月"+date+"日";
var myTime1=year+"-"+yue+"-"+date;
$(function(){
	getActiveN("a16","a1600");
})
$("#ssselS1 .selected-item").click(function(){
		$("#ssselS1 .optionB").slideToggle(5);
	})
	$("#ssselS1 .sel-wrap img").click(function(){
		$("#ssselS1 .optionB").slideToggle(5);
	})
	$(document).click(function(event){
	var st=$("#ssselS1 .selected-item");
	var img1=$("#ssselS1 .sel-wrap img");
	if(!st.is(event.target)&& st.has(event.target).length === 0&&!img1.is(event.target)&& img1.has(event.target).length === 0){
	$("#ssselS1 .optionB").slideUp(1);
	}
})
$("#ssselS1 .optionB li").click(function(){
	    $(".errorInfo").hide();
	    $(".errorInfo a").remove();
	    $(".sel-wrap input").css("background","url(../style/image/select.png) no-repeat right bottom 4px");
	    $("#zr").css("background","none");
		$(".input-init").removeClass("errorRed");
		$(".inputstyle").removeClass("fontRed").children("input").removeClass("fontRed");
		bbtype2=$(this).text();
		$("#ssselS1 .selected-item1").text(bbtype2);
		$("#ssselS1 .optionB").slideUp(1);
		if(bbtype2=="停产/停业备案"){
			$(".tc").show();
			$(".wxx").hide();
			$(".wjh").hide();
			$(".zr").hide();
			$(".otherqur").show();
			$(".tcTime").text(myTime1);
		}else if(bbtype2=="无销售行为备案"){
			$(".wxx").show();
			$(".tc").hide();
			$(".wjh").hide();
			$(".zr").hide();
			$(".otherqur").show();
			$(".wxxTime").text(myTime1);
		}else if(bbtype2=="无进货行为备案"){
			$(".wjh").show();
			$(".tc").hide();
			$(".wxx").hide();
			$(".zr").hide();
			$(".otherqur").show();
			$(".wjhTime").text(myTime1);
		}else if(bbtype2=="企业转让备案"){			
			$("#zr").val(myTime);
			$(".zr").show();
			$(".tc").hide();
			$(".wxx").hide();
			$(".wjh").hide();
			$(".otherqur").show();
			$(".zr1").text($("#zr").val());
			$(".zrTime").text(myTime1);
		}
})
		/**日历**/
$("#tc").jeDate({       	
	        	format: "YYYY年MM月DD日",	
	        	minDate: $.nowDate({MM:-1}),
                maxDate: $.nowDate({DD:0}),
                choosefun: function(elem,datas){
               	console.log(datas);
               	$("#tc1").text(datas);
               }
});

$("#wxx").jeDate({	            	                  
	        	format: "YYYY年MM月",
	        	minDate: $.nowDate({MM:-1}), 
                maxDate: $.nowDate({MM:0}),
                choosefun: function(elem,datas){
               	console.log(datas);
               	$("#wxx1").text(datas);
               }
});

$("#wjh").jeDate({
	        	format: "YYYY年MM月",
                minDate: $.nowDate({MM:-1}), 
                maxDate: $.nowDate({MM:0}),
                choosefun: function(elem,datas){
               	console.log(datas);
               	$("#wjh1").text(datas);
               }	            
});
//$("#zr").jeDate({
//	        	isShow:false,
//	        	format: "YYYY年MM月DD日",
//	        	minDate: $.nowDate({DD:0}), 
//              maxDate: $.nowDate({DD:0}) 
//});

 /**输入受让人信息**/
$('input.srr').keyup(function () {
    $("#srr1").text($(".srr").val());
});
$('input.phone').keyup(function () {
    $("#phone1").text($(".phone").val());
});
$('input.idCard').keyup(function () {
    $("#idCard1").text($(".idCard").val());
});

// 验证手机号
function isPhoneNo(phone) { 
 var pattern = /^1[34578]\d{9}$/; 
 return pattern.test(phone); 
}
 
// 验证身份证 
function isCardNo(idCard) { 
 var pattern = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/; 
 return pattern.test(idCard); 
}

//input获取焦点时
$(".sel-wrap #wxx").on("focus",function(){
	$(this).parent().parent().parent().parent(".input-init").removeClass("errorRed");
    $(this).css("background","url(../style/image/select.png) no-repeat right bottom 4px");
})
$(".sel-wrap #wjh").on("focus",function(){
	$(this).parent().parent().parent().parent(".input-init").removeClass("errorRed");
    $(this).css("background","url(../style/image/select.png) no-repeat right bottom 4px");
})
$(".sel-wrap #tc").on("focus",function(){
	$(this).parent().parent().parent().parent(".input-init").removeClass("errorRed");
    $(this).css("background","url(../style/image/select.png) no-repeat right bottom 4px");
})
//$(".sel-wrap #zr").on("focus",function(){
//	$(this).parent().parent().parent().parent(".input-init").removeClass("errorRed");
//  $(this).css("background","url(../style/image/select.png) no-repeat right bottom 4px");
//})
$(".srr").on("focus",function(){
	$(this).parents(".inputstyle").removeClass("fontRed").parent(".input-init").removeClass("errorRed");
})
$(".phone").on("focus",function(){
	$(this).removeClass("fontRed").parents(".inputstyle").removeClass("fontRed").parent(".input-init").removeClass("errorRed");
})
$(".idCard").on("focus",function(){
	$(this).removeClass("fontRed").parents(".inputstyle").removeClass("fontRed").parent(".input-init").removeClass("errorRed");
})
//点击保存,验证输入的信息
$(".important").click(function(){
	if($(".errorInfo a").length=="1"){
		$(".errorInfo").hide();
	}
	var liType=$(".sel-wrap span").text();
	var wxx=$("#wxx").val();
	var wjh=$("#wjh").val();
	var tc=$("#tc").val();
	var zr=$("#zr").val();
	var srr=$(".srr").val();
	var phone=$(".phone").val();
	var idCard=$(".idCard").val();
	if(wxx=="请选择报备日期"){
		wxx="";
	}
	if(wjh=="请选择报备日期"){
		wjh="";
	}
	if(tc=="请选择停产日期"){
		tc="";
	}
	if(zr=="请选择转让日期"){
		zr="";
	}
	if(srr=="请输入受让人姓名"){
		srr="";
	}
	if(phone=="请输入受让人手机号"){
		phone="";
	}
	if(idCard=="请输入受让人身份证号"){
		idCard="";
	}
	if(liType=="无销售行为备案"){
	  if(wxx==""){
		$("#wxx").parent().parent().parent(".inputstyle").addClass("fontRed");
		$("#wxx").parent().parent().parent().parent(".input-init").addClass("errorRed");
		$(".errorInfo").show();
		$(".sel-wrap input").css("background","url(../style/image/dropdowns-error-btn-default.png) no-repeat right bottom 4px");
		   if(!$('.errorInfo a').hasClass('wxx1')){
			$(".errorInfo").append('<a href="javascript:void(0);" class="wxx1"><img src="../style/image/error.png"/><span>报备月份不能为空</span></a>');
		   }
	  }else{
		$(".wxx1").remove();
	  }
	}else if(liType=="无进货行为备案"){
	  if(wjh==""){
		$("#wjh").parent().parent().parent(".inputstyle").addClass("fontRed");
		$("#wjh").parent().parent().parent().parent(".input-init").addClass("errorRed");
		$(".errorInfo").show();
		$(".sel-wrap input").css("background","url(../style/image/dropdowns-error-btn-default.png) no-repeat right bottom 4px");
		   if(!$('.errorInfo a').hasClass('wjh1')){
			$(".errorInfo").append('<a href="javascript:void(0);" class="wjh1"><img src="../style/image/error.png"/><span>报备月份不能为空</span></a>');
		   }
	  }else{
		$(".wjh1").remove();
	  }
	}else if(liType=="停产/停业备案"){
	  if(tc==""){
		$("#tc").parent().parent().parent(".inputstyle").addClass("fontRed");
		$("#tc").parent().parent().parent().parent(".input-init").addClass("errorRed");
		$(".errorInfo").show();
		$(".sel-wrap input").css("background","url(../style/image/dropdowns-error-btn-default.png) no-repeat right bottom 4px");
		   if(!$('.errorInfo a').hasClass('tc1')){
			$(".errorInfo").append('<a href="javascript:void(0);" class="tc1"><img src="../style/image/error.png"/><span>停产/停业日期不能为空</span></a>');
		   }
	  }else{
		$(".tc1").remove();
	  }
   }else if(liType=="企业转让备案"){
// 	  if(zr==""){
//		$("#zr").parent().parent().parent(".inputstyle").addClass("fontRed");
//		$("#zr").parent().parent().parent().parent(".input-init").addClass("errorRed");
//		$(".errorInfo").show();
//		$(".sel-wrap input").css("background","url(../style/image/dropdowns-error-btn-default.png) no-repeat right bottom 4px");
//		   if(!$('.errorInfo a').hasClass('zr1')){
//			$(".errorInfo").append('<a href="javascript:void(0);" class="zr1"><img src="../style/image/error.png"/><span>转让日期不能为空</span></a>');
//		   }
//	  }else{
//		$(".zr1").remove();
//	  }
	  if(srr==""){
	  	$(".srr").parent(".inputstyle").addClass("fontRed");
		$(".srr").parent().parent(".input-init").addClass("errorRed");
		$(".errorInfo").show();
		   if(!$('.errorInfo a').hasClass('srr1')){
			$(".errorInfo").append('<a href="javascript:void(0);" class="srr1"><img src="../style/image/error.png"/><span>受让人姓名不能为空</span></a>');
		   }
	  }else{
		$(".srr1").remove();
	  }
	  if(phone==""){
	  	$(".phone1").remove();
	  	$(".phone").parent(".inputstyle").addClass("fontRed");
		$(".phone").parent().parent(".input-init").addClass("errorRed");
		$(".errorInfo").show();
		   if(!$('.errorInfo a').hasClass('phone1')){
			$(".errorInfo").append('<a href="javascript:void(0);" class="phone1"><img src="../style/image/error.png"/><span>受让人手机号不能为空</span></a>');
		   }
	  }else if(isPhoneNo(phone)==false){
	  	$(".phone1").remove();
	  	$(".phone").addClass("fontRed").parent(".inputstyle").addClass("fontRed");
		$(".phone").parent().parent(".input-init").addClass("errorRed");
		$(".errorInfo").show();
		   if(!$('.errorInfo a').hasClass('phone1')){
			$(".errorInfo").append('<a href="javascript:void(0);" class="phone1"><img src="../style/image/error.png"/><span>受让人手机号格式错误</span></a>');
		   }
	  }else{
	  	$(".phone1").remove();
	  }
	  if(idCard==""){
	  	$(".idCard1").remove();
	  	$(".idCard").parent(".inputstyle").addClass("fontRed");
		$(".idCard").parent().parent(".input-init").addClass("errorRed");
		$(".errorInfo").show();
		   if(!$('.errorInfo a').hasClass('idCard1')){
			$(".errorInfo").append('<a href="javascript:void(0);" class="idCard1"><img src="../style/image/error.png"/><span>受让人身份证号不能为空</span></a>');
		   }
	  }else if(isCardNo(idCard)==false){
	  	$(".idCard1").remove();
	  	$(".idCard").addClass("fontRed").parent(".inputstyle").addClass("fontRed");
		$(".idCard").parent().parent(".input-init").addClass("errorRed");
		$(".errorInfo").show();
		   if(!$('.errorInfo a').hasClass('idCard1')){
			$(".errorInfo").append('<a href="javascript:void(0);" class="idCard1"><img src="../style/image/error.png"/><span>受让人身份证号格式错误</span></a>');
		   }
	  }else{
	  	$(".idCard1").remove();
	  }
  }
})
