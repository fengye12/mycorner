var a1="a16";var a2="a1600";
/**获取当前年月日**/
var myDate=new Date();
var year = myDate.getFullYear();//获取当前年
var yue = myDate.getMonth()+1;//获取当前月
var date = myDate.getDate();//获取当前日
var myTime=year+"年"+yue+"月"+date+"日";
var myTime1=year+"-"+yue+"-"+date;
// 分页相关
    var pindex=1, pcount=1000, psize=$("#pageCentS select").val()?$("#pageCentS select").val():"10";
    var pcent = new CentPage();
    var pTemplate = "";
    var activeNum=pcent.PageNum;
    var obj=$("#page");
    //分页active页码
      function getActive(obj,activeNum){
       $.each(obj.find('li'), function(index, val) {
        var nowNum=$(val).text()
          if(nowNum==activeNum){
            $(this).addClass("active")
          }else{
            $(this).removeClass("active")
          }
        });
        }
       //分页点击页码触发
    function CentPageOper(num){
      pindex=num;
      pTemplate = pcent.GetCentPage(pindex, pcount, psize);
      $("#page").html(pTemplate);
       getActive(obj,num);
    }
    // 分页select change事件
    function pageChange(objselect){
      objselect.change(function(){
        console.log($(this).val())
        psize=$(this).val();
        pTemplate = pcent.GetCentPage(1, 1000, psize);
        $("#page").html(pTemplate);
        getActive(obj,1)
      });
    }
$(function(){
	getActiveN("a16","a1600");
	//初始化分页select3
        $("#pageCentS").select3({
        'animate':'slide',
          'value':"10",
          callback:function(obj){
            console.log(obj)
             // var obj=$("#ssselS select");
            pageChange(obj);
          }
      });
        // 初始化分页select3之后才能初始化分页模板
        pTemplate=pcent.GetCentPage(pindex, pcount, psize);
         $("#page").html(pTemplate);
        getActive(obj,activeNum);
})



/**点击无销售行为备案的查看**/
function ck(t){
	var tabType=$(t).parent().prev().prev().prev().text();
	console.log(tabType);
	var html=' <div class="content">'+
	            '<div class="errorInfo">'+
                	'<p>请检查以下问题：</p>'+          	
                '</div>'+
                '<p class="li-title blueColor2">基础信息</p>'+
                  '<form class="formData">'+
                  /**查看**/
                    '<ul class="list list1">'+
                      '<li>'+
                        '<div class="input-init">'+
                          '<label for="">备案类型</label>'+
                          '<div class="inputstyle">'+
                            '<input type="text" value="'+tabType+'"  maxlength="30" readonly/>'+
                          '</div>'+
                        '</div>'+
                      '</li>'+
                      '<li class="rightIcon">'+
                        '<div class="input-init">'+
                          '<label for="">状态</label>'+
                          '<div class="inputstyle">'+
                            '<input type="text" value="备案中" maxlength="20" readonly/>'+
                          '</div>'+                          
                        '</div>'+
                      '</li>'+
                      '<li>'+
                          '<div class="imgContent">'+
                          '<p class="li-title blueColor2">备案说明</p>';
                      if(tabType=="无销售行为备案"){
                        html +=  '<ul class="list">'+   
                               '<li>'+
                                '<div class="input-init" style="position:relative;">'+
                                    '<label for="">报备月份</label>'+
                                    '<div class="inputstyle">'+
                                        '<div class="selectedB" id="ssselS2" >'+
                                            '<div class="sel-wrap">'+
                                            	'<input type="text" class="selected-item selected-item1" value="" readonly>'+                                              
                                            '</div>'+                                      
                                        '</div>'+
                                    '</div>'+
                                '</div>'+
                                '<div class="typeDetail" style="height:170px;">'+
                                	'<span class="comp">监管单位名称：</span><p>(当前<span>监管单位名称</span>)于（<span>报备月份</span>）无任何食品销售行为，此说明保证真实有效，特此向贵局备案。</br><span style="text-align:left;display:block;margin-top:20px;">'+myTime1+'</span></p>'+
                                '</div>'+
                                '</li>'+
                                '</ul>';
                               }if(tabType=="无进货行为备案"){
                               	html += '<ul class="list">'+   
                               '<li>'+
                                '<div class="input-init" style="position:relative;">'+
                                    '<label for="">报备月份</label>'+
                                    '<div class="inputstyle">'+
                                        '<div class="selectedB" id="ssselS2" >'+
                                            '<div class="sel-wrap">'+
                                            	'<input type="text" class="selected-item selected-item1" value="" readonly>'+                                              
                                            '</div>'+                                      
                                        '</div>'+
                                    '</div>'+
                                '</div>'+
                                '<div class="typeDetail" style="height:170px;">'+
                                	'<span class="comp">监管单位名称：</span><p>(当前<span>监管单位名称</span>)于（<span>报备月份</span>）无任何食品采购行为，此说明保证真实有效，特此向贵局备案。</br><span style="text-align:left;display:block;margin-top:20px;">'+myTime1+'</span></p>'+ 
                                '</div>'+
                                '</li>'+
                                '</ul>';
                               }else if(tabType=="停产/停业备案"){
                               	 html +='<ul class="list">'+     
                               '<li>'+ 
                                '<div class="input-init" style="position:relative;">'+ 
                                    '<label for="">停产/停业日期</label>'+ 
                                    '<div class="inputstyle">'+ 
                                        '<div class="selectedB" id="ssselS2" >'+ 
                                            '<div class="sel-wrap">'+ 
                                            	'<input type="text" class="selected-item selected-item1" value="" readonly>'+                                                           
                                            '</div>'+                                        
                                        '</div>'+ 
                                    '</div>'+ 
                                '</div>'+ 
                                '<div class="typeDetail" style="height:170px;">'+ 
                                	'<span class="comp">监管单位名称：</span><p>(当前<span>监管单位名称</span>)于（<span>停产日期</span>）起，停止生产经营食品，恢复生产经营前三日另行备案说明，此说明保证真实有效，特此向贵局备案。</br><span style="text-align:left;display:block;margin-top:20px;">'+myTime1+'</span></p>'+ 
                                '</div>'+ 
                                '</li>'+ 
                                '</ul>';
                               }else if(tabType=="企业转让备案"){                
                               	html += '<ul class="list">'+    
                               '<li>'+
                                '<div class="input-init" style="position:relative;">'+
                                    '<label for="">转让日期</label>'+
                                    '<div class="inputstyle">'+
                                        '<div class="selectedB" id="ssselS2" >'+
                                            '<div class="sel-wrap">'+
                                            	'<input type="text" class="selected-item selected-item1 zr" style="background:none;" value="" readonly>'+                                                                                       
                                            '</div>'+                                      
                                        '</div>'+
                                    '</div>'+
                                '</div>'+
                                '<div class="input-init">'+
                                 '<label for="">受让人</label>'+
                                 '<div class="inputstyle">'+
                                  '<input type="text" value="" maxlength="20" readonly/>'+
                                 '</div>'+
                                '</div>'+
                                '<div class="input-init">'+
                                 '<label for="">手机号</label>'+
                                 '<div class="inputstyle">'+
                                  '<input type="text" value="" maxlength="11" readonly/>'+
                                 '</div>'+
                                '</div>'+
                                '<div class="input-init">'+
                                 '<label for="">身份证</label>'+
                                 '<div class="inputstyle">'+
                                  '<input type="text" value="" maxlength="18" readonly/>'+
                                 '</div>'+
                                '</div>'+
                                '<div class="typeDetail" style="height:170px;">'+
                                	'<span class="comp">监管单位名称：</span><p>(当前<span>监管单位名称</span>)于（<span>转让时间</span>）起，转让给（受让人姓名，手机号：   身份证号：   ），此说明保证真实有效，特此向贵局备案。</br><span style="text-align:left;display:block;margin-top:20px;">'+myTime1+'</span></p>'+
                                '</div>'+
                                '</li>'+
                                '</ul>';
                               }
                      html += ' </div>'+
                      '</li>'+
                    '</ul>'+
                    /**编辑**/
                    '<ul class="list list2" style="display:none;">'+    
                            '<li>'+
                                '<div class="input-init" style="position:relative;">'+
                                    '<label for="">备案类型</label>'+
                                    '<div class="inputstyle">'+
                                        '<div class="selectedB" id="ssselS1" >'+
                                            '<div class="sel-wrap">'+
                                                '<span class="selected-item selected-item1">'+tabType+'</span>'+                                         
                                            '</div>'+
                                            '<ul class="optionB">'+
                                                '<li class="op-item" data-value="0">无销售行为备案</li>'+
                                                '<li class="op-item" data-value="1">无进货行为备案</li>'+
                                                '<li class="op-item" data-value="2">停产/停业备案</li>'+
                                                '<li class="op-item" data-value="3">企业转让备案</li>'+
                                            '</ul>'+
                                        '</div>'+
                                    '</div>'+
                                '</div>'+
                            '</li>'+
                            //无销售备案
                            '<li class="wxx">'+
                            '<p class="li-title blueColor2">备案说明</p>'+
                              '<ul class="list">'+    
                               '<li>'+
                                '<div class="input-init" style="position:relative;">'+
                                    '<label for="">报备月份<em class="color-red">*</em></label>'+
                                    '<div class="inputstyle">'+
                                        '<div class="selectedB" id="ssselS2" >'+
                                            '<div class="sel-wrap">'+
                                            	'<input type="text" class="selected-item selected-item1 jydate" value="" name="date" id="wxx" placeholder="请选择报备日期" readonly>'+                                
                                            '</div>'+                                       
                                        '</div>'+
                                    '</div>'+
                                '</div>'+
                                '<div class="typeDetail" style="height:170px;">'+
                                	'<span class="comp">监管单位名称：</span><p>(当前<span>监管单位名称</span>)于（<span id="wxx1">报备月份</span>）无任何食品销售行为，此说明保证真实有效，特此向贵局备案。</br><span style="text-align:left;display:block;margin-top:20px;">'+myTime1+'</span></p>'+
                                '</div>'+
                                '</li>'+
                                '</ul>'+
                            '</li>'+ 
                            //停产
                            '<li class="tc">'+ 
                            '<p class="li-title blueColor2">备案说明</p>'+
                              '<ul class="list">'+     
                               '<li>'+ 
                                '<div class="input-init" style="position:relative;">'+ 
                                    '<label for="">停产/停业日期<em class="color-red">*</em></label>'+ 
                                    '<div class="inputstyle">'+ 
                                        '<div class="selectedB" id="ssselS2" >'+ 
                                            '<div class="sel-wrap">'+ 
                                            	'<input type="text" class="selected-item selected-item1 jydate" value="" name="date" id="tc" placeholder="请选择停产起始日期" onchange="tc()" readonly>'+                                                           
                                            '</div>'+                                        
                                        '</div>'+ 
                                    '</div>'+ 
                                '</div>'+ 
                                '<div class="typeDetail" style="height:170px;">'+ 
                                	'<span class="comp">监管单位名称：</span><p>(当前<span>监管单位名称</span>)于（<span id="tc1">停产日期</span>）起，停止生产经营食品，恢复生产经营前三日另行备案说明，此说明保证真实有效，特此向贵局备案。</br><span style="text-align:left;display:block;margin-top:20px;">'+myTime1+'</span></p>'+ 
                                '</div>'+ 
                                '</li>'+ 
                                '</ul>'+ 
                            '</li>'+  
                            //无进货行为备案
                            '<li class="wjh">'+ 
                            '<p class="li-title blueColor2">备案说明</p>'+ 
                              '<ul class="list">'+     
                               '<li>'+ 
                                '<div class="input-init" style="position:relative;">'+ 
                                    '<label for="">报备月份<em class="color-red">*</em></label>'+ 
                                    '<div class="inputstyle">'+ 
                                        '<div class="selectedB" id="ssselS2" >'+ 
                                            '<div class="sel-wrap">'+ 
                                            	'<input type="text" class="selected-item selected-item1 jydate" value="" name="date" id="wjh" placeholder="请选择报备日期" readonly>'+                                             
                                            '</div>'+                                        
                                        '</div>'+ 
                                    '</div>'+ 
                                '</div>'+ 
                                '<div class="typeDetail" style="height:170px;">'+ 
                                	'<span class="comp">监管单位名称：</span><p>(当前<span>监管单位名称</span>)于（<span id="wjh1">报备月份</span>）无任何食品采购行为，此说明保证真实有效，特此向贵局备案。</br><span style="text-align:left;display:block;margin-top:20px;">'+myTime1+'</span></p>'+ 
                                '</div>'+ 
                                '</li>'+ 
                                '</ul>'+ 
                            '</li>'+ 
                            //企业转让
                            '<li class="zr">'+
                            '<p class="li-title blueColor2">备案说明</p>'+
                              '<ul class="list">'+    
                               '<li>'+
                                '<div class="input-init" style="position:relative;">'+
                                    '<label for="">转让日期</label>'+
                                    '<div class="inputstyle">'+
                                        '<div class="selectedB" id="ssselS2" >'+
                                            '<div class="sel-wrap">'+
                                            	'<input type="text" class="selected-item selected-item1" value="'+myTime+'" style="background:none;" name="date" id="zr" readonly>'+                                                                                       
                                            '</div>'+                                      
                                        '</div>'+
                                    '</div>'+
                                '</div>'+
                                '<div class="input-init">'+
                                 '<label for="">受让人<em class="color-red">*</em></label>'+
                                 '<div class="inputstyle">'+
                                  '<input type="text" placeholder="请输入受让人姓名" class="srr" maxlength="20" />'+
                                 '</div>'+
                                '</div>'+
                                '<div class="input-init">'+
                                 '<label for="">手机号<em class="color-red">*</em></label>'+
                                 '<div class="inputstyle">'+
                                  '<input type="text" placeholder="请输入受让人手机号" class="phone" maxlength="11" />'+
                                 '</div>'+
                                '</div>'+
                                '<div class="input-init">'+
                                 '<label for="">身份证<em class="color-red">*</em></label>'+
                                 '<div class="inputstyle">'+
                                  '<input type="text" placeholder="请输入受让人身份证号" class="idCard" maxlength="18" />'+
                                 '</div>'+
                                '</div>'+
                                '<div class="typeDetail" style="height:170px;">'+
                                	'<span class="comp">监管单位名称：</span><p>(当前<span>监管单位名称</span>)于（<span class="zr1">转让时间</span>）起，转让给（<span id="srr1">受让人姓名</span>，手机号：<span id="phone1"></span>  身份证号：<span id="idCard1"></span> ），此说明保证真实有效，特此向贵局备案。</br><span style="text-align:left;display:block;margin-top:20px;">'+myTime1+'</span></p>'+
                                '</div>'+
                                '</li>'+
                                '</ul>'+
                            '</li>'+        
                            '</ul>'+
                 ' <div class="btnGroup footerbtn footerbtn1">';
                 if(tabType=="停产/停业备案"){
                 	html +='<a href="javascript:;" class="btn cancel">作废</a>'+
                 	'<a href="javascript:;" class="btn edit">编辑</a>'+
                   '<a href="javascript:;" class="btn important">恢复经营</a>';             
                 }else{
                 html +='<a href="javascript:;" class="btn qur">取消</a>'+
                   '<a href="javascript:;" class="btn cancel">作废</a>'+
                   ' <a href="javascript:;" class="btn important edit">编辑</a>';
                  }
                 html += '</div>'+
                  ' <div class="btnGroup footerbtn footerbtn2" style="display:none;">'+
                  ' <a href="javascript:;" class="btn qur">取消</a>'+
                  ' <a href="javascript:;" class="btn important important1">保存</a>'+       
                  '</div>'+
                '</form>'+
                '</div>';
	        layer.open({
			type: 1
			,title: '经营备案详情'
			,content: html
			,area: ['500px', '700px']
			//,btn: ['保存','取消']
			,yes: function(){
				console.log('abc');
			}
			,btn2:function(){

			}
			,cancel: function(){ 
				//右上角关闭回调
				//return false 开启该代码可禁止点击该按钮关闭
			}
		});
		
		//点击取消
		$(".qur").click(function(){
			$(".layui-layer-shade").remove();
			$(".layui-layer-page").remove();
		})
		
		//点击作废
		$(".cancel").click(function(){
			var html1="";
			html1 +='<div class="errorInfo">'+                	          	
                    '</div><textarea placeholder="请输入作废原因" class="zuofei"></textarea>';
//			'<div class="btnGroup footerbtn footerbtn2" style="margin-top:0;">'+
//                ' <a href="javascript:;" class="btn cancel1">取消</a>'+
//                ' <a href="javascript:;" class="btn important">确认</a>'+       
//                '</div>';
			$(".layui-layer-shade").remove();
			$(".layui-layer-page").remove();
			layer.open({
			type: 1
			,title: '作废原因'
			,content: html1
			,area: ['400px', '450px']
			,btn: ['取消','确认']
			,yes: function(index){
				//console.log('abc');				
				layer.close(index);
			}
			,btn2:function(){ 
			   var reasion=$.trim($(".zuofei").val());
			   if(reasion=="请输入作废原因"){
			   	 reasion="";
			   }
			   if(reasion==""){
			   	 $(".errorInfo").show();
			   	 $(".errorInfo").css({"margin-left": "40px","margin-right": "40px"});
			   	if(!$('.errorInfo a').hasClass('reasion')){
			   	 $(".errorInfo").append('<a href="javascript:void(0);" class="reasion"><img src="../style/image/error.png"/><span>作废原因不能为空</span></a>');
			    }
			     return false;
			   }else{
			   	 $(".errorInfo").hide();
			   	 $(".reasion").remove();			  
			   }
               //console.log("123");
			}						
			,cancel: function(){ 
				//右上角关闭回调
				//return false 开启该代码可禁止点击该按钮关闭
			}
		});
		})
		$(".edit").click(function(){
			$(".footerbtn1").hide();
			$(".footerbtn2").show();
			$(".list1").hide();
			$(".list2").show();
			var bbtype1=$(".inputstyle>input").val();
			console.log(bbtype1);
		if(bbtype1=="停产/停业备案"){
			$(".tc").show();
			$(".wxx").hide();
			$(".wjh").hide();
			$(".zr").hide();
		}else if(bbtype1=="无销售行为备案"){
			$(".wxx").show();
			$(".tc").hide();
			$(".wjh").hide();
			$(".zr").hide();
		}else if(bbtype1=="无进货行为备案"){
			$(".wjh").show();
			$(".tc").hide();
			$(".wxx").hide();
			$(".zr").hide();
		}else if(bbtype1=="企业转让备案"){
			$(".zr").show();
			$(".tc").hide();
			$(".wxx").hide();
			$(".wjh").hide();
		}
		})
		/**日历**/
$("#tc").jeDate({       	
	        	format: "YYYY年MM月DD日",	
	        	minDate: $.nowDate({MM:-1}),
                maxDate: $.nowDate({DD:0}),
                choosefun: function(elem,datas){
               	console.log(datas);
               	$("#tc1").text(datas);
               }
});

$("#wxx").jeDate({	            	                  
	        	format: "YYYY年MM月",
	        	minDate: $.nowDate({MM:-1}), 
                maxDate: $.nowDate({MM:0}),
                choosefun: function(elem,datas){
               	console.log(datas);
               	$("#wxx1").text(datas);
               }
});

$("#wjh").jeDate({
	        	format: "YYYY年MM月",
                minDate: $.nowDate({MM:-1}), 
                maxDate: $.nowDate({MM:0}),
                choosefun: function(elem,datas){
               	console.log(datas);
               	$("#wjh1").text(datas);
               }	            
});

//$("#zr").jeDate({
//	        	format: "YYYY年MM月DD日",
//	        	minDate: $.nowDate({DD:0}), 
//              maxDate: $.nowDate({DD:0}) 
//});

$("#ssselS1 .selected-item").click(function(){
		$("#ssselS1 .optionB").slideToggle(5);
})
$(document).click(function(event){
	var st=$("#ssselS1 .selected-item");
	if(!st.is(event.target)&& st.has(event.target).length === 0){
	$("#ssselS1 .optionB").slideUp(1);
	}
})
$("#ssselS1 .optionB li").click(function(){
	    $(".errorInfo").hide();
	    $(".errorInfo a").remove();
	    $(".sel-wrap input").css("background","url(../style/image/select.png) no-repeat right bottom 7px");
	    $("#zr").css("background","none");
		$(".input-init").removeClass("errorRed");
		$(".inputstyle").removeClass("fontRed").children("input").removeClass("fontRed");
		bbtype2=$(this).text();
		$("#ssselS1 .selected-item1").text(bbtype2);
		$("#ssselS1 .optionB").slideUp(1);
		if(bbtype2=="停产/停业备案"){
			$(".tc").show();
			$(".wxx").hide();
			$(".wjh").hide();
			$(".zr").hide();
		}else if(bbtype2=="无销售行为备案"){
			$(".wxx").show();
			$(".tc").hide();
			$(".wjh").hide();
			$(".zr").hide();
		}else if(bbtype2=="无进货行为备案"){
			$(".wjh").show();
			$(".tc").hide();
			$(".wxx").hide();
			$(".zr").hide();
		}else if(bbtype2=="企业转让备案"){
			$(".zr").show();
			$(".tc").hide();
			$(".wxx").hide();
			$(".wjh").hide();
		}
})
//input获取焦点时
$(".sel-wrap #wxx").on("focus",function(){
	$(this).parent().parent().parent().parent(".input-init").removeClass("errorRed");
    $(this).css("background","url(../style/image/select.png) no-repeat right bottom 7px");
})
$(".sel-wrap #wjh").on("focus",function(){
	$(this).parent().parent().parent().parent(".input-init").removeClass("errorRed");
    $(this).css("background","url(../style/image/select.png) no-repeat right bottom 7px");
})
$(".sel-wrap #tc").on("focus",function(){
	$(this).parent().parent().parent().parent(".input-init").removeClass("errorRed");
    $(this).css("background","url(../style/image/select.png) no-repeat right bottom 7px");
})
$(".srr").on("focus",function(){
	$(this).parents(".inputstyle").removeClass("fontRed").parent(".input-init").removeClass("errorRed");
})
$(".phone").on("focus",function(){
	$(this).removeClass("fontRed").parents(".inputstyle").removeClass("fontRed").parent(".input-init").removeClass("errorRed");
})
$(".idCard").on("focus",function(){
	$(this).removeClass("fontRed").parents(".inputstyle").removeClass("fontRed").parent(".input-init").removeClass("errorRed");
})

//点击保存,验证输入的信息
$(".important1").click(function(){
	if($(".errorInfo a").length=="1"){
		$(".errorInfo").hide();
	}
	var liType=$(".selected-item1").text();
	var wxx=$("#wxx").val();
	var wjh=$("#wjh").val();
	var tc=$("#tc").val();
	var zr=$("#zr").val();
	var srr=$(".srr").val();
	var phone=$(".phone").val();
	var idCard=$(".idCard").val();
	if(wxx=="请选择报备日期"){
		wxx="";
	}
	if(wjh=="请选择报备日期"){
		wjh="";
	}
	if(tc=="请选择停产日期"){
		tc="";
	}
	if(zr=="请选择转让日期"){
		zr="";
	}
	if(srr=="请输入受让人姓名"){
		srr="";
	}
	if(phone=="请输入受让人手机号"){
		phone="";
	}
	if(idCard=="请输入受让人身份证号"){
		idCard="";
	}
	if(liType=="无销售行为备案"){
	  if(wxx==""){
		$("#wxx").parent().parent().parent(".inputstyle").addClass("fontRed");
		$("#wxx").parent().parent().parent().parent(".input-init").addClass("errorRed");
		$(".errorInfo").show();
		$(".sel-wrap input").css("background","url(../style/image/dropdowns-error-btn-default.png) no-repeat right bottom 7px");
		   if(!$('.errorInfo a').hasClass('wxx1')){
			$(".errorInfo").append('<a href="javascript:void(0);" class="wxx1"><img src="../style/image/error.png"/><span>报备月份不能为空</span></a>');
		   }
	  }else{
		$(".wxx1").remove();
	  }
	}else if(liType=="无进货行为备案"){
	  if(wjh==""){
		$("#wjh").parent().parent().parent(".inputstyle").addClass("fontRed");
		$("#wjh").parent().parent().parent().parent(".input-init").addClass("errorRed");
		$(".errorInfo").show();
		$(".sel-wrap input").css("background","url(../style/image/dropdowns-error-btn-default.png) no-repeat right bottom 7px");
		   if(!$('.errorInfo a').hasClass('wjh1')){
			$(".errorInfo").append('<a href="javascript:void(0);" class="wjh1"><img src="../style/image/error.png"/><span>报备月份不能为空</span></a>');
		   }
	  }else{
		$(".wjh1").remove();
	  }
	}else if(liType=="停产/停业备案"){
	  if(tc==""){
		$("#tc").parent().parent().parent(".inputstyle").addClass("fontRed");
		$("#tc").parent().parent().parent().parent(".input-init").addClass("errorRed");
		$(".errorInfo").show();
		$(".sel-wrap input").css("background","url(../style/image/dropdowns-error-btn-default.png) no-repeat right bottom 7px");
		   if(!$('.errorInfo a').hasClass('tc1')){
			$(".errorInfo").append('<a href="javascript:void(0);" class="tc1"><img src="../style/image/error.png"/><span>停产/停业日期不能为空</span></a>');
		   }
	  }else{
		$(".tc1").remove();
	  }
   }else if(liType=="企业转让备案"){
	  if(srr==""){
	  	$(".srr").parent(".inputstyle").addClass("fontRed");
		$(".srr").parent().parent(".input-init").addClass("errorRed");
		$(".errorInfo").show();
		   if(!$('.errorInfo a').hasClass('srr1')){
			$(".errorInfo").append('<a href="javascript:void(0);" class="srr1"><img src="../style/image/error.png"/><span>受让人姓名不能为空</span></a>');
		   }
	  }else{
		$(".srr1").remove();
	  }
	  if(phone==""){
	  	$(".phone1").remove();
	  	$(".phone").parent(".inputstyle").addClass("fontRed");
		$(".phone").parent().parent(".input-init").addClass("errorRed");
		$(".errorInfo").show();
		   if(!$('.errorInfo a').hasClass('phone1')){
			$(".errorInfo").append('<a href="javascript:void(0);" class="phone1"><img src="../style/image/error.png"/><span>受让人手机号不能为空</span></a>');
		   }
	  }else if(isPhoneNo(phone)==false){
	  	$(".phone1").remove();
	  	$(".phone").addClass("fontRed").parent(".inputstyle").addClass("fontRed");
		$(".phone").parent().parent(".input-init").addClass("errorRed");
		$(".errorInfo").show();
		   if(!$('.errorInfo a').hasClass('phone1')){
			$(".errorInfo").append('<a href="javascript:void(0);" class="phone1"><img src="../style/image/error.png"/><span>受让人手机号格式错误</span></a>');
		   }
	  }else{
	  	$(".phone1").remove();
	  }
	  if(idCard==""){
	  	$(".idCard1").remove();
	  	$(".idCard").parent(".inputstyle").addClass("fontRed");
		$(".idCard").parent().parent(".input-init").addClass("errorRed");
		$(".errorInfo").show();
		   if(!$('.errorInfo a').hasClass('idCard1')){
			$(".errorInfo").append('<a href="javascript:void(0);" class="idCard1"><img src="../style/image/error.png"/><span>受让人身份证号不能为空</span></a>');
		   }
	  }else if(isCardNo(idCard)==false){
	  	$(".idCard1").remove();
	  	$(".idCard").addClass("fontRed").parent(".inputstyle").addClass("fontRed");
		$(".idCard").parent().parent(".input-init").addClass("errorRed");
		$(".errorInfo").show();
		   if(!$('.errorInfo a').hasClass('idCard1')){
			$(".errorInfo").append('<a href="javascript:void(0);" class="idCard1"><img src="../style/image/error.png"/><span>受让人身份证号格式错误</span></a>');
		   }
	  }else{
	  	$(".idCard1").remove();
	  }
  }
})
 /**输入受让人信息**/
$('input.srr').keyup(function () {
    $("#srr1").text($(".srr").val());
});
$('input.phone').keyup(function () {
    $("#phone1").text($(".phone").val());
});
$('input.idCard').keyup(function () {
    $("#idCard1").text($(".idCard").val());
});

$(".zr1").text($("#zr").val());
}

// 验证手机号
function isPhoneNo(phone) { 
 var pattern = /^1[34578]\d{9}$/; 
 return pattern.test(phone); 
}
 
// 验证身份证 
function isCardNo(idCard) { 
 var pattern = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/; 
 return pattern.test(idCard); 
}

