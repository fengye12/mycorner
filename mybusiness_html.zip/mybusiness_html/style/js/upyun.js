/*
 * @Author: anchen
 * @Date:   2017-08-28 11:05:28
 * @Last Modified by:   anchen
 * @Last Modified time: 2017-10-13 18:10:48
 */
// var systemUrl="https://wxqy.myspzh.com";
function Upyun(options) {
  this.bucket = "meyoungpc"; //又拍云服务空间
  this.operator = "meyoungpc"; //操作员
  this.getSignatureUrl = systemUrl + "/upyun/getSignature";
}
//上传图片
Upyun.prototype.upload = function(options) {
  var self = this
  var date = (new Date()).toGMTString()
  var imgpath = GetReDate("{$Year}/{$Month}/{$Day}/");
  var fname = "/shianyun_qy/" + imgpath + GetReDate("{$Year}{$Month}{$Day}{$Hours}{$Minutes}{$Seconds}{$Ms}{$Ran}") + options.localName;
  var opts = {
    'save-key': window.encodeURIComponent(fname),
    bucket: self.bucket,
    expiration: Math.round(new Date().getTime() / 1000) + 3600,
    date: date
  }
  var policy = window.btoa(JSON.stringify(opts))
    // var policy =  JSON.stringify(opts)
    // var form_api_secret = 'ZDu7KK+/IZbe58DDm4/lRxALgmk=';
  var form_api_secret = 'EUJtsYiCAz9eWmcBgeaLq7w+kM0='; //直接暴露不安全区后台请求签名
  var signature = md5(policy + '&' + form_api_secret);
  // self.getSignature(dataup, function (err, signature) {
  if (signature) {
    // if (err) {
    //   options.fail && options.fail(err)
    //   options.complete && options.complete(err)
    //   return
    // }
    var data = new FormData();
    data.append('policy', policy);
    data.append('signature', signature);
    data.append('file', options.localPath);
    // console.log(`https://v0.api.upyun.com/${self.bucket}`)
    $.ajax({
      type: 'POST',
      url: 'https://v0.api.upyun.com/' + self.bucket,
      data: data,
      cache: false,
      processData: false,
      contentType: false,
      beforeSend: options.beforeSend,
      success: options.success,
      complete: options.complete,
      error: options.fail
    });
  }
}

//获取签名
Upyun.prototype.getSignature = function(data, cb) {
  $.ajax({
    type: 'POST',
    url: this.getSignatureUrl,
    data: data,
    beforeSend: function(XMLHttpRequest) {
      //ShowLoading();
    },
    success: function(res) {
      cb(null, res.data.signature)
    },
    complete: function(XMLHttpRequest, textStatus) {
      //HideLoading();
    },
    error: function(err) {
      cb(err)
    }
  });
}

function GetImageUrl(imsrc) {
  // return  "https://meyoung.b0.upaiyun.com" + imsrc;//小程序
  return "http://meyoungpc.b0.upaiyun.com/" + imsrc; //企业端
  // return  "https://qy.myspzh.com" + imsrc;

}