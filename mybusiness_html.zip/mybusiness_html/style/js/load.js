var PageISLock = 0;
function PageLockOper() {
	if(PageISLock == 0) {
		$(".neirong").css("display", "");
		$(".loadimage").css("display", "none");
	} else {
		$(".neirong").css("display", "none");
		$(".loadimage").css("display", "");
	}
}

PageLockOper();