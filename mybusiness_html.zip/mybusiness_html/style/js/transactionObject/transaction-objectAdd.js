var a1="a13";var a2="a1300";
$(function(){
	getActiveN("a13","a1300");
	upyunF();
})

var imgPath=[];
  var upyun = new Upyun({});
  function upLoad(file){
  //	if(file!=undefined||file!=null){
      layer.msg('图片上传中，请稍后');
    //  $("#addIcon").hide();
  // }
   upyun.upload({
     localPath: file,
     localName:file.name,
     success: function (res) {
      //layer.closeAll();
      var picJson=JSON.parse(res);
      console.log(picJson);
      var imgurl=GetImageUrl(picJson.url);
      console.log(imgurl)
      imgPath.push(imgurl);
      $("#imgBox").append('<a href="javascript:void(0)" class="img-list" title="资质证件"><img src="'+imgurl+'" class="img" alt="资质证件"><img src="../style/image/delete-btn.png" class="img-delete"></a>');
      if(imgPath.length>2){
        $("#addIcon").hide();
      }
    },
    fail: function (errMsg) {
      layer.msg('图片上传失败');
    },
    complete: function () {
   console.log('complete');
 }
  })
  }
  // 删除图片
 function upyunF(){
  var filesArray=[];
  $("#imgBox").on('click', '.img-delete', function(event) {
    var self=this;
    var deleteImg=$("#imgBox .img-delete");
    console.log("delete");
    $.each(deleteImg, function(index, val) {
      if(val==self){
       $(self).closest('.img-list').remove();
       imgPath.del(index);
       console.log(imgPath);
       if(imgPath.length<3){
         $("#addIcon").show();
       }
	   return false;      
     }
   });
  });
  }

//删除指定下标的数组
Array.prototype.del=function(index){
  if(isNaN(index)||index>=this.length){
    return false;
  }
  for(var i=0,n=0;i<this.length;i++){
    if(this[i]!=this[index]){
      this[n++]=this[i];
    }
  }
  this.length-=1;
};
/**省市区县街道**/
 $('.selectArea').areaSelection({
      animateFunction: "toggle",
      //动画效果
      callback: "",
      //回调函数
      province_code: "",
      //默认城市的code
      city_code: "",
      //默认城市的code
      area_code: "",
      //默认城市的code
      street_code: "",
      //默认城市的code
      callback: function() {
        console.log("callback")
      }
    });
// 验证手机号
function isPhoneNo(phone) { 
 var pattern = /^1[34578]\d{9}$/; 
 return pattern.test(phone); 
}
//验证电话
function isTelNo(phone){
  var pattern = /^((0\d{2,3})-?)?\d{7,8}$/;
  return pattern.test(phone);
}
// 验证商品条码是否是字母和数字
function isLicence(licence) { 
 var pattern = /^[A-Za-z0-9]+$/; 
 return pattern.test(licence); 
}

//input获取焦点时
$(".compName").on("focus",function(){
		$(this).parents(".inputstyle").removeClass("fontRed").parent(".input-init").removeClass("errorRed");
})
$(".licence").on("focus",function(){
		$(this).removeClass("fontRed").parents(".inputstyle").removeClass("fontRed").parent(".input-init").removeClass("errorRed");
})
$(".phone").on("focus",function(){
		$(this).removeClass("fontRed").parents(".inputstyle").removeClass("fontRed").parent(".input-init").removeClass("errorRed");
})
$(".checkAddress").on("focus",function(){
		$(this).removeClass("fontRed").parent().parents(".inputstyle").removeClass("fontRed").parent(".input-init").removeClass("errorRed");
        $(this).css("background","url(../style/image/select.png) no-repeat right bottom 4px");
})
$(".detailAddress").on("focus",function(){
		$(this).removeClass("fontRed").parents(".inputstyle").removeClass("fontRed").parent(".input-init").removeClass("errorRed");
})
//点击保存,验证输入的信息
$(".important").click(function(){
	console.log($(".errorInfo a").length);
	if($(".errorInfo a").length=="1"){
		$(".errorInfo").hide();
	}
	var compName=$.trim($(".compName").val());
	var licence=$.trim($(".licence").val());
	var phone=$.trim($(".phone").val());
	var checkAddress=$(".checkAddress").val();
	var detailAddress=$.trim($(".detailAddress").val());
	if(licence=="请输入营业执照上的注册号或统一社会信用代码"){
		licence="";
	}
	if(phone=="请输入联系电话"){
		phone="";
	}
	if(checkAddress=="请选择注册地址"){
		checkAddress="";
	}
	if(detailAddress=="请输入详细地址"){
		detailAddress="";
	}
	if(compName==""){
		$(".compName").parent(".inputstyle").addClass("fontRed");
		$(".compName").parent().parent(".input-init").addClass("errorRed");
		$(".errorInfo").show();
		if(!$('.errorInfo a').hasClass('compName1')){
			$(".errorInfo").append('<a href="javascript:void(0);" class="compName1"><img src="../style/image/error.png"/><span>企业名称不能为空</span></a>');
		}
	}else{
		$(".compName1").remove();
	}
	if(licence!=""&&isLicence(licence)==false){
		$(".licence").addClass("fontRed").parent(".inputstyle").addClass("fontRed");
		$(".licence").parent().parent(".input-init").addClass("errorRed");
		$(".errorInfo").show();
		if(!$('.errorInfo a').hasClass('licence1')){
			$(".errorInfo").append('<a href="javascript:void(0);" class="licence1"><img src="../style/image/error.png"/><span>营业执照格式错误</span></a>');
		}
	}else{
		$(".licence1").remove();
	}
	if(phone!=""&&isPhoneNo(phone)==false&&isTelNo(phone)==false){
		$(".phone").addClass("fontRed").parent(".inputstyle").addClass("fontRed");
		$(".phone").parent().parent(".input-init").addClass("errorRed");
		$(".errorInfo").show();
		if(!$('.errorInfo a').hasClass('phone1')){
			$(".errorInfo").append('<a href="javascript:void(0);" class="phone1"><img src="../style/image/error.png"/><span>联系电话格式错误</span></a>');
		}
	}else{
		$(".phone1").remove();
	}
	if(checkAddress!=""&&detailAddress==""){
		$(".detailAddress").addClass("fontRed").parent(".inputstyle").addClass("fontRed");
		$(".detailAddress").parent().parent(".input-init").addClass("errorRed");
		$(".errorInfo").show();
		if(!$('.errorInfo a').hasClass('detailAddress1')){
			$(".errorInfo").append('<a href="javascript:void(0);" class="detailAddress1"><img src="../style/image/error.png"/><span>详细地址不能为空</span></a>');
		}
	}else{
		$(".detailAddress1").remove();
	}
	if(checkAddress==""&&detailAddress!=""){
		$(".checkAddress").addClass("fontRed").parent(".inputstyle").addClass("fontRed");
		$(".checkAddress").parent().parent().parent(".input-init").addClass("errorRed");
		$(".checkAddress").css("background","url(../style/image/dropdowns-error-btn-default.png) no-repeat right bottom 4px");
		$(".errorInfo").show();
		if(!$('.errorInfo a').hasClass('checkAddress1')){
			$(".errorInfo").append('<a href="javascript:void(0);" class="checkAddress1"><img src="../style/image/error.png"/><span>请选择注册地址</span></a>');
		}
	}else{
		$(".checkAddress1").remove();
	}
	if((checkAddress!=""&&detailAddress!="")||(checkAddress==""&&detailAddress=="")){
		$(".checkAddress").removeClass("fontRed").parent().parents(".inputstyle").removeClass("fontRed").parent(".input-init").removeClass("errorRed");
      $(".checkAddress").css("background","url(../style/image/select.png) no-repeat right bottom 4px");
	}
})
