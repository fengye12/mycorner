
var systemUrl="";
// http://wx.myfda.cn:8054
var outUrl=systemUrl+"/uploadfile/incuserfile/";//导出
var inUrl=systemUrl+"/request";//导入
var tplUrl=systemUrl+"/uploadfile/templates";//下载模板地址
//服务器返回json对象
function ojson(){
    this.action = "";
    this.status = 0;
    this.info = "";
    this.md5ver = "";
    this.paramcentcount = 0;
    this.param = new Array();
};

//服务器请求json对象
function webjson(act){
    this.url = systemUrl+"/request/action";
    this.action = act;
    this.time = "";
    this.sessid = "";
    this.rannum = "";
    this.md5ver = "";
    this.param = new Array();
};

//新增param键值
webjson.prototype.AddParam=function(keyname, keyval) {
    var pars = "";
    if (this.param.length <= 0) {
        this.param[0] = "";
    } else {
        pars = this.param[this.param.length - 1];
    }
    if (pars != "") {
        pars += ","
    }
    pars += '"' + keyname + '":"' + escape(keyval) + '"';
    this.param[this.param.length - 1] = pars;
};

//指定索引param行新增param键值
webjson.prototype.AddParamAt=function(keyname, keyval, pindex) {
    var pars = "";
    if (this.param.length <= 0) {
        this.param[0] = "";
        pindex = 0;
    } else {
        if (pindex < this.param.length) {
            pars = this.param[pindex];
        } else {
            pars = this.param[this.param.length - 1];
            pindex = this.param.length - 1;
        }
    }
    if (pars != "") {
        pars += ","
    }
    pars += '"' + keyname + '":"' + escape(keyval) + '"';
    this.param[pindex] = pars;
};

//新增param行
webjson.prototype.AddParamLine=function() {
    if (this.param.length <= 0) {
        this.param[0] = "";
    } else {
        this.param[this.param.length] = "";
    }
};

//返回Json字符串值
webjson.prototype.GetJsons=function() {
    var jstr = "";
    jstr += '"action":"' + this.action + '"';
    jstr += ',"time":"' + escape(this.time) + '"';
    jstr += ',"sessid":"' + escape(this.sessid) + '"';
    jstr += ',"rannum":"' + escape(this.rannum) + '"';
    jstr += ',"md5ver":"' + escape(this.md5ver) + '"';
    var pint = 0;
    var pars = "";
    for (var i = 0; i < this.param.length; i++) {
        var ps = Trim(this.param[i]);
        if (ps != "") {
            if (pars != "") {
                pars += ",";
            }
            pars += "{" + ps + "}";
            pint += 1;
        }
    }
    if (pint > 0) {
        jstr += ',"param":[' + pars + ']';
    } else {
        jstr += ',"param":[]';
    }
    return "{" + jstr + "}";
};

webjson.prototype.GetUrl=function(){
    return this.url+"?rannum="+GetReDate();
};

function GetOjson(jos) {
    var sobj = jos;
    var os = new ojson();
    if(sobj.hasOwnProperty("action")){
        os.action=sobj.action;
    }
    if(sobj.hasOwnProperty("status")){
        os.status=sobj.status;
    }
    if(sobj.hasOwnProperty("info")){
        os.info=UnTrim(sobj.info);
    }
    if(sobj.hasOwnProperty("md5ver")){
        os.md5ver=UnTrim(sobj.md5ver);
    }
    if(sobj.hasOwnProperty("paramcentcount")){
        os.paramcentcount=sobj.paramcentcount;
    }
    if(sobj.hasOwnProperty("param")){
        if(isArray(sobj.param)){
            os.param=sobj.param;
            for(var i=0; i < os.param.length; i++){
                for (var key in os.param[i]) {
                    os.param[i][key] = UnTrim(os.param[i][key]);
                }
            }
        }
    }
    return os;
};

function WebRequestAsync(wjson, fun){
    var myJson = wjson.GetJsons();
    console.log(myJson);
    $.ajax({
        async: true,
        url: wjson.url,
        data: myJson,
        method:'POST',
        contentType:'application/json;charset=UTF-8',
        success: function(res, tstatus, jqxhr) {
            console.log(res);
            fun(res);
        },
        error: function(jqxhr, tstatus, errmsg){
            console.log(errmsg);
        }
    });
}

function WebRequest(wjson){
    var myJson = wjson.GetJsons();
    console.log(myJson);
    var res = $.ajax({
        async: false,
        url: wjson.url,
        data: myJson,
        method:'POST',
        contentType:'application/json;charset=UTF-8'
    }).responseText;
    console.log(res);
    return res;
}

// 前端图片预览，会被隐藏掉，大小不用考虑
function previewImage(file)
{
    var MAXWIDTH  = 218;     //用来显示上传图片的宽度
    var MAXHEIGHT = 158;     //用来显示上传图片的高度
    var div = document.getElementById('preview');
    if (file.files && file.files[0])
    {
      filesArray.push(file.files[0]);
      console.log(filesArray)
      div.innerHTML = '<img id=imghead>';
      var img = document.getElementById('imghead');
      img.onload = function(){
        var rect = clacImgZoomParam(MAXWIDTH, MAXHEIGHT, img.offsetWidth, img.offsetHeight);
        img.width = rect.width;
        img.height = rect.height;
        // img.style.marginLeft = rect.left+'px';
        // img.style.marginTop = rect.top+'px';
      };
      var reader = new FileReader();
      reader.onload = function(evt){img.src = evt.target.result;
        $("#imgBox").append('<a href="javascript:void(0)" class="img-list imgDiv" title="资质证件"><img src="'+evt.target.result+'" class="img" alt="资质证件"><img src="../style/image/png-delete.png" class="img-delete"></a>')
      };
      console.log($("#imgBox .img-list "))
      if($("#imgBox .img").length>1){
        $("#preview").next('.fileInput').css('display', 'none');
      }else{
        $("#preview").next('.fileInput').css('display', 'inline-block');
      }
      reader.readAsDataURL(file.files[0]);
    }
    else
    {
      var sFilter='filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod=scale,src="';
      file.select();
      var src = document.selection.createRange().text;
      div.innerHTML = '<img id=imghead>';
      var img = document.getElementById('imghead');
      img.filters.item('DXImageTransform.Microsoft.AlphaImageLoader').src = src;
      var rect = clacImgZoomParam(MAXWIDTH, MAXHEIGHT, img.offsetWidth, img.offsetHeight);
      status =('rect:'+rect.top+','+rect.left+','+rect.width+','+rect.height);
      div.innerHTML = "<div id=divhead style='width:"+rect.width+"px;height:"+rect.height+"px;margin-top:"+rect.top+"px;margin-left:"+rect.left+"px;"+sFilter+src+"\"'></div>";
    }


  }
  function clacImgZoomParam( maxWidth, maxHeight, width, height ){
    var param = {top:0, left:0, width:width, height:height};
    if( width>maxWidth || height>maxHeight )
    {
      rateWidth = width / maxWidth;
      rateHeight = height / maxHeight;
      if( rateWidth > rateHeight )
      {
        param.width =  maxWidth;
        param.height = Math.round(height / rateWidth);
      }else
      {
        param.width = Math.round(width / rateHeight);
        param.height = maxHeight;
      }
    }
    param.left = Math.round((maxWidth - param.width) / 2);
    param.top = Math.round((maxHeight - param.height) / 2);
    return param;
  }

//删除指定下标的数组
Array.prototype.del=function(index){
  if(isNaN(index)||index>=this.length){
    return false;
  }
  for(var i=0,n=0;i<this.length;i++){
    if(this[i]!=this[index]){
      this[n++]=this[i];
    }
  }
  this.length-=1;
};
function GetQueryString(name)
{
     var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
     var r = window.location.search.substr(1).match(reg);
     if(r!=null)return  unescape(r[2]); return null;
}
