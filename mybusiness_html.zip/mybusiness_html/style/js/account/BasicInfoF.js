
  $(document).ready(function () {
    var textBookObj= document.getElementById("textBook");
      var height=textBookObj.offsetHeight;
      $('#slimtest2').slimScroll({ size: '5px', height: height,color:'#999'});

  });
        // 营业执照提示
    $(".iconIfnfo").click(function(){
      $(".fillTip").show();
    });
    $(".fillTip .closeBtn").click(function(){
      $(".fillTip").hide();
    });
      //城市选择器
    $('.selectArea').areaSelection({
      animateFunction: "toggle",
      //动画效果
      callback: "",
      //回调函数
      province_code: "",
      //默认城市的code
      city_code: "",
      //默认城市的code
      area_code: "",
      //默认城市的code
      street_code: "",
      //默认城市的code
      callback: function() {
        console.log("callback")
      }
    });
    // 切换企业类型
     $("#ctype").select3({
      'animate':'slide',
        'value':"1",
        callback:function(obj){
          console.log(obj)
           // var obj=$("#ssselS select");
           //触发change事件
          changeCtype(obj);
        }
    });
function changeCtype(obj){
    obj.change(function(){
        if($(this).val()==0){

        }
      });
}
     // 切换监管单位
      $("#fatherCom").select3({
       'animate':'slide',
         'value':"1",
         callback:function(obj){
           console.log(obj)
            // var obj=$("#ssselS select");
            //触发change事件
           // change(obj);
         }
     });

  //上传图片
  var imgPath=[];

  var upyun = new Upyun({});
  function upLoad(file){
    layer.msg('图片上传中，请稍后')
   upyun.upload({
     localPath: file,
     localName:file.name,
     success: function (res) {
      layer.closeAll();
      var picJson=JSON.parse(res);
      console.log(picJson);
      var imgurl=GetImageUrl(picJson.url);
      console.log(imgurl)
      imgPath.push(imgurl);
      $("#imgBox").append('<a href="javascript:void(0)" class="img-list" title="营业执照"><img src="'+imgurl+'" class="img" alt="营业执照"><img src="../style/image/delete-btn.png" class="img-delete"></a>');
      if(imgPath.length>2){
        $("#addIcon").hide();
      }
    },
    fail: function (errMsg) {
      layer.msg('图片上传失败')
    },
    complete: function () {
     console.log('complete')
   }
  })
  }
  // 删除图片
  var filesArray=[];
  $("#imgBox").on('click', '.img-delete', function(event) {
    var self=this;
    var deleteImg=$("#imgBox .img-delete");
    $.each(deleteImg, function(index, val) {
      if(val==self){
       $(self).closest('.img-list').remove();
       imgPath.del(index);
       console.log(imgPath);
       if(imgPath.length<3){
         $("#addIcon").show();
       }
       return false;
     }
   });
  });
//验证
function confirm(){
  var formDataObj=$(".formData");
   $(".errContent").find('.errTip').remove();
  formDataObj.find('.input-init').removeClass('errMsg');
  var listObj=formDataObj.find(".inputstyle input");
  console.log(listObj)
  var CNameObj=listObj.eq(0);//企业名称
  var BCodeObj=listObj.eq(1);//营业执照*
  var legalObj=listObj.eq(2);//法定代表人
  var Raddress=listObj.eq(3);//注册地址
  var RADetail=listObj.eq(4);//注册详细地址
  var CType=$("#ctype select").val();//企业类型
  var contacts=listObj.eq(5);//联系人
  var phone=listObj.eq(6);//联系电话
  var Baddress=listObj.eq(7);//生产/经营地址
  // var BAdetail=listObj.eq(8);//生产/经营地址详细
  var fatherCom=$("#fatherCom select").val();//监管单位
  validate(CNameObj,0);
  validate(BCodeObj,1);
  validate(legalObj,2);
  validate(Raddress,3);

  validate(contacts,5);
  validate(phone,6);
  validate(Baddress,7);
  if($(".errContent .errTip").length==0){
    $(".errContent").hide();
    alert('成功');
  }else{
    $(".errContent").show();
  }
}

function validate(obj,type){
  var val=$.trim($(obj).val());
 if(type==0){
  // 验证账号
  if(val== ""){
    $(obj).closest('.input-init').addClass('errMsg');
    $(".errContent").append('<p class="errTip">请输入企业名称</p>');
  }
}else if(type==1){
  //验证密码
  if(val== ""){
    $(obj).closest('.input-init').addClass('errMsg');
    $(".errContent").append('<p class="errTip">请输入营业执照</p>');
 }else if(!(/^[A-Za-z0-9-]{0,50}$/).test(val)){
   $(obj).closest('.input-init').addClass('errMsg');
   $(".errContent").append('<p class="errTip">请输入正确营业执照</p>');
 }
}else if(type==2){
  //验证密码
  if(val== ""){
    $(obj).closest('.input-init').addClass('errMsg');
    $(".errContent").append('<p class="errTip">请输入法定代表人</p>');
 }
}else if(type==3){
  //验证密码
  if(val== ""){
    $(obj).closest('.input-init').addClass('errMsg');
    $(".errContent").append('<p class="errTip">请选择注册地址</p>');
 }
}else if(type==5){
  //验证密码
  if(val== ""){
    $(obj).closest('.input-init').addClass('errMsg');
    $(".errContent").append('<p class="errTip">请输入联系人</p>');
 }
}else if(type==6){
  //验证密码
  if(val== ""){
    $(obj).closest('.input-init').addClass('errMsg');
    $(".errContent").append('<p class="errTip">请输入联系电话</p>');
 }
}else if(type==7){
  //验证密码
  if(val== ""){
    $(obj).closest('.input-init').addClass('errMsg');
    $(".errContent").append('<p class="errTip">请选择生产/经营地址</p>');
 }
}
}
