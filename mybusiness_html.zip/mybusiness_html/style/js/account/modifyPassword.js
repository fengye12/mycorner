/*
* @Author: anchen
* @Date:   2017-10-16 14:22:54
* @Last Modified by:   anchen
* @Last Modified time: 2017-10-16 14:23:24
*/
  function confirm(){
    var formDataObj=$(".formData");
    var phone=formDataObj.find("#phone");
    var verCode=formDataObj.find("#verCode");
    var password=formDataObj.find("#password");
    var comPassword=formDataObj.find("#comPassword");
    validate(phone,0);
    validate(verCode,1);
     validate(password,2);
      validate(comPassword,3);
    if(formDataObj.find(".tip").length==0){
      window.open("changeCompany.html","_self")
    }

  }
  // 表单验证
  function validate(obj,type){
     var val=$.trim($(obj).val());
   if(type==0){
    //验证手机号
    if(val!= "" && /^1[34578]\d{9}$/.test(val)){
     $(obj).closest('li').removeClass('error').find('.tip').remove();
     return true;
    }else{
        $(obj).closest('li').addClass('error');
        $(obj).closest('li').find('.tip').remove();
        $(obj).closest('li').append('<p class="tip">请输入11位手机号</p>');
     return false;
    }
  }else if(type==1){
    // 验证验证码
   if(val!= ""){
    $(obj).closest('li').removeClass('error').find('.tip').remove();
    return true;
   }else{
    $(obj).closest('li').addClass('error');
    $(obj).closest('li').find('.tip').remove();
    $(obj).closest('li').append('<p class="tip">请输入验证码</p>');
    return false;
   }
  }else if(type==2){
    console.log(val.length)
    // 验证密码
   if(val!= "" && val.length>5 && val.length<20){
    $(obj).closest('li').removeClass('error').find('.tip').remove();
    if($("#comPassword").val() !="" && val == $("#comPassword").val()){
      $(obj).closest('li').next('li').removeClass('error').find(".tip").remove();

    }
    return true;
   }else{

      $(obj).closest('li').addClass('error');
      $(obj).closest('li').find('.tip').remove();
      $(obj).closest('li').append('<p class="tip">请输入6-20密码</p>');
      return false;


   }
  }else if(type==3){
    // 验证确认密码
   if(val!= "" && val==$("#password").val()){
    $(obj).closest('li').removeClass('error').find('.tip').remove();
    return true;
   }else{
    if(val==""){
      $(obj).closest('li').addClass('error');
      $(obj).closest('li').find('.tip').remove();
      $(obj).closest('li').append('<p class="tip">请输入确认密码</p>');
      return false;
    }else{
      $(obj).closest('li').addClass('error');
      $(obj).closest('li').find('.tip').remove();
      $(obj).closest('li').append('<p class="tip">两次输入密码不一致</p>');
      return false;
    }

   }
  }
  }
  //发送验证码
  function sendCode(obj){
    if(validate($("#phone"),0)){
      // 发送成功。触发time
      time(obj);
    }
  }
  var wait=60;
  function time(o) {
      if (wait == 0) {
           $(o).attr('onclick', 'sendCode(this)');
          o.text="发送验证码";
          wait = 60;
      } else {
          $(o).attr('onclick', '');
          o.text=wait+"s";
          wait--;
          setTimeout(function() {
              time(o)
          },
          1000)
      }
    }

    function on_return(e){
        var e=window.event || e;
         var k = e.keyCode || e.which;
     if(k==13){
     confirm();//登录验证
    }
    }
