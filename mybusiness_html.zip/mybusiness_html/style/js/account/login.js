/*
* @Author: anchen
* @Date:   2017-10-16 14:22:54
* @Last Modified by:   anchen
* @Last Modified time: 2017-10-16 14:23:24
*/

function confirm(){
  var formDataObj=$(".formData");
  var account=formDataObj.find("#account");
  var password=formDataObj.find("#password");
  validate(account,0);
  validate(password,1);
  if(formDataObj.find('.tip').length==0){
    alert('登陆成功');
    window.location.replace("companyManage.html")
    // window.open('companyManage.html',"_self")
  }
}

function validate(obj,type){
  var val=$.trim($(obj).val());
 if(type==0){
  // 验证账号
  if(val!= ""){
   $(obj).closest('li').removeClass('error').find('.tip').remove();
  }else{
    $(obj).closest('li').addClass('error');
    $(obj).closest('li').find('.tip').remove();
    $(obj).closest('li').append('<p class="tip">请输入账号</p>');
  }
}else if(type==1){
  //验证密码
  if(val!= ""){
  $(obj).closest('li').removeClass('error').find('.tip').remove();
 }else{
  $(obj).closest('li').addClass('error');
  $(obj).closest('li').find('.tip').remove();
  $(obj).closest('li').append('<p class="tip">请输入密码</p>');
 }
}
}
function on_return(e){
    var e=window.event || e;
     var k = e.keyCode || e.which;
 if(k==13){
 confirm();//登录验证
}
}
