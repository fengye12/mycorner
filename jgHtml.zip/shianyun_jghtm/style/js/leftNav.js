//左侧导航html
var navHtml="<div class='left-nav' style='float:left;'>"+
"<a href='javascript:void(0);' class='logo' style='color:#ffffff;font-size:18px;'><img src='../style/image/logo00.png' />"+
"<span>智慧监管</span></a>"+
"<ul>"+
"<li class='list-title'>"+
"<i class='keyId'>a10</i>"+
"<a href='home.html' class='nav-title father-a'><img src='../style/image/kzt.png' style='margin-left:-11px;' class='kzt'/><span>控制台</span></a>"+
"<ul class='list-cont'>"+
"<li style='height:0;line-height:1;'>"+
"<i class='keyId'>a1000</i>"+
"<a href='#' style='height:0;line-height:1;'><i></i></a>"+
"</li>"+
"</ul>"+
"</li>"+
"<li class='list-title'>"+
"<i class='keyId'>a11</i>"+
"<img src='../style/image/jcda.png' class='jcda'/><a href='javascript:void(0);' class='nav-title father-a'><span>基础信息</span><i class='up-down'></i></a>"+
"<ul class='list-cont'>"+
"<li>"+
"<i class='keyId'>a1100</i>"+
"<a href='Enterprise_archives.html' class='child-a'><b class='leftRad'></b>企业档案<i></i></a>"+
"</li>"+
"<li>"+
"<i class='keyId'>a1101</i>"+
"<a href='Food_archives.html' class='child-a'><b class='leftRad'></b>食品档案<i></i></a>"+
"</li>"+
"<li>"+
"<i class='keyId'>a1102</i>"+
"<a href='personnel_files.html' class='child-a'><b class='leftRad'></b>人员档案<i></i></a>"+
"</li>"+
// "<li>"+
// "<i class='keyId'>a1102</i>"+
// "<a href='billEntry.html'>人员档案<i></i></a>"+
// "</li>"+
"<li>"+
"<i class='keyId'>a1103</i>"+
"<a href='ReportedToTheStandingBook.html' class='child-a'><b class='leftRad'></b>台账报备<i></i></a>"+
"</li>"+
"<li>"+
"<i class='keyId'>a1105</i>"+
"<a href='billList.html' class='child-a'><b class='leftRad'></b>票据报备<i></i></a>"+
"</li>"+
"<li>"+
"<i class='keyId'>a1104</i>"+
"<a href='Onfiling.html' class='child-a'><b class='leftRad'></b>经营备案<i></i></a>"+
"</li>"+
"</ul>"+
"</li>"+
"<li class='list-title'>"+
"<i class='keyId'>a12</i>"+
"<img src='../style/image/tjfx.png' class='tjfx'/><a href='javascript:void(0);' class='nav-title father-a' ><span>统计分析</span><i class='up-down'></i></a>"+
"<ul class='list-cont'>"+
"<li>"+
"<i class='keyId'>a1200</i>"+
"<a href='netStatistics.html' class='child-a'><b class='leftRad'></b>入网统计<i></i></a>"+
"</li>"+
"<li>"+
"<i class='keyId'>a1201</i>"+
"<a href='ReportedCompany.html' class='child-a'><b class='leftRad'></b>报备统计<i></i></a>"+
"</li>"+
// "<li>"+
// "<i class='keyId'>a1202</i>"+
// "<a href='focusStatistics.html' class='child-a'><b class='leftRad'></b>重点关注统计<i></i></a>"+
// "</li>"+
"<li>"+
"<i class='keyId'>a1202</i>"+
"<a href='districtStatistics.html' class='child-a'><b class='leftRad'></b>辖区统计<i></i></a>"+
"</li>"+
"<li>"+
"<i class='keyId'>a1203</i>"+
"<a href='Enterprise_statistic.html' class='child-a'><b class='leftRad'></b>企业分类统计<i></i></a>"+
"</li>"+
"<li>"+
"<i class='keyId'>a1204</i>"+
"<a href='foodStatistics.html' class='child-a'><b class='leftRad'></b>食品分类统计<i></i></a>"+
"</li>"+
"</ul>"+
"</li>"+
"<li class='list-title'>"+
"<i class='keyId'>a13</i>"+
"<img src='../style/image/jkyj.png' class='jkyj'/><a href='javascript:void(0);' class='nav-title father-a' ><span>监控预警</span><i class='up-down'></i></a>"+
"<ul class='list-cont'>"+
"<li>"+
"<i class='keyId'>a1300</i>"+
"<a href='warn_unlicensedList.html' class='child-a'><b class='leftRad'></b>疑似无证经营预警<i></i></a>"+
"</li>"+
"<li>"+
"<i class='keyId'>a1301</i>"+
"<a href='warn_licenseExpiredList.html' class='child-a'><b class='leftRad'></b>许可证过期预警<i></i></a>"+
"</li>"+
"<li>"+
"<i class='keyId'>a1302</i>"+
"<a href='warn_scopeOperationList.html' class='child-a'><b class='leftRad'></b>疑似超范围经营预警<i></i></a>"+
"</li>"+
"<li>"+
"<i class='keyId'>a1303</i>"+
"<a href='warn_unusuallyRecordList.html' class='child-a'><b class='leftRad'></b>异常备案预警<i></i></a>"+
"</li>"+
"<li>"+
"<i class='keyId'>a1304</i>"+
"<a href='warn_suozhengList.html' class='child-a'><b class='leftRad'></b>索证索票监控<i></i></a>"+
"</li>"+
"<li>"+
"<i class='keyId'>a1305</i>"+
"<a href='warn_proEnterprisesList.html' class='child-a'><b class='leftRad'></b>生产企业监控<i></i></a>"+
"</li>"+
"<li>"+
"<i class='keyId'>a1306</i>"+
"<a href='warn_enterprisesTransferList.html' class='child-a'><b class='leftRad'></b>企业转让监控<i></i></a>"+
"</li>"+
"<li>"+
"<i class='keyId'>a1307</i>"+
"<a href='warn_enterpriseInfoChangeList.html' class='child-a'><b class='leftRad'></b>企业信息变更监控<i></i></a>"+
"</li>"+
// "<li>"+
// "<i class='keyId'>a1308</i>"+
// "<a href='warn_publicMonitorList.html' class='child-a'><b class='leftRad'></b>舆情监控<i></i></a>"+
// "</li>"+
"</ul>"+
"</li>"+
/**"<li class='list-title'>"+
"<i class='keyId'>a14</i>"+
"<img src='../style/image/tzgg.png' class='tzgg'/><a href='javascript:void(0);' class='nav-title father-a' ><span>通知公告</span><i class='up-down'></i></a>"+
"<ul class='list-cont'>"+
"</ul>"+
"</li>"+**/
"<li class='list-title'>"+
"<i class='keyId'>a15</i>"+
"<img src='../style/image/xtsz.png' class='xtsz'/><a href='javascript:void(0);' class='nav-title father-a' ><span>系统设置</span><i class='up-down'></i></a>"+
"<ul class='list-cont'>"+
"<li>"+
"<i class='keyId'>a1500</i>"+
"<a href='sys_account.html' class='child-a'><b class='leftRad'></b>账号<i></i></a>"+
"</li>"+
"<li>"+
"<i class='keyId'>a1501</i>"+
"<a href='sys_OrganInfo.html' class='child-a'><b class='leftRad'></b>机关信息<i></i></a>"+
"</li>"+
"<li>"+
"<i class='keyId'>a1502</i>"+
"<a href='sys_maintain.html' class='child-a'><b class='leftRad'></b>辖区数据维护<i></i></a>"+
"</li>"+
"<li>"+
"<i class='keyId'>a1503</i>"+
"<a href='feedbackSuggestion.html' class='child-a'><b class='leftRad'></b>反馈建议<i></i></a>"+
"</li>"+
"</ul>"+
"</li>"+
"</ul>"+
"<img src='../style/image/sq.png' class='qh'>"+
"</div>"+
"<div class='header-nav'>"+
"<a href='home.html' class='com-name'><i id='Faorgan'></i></a>"+
"<div class='right-num'>"+
"<span class='user-name'id='modefiy2'></span>"+
"<div class='loginMessage'>"+
"<div class='info1' id='modify'><span class='user' style='cursor: pointer;'></span><a class='login-out'>修改个人信息</a></div>"+
"<div style='text-align:left;margin-left:18px;' class='info2' id='login-out'><span class='out' style='cursor: pointer;'></span><a class='login-out'>退出</a></div>"+
"</div>"+
"</div>"+
"</div>"
// 写入导航
document.write(navHtml);
//当前导航选中
function getActiveN(paret,activeN){
	var listTitle=$('.left-nav .list-title');
	listTitle.each(function(index, el) {
		if($(this).find(".keyId").eq(0).text()==paret){
			$(this).siblings().children(".nav-title").removeClass("down-active");
			$(this).children(".nav-title").addClass("down-active");
			$(this).children().find(".list-cont li").removeClass("active1");
			$(this).children().find(".list-cont a").removeClass("active2");
			$(this).children().find(".list-cont b").removeClass("active3");
			$(this).siblings().children().find(".list-cont li").removeClass("active1");
			$(this).siblings().children().find(".list-cont a").removeClass("active2");
			$(this).siblings().children().find(".list-cont b").removeClass("active3");
			$(this).siblings().find(".list-cont").hide();
			$(this).find(".list-cont li").each(function(index, el) {
				if($(this).children(".keyId").text()==activeN){
					$(this).closest('.list-cont').show();
					$(this).addClass("active1");
	                $(this).siblings().removeClass("active1");
	                $(this).children(".child-a").addClass("active2");
	                $(this).siblings().children(".child-a").removeClass("active2");
	                $(this).children().find(".leftRad").addClass("active3");
	                $(this).siblings().children().find(".leftRad").removeClass("active3");
	                $(this).parents("ul").slideDown(100).children('li');
				}
			});
		}
	});
}
function autoH(){//自动左右高度
	var wh=$(window).height();
	$(".left-nav").height(wh);
	$(".left-nav").css({'position':'fixed'});
}

// 屏幕尺寸变化计算高度
$(window).resize(function() {
	autoH();
});

$(function(){
	autoH();
	//存储用户名
	var user=$.cookie('username');
	var dept_name=$.cookie('dept_name');
	// var user=user;
	if(user && user!="undefined"){
		$(".user-name").text(user);
		$("#Faorgan").text(dept_name);

	}else{
		$(".user-name").text("请重新登录")
	}
	// 右上角鼠标悬浮移除事件
	$(".right-num").on('mouseover', function(event) {
		$(".loginMessage").show();
	});
	$(".right-num").on('mouseout', function(event) {
		$(".loginMessage").hide();
	});
	//鼠标移入事件和移除事件
	$(".info1").on('mouseenter', function(event) {
		$(this).find("span").addClass('user1');
		$(this).find("a").css("color","#158cea");
	});
	$(".info1").on('mouseleave', function(event) {
		$(this).find("span").removeClass('user1');
		$(this).find("a").css("color","");
	});
	$(".info2").on('mouseenter', function(event) {
		$(this).find("span").addClass('out1');
		$(this).find("a").css("color","#158cea");
	});
	$(".info2").on('mouseleave', function(event) {
		$(this).find("span").removeClass('out1');
		$(this).find("a").css("color","");
	});
	//导航菜单点击事件
	$(".down-active").next("ul").show();
	$('.nav-title').click(function(){
		if($(this).siblings('ul').css('display')=='none'){
			$(this).parent('li').siblings('li').removeClass('inactives');
			$(this).addClass('down-active');
			$(this).parent().siblings('li').children('ul').css('display','none');
			$(this).parent().siblings('li').children('ul').siblings('a').removeClass('down-active');
			$(this).siblings('ul').slideDown(100).children('li');
			if($(this).parents('li').siblings('li').children('ul').css('display')=='block'){
				$(this).parents('li').siblings('li').children('ul').parent('li').children('a').removeClass('down-active');
				$(this).parents('li').siblings('li').children('ul').slideUp(100);
			}
		}else{
			//控制自身变成向右箭头
			$(this).removeClass('down-active');
			//控制自身菜单下子菜单隐藏
			$(this).siblings('ul').slideUp(100);
			//控制自身子菜单变成向右箭头
			$(this).siblings('ul').children('li').children('ul').parent('li').children('a').addClass('inactives');
			//控制自身菜单下子菜单隐藏
			$(this).siblings('ul').children('li').children('ul').slideUp(100);

			//控制同级菜单只保持一个是展开的（向下箭头显示）
			$(this).siblings('ul').children('li').children('a').removeClass('down-active');
		}
	})

	//退出登录
	$("#login-out").click(function(){
		var wxjson = new webjson("27");
		var res = WebRequest(wxjson);
		var data = GetOjson(json_parse(res));
		if(data.status == "0"){
		//清除用户id、用户名、自动登录标示uuid
		localStorage.removeItem("uuid");
		// $.cookie('user_id', null, { expires: 30 });
		// $.cookie('user', null, { expires: 30 });
		// $.cookie('departmentid', null, { expires: 30 });
		// $.cookie('dept_name', null, { expires: 30 });
		// $.cookie('username', null, { expires: 30 });
		// $.cookie('user_type', null, { expires: 30 });
		// $.cookie('user', null, { expires: 30 });
		clearAllCookie();
		function clearAllCookie() {
                var keys = document.cookie.match(/[^ =;]+(?=\=)/g);
                if(keys) {
                    for(var i = keys.length; i--;)
                        document.cookie = keys[i] + '=0;expires=' + new Date(0).toUTCString()
                }
            }
		window.location.replace("index.html?loginOut=true");//禁止浏览器后退
		}else if(data.status==9){//超时登录
			window.location.href="index.html?loginOut=true";
		}else{
			layer.msg(data.info);
		}
	});

})
//修改个人信息跳转
$("#modify").on('click',function(event) {
	window.open("ModifyPersonalInformation.html?current1="+a1+"&current2="+a2,'_self')

});
//修改个人信息跳转
$("#modefiy2").on('click',function(event) {
	window.open("ModifyPersonalInformation.html?current1="+a1+"&current2="+a2,'_self')

});

/**绑定鼠标事件**/
$(".list-title").mouseenter(function(){
	$(this).children().find(".kzt").attr("src","../style/image/kzt1.png");
	$(this).children().find("span").css("color","#158cea");
})
$(".list-title").mouseleave(function(){
	$(this).children().find(".kzt").attr("src","../style/image/kzt.png");
	$(this).children().find("span").css("color","#ffffff");
})
$(".list-title").mouseenter(function(){
	$(this).children(".jcda").attr("src","../style/image/jcda1.png");
})
$(".list-title").mouseleave(function(){
	$(this).children(".jcda").attr("src","../style/image/jcda.png");
})
$(".list-title").mouseenter(function(){
	$(this).children(".tjfx").attr("src","../style/image/tjfx1.png");
})
$(".list-title").mouseleave(function(){
	$(this).children(".tjfx").attr("src","../style/image/tjfx.png");
})
$(".list-title").mouseenter(function(){
	$(this).children(".jkyj").attr("src","../style/image/jkyj1.png");
})
$(".list-title").mouseleave(function(){
	$(this).children(".jkyj").attr("src","../style/image/jkyj.png");
})
$(".list-title").mouseenter(function(){
	$(this).children(".tzgg").attr("src","../style/image/tzgg1.png");
})
$(".list-title").mouseleave(function(){
	$(this).children(".tzgg").attr("src","../style/image/tzgg.png");
})
$(".list-title").mouseenter(function(){
	$(this).children(".xtsz").attr("src","../style/image/xtsz1.png");
})
$(".list-title").mouseleave(function(){
	$(this).children(".xtsz").attr("src","../style/image/xtsz.png");
})

/**设置菜单收起的点击事件**/
$("img.qh").click(function(){
	$(this).toggleClass("qhsq");
	//$(this).addClass("qhsq");
	if($(".left-nav").hasClass("nav-close")){
		$(".left-nav").removeClass("nav-close");
		$(".header-nav").css({"margin-left":"180px","transition": "all .1s linear"});
		$(".warp-content").css({"margin-left":"180px","transition": "all .1s linear"});
		$(".left-nav>ul>li:first-child").css({"width":"160px","margin-left":"10px","padding-left":"0","border-bottom":"1px solid #404D6E"});
	    $(".list-title>img").css({"margin-left":"10px","transition": "all .1s linear"});
	    $(".kzt").css({"margin-left":"-10px","transition": "all .1s linear"});
	}else{
		$(".left-nav").addClass("nav-close");
		$("img.kzt").css("left","-5px");
		$(".left-nav>ul>li:first-child").css("border-bottom","1px solid #404D6E");
		$(".header-nav").css({"margin-left":"50px","transition": "all .1s linear"});
		$(".warp-content").css({"margin-left":"50px","transition": "all .1s linear"});
		$(".left-nav>ul>li:first-child").css({"width":"50px","margin-left":"0","padding-left":"10px","border-bottom":"1px solid #404D6E"});
		$(".list-cont").css("display","none");
		$(".nav-title").removeClass("down-active");
		$(".list-title>img").css({"margin-left":"15px","transition": "all .1s linear"});
		$(".kzt").css({"margin-left":"-6px","transition": "all .1s linear"});
	}
})

