var saveCodes="",packageModes="",proPlaces="",goodName="",pindex = "1",psize = "20",pname1="",zoneCode="",cId="",type="",goodsCode1="",keyWords="",foodType="";
var departmentid="";/**当前监管局id**/
var cheType="";/**添加食品分类的传参**/
var jj=0;/**设置动态生成id的初始值**/
var foodType1="";/**保存食品分类名称**/
var cskey="";/**关注中创建新分类的名称**/
var j=0;
/**分页设置**/
var pcent = new CentPage();
var pcount = ""; //总条数
var ps = pcent.GetCentPage(pindex, pcount, psize);
$("#page").html(ps);
function CentPageOper(spindex) {
	search(cId, zoneCode, departmentid,saveCodes,packageModes,proPlaces,goodName,type,spindex, psize);
}

/**页面加载时**/
$(function() {
	departmentid=$.cookie("departmentid");
	zoneCode=$.cookie("dep_code");
	console.log(departmentid);
	cId = getQueryString("cId"); /**将url中传过来的值进行解码**/
	search(cId, zoneCode, departmentid,saveCodes,packageModes,proPlaces,goodName,type,pindex, psize);
 	getActiveN("a12", "a1204");//当前页标志
 	autoH();
});

/**页面搜索调用的方法**/
function search(cId, zoneCode, departmentid,saveCodes,packageModes,proPlaces,goodName,type,spindex, psize){
	pindex = spindex;
	$("#mySelectS").css("display","none");
	$("table tbody").children().remove();
	$("table tbody").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;'><img src='../style/image/load.gif' alt='' /></td></tr>");
	//$(".gz").css("display","none");
	var wxjson = new webjson("63"); //设置action值
	//新增param键值	
	wxjson.AddParam("departmentid", departmentid);	
	wxjson.AddParam("zoneCode",zoneCode);
	wxjson.AddParam("cId",cId);
	wxjson.AddParam("type", "USERINFO");
	wxjson.AddParam("saveCodes",saveCodes);
	wxjson.AddParam("packageModes",packageModes);
	wxjson.AddParam("proPlaces",proPlaces);
	wxjson.AddParam("goodName",goodName);
	wxjson.AddParam("page_index", pindex);
	wxjson.AddParam("page_size", psize);
	WebRequestAsync(wxjson, searchInfo);
}

function searchInfo(res){
	var html = "";
	var data = GetOjson(json_parse(res));
	console.log(data);
	pcount = data.paramcentcount;
	$(".totalNum1").html("共"+pcount+"条");
	var ps = pcent.GetCentPage(pindex, pcount, psize);
	$("#page").html(ps);
	if(data.status == 0) {
		if(pcount!="0"){
			//$(".gz").css("display","");
			$("#mySelectS").css("display","");
			}else{
			//$(".gz").css("display","none");
			$("#mySelectS").css("display","none");
			}
		for(var i = 0; i < data.param.length; i++){
			var pid="",pname="",barCoce="",zsl="",ysc="",packageMode="";
			pid=data.param[i].goodsCode;
			pname=escape(data.param[i].goodsName);
			barCoce=data.param[i].barCoce;
			ysc=data.param[i].ysc;
			zsl=data.param[i].zsl;
			var ycountry1=escape(data.param[i].proPlace);
			var gz=data.param[i].isAttention;
			if(data.param[i].isAttention=="0"){
				gz="取消关注";
			}else{
				gz="关注";
			}
			sessionStorage.setItem("gz", gz);
			if(zsl=="null"){
				zsl="0";
			}
			if(ysc=="null"){
				ysc="0";
			}
			if(barCoce=="null"){
				barCoce="";
			}
			if(packageMode=="null"){
				packageMode="";
			}
			if(data.param[i].proPlace=="null"){
				ycountry1="";
			}
			html += "<tr>";
			html +='<td class="hs fo">' +data.param[i].goodsName +
			"</td><td class='hs'>" +barCoce +
			"</td><td class='hs'>" +packageMode +"</td>";
			if(data.param[i].isSera=="0"){
				if(data.param[i].zsl=="0"){
					html +='<td class="hs">'+ysc+'/'+zsl +'</td>';	
				}else{
				    html +='<td class="rs"><a href="Food_BatchNumber.html?pid='+pid+'&barcode='+barCoce+'&pname='+pname+'&ycountry='+ycountry1+'" target="_blank" style="color:#ef2121;">'+ysc+'/'+zsl +'</a></td>';
				}
			}else{
				if(data.param[i].zsl=="0"){
					html +='<td class="hs">'+ysc+'/'+zsl +'</td>'; 
				}else{
				    html +='<td class="hs"><a href="Food_BatchNumber.html?pid='+pid+'&barcode='+barCoce+'&pname='+pname+'&ycountry='+ycountry1+'" target="_blank">'+ysc+'/'+zsl +'</a></td>'; 
				}
			}
            html +='<td class="hs ls"><a href="Food_info.html?pid='+pid+'&barcode='+barCoce+'&pname='+pname+'&ycountry='+ycountry1+'" target="_blank">详情<span style="display:none;">'+pid+'</span></a><span class="ls">|</span><a href="javascript:void(0);" onclick="gz1(this)"><s style="display:none;">'+data.param[i].goodsName+'</s><i style="display:none;">'+data.param[i].goodsCode+'</i><span>'+gz+'</span></a></td>';
		    html += "</tr>";
	}
	$("table tbody").html(html);
	autoH();
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else {
		$("table tbody").html("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;font-size:14px;'>没有相关数据</td></tr>");
		$("#daochu").css("display","none");
		$("#mySelectS").css("display","none");
	}
}

//重置按钮
$("#form .btn1").click(function(){
	$("#bz").find("input[type='checkbox']:checked").removeAttr('checked', 'checked');
	$("#cc").find("input[type='checkbox']:checked").removeAttr('checked', 'checked');
	$("#ycg").find("input[type='checkbox']:checked").removeAttr('checked', 'checked');
})

/**设置全选或全不选**/
/**$(".labelAll").click(function(){
	if($("#tabinp").is(':checked')){
	   $(".xzpname").find("input[type='checkbox']:checked").removeAttr('checked', 'checked');
	}else{
	   $(".xzpname").find("input[type='checkbox']").attr('checked', 'checked');
	}
})**/

/**添加到获取食品分类，调用接口**/
/**$(".addType").click(function(){
	$(".foodList").slideToggle();
	var wxjson = new webjson("21"); //设置action值
	//新增param键值
	wxjson.AddParam("pid","");
	WebRequestAsync(wxjson, addTypeDate);
})

function addTypeDate(res){
	var htmlT="";
	var data = GetOjson(json_parse(res));
	console.log(data);
	if(data.status == 0) {	
		for(var i=0;i<data.param.length;i++){
		htmlT +='<li><div class="div-init foodType">'+
	      '<input name="" type="checkbox" value="'+data.param[i].foodType+'" id="foodType'+i+'"/>'+
	      '<label class="label1 label3" for="foodType'+i+'">'+data.param[i].foodType+'</label></div></li>';
		}
	   htmlT +='<li style="background: #fff;font-size=14px;color:#54aff0;"><span class="ok">确定</span><span class="exit">取消</span></li>';
	   $(".foodList").append(htmlT);
	   $(".foodList").slideToggle();
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else{
	  $(".foodList").append("");
}
}**/

/**添加分类点击取消按钮**/
/**$(".exit").click(function(){
	$(".foodList").slideUp(1);
	$(".foodList").find("input[type='checkbox']:checked").removeAttr('checked', 'checked');
})**/

/**添加分类点击确认按钮**/
/**$(".ok").click(function(){
	var selectV=checkBoxTable($(".foodList"));
	var tableV=checkBoxTable($(".xzpname"));
	console.log("添加至："+selectV+"tbody:"+tableV);
	if(tableV==""){
		layer.msg("您还未选择食品名称！");
	}else if(selectV==""){
		layer.msg("您还未选择分类！");
	}else{
	    var wxjson = new webjson("21"); //设置action值
	    //新增param键值
	    wxjson.AddParam("selectV",selectV);
	    wxjson.AddParam("tableV",tableV);
	    WebRequestAsync(wxjson, okTypeDate);
	}
})
function okTypeDate(res){
	var data = GetOjson(json_parse(res));
	console.log(data);
	if(data.status == 0) {
		layer.msg("添加分类成功！");
		
	}
}

$(document).click(function(event){
	var st=$(".addType");
	var fl=$(".foodList");
	if(!st.is(event.target)&& st.has(event.target).length === 0&&!fl.is(event.target)&& fl.has(event.target).length === 0){
	$(".foodList").slideUp(1);
	$(".foodList").find("input[type='checkbox']:checked").removeAttr('checked', 'checked');
	}
})**/

//点击高级搜索下拉
$("#gjSearch").click(function(){
    $("#form").slideToggle();
});

/**按enter键查询**/
$(".foodName").keydown(function(event){
 if(event.keyCode==13){
	$("#Search").click();
}
})

/**点击查询**/
$("#Search").click(function(){
	pindex="1";
	sskey=$.trim($(".foodName").val());
	if(sskey=="请输入关键字进行查询"){
		sskey="";
	}
	goodName=sskey;
	console.log("sskey:"+sskey);
	search(cId, zoneCode, departmentid,saveCodes,packageModes,proPlaces,goodName,type,pindex, psize);
})

/**点击高级查询**/
$("#confirBtn").click(function(){
	pindex="1";
	sskey=$.trim($(".foodName").val());
	goodName=sskey;
	if(sskey=="请输入关键字进行查询"){
		sskey="";
	}
	packageModes=checkBoxFormat1($("#bz"));
	saveCodes=checkBoxFormat1($("#cc"));
	proPlaces=checkBoxFormat1($("#ycg"));
	search(cId, zoneCode, departmentid,saveCodes,packageModes,proPlaces,goodName,type,pindex, psize);
})

/**点击关注**/
function gz1(t){
	pname1=$(t).children("s").text();
	goodsCode1=$(t).children("i").text();
	var text1=$(t).children("span").text();
	console.log(text1);
	if(text1=="关注"){
	 layer.open({
		title: '提示'
		,content: '\<div class="warpper"><div class="guanzhu"><div>为<span style="font-weight:bold;">'+pname1+'</span>选择分类<p style="float:right;" class="rs"></p></div><div><button class="creatType" onclick="creatType()">创建新分类</button><div class="creatName" style="display:none;"><input type="text" value="" placeholder="请输入新分类名称" /><button class="sbtn btn-exit" onclick="creatName()">取消</button><button class="sbtn" onclick="creatBaoc()">保存</button></div></div><div class="select"></div></div><\/div><script> addList();</script>'
		,area: ['560px', '500px']
		,btn: ['取消','确认']
		,yes: function(index, layero){			
			layer.close(index);
		}
	    ,btn2:function(index, layero){
	    	var cheType1=checkBoxTable($(".select"));//勾选的分类值
	    	console.log(cheType1);
	    	cheType=cheType1;
	    	console.log(cheType);
	    	var wxjson = new webjson("54"); //设置action值
	    	//新增param键值
	    	wxjson.AddParam("departmentid",departmentid);
	    	wxjson.AddParam("enterpriseid",goodsCode1);
	    	wxjson.AddParam("types",cheType1);
	    	wxjson.AddParam("flag","sp");
	    	WebRequestAsync(wxjson, qurDate);
	    	function qurDate(res){
	    		var data = GetOjson(json_parse(res));
	    		console.log(data);
	    		if(data.status == 0) {	
	    			$(t).children("span").html("取消关注");
	    			text1="取消关注";
	    			layer.msg("关注成功!");
	    			sessionStorage.setItem("gz", text1);
	    		}else if(data.status == 9) {
	    			window.location.href = "index.html?loginOut=true";
	    		}else{
	    			$(t).children("span").html("关注");
	    			text1="关注";
	    			layer.msg(data.info);
	    		}
	    	}
	    }
		,cancel: function(){ 
			//右上角关闭回调
			//return false 开启该代码可禁止点击该按钮关闭
		}
	});
 }else{
	    var wxjson = new webjson("55"); //设置action值
		//新增param键值	
		wxjson.AddParam("departmentid",departmentid);
		wxjson.AddParam("enterpriseid",goodsCode1);
		WebRequestAsync(wxjson, qxGzData);
		function qxGzData(res){
			var data = GetOjson(json_parse(res));
			console.log(data);
			if(data.status == 0) {
				$(t).children("span").html("关注");
				text1="关注";
				layer.msg("取消成功！");
				sessionStorage.setItem("gz", text1);
			}else if(data.status == 9){
				window.location.href="index.html?loginOut=true";
			}else {
				$(t).children("span").html("取消关注");
				text1="取消关注";
				layer.msg(data.info);
			}
		}
 }
}

/**点击关注，弹框中显示的内容调用的方法**/
function addList(){
	var wxjson = new webjson("60"); //设置action值
	//新增param键值
	wxjson.AddParam("departmentid",departmentid);
	wxjson.AddParam("zoneCode",zoneCode);
	var res=WebRequest(wxjson);
	var data = GetOjson(json_parse(res));
	console.log(data);
	var html2="";
	if(data.status == 0) {	
		for(var i = 0; i < data.param.length; i++) {
		    foodType=data.param[i].typeName;
		    keyWords=data.param[i].keyWords;
		   // var selected=data.param[i].selected;
			html2 +='<div class="div-init foodType">';
			//if(selected.indexOf(foodType)>-1){
			/**if(foodType==selected){
			  html2 +='<input name="" type="checkbox" value="'+foodType+'" id="foodSelect'+i+'" checked/>';
			}else{**/
			  html2 +='<input name="" type="checkbox" value="'+data.param[i].cId+'" id="foodSelect'+i+'"/>';
			//}
			html2 +='<label class="label1 label4" for="foodSelect'+i+'">'+foodType+'</label></div>';
		    foodType1=foodType1+foodType+",";		    
		}
		 $(".select").html(html2);
		foodType1=foodType1.substr(0,foodType1.length-1);
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else{
	    $(".select").html("");
	}
}

/**关注中判断输入的分类是否和已存在的分类名称相同**/
function compare(){
	var inputs=$.trim($(".creatName input").val());//输入的值
	var ft=[];
	console.log("foodType1:"+foodType1);
	ft=foodType1.split(",");
	console.log("ft:"+ft);
	if(ft.length>0){
	 for(var i=0;i<ft.length;i++){
		console.log("数组："+ft[i]);
		    if(ft[i]==inputs){
			 $(".warpper p").html("此分类已存在，不能重复添加！");
			  $(".creatName").show();
			  $(".creatType").hide();
			  return true;
		}else if(inputs=="关注食品"){
			$(".warpper p").html("此分类已存在，不能重复添加！");
			$(".creatName").show();
			  $(".creatType").hide();
		  return true;
		}else{
			$(".warpper p").html("");
			  $(".creatType").show();
			  $(".creatName").hide();
			  $(".creatName input").val("");
		}
	}
}
}

/**关注中点击创建新分类**/
function creatType(){
	console.log("12");
	$(".creatType").hide();
	$(".creatName").show();
}

/**关注中创建新分类中取消按钮**/
function creatName(){
	$(".creatType").show();
	$(".creatName").hide();
	$(".creatName input").val("");
	$(".warpper p").css("display","none");
}

/**关注中创建新分类中保存按钮**/
function creatBaoc(){
	cskey=$.trim($(".creatName input").val());
	console.log(cskey);
	console.log(foodType1);
	if(cskey=="请输入新分类名称"||cskey==""){
		$(".warpper p").html("请输入新分类名称");
	}else if(compare()){
		return;
	}else{
	  	var wxjson = new webjson("61"); //设置action值
		//新增param键值	
		wxjson.AddParam("keywords","");	
		wxjson.AddParam("typename",cskey);
		wxjson.AddParam("departmentid",departmentid);
		wxjson.AddParam("type","INSERT");
		WebRequestAsync(wxjson, creatBaoDate);
	}
}

function creatBaoDate(res){
	var htmlL="";
	var data = GetOjson(json_parse(res));
	console.log(data);
	if(data.status == 0) {	
		htmlL +='<div class="div-init foodType">'+
	   '<input name="" type="checkbox" value="'+data.param[0].cId+'" id="foodSel'+jj+'"/>'+
	   '<label class="label1 label4" for="foodSel'+jj+'"><pre>'+cskey+'</pre></label></div>';
	   jj++;
	   $(".select").append(htmlL);
	   foodType1=foodType1+","+cskey;
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else{
	  $(".select").append("");
	}
}

//格式化复选框提交方式
function checkBoxFormat1(warpBox){
  var checked=warpBox.find("input[type='checkbox']:checked");
  var check=warpBox.find("input[type='checkbox']");
  if(checked.length == 0){
    return '';
  }else{
    var str='';
    $.each(check,function(i,item){
      if($(this).is(':checked')){
        str=str+i+',';
      }
    })
    str=str.substr(0,str.length-1)
    return str;
  }
}

/**取消关注按钮**/
/**$(".removeGz").click(function(){
	console.log("quxiao");
	var wxjson = new webjson("5"); //设置action值
	//新增param键值	
	wxjson.AddParam("departmentid",departmentid);
	wxjson.AddParam("enterpriseid",goodsCode1);
	WebRequestAsync(wxjson, removeGzData);
})
function removeGzData(res){
	var data = GetOjson(json_parse(res));
	console.log(data);
	if(data.status == 0) {
		layer.msg("操作成功！");
		window.location.reload();
	}else if(data.status == 9){
		//window.location.href="index.html?loginOut=true";
	}else {
		layer.msg(data.info);
	}
}**/