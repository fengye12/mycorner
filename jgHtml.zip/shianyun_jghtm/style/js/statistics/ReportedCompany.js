/*
* @Author: anchen
* @Date:   2017-08-02 20:21:15
* @Last Modified by:   anchen
* @Last Modified time: 2017-09-08 17:56:42
*/
// var paramcentcount=0;//总数据条数
var leftxAxis=[];
var bbqy=[];
var bbl = [];
var wbbqy = [];
var cg_pj = [];
var cg_tz = [];
var no_sc=[];
var xs_pj=[];
var xs_tz=[];
var wcg=[];
var wxs=[];
var zr_ba=[];
var bbzl=[];
var zl_cg_pj=[];
var zl_cg_tz=[];
var zl_no_sc=[];
var zl_wcg=[];
var zl_wxs=[];
var zl_xs_pj=[];
 var zl_xs_tz=[];
 var zl_zr_ba=[];

var a1='a12',a2='a1201';
getActiveN("a12","a1201");
//下辖地区初始值
  var data = [];
var departmentid=$.cookie("departmentid");
var isLock=0;

var de_idName=[];
var de_idCode=[];

 $(function(){
    $(window).resize(function() {
      location.reload();
  });

DefaultDate(2);
      //初始化图表
    setAnyChartFun(bbl,'bar','报备率');
    if(GetQueryString('qyType')){
      var type=+GetQueryString('qyType');
      if(type==0){
         $('.c_type .selected-item').text('生产企业');
      }else if(type==1){
         $('.c_type .selected-item').text('销售经营企业');
      }else if(type==2){
         $('.c_type .selected-item').text('餐饮企业');
      }else if(type==3){
         $('.c_type .selected-item').text('单位食堂');
      }

                getChartData(departmentid,type,'0',$("#from").val(),$("#to").val())
               }else{
                getChartData(departmentid,'-1','0',$("#from").val(),$("#to").val())
               }
})

    //设置最小高度
     var mainHeight=$('body').height()-110;
     $(".mainContent").css('min-height', mainHeight);

    var start,end;
    start = {
             format: 'YYYY-MM-DD',
             isinitVal:true,
             ishmsVal:false,
             isClear:false,
             isToday:true,
                 maxDate: $.nowDate({DD:0}), //最大日期
                 choosefun: function(elem,datas){
                  var type='按月';
                    if(type=="按日"){
                        $("#from").val(datas)
                    }else if(type=="按月"){
                        $("#from").val(datas+'-01')
                    }else if(type=="按年"){
                        $("#from").val(datas+'-01-01')
                    }
        }
             };
             end = {
                 format: 'YYYY-MM-DD',
                 isToday:true,
                isClear:false,
                 maxDate:$.nowDate({DD:0}), //最大日期
                 choosefun: function(elem,datas){
                  var type='按月';
                if(type=="按日"){
                    $("#to").val(datas)
                }else if(type=="按月"){
                    $("#to").val(datas+'-01')
                }else if(type=="按年"){
                    $("#to").val(datas+'-01-01')
                }
        }
             };
    $('#fromReal').jeDate(start);
    $('#toReal').jeDate(end);
    function DefaultDate(type){
        if(type==1){
         var today=new Date();
              var Month=+today.getMonth()+1;
              var Datet=today.getDate();
              if(Month<10){
               Month='0'+Month;
              }
              if(Datet<10){
                Datet='0'+Datet;
              }
              toDate=today.getFullYear()+'-'+Month+'-'+Datet;
              today.setDate(today.getDate()-29);
              var Month2=+today.getMonth()+1;
              var Datet2=today.getDate();
              if(Month2<10){
               Month2='0'+Month2;
              }
              if(Datet2<10){
                Datet2='0'+Datet2;
              }
               fromDate=today.getFullYear()+'-'+Month2+'-'+Datet2;
              today.setDate(today.getDate()+2);
               toDate2=today.getFullYear()+'-'+(+today.getMonth()+1)+'-'+today.getDate();
            $("#fromReal").val(fromDate);
            $("#toReal").val(toDate)
            $("#from").val(fromDate)
            $("#to").val(toDate)
    start.format="YYYY-MM-DD";
    end.format="YYYY-MM-DD";
        }else if(type==2){
             var today=new Date();
         var Month=+today.getMonth()+1;
         var Datet=today.getDate();
         if(Month<10){
          Month='0'+Month;
         }
         if(Datet<10){
           Datet='0'+Datet;
         }
         toDate=today.getFullYear()+'-'+Month+'-'+'01';
              var toDate1=today.getFullYear()+'-'+Month;
              today.setMonth(today.getMonth()-11);
          var Month2=+today.getMonth()+1;
          var Datet2=today.getDate();
          if(Month2<10){
           Month2='0'+Month2;
          }
          if(Datet2<10){
            Datet2='0'+Datet2;
          }
           fromDate=today.getFullYear()+'-'+Month2+'-01';
           // fromDate=today.getFullYear()+'-'+(+today.getMonth()+1)+'-'+today.getDate();
             var fromDate2=today.getFullYear()+'-'+Month2;
              today.setMonth(today.getMonth()+2);
               toDate2=today.getFullYear()+'-'+(+today.getMonth()+1)+'-'+today.getDate();
            $("#fromReal").val(fromDate2);
            $("#toReal").val(toDate1)
            $("#from").val(fromDate)
            $("#to").val(toDate)
            start.format="YYYY-MM";
            end.format="YYYY-MM";
        }else if(type==3){
             var today=new Date();
           toDate=today.getFullYear()+'-01-01';
               toDate1=today.getFullYear()
              today.setFullYear(today.getFullYear()-9);
           fromDate=today.getFullYear()+'-01-01';
               fromDate2=today.getFullYear();
              today.setFullYear(today.getFullYear()+2);
               toDate2=today.getFullYear()+'-'+(+today.getMonth()+1)+'-'+today.getDate();
            $("#fromReal").val(fromDate2);
            $("#toReal").val(toDate1)
            $("#from").val(fromDate)
            $("#to").val(toDate)
          start.format="YYYY";
            end.format="YYYY";
        }
    }

    function ComparetIME(beginDate,endDate){
        var d1 = new Date(beginDate).getTime();
       var d2 = new Date(endDate).getTime();
       var type="按月";
       if(beginDate!=""&&endDate!="" &&d1 >=d2)
       {
        layer.msg('开始日期不能大于或等于结束日期');
        return false;
    }else{
        var d3=d2-d1;
       if(type=="按日"){
        if(d3<1*24*60*60*1000){
         layer.msg('开始和结束的时间差不能少于1天');
         return false;
       }else if(d3>29*24*60*60*1000){
         layer.msg('开始和结束的时间差不能大于30天');
         return false;
       }else{
        return true;
       }
    }else if(type=="按月"){
    if(!completeDate(new Date(beginDate), new Date(endDate),12)){
         layer.msg('开始和结束的时间差不能大于12个月');
         return false;
    }else{
        return true;
       }
    }else if(type=="按年"){
        var d4=new Date(endDate).getFullYear()-new Date(beginDate).getFullYear();
    if(d4>=10){
      layer.msg('开始和结束的时间差不能大于10年');
      return false;
    }else{
        return true;
       }
    }
    }
    }
    function completeDate(time1 , time2 , m)
    {
        var diffyear = time2.getFullYear() - time1.getFullYear() ;
        var diffmonth = diffyear * 12 + time2.getMonth() - time1.getMonth() ;
        if(diffmonth < m){
            return true ;
        }else{
          return false ;
        }

    }
//模拟select
  $(".selectedB").on('click', '.sel-wrap', function(event) {
    if($(this).is(":hover")){
      console.log($(".selectedB .optionB").not($(this).next('.optionB')))
      $(".selectedB .optionB").not($(this).next('.optionB')).hide(20);
      $(this).next('.optionB').slideToggle(20);
    }
   return false;
 });

  $(".selectedB").on('click', '.op-item', function(event) {
    $(this).closest('.selectedB').find('.selected-item').text($(this).text());
    $(this).closest('.optionB').slideUp(20);
  });


 document.onclick = function(){
   $(".optionB").hide();
 };

 //时间差
 function TwoDays(type,date){
  var setType='按月';
   var curDate = new Date(date);
   var startDate="";
if(type==1){
  if(setType=="按日"){
   startDate=new Date(curDate.setDate(curDate.getDate()+2));
     return startDate.getFullYear()+'-'+(+startDate.getMonth()+1)+'-'+startDate.getDate();
  }else if(setType=="按月"){
startDate=new Date(curDate.setMonth(curDate.getMonth()+2));
return startDate.getFullYear()+'-'+(+startDate.getMonth()+1)+'-01';
}else if(setType=="按年"){
  startDate=new Date(curDate.setFullYear(curDate.getFullYear()+2));
  return startDate.getFullYear()+'-01-01';
}


}else if(type=2){

    if(setType=="按日"){
     startDate=new Date(curDate.setDate(curDate.getDate()-2));
      return startDate.getFullYear()+'-'+(+startDate.getMonth()+1)+'-'+startDate.getDate();
    }else if(setType=="按月"){
  startDate=new Date(curDate.setMonth(curDate.getMonth()-2));
   return startDate.getFullYear()+'-'+(+startDate.getMonth()+1)+'-01';
  }else if(setType=="按年"){
    startDate=new Date(curDate.setFullYear(curDate.getFullYear()-2));
     return startDate.getFullYear()+'-01-01';
  }
}
 }
  //时间差
  function maxTwoDays(type,date){
   var setType='按月';
    var curDate = new Date(date);
    var startDate="";
 if(type==1){
   if(setType=="按日"){
    startDate=new Date(curDate.setDate(curDate.getDate()+30));
      return startDate.getFullYear()+'-'+(+startDate.getMonth()+1)+'-'+startDate.getDate();
   }else if(setType=="按月"){
 startDate=new Date(curDate.setMonth(curDate.getMonth()+12));
 return startDate.getFullYear()+'-'+(+startDate.getMonth()+1)+'-01';
 }else if(setType=="按年"){
   startDate=new Date(curDate.setFullYear(curDate.getFullYear()+10));
   return startDate.getFullYear()+'-01-01';
 }


 }else if(type=2){

     if(setType=="按日"){
      startDate=new Date(curDate.setDate(curDate.getDate()-30));
       return startDate.getFullYear()+'-'+(+startDate.getMonth()+1)+'-'+startDate.getDate();
     }else if(setType=="按月"){
   startDate=new Date(curDate.setMonth(curDate.getMonth()-12));
    return startDate.getFullYear()+'-'+(+startDate.getMonth()+1)+'-01';
   }else if(setType=="按年"){
     startDate=new Date(curDate.setFullYear(curDate.getFullYear()-10));
      return startDate.getFullYear()+'-01-01';
   }
 }
  }

//获取图表数据
function getChartData(zone_code,qyType,countWay,startTime,endtTime){
    if(isLock==1){
        return false;
    }
    isLock=1;
    myChart.showLoading({
                    text : '数据获取中',
                    effect: 'whirling',
                    color:'#56b4f8'
                });
    $(".checkStyle").hide();
    $(".table-body").empty();
    if(countWay==1){
      $(".tTable thead").empty();
      var Head='<tr>'+
    '<th>时间</th>'+
    '<th><label class="radioL noCheck "><input type="radio" name="showtype" value="报备总量"/>报备总量</label></th>'+
    '<th class="active"><div class="borderS"></div><label class="radioL checked"><input type="radio" checked="true" name="showtype"  value="采购台账备案"/>采购台账备案</label></th>'+
    '<th><label class="radioL noCheck"><input type="radio" name="showtype"  value="采购票据备案"/>采购票据备案</label>'+
    '</th>'+
    '<th><label class="radioL noCheck"><input type="radio" name="showtype"  value="销售台账备案"/>销售台账备案</label></th>'+
    '<th><label class="radioL noCheck"><input type="radio" name="showtype"  value="销售票据备案"/>销售票据备案</label></th>'+
    '<th><label class="radioL noCheck"><input type="radio" name="showtype"  value="无采购经营备案"/>无采购经营备案</label></th>'+
    '<th><label class="radioL noCheck"><input type="radio" name="showtype"  value="无销售经营备案"/>无销售经营备案</label></th>'+
    '<th><label class="radioL noCheck"><input type="radio" name="showtype"  value="停止生产备案"/>停止生产备案</label></th>'+
    '<th><label class="radioL noCheck"><input type="radio" name="showtype"  value="转让备案"/>转让备案</label></th>'+
  '</tr>';
   $(".tTable thead").append(Head);
   $(".table-body").append("<tr class='loading' style='width:100%'><td colspan='10' style='padding:20px 0; text-align:center'><img src='../style/image/load.gif' width='32px' height='32px'/></td></tr>");
    }else{
       $(".tTable thead").empty();
        var Head='<tr>'+
         '<th>时间</th>'+
         '<th><label class="radioL noCheck "><input type="radio" name="showtype" value="新增企业"/>报备企业</label></th>'+
         '<th><label class="radioL noCheck "><input type="radio" name="showtype" value="未报备企业"/>未报备企业</label></th>'+
         '<th class="active"><div class="borderS"></div><label class="radioL checked"><input type="radio" checked="true" name="showtype"  value="报备率"/>报备率</label></th>'+
         '<th><label class="radioL noCheck"><input type="radio" name="showtype"  value="采购台账备案企业"/>采购台账备案企业</label></th>'+
         '<th><label class="radioL noCheck"><input type="radio" name="showtype"  value="采购票据备案企业"/>采购票据备案企业</label></th>'+
         '<th><label class="radioL noCheck"><input type="radio" name="showtype"  value="销售台账备案企业"/>销售台账备案企业</label></th>'+
         '<th><label class="radioL noCheck"><input type="radio" name="showtype"  value="销售票据备案企业"/>销售票据备案企业</label></th>'+
        '<th><label class="radioL noCheck"><input type="radio" name="showtype"  value="无采购经营备案"/>无采购经营备案企业</label></th>'+
         '<th><label class="radioL noCheck"><input type="radio" name="showtype"  value="无销售经营备案"/>无销售经营备案企业</label></th>'+
         '<th><label class="radioL noCheck"><input type="radio" name="showtype"  value="停止生产备案企业"/>停止生产备案企业</label></th>'+
         '<th><label class="radioL noCheck"><input type="radio" name="showtype"  value="转让备案企业"/>转让备案企业</label></th>'+
       '</tr>';
       $(".tTable thead").append(Head);
       $(".table-body").append("<tr class='loading' style='width:100%'><td colspan='12' style='padding:20px 0; text-align:center'><img src='../style/image/load.gif' width='32px' height='32px'/></td></tr>");
    }

          var wxjson = new webjson("33");
            wxjson.AddParam("jgj",zone_code);
            wxjson.AddParam("qylx",qyType);
            wxjson.AddParam("tjfs", countWay);
            wxjson.AddParam("sj",startTime+','+endtTime);
          WebRequestAsync(wxjson, successGroup);
          function successGroup(res){
            console.log(res)
              var data = GetOjson(json_parse(res));
              console.log(data);
              if(data.status == 0){
                  $(".borderS").show();
                  var organList=[];
                  $.each(data.datas.deptArray, function(index, val) {
                    organList.push({'id':val.id,'text':val.text});
                     de_idName.push(val.text);
                     de_idCode.push(val.id)
                  });
                  var selects= $(".js-example-data-array").select2({
                     data: organList,
                     language: "Zh-CN"
                   })
                if(data.param.length>0){
                    isLock=0;
                    $(".start1").text($("#fromReal").val());
                    $(".end1").text($("#toReal").val());
                    if(countWay==0){
                    leftxAxis=[];
                    bbqy=[];
                    bbl = [];
                    wbbqy = [];
                    cg_pj = [];
                    cg_tz = [];
                    no_sc=[];
                    xs_pj=[];
                    xs_tz=[];
                    wcg=[];
                    wxs=[];
                    zr_ba=[];
                  }else{
                    leftxAxis=[];
                      bbzl=[];
                      zl_cg_pj=[];
                      zl_cg_tz=[];
                      zl_no_sc=[];
                      zl_wcg=[];
                      zl_wxs=[];
                       zl_xs_pj=[];
                       zl_xs_tz=[];
                       zl_zr_ba=[];
                  }
                    $(".table-body").empty();
                    var HTML="";
                $.each(data.param.reverse(), function(index, val) {
                    leftxAxis.push(val.time);
                   if(countWay==0){
                     bbqy.push(val.bbqy);
                    bbl.push(val.bbl.slice(0, -1));
                    wbbqy.push(val.wbbqy);
                    cg_pj.push(val.cg_pj);
                    cg_tz.push(val.cg_tz);
                    no_sc.push(val.no_sc);
                    xs_pj.push(val.xs_pj);
                    xs_tz.push(val.xs_tz);
                    wxs.push(val.wxs);
                    zr_ba.push(val.zr_ba);
                    wcg.push(val.wcg);
                     HTML+='<tr>'+
                      '<td class="timeD small">'+val.time+'</td>';
                      if(val.bbqy==0){
                      HTML+= '<td class="small3">'+val.bbqy+'</td>';
                      }else{
                        HTML+= '<td class="activeA small3" onclick="getDetail(1,$(this))">'+val.bbqy+'</td>';
                      }
                      if(val.wbbqy==0){
                      HTML+= '<td class=" small4">'+val.wbbqy+'</td>';
                      }else{
                        HTML+= '<td class="activeA small4" onclick="getDetail(2,$(this))">'+val.wbbqy+'</td>';
                      }
                       if(val.bbl==0){
                      HTML+= '<td class=" small2  active">'+val.bbl+'</td>';
                      }else{
                        HTML+= '<td class=" small2  active" >'+val.bbl+'</td>';
                      }
                        if(val.cg_tz==0){
                      HTML+= '<td class="">'+val.cg_tz+'</td>';
                      }else{
                        HTML+='<td class=" activeA" onclick="getDetail(3,$(this))">'+val.cg_tz+'</td>'
                      }
                       if(val.cg_pj==0){
                      HTML+='<td class="">'+val.cg_pj+'</td>';
                      }else{
                        HTML+='<td class="activeA" onclick="getDetail(4,$(this))">'+val.cg_pj+'</td>';
                      }
                       if(val.xs_tz==0){
                      HTML+='<td class="">'+val.xs_tz+'</td>';
                      }else{
                        HTML+='<td class="activeA" onclick="getDetail(5,$(this))">'+val.xs_tz+'</td>';
                      }
                        if(val.xs_pj==0){
                      HTML+='<td class="">'+val.xs_pj+'</td>';
                      }else{
                        HTML+='<td class="activeA" onclick="getDetail(6,$(this))">'+val.xs_pj+'</td>';
                      }
                        if(val.wcg==0){
                      HTML+='<td class="">'+val.wcg+'</td>';
                      }else{
                        HTML+='<td class="activeA" onclick="getDetail(7,$(this))">'+val.wcg+'</td>';
                      }
                        if(val.wxs==0){
                      HTML+='<td class="">'+val.wxs+'</td>';
                      }else{
                        HTML+='<td class="activeA" onclick="getDetail(8,$(this))">'+val.wxs+'</td>';
                      }
                       if(val.no_sc==0){
                      HTML+='<td class=" small5">'+val.no_sc+'</td>';
                      }else{
                        HTML+='<td class="activeA small5" onclick="getDetail(9,$(this))">'+val.no_sc+'</td>';
                      }
                       if(val.zr_ba==0){
                      HTML+='<td class="small5">'+val.zr_ba+'</td>';
                      }else{
                       HTML+='<td class="activeA small5" onclick="getDetail(10,$(this))">'+val.zr_ba+'</td>';
                      }
                   HTML+= '</tr>';
                  }else{
                     bbzl.push(val.bbzl);
                    zl_cg_pj.push(val.zl_cg_pj);
                    zl_cg_tz.push(val.zl_cg_tz);
                    zl_no_sc.push(val.zl_no_sc);
                    zl_wcg.push(val.zl_wcg);
                    zl_wxs.push(val.zl_wxs);
                    zl_xs_pj.push(val.zl_xs_pj);
                    zl_xs_tz.push(val.zl_xs_tz);
                    zl_zr_ba.push(val.zl_zr_ba);
                     HTML+='<tr>'+
                      '<td class="timeD small">'+val.time+'</td>';
                      if(val.bbzl==0){
                      HTML+= '<td class="small3">'+val.bbzl+'</td>';
                      }else{
                        HTML+= '<td class="small3">'+val.bbzl+'</td>';
                      }
                        if(val.zl_cg_tz==0){
                      HTML+= '<td class="">'+val.zl_cg_tz+'</td>';
                      }else{
                        HTML+='<td class=" activeA" onclick="getDetail(13,$(this))">'+val.zl_cg_tz+'</td>'
                      }
                       if(val.zl_cg_pj==0){
                      HTML+='<td class="">'+val.zl_cg_pj+'</td>';
                      }else{
                        HTML+='<td class="activeA" onclick="getDetail(14,$(this))">'+val.zl_cg_pj+'</td>';
                      }
                       if(val.zl_xs_tz==0){
                      HTML+='<td class="">'+val.zl_xs_tz+'</td>';
                      }else{
                        HTML+='<td class="activeA" onclick="getDetail(15,$(this))">'+val.zl_xs_tz+'</td>';
                      }
                        if(val.zl_xs_pj==0){
                      HTML+='<td class="">'+val.zl_xs_pj+'</td>';
                      }else{
                        HTML+='<td class="activeA" onclick="getDetail(16,$(this))">'+val.zl_xs_pj+'</td>';
                      }
                        if(val.zl_wcg==0){
                      HTML+='<td class="">'+val.zl_wcg+'</td>';
                      }else{
                        HTML+='<td class="activeA" onclick="getDetail(17,$(this))">'+val.zl_wcg+'</td>';
                      }
                        if(val.zl_wxs==0){
                      HTML+='<td class="">'+val.zl_wxs+'</td>';
                      }else{
                        HTML+='<td class="activeA" onclick="getDetail(18,$(this))">'+val.zl_wxs+'</td>';
                      }
                       if(val.zl_no_sc==0){
                      HTML+='<td class=" small5">'+val.zl_no_sc+'</td>';
                      }else{
                        HTML+='<td class="activeA small5" onclick="getDetail(19,$(this))">'+val.zl_no_sc+'</td>';
                      }
                       if(val.zl_zr_ba==0){
                      HTML+='<td class="small5">'+val.zl_zr_ba+'</td>';
                      }else{
                       HTML+='<td class="activeA small5" onclick="getDetail(20,$(this))">'+val.zl_zr_ba+'</td>';
                      }
                   HTML+= '</tr>';
                  }

                  });
                    if(countWay==0){
                    leftxAxis.reverse();
                    bbqy.reverse();
                    bbl.reverse();
                    wbbqy.reverse();
                    cg_pj.reverse();
                    cg_tz.reverse();
                    no_sc.reverse();
                    xs_pj.reverse();
                    xs_tz.reverse();
                    wcg.reverse();
                    wxs.reverse();
                    zr_ba.reverse();
                  }else{
                    leftxAxis.reverse();
                      bbzl.reverse();
                      zl_cg_pj.reverse();
                      zl_cg_tz.reverse();
                      zl_no_sc.reverse();
                      zl_wcg.reverse();
                      zl_wxs.reverse();
                       zl_xs_pj.reverse();
                       zl_xs_tz.reverse();
                       zl_zr_ba.reverse();
                  }
                 $(".table-body").append(HTML);
                 $(".st_type").text($(".active").find("input").val());
                 // document.getElementsByClassName
                 var obj = $(".table")[0];
                 var height=obj.offsetHeight;
                 var thheight=$('.table th')[0].offsetHeight;
                 $(".borderS").css('bottom',thheight-height);
                 myChart.hideLoading();
                var checkedV=$(".radioL.checked input").val();
                 if(countWay==1){
                  setAnyChartFun(zl_cg_tz,'bar',checkedV);
                }else{
                    setAnyChartFun(bbl,'bar',checkedV);
                }
            }

          }else if(data.status == 9){//超时重新登录
            window.location.href="index.html?loginOut=true";
            return;
        }else{
         // layer.close(layer1)
         layer.msg(data.info);
     }
    }
}

function getDetail(flag,$this){

    var FLAG="报备企业";
    if(flag==1){
        FLAG="报备企业"
    }else if(flag==2){
        FLAG="未报备企业"
    }else if(flag==3){
        FLAG="采购台账备案企业"
    }else if(flag==4){
        FLAG="采购票据备案企业"
    }else if(flag==5){
        FLAG="销售台账备案企业"
    }else if(flag==6){
        FLAG="销售票据备案企业"
    }else if(flag==7){
        FLAG="无采购经营备案企业"
    }else if(flag==8){
        FLAG="无销售经营备案企业"
    }else if(flag==9){
        FLAG="停止生产备案企业"
    }else if(flag==10){
        FLAG="转让备案企业"
    }else if(flag==13){
        FLAG="采购台账备案"
    }else if(flag==14){
        FLAG="采购票据备案"
    }else if(flag==15){
        FLAG="销售台账备案"
    }else if(flag==16){
        FLAG="销售票据备案"
    }else if(flag==17){
        FLAG="无采购经营备案"
    }else if(flag==18){
        FLAG="无销售经营备案"
    }else if(flag==19){
        FLAG="停止生产备案"
    }else if(flag==20){
        FLAG="转让备案"
    }
      var zone_code=$(".js-example-data-array").val();
      // cosole.log($this)
      var sum=$this.text();
      var qyTypeText=$(".c_type .selected-item").text();
      console.log($this.closest('.table_tr'))
      var time=$this.closest('tr').find('.timeD').text();
      var qyType="";
      var countWay=0;
      if(qyTypeText=="所有企业"){
          qyType=-1;
      }else if(qyTypeText=="生产企业"){
          qyType=0;
      }else if(qyTypeText=="销售经营企业"){
          qyType=1;
      }else if(qyTypeText=="餐饮企业"){
          qyType=2;
      }else if(qyTypeText=="单位食堂"){
          qyType=3;
      }
      var countWayText=$("#seT_type").text();
      if(countWayText=="按企业"){
          countWay=0;
      }else if(countWayText=="按报备量"){
          countWay=1;
      }
      var neTitle="";
      var TITLE="";
      var liTitle="";
      $.each(de_idCode, function(index, val) {
         if(val==zone_code){
            neTitle=de_idName[index];
            return false;
         }
      });

     var chuanzf={'jgj':zone_code,'time':time,'qylx':qyType,'jgj_name':neTitle}
    // var objSting={"neTitle":neTitle,"liTitle":liTitle,"zone_code":zone_code,"qyType":qyType,"countWay":countWay,"time":time,"flag":FLAG,"sum":sum};
    chuanzf=JSON.stringify(chuanzf);
    if(sum!="0"){
      if(flag>10){
        if(flag==13||flag==15){
          window.open('look_book.html?chuanzf='+escape(chuanzf)+'&lx='+escape(FLAG),'_blank')
        }else if(flag==14||flag==16){
          window.open('look_bill.html?chuanzf='+escape(chuanzf)+'&lx='+escape(FLAG),'_blank')
        }else if(flag==17||flag==18||flag==19||flag==20){
          window.open('look_record.html?chuanzf='+escape(chuanzf)+'&lx='+escape(FLAG),'_blank')
        }
      }else{
         window.open('look_company.html?chuanzf='+escape(chuanzf)+'&lx='+escape(FLAG),'_blank')
      }

    }

}
  var myChart = echarts.init(document.getElementById('chartMain'));
//图表调用
 function setAnyChartFun(dataA,type,name){

  var amax=Math.max.apply(null, dataA);
  amax=Math.ceil(amax);
  var length=amax.toString().length;
  var bai=1;
  for(var i=0;i<length-1;i++){
    bai=bai*10
  }
   var max;
  if(length>1){
  max=(+amax.toString().split('')[0]+1)*bai;
  }else{
max=10;
  }

  console.log(Math.ceil(max/5))
  var code="";
  if(name=="报备率"){
  code="%"
  }
  option = {
    color: ['#5897fB'],
    tooltip : {
      trigger: 'axis',
                              axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                                  type : 'line'        // 默认为直线，可选为：'line' | 'shadow'
                                },
                               formatter:function (params, ticket, callback) {
                                             var dataIndex=params[0].dataIndex;

                                               return leftxAxis[dataIndex]+'<br><span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:#5897fB;"></span>'+name+':'+params[0].value+code
                                }
                              },
                              grid: {
                                left: '0',
                                right: '20px',
                                bottom: '40px',
                                top:'10px',
                                containLabel: true
                              },
                              calculable : true,
                              xAxis : [
                              {
                                type : 'category',
                                data : leftxAxis,
                          // data : {
                          //   value:leftxAxis,
                          //   textStyle:{
                          //     color:'#333'
                          //   }
                          // },
                          axisLine:{
                           lineStyle:{
                            color:'#333'
                          }
                        },
                        axisTick: {
                                  show:false,//坐标轴刻度
                                  alignWithLabel: true
                                },
                              }
                              ],
                              yAxis : [
                              {
                                type: 'value',
                                 minInterval: 1,
                                max:max,
                                 interval:Math.ceil(max/5),
                                axisLine:{
                                 lineStyle:{
                                  color:'#333'
                                }
                              },
                              nameGap:25,
                              axisTick: {
                             show:false,//坐标轴刻度
                             alignWithLabel: true
                           },
                           min: 0,
                           position: 'left',
                           axisLabel: {
                            formatter: '{value}'+code
                          }
                        },
                        ],
                        series : [
                        {
                          name:name,
                          type:type,
                          barWidth:'25%',
                          // barMinHeight:2,
                          barMaxWidth:40,
                          data:dataA
                        }
                        ]
                      };
                       // 使用刚指定的配置项和数据显示图表。
                       myChart.setOption(option);
                     }
                                 $("body").on('click', '.radioL', function(event) {
                                   $('.radioL').each(function(index, el) {
                                     $('.radioL').removeClass('checked').addClass('noCheck');
                                     if($(this).find('input').prop("checked")){
                                      console.log($(this).closest('th').find('.borderS'))
                                      $(this).closest('tr').find('.borderS').remove();
                                      var obj = $(".table")[0];
                                      var height=obj.offsetHeight;
                                      var thheight=$('.table th')[0].offsetHeight;
                                      var lowerH=thheight-height;
                                      $(this).closest('th').append('<div class="borderS" style="bottom:'+lowerH+'px;display:block"></div>').siblings('th').find('.borderS').remove();
                                       $(this).removeClass('noCheck').addClass('checked');
                                        var index2=index+1;
                                         $('.tTable th').eq(index2).addClass('active').siblings().removeClass('active')
                                         $(".tTable tr").find("td:eq("+index2+")").addClass('active').siblings().removeClass('active');
                                         $(".end1").text($('#toReal').val())
                                         $(".start1").text($('#fromReal').val())
                                         $(".st_type").text($(this).text())
                                         if($(this).closest('tr').find('th').length==12){


                                         if($(this).text()=="报备企业"){
                                              setAnyChartFun(bbqy,'bar',$(this).text());
                                         }else if($(this).text()=="未报备企业"){
                                          setAnyChartFun(wbbqy,'bar',$(this).text());
                                         }else if($(this).text()=="报备率"){
                                          setAnyChartFun(bbl,'bar',$(this).text());
                                         }else if($(this).text()=="采购台账备案企业"){
                                          setAnyChartFun(cg_tz,'bar',$(this).text());
                                         }else if($(this).text()=="采购票据备案企业"){
                                          setAnyChartFun(cg_pj,'bar',$(this).text());
                                         }else if($(this).text()=="销售台账备案企业"){
                                          setAnyChartFun(xs_tz,'bar',$(this).text());
                                         }else if($(this).text()=="销售票据备案企业"){
                                          setAnyChartFun(xs_pj,'bar',$(this).text());
                                         }else if($(this).text()=="无采购经营备案企业"){
                                          setAnyChartFun(wcg,'bar',$(this).text());
                                         }else if($(this).text()=="无销售经营备案企业"){
                                          setAnyChartFun(wxs,'bar',$(this).text());
                                         }else if($(this).text()=="停止生产备案企业"){
                                          setAnyChartFun(no_sc,'bar',$(this).text());
                                         }else if($(this).text()=="转让备案企业"){
                                          setAnyChartFun(zr_ba,'bar',$(this).text());
                                         }
                                       }else{
                                        if($(this).text()=="报备总量"){
                                             setAnyChartFun(bbzl,'bar',$(this).text());
                                        }else if($(this).text()=="采购台账备案"){
                                         setAnyChartFun(zl_cg_tz,'bar',$(this).text());
                                        }else if($(this).text()=="采购票据备案"){
                                         setAnyChartFun(zl_cg_pj,'bar',$(this).text());
                                        }else if($(this).text()=="销售台账备案"){
                                         setAnyChartFun(zl_xs_tz,'bar',$(this).text());
                                        }else if($(this).text()=="销售票据备案"){
                                         setAnyChartFun(zl_xs_pj,'bar',$(this).text());
                                        }else if($(this).text()=="无采购经营备案"){
                                         setAnyChartFun(zl_wcg,'bar',$(this).text());
                                        }else if($(this).text()=="无销售经营备案"){
                                         setAnyChartFun(zl_wxs,'bar',$(this).text());
                                        }else if($(this).text()=="停止生产备案"){
                                         setAnyChartFun(zl_no_sc,'bar',$(this).text());
                                        }else if($(this).text()=="转让备案"){
                                         setAnyChartFun(zl_zr_ba,'bar',$(this).text());
                                        }
                                       }

                                      return false;
                                    }
                                  });

                     });
                $("#comfire").click(function(event) {
                  var startDate=$("#from").val();
                  var endDate=$("#to").val();
                   if(ComparetIME(startDate,endDate)){
                  $(".borderS").hide();
                    var zone_code=$(".js-example-data-array").val();
                    var qyTypeText=$(".c_type .selected-item").text();
                    var qyType="";
                    var countWay=0;
                    if(qyTypeText=="所有企业"){
                        qyType=-1;
                    }else if(qyTypeText=="生产企业"){
                        qyType=0;
                    }else if(qyTypeText=="销售经营企业"){
                        qyType=1;
                    }else if(qyTypeText=="餐饮企业"){
                        qyType=2;
                    }else if(qyTypeText=="单位食堂"){
                        qyType=3;
                    }
                    var countWayText=$("#seT_type").text();
                    if(countWayText=="按企业"){
                        countWay=0;
                    }else if(countWayText=="按报备量"){
                        countWay=1;
                    }
                    var formDatev=$("#from").val();
                    var toDatev=$("#to").val();
                    if(formDatev==""){
                        layer.msg('请选择开始日期')
                    }else if(toDatev==""){
                         layer.msg('请选择结束日期')
                    }else{
                        getChartData(zone_code,qyType,countWay,formDatev+','+toDatev)
                    }
                  }
                });
