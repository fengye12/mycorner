var c_id="",zoneCode="",typeName="",sskey="",cId="",pindex = "1",psize = "20";
var st="0";/**状态初始值**/
var a1 = "a12",a2 = "a1204";
var key=[];/**后台获取的食品名称关键字**/

/**分页设置**/
var pcent = new CentPage();
var pcount = ""; //总条数
var ps = pcent.GetCentPage(pindex, pcount, psize);
$("#page").html(ps);
function CentPageOper(spindex) {
	foodList(c_id,zoneCode,spindex, psize);
}

/**页面加载时**/
$(function(){
	getActiveN("a12", "a1204");//当前页标志
	autoH();
	c_id=$.cookie("departmentid");
	zoneCode=$.cookie("dep_code");
	console.log(c_id+","+zoneCode);	
	foodList(c_id,zoneCode,pindex, psize);
})

function foodList(c_id,zoneCode,spindex, psize){
	pindex = spindex;
	$("#mySelectS").css("display","none");
	$("table tbody").children().remove();
	$("table tbody").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;'><img src='../style/image/load.gif' alt='' /></td></tr>");
	var wxjson = new webjson("60"); //设置action值
	//新增param键值	
	wxjson.AddParam("departmentid", c_id);
	wxjson.AddParam("zoneCode", zoneCode);
	wxjson.AddParam("page_index", pindex);
	wxjson.AddParam("page_size", psize);
	WebRequestAsync(wxjson,foodListDate);
}
function foodListDate(res){
	var html = "";
	var data = GetOjson(json_parse(res));
	console.log(data);
	pcount = data.paramcentcount;
	$(".totalNum1").html("共"+pcount+"条");
	var ps = pcent.GetCentPage(pindex, pcount, psize);
	$("#page").html(ps);
	if(data.status == 0) {
		if(pcount!="0"){
			$("#mySelectS").css("display","");
			}else{
			 $("#mySelectS").css("display","none");
			}
		for(var i = 0; i < data.param.length; i++){
			    html +='<tr><td class="hs"><pre>'+data.param[i].typeName+'</pre></td><td class="hs">'+data.param[i].foodTypeCount+'</td>';
			if(data.param[i].typeName=="关注食品"){
				if(data.param[i].foodTypeCount=="0"){
					html +='<td><a href="javascript:void(0);" class="ls" onclick="ck(this)">查看</a></td>';
				}else{
				html +='<td><a href="look_foodStatistics.html?cId='+data.param[i].cId+'" class="ls" target="_blank">查看</a></td>';
				}
			}else if(data.param[i].typeName=="保健食品"||data.param[i].typeName=="婴幼儿配方乳粉"||data.param[i].typeName=="其他婴幼儿配方食品"||data.param[i].typeName=="特殊医学用途配方食品"){
				if(data.param[i].foodTypeCount=="0"){
					html +='<td><a href="javascript:void(0);" class="ls" onclick="ck(this)">查看</a><span class="ls">|</span><a href="javascript:void(0);" class="ls" onclick="edit(this)"><span style="display:none;">'+data.param[i].typeName+'</span><i style="display:none;">'+data.param[i].cId+'</i>编辑</a></td>';
				}else{
				html +='<td><a href="look_StatisticsList.html?cId='+data.param[i].cId+'&typeName='+escape(data.param[i].typeName)+'" class="ls" target="_blank">查看</a><span class="ls">|</span><a href="javascript:void(0);" class="ls" onclick="edit(this)"><span style="display:none;">'+data.param[i].typeName+'</span><i style="display:none;">'+data.param[i].cId+'</i>编辑</a></td>';
				}
			}else{
				if(data.param[i].foodTypeCount=="0"){
					html +='<td><a href="javascript:void(0);" class="ls" onclick="ck(this)">查看</a><span class="ls">|</span><a href="#" class="ls" onclick="editAll(this)"><span style="display:none;">'+data.param[i].typeName+'</span><i style="display:none;">'+data.param[i].cId+'</i>编辑</a><span class="ls">|</span><a href="#" class="ls" onclick="delet(this)"><i style="display:none;">'+data.param[i].cId+'</i>删除</a></td>';
				}else{
				html +='<td><a href="look_StatisticsList.html?cId='+data.param[i].cId+'&typeName='+escape(data.param[i].typeName)+'" class="ls" target="_blank">查看</a><span class="ls">|</span><a href="#" class="ls" onclick="editAll(this)"><span style="display:none;">'+data.param[i].typeName+'</span><i style="display:none;">'+data.param[i].cId+'</i>编辑</a><span class="ls">|</span><a href="#" class="ls" onclick="delet(this)"><i style="display:none;">'+data.param[i].cId+'</i>删除</a></td>';
				}
			}
			    html +='</tr>';
		}
		$("table tbody").html(html);
		autoH();
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else{
		$("table tbody").html("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;font-size:14px;'>没有相关数据</td></tr>");
	}
}

/**点击删除**/
function delet(d){
	var cid=$(d).children('i').text();
	var t=$(d).parent("tr");
	console.log(t);
	layer.open({
		title: '提示'
		,content: '\<div class="warpper1"><div style="font-size:14px;color:#333;margin-top: -15px;">点击确认将此分类删除。</div><\/div>'
		,area: ['390px', '160px']
		,btn: ['取消','确认']
		,yes: function(index, layero){
			layer.close(index);
		}
	   ,btn2:function(index, layero){
		 //点击确定调用的方法
			 var wxjson = new webjson("61"); //设置action值
           //新增param键值
           wxjson.AddParam("cId", cid);
           wxjson.AddParam("type", "DELETE");
           var res=WebRequest(wxjson);
           var obj=GetOjson(json_parse(res));
           if(obj.status == "0"){
               //layer.closeAll();
               t.remove();
               layer.msg("删除成功！");
               foodList(c_id,zoneCode,pindex, psize);
           }else if(obj.status == "9"){
               window.location.href="index.html?loginOut=true";
               return;
           }else{
               layer.msg(obj.info);
           }
             return false;
		}
		,cancel: function(){ 
			//右上角关闭回调
			//return false 开启该代码可禁止点击该按钮关闭
		}
	});
}

/**四大类点击编辑**/
function edit(f){
	cId=$(f).children("i").text();
	console.log(cId);
	st="2";
	console.log("四大类："+st);
	typeName=$("f").children("span").text();
	console.log("typeName:"+typeName);
	layer.open({
		title: '提示'
		,content: '\<div class="warpper wa" style="margin:-10px 10px 0 10px;"><\/div><script> addFen();</script>'
		,area: ['560px', 'auto']
	    ,type:1
		,btn: ['取消','确认']
		,yes: function(index, layero){		
			layer.close(index);		
		}
	   ,btn2:function(index, layero){
		 //点击确定调用的方法
		   var str="";
			typeName=$(".foodNa").val();
			var valArray=[];
			$(".clearfix .span-tname").each(function(){
				valArray.push($.trim($(this).text()));
			})
			     sskey=valArray.join(" ");
				 console.log("分类名称："+sskey);
				/** var ss="";
				 var sz=[];
				 sz=sskey.split(" ");
				 console.log("sz:"+sz[0]);
				 for(var i=0;i<sz.length;i++){
					 ss=sz[i];
					 console.log("ss:"+ss);
					 if(ss.length>25){
						 layer.msg('关键字不能超过25个字！'); 
						 return false;
					 }
				 }	**/
				 if(sskey.length>200){
					 layer.msg('关键字不能超过200个字！'); 
					 return false;
				 }
			//确定调用方法
				 creatType();
	    }
		,cancel: function(){ 
			//右上角关闭回调
			//return false 开启该代码可禁止点击该按钮关闭
		}
	});
}

/**手动添加的分类点击编辑**/
function editAll(a){
	st="3";
	cId=$(a).children("i").text();
	console.log(cId);
	typeName=$("a").children("span").text();
	console.log(typeName);
	var fl=$(a).parent().prev().prev().text();
	layer.open({
		title: '提示'
		,content: '\<div class="warpper wa" style="margin:-10px 10px 0 10px;"><\/div><script> addFen();</script>'
		,area: ['560px', 'auto']
	    ,type:1
		,btn: ['取消','确认']
		,yes: function(index, layero){
			layer.close(index);
		}
	   ,btn2:function(index, layero){
		   //点击确定调用的方法		
			var str="";
			typeName=$(".foodNa").val();
			console.log(typeName);
			var valArray=[];
			$(".clearfix .span-tname").each(function(){
				valArray.push($.trim($(this).text()));
			})
			     sskey=valArray.join(" ");
				 console.log("分类名称："+sskey);
				/** var ss="";
				 var sz=[];
				 sz=sskey.split(" ");
				 console.log("sz:"+sz[0]);
				 for(var i=0;i<sz.length;i++){
					 ss=sz[i];
					 console.log("ss:"+ss);
					 if(ss.length>25){
						 layer.msg('关键字不能超过25个字！'); 
						 return false;
					 }
				 }	**/
				 if(sskey.length>200){
					 layer.msg('关键字不能超过200个字！'); 
					 return false;
				 }
				 if(typeName==""){
					 layer.msg("分类名称不能为空！");
					 return false;
				 }else{
					 if(typeName==fl){
						//调用方法
							creatType();
							layer.close(index); 
					 }else{
						var flag=1;
						$("table tr").each(function(i,item){
							var tdname=$(this).find("td").eq(0).text();
							if(Trim(tdname) == Trim(typeName)){
								flag=0;
								return;
							}
						})
						if(flag){
							//调用方法
							creatType();
							//layer.close(index);
						}else{
							layer.msg('分类名称不能重复！');
							return false;
						}
					 }	
					}
	   }
		,cancel: function(){ 
			//右上角关闭回调
			//return false 开启该代码可禁止点击该按钮关闭
		}
	});
}

/**创建新分类**/
$(".addFen").click(function(){
	st="1";
	layer.open({
		title: '提示'
		,content: '\<div class="warpper wa" style="margin:-10px 10px 0 10px;"><\/div><script> addFen();</script>'
		,area: ['560px', 'auto']
	    ,shadeClose: true
		,shade: 0.5
		,type:1
		,btn: ['取消','确认']
		,yes: function(index, layero){
			layer.close(index);
			//return false;
		}
	    ,btn2:function(index, layero){
		//点击确定调用的方法
			var str="";
			typeName=$(".foodNa").val();
			console.log("typeName:"+typeName);			
			$(".clearfix .span-tname").each(function(){
				 str=str+$(this).text()+" ";			    	
			})
				 sskey=str.substr(0,str.length-1);  
				 console.log("分类名称："+sskey);
				 /**var ss="";
				 var sz=[];
				 sz=sskey.split(" ");
				 console.log("sz:"+sz[0]);
				 for(var i=0;i<sz.length;i++){
					 ss=sz[i];
					 console.log("ss:"+ss);
					 if(ss.length>25){
						 layer.msg('关键字不能超过25个字！'); 
						 return false;
					 }
				 }**/
				 if(sskey.length>200){
					 layer.msg('关键字不能超过200个字！'); 
					 return false;
				 }
			if(typeName==""){			
				layer.msg('分类名称不能为空！');
				return false;
			}else{
				var flag=1;
				$("table tr").each(function(i,item){
					var tdname=$(this).find("td").eq(0).text();
					if(Trim(tdname) == Trim(typeName)){
						flag=0;
						return;
					}
				})
				if(flag){
					//调用方法
					creatType();
					//layer.close(index);
				}else{
					layer.msg('分类名称不能重复！');
					return false;
				}
				
			}
	   }
		,cancel: function(){ 
			//右上角关闭回调
			//return false 开启该代码可禁止点击该按钮关闭
		}
	});
})

/**创建新分类方法验证输入的信息**/
function addFen(){
	var html1="";
	var key1=[];
	html1 +='<div><span class="sp1">食品分类名称</span>';
	if(st=="1"){
	   html1 +='<input value="" type="text" class="foodNa">';
	   html1 +='</div><div class="sx"><a>筛选方式</a><span><img src="../style/image/cir.png" alt=""/></span><p><span class="tip">根据食品的名称进行筛选，多个关键字用空格隔开。</span></p></div>'+
		  '<div><span style="border-bottom:none;" class="sp1">食品名称关键字</span></div>'+
		  '<label for="inp"><div class="t-list clearfix" style="width:100%;height:150px;padding:10px;box-sizing:border-box;border:1px solid #ccc;">'+
			'<div class="ty-content clearfix">'+
			'<div class="key-list">'+
			'<input type="text" value="" placeholder="多个关键字使用空格隔开" class="input-write" id="inp"/>'+
			'</div>'+
			'</div>'+
			'</div></label>'; 
	}else{
		 var wxjson = new webjson("60");  
	      wxjson.AddParam("cId",cId);
	      wxjson.AddParam("zoneCode",zoneCode);
	      wxjson.AddParam("departmentid",c_id);
	  var res=WebRequest(wxjson);
	  var data = GetOjson(json_parse(res));
	  if(data.status == "0"){
		  if(st=="2"){
		      html1 +='<input value="'+data.param[0].typeName+'" type="text" class="foodNa" readonly="readonly">';
		  }else{
			  html1 +='<input value="'+data.param[0].typeName+'" type="text" class="foodNa">';  
		  }
		  html1 +='</div><div class="sx"><a>筛选方式</a><span><img src="../style/image/cir.png" alt=""/></span><p><span class="tip">根据食品的名称进行筛选，多个关键字用空格隔开。</span></p></div>'+
		  '<div><span style="border-bottom:none;" class="sp1">食品名称关键字</span></div>'+
		  '<label for="inp"><div class="t-list clearfix" style="width:100%;height:150px;padding:10px;box-sizing:border-box;border:1px solid #ccc;">'+
			'<div class="ty-content clearfix">'+
			'<div class="key-list">';
		  if(data.param[0].keyWords.length>0){
		      key1=data.param[0].keyWords.split(" ");
		  }
		  for(var i=0;i<key1.length;i++){
		    html1 +='<a href="javascript:void(0);">'+
					'<span class="span-tname">'+key1[i]+'</span>'+
					'<img src="../style/image/delete.png" class="delT">'+
					'</a>';
		  } 
			html1 +='<input type="text" value="" placeholder="多个关键字使用空格隔开" class="input-write" id="inp1"/>'+
			'</div>'+
			'</div>'+
			'</div></label>';
	  }else if(data.status == "9"){
			window.location.href="index.html?loginOut=true";
			return;
	  }else{
			layer.msg(data.info);
	  }
	}
	$(".warpper").html(html1);
	$(".input-write").on("keyup",function(event){
	      var event=event || window.event;
	      var inputVal=$(this).val();
	      var lastVal=inputVal.substr(inputVal.length-1,1);
	      if((lastVal == " " || event.keyCode == 13) && Trim(inputVal).length > 0){
	        var html='<a href="javascript:void(0);">'+
	        '<span class="span-tname">'+Trim($(this).val()).replace(/\ +/g,"")+'</span>'+
	        '<img src="../style/image/delete.png" class="delT">'+
	        '</a>';
	        var flag=true;
	        $.each($(".key-list .span-tname"),function(i,item){
	          if($(this).text() == Trim(inputVal)){
	            flag=false;
	          };
	        })
	        if(flag){
	          $(this).before(html);
	        }
	        $(this).val("").css("width",30);

	      }else{
	        var len=$(this).val().length*14;
	        if(len > 120){
	          $(this).css("width",120);
	        }else if(len < 30){
	          $(this).css("width",30);
	        }else{
	        	$(this).css("width",len);
	        }
	      }
	    })
	    $(".t-list").on("click","a",function(){
	    	$(this).remove();
	    })
 /**点击问号图标事件**/
 $(".sx>span").click(function(event) {
 	console.log("1111");
 	$(this).next('p').fadeToggle(10);
 });
 $(document).click(function(e){
 	    var sp = $(".sx>span");   // 设置目标区域
 	    if(!sp.is(e.target) && sp.has(e.target).length === 0){
 	        sp.next('p').hide();
 	    }
 	  });
}

/**创建新分类调用的方法及传值**/
function creatType(){
	var wxjson = new webjson("61"); //设置action值
	//新增param键值
	if(st=="2"||st=="3"){
	    wxjson.AddParam("cId",cId);
	    wxjson.AddParam("typeName",typeName);
	    wxjson.AddParam("keyWords",sskey);
	    wxjson.AddParam("type","UPDATE");
	}else{
		wxjson.AddParam("typename",typeName);
		wxjson.AddParam("departmentid",c_id);
		wxjson.AddParam("keywords",sskey);
		wxjson.AddParam("type","INSERT");
	}
	 WebRequestAsync(wxjson, addListDate);
}
function addListDate(res){
	var data = GetOjson(json_parse(res));
	console.log(data);
	if(data.status == 0) {
		if(st=="2"||st=="3"){
		 layer.msg(data.info);
		 foodList(c_id,zoneCode,pindex, psize);
		}else if(st=="1"){
			foodList(c_id,zoneCode,pindex, psize);
			layer.msg(data.info);
		}
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else{
		layer.msg(data.info);
	}
}

function ck(ts){
	layer.msg("该分类没有食品！");
}