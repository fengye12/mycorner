autoH();
var a1 = "a12",
	a2 = "a1202";
var zdgz="",typeId="",type="",cType="",pindex = "1",psize = "20",chuanzf="",lx="",name="";
/**分页设置**/
var pcent = new CentPage();
var pcount = ""; //总条数
var ps = pcent.GetCentPage(pindex, pcount, psize);
var jsonParam="";//导出时需要传的参数
$("#page").html(ps);
function CentPageOper(spindex) {
   if(chuanzf!=null&&chuanzf!=undefined){
	    var jgj=chuanzf.jgj;
		var time=chuanzf.time;
		var qylx=chuanzf.qylx;
		var jgj_name=chuanzf.jgj_name;
	  tongji(lx,jgj,time,qylx,jgj_name,spindex, psize);
   }else{
      book(zdgz,typeId,type,cType,spindex, psize);
   }
}

/**页面加载时**/
$(function() {
	var htmlTitle="";
    chuanzf=JSON.parse(getQueryString("chuanzf"));//报备统计页面传值
    console.log(chuanzf);
    lx=getQueryString("lx");
	name=$("#Faorgan").text();//报备统计页面的监管所名称
	if(chuanzf!=null&&chuanzf!=undefined){
		getActiveN("a12", "a1201");//当前页标志
		//$("img.qh").trigger('click');
		var jgj=chuanzf.jgj;
		var time=chuanzf.time;
		var qylx=chuanzf.qylx;
		var jgj_name=chuanzf.jgj_name;
		htmlTitle +="<a href='javascript:void(0);'>统计分析</a>><a href='ReportedCompany.html'>报备统计</a>><a href='javascript:void(0);'>查看相关台账</a>";
		$(".bread-nav").html(htmlTitle);
		tongji(lx,jgj,time,qylx,jgj_name,pindex, psize);
	}else{
		getActiveN("a12", "a1202");//当前页标志
		//$("img.qh").trigger('click');
		zdgz=getQueryString("zdgz");
		typeId=getQueryString("typeId");
		type=getQueryString("type");
		cType=getQueryString("cType");
		htmlTitle +="<a href='javascript:void(0);'>统计分析</a>><a href='focusStatistics.html'>重点关注统计</a>><a href='javascript:void(0);'>查看相关台账</a>";
		$(".bread-nav").html(htmlTitle);
		book(zdgz,typeId,type,cType,pindex, psize);
	}
		var zx=getQueryString("zx");
	if(zx=="" || zx == "zx"){
		getActiveN("a12", "a1202");//当前页标志
		a1="a12";a2="a1202";

         	var html ="<a href='javascript:void(0);'>统计分析</a>><a href='districtStatistics.html'>辖区统计</a>><a href='javascript:void(0);'>查看相关台账</a>";
         	$(".bread-nav").html(html);

	}
});

/**重点关注页面跳转**/
function book(zdgz,typeId,type,cType,spindex, psize){
	pindex = spindex;
	var zt1="";
	if(cType=="0"||cType=="1"){
		zt1="相关已入网生产企业";
	}else if(cType=="2"){
		zt1="相关已入网企业";
	}else if(cType=="3"){
		zt1="";
	}else if(cType=="4"){
		zt1="相关台账";
	}
	//console.log("name:"+name,"zt1:"+zt1,"type:"+type);
	var htmlCt="";
	 if(zt1!=null&&type!=null&&name!==null){
		htmlCt +="<a href='javascript:void(0);'>"+name+type+zt1+"</a>";
     $(".content-title").html(htmlCt);
	}else{
   	 $(".content-title").html("");
    }
	$("table tbody").children().remove();
	$("table tbody").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;'><img src='../style/image/load.gif' alt='' /></td></tr>");
	$("#mySelect").css("display","none");
	$("#daochu").css("display","none");
	var wxjson = new webjson("9");
	wxjson.AddParam("zdgz", zdgz);
	wxjson.AddParam("typeId", typeId);
	wxjson.AddParam("type", type);
	wxjson.AddParam("cType", cType);
	wxjson.AddParam("page_index", pindex);
	wxjson.AddParam("page_size", psize);
	WebRequestAsync(wxjson, bookList);
	jsonParam=wxjson.GetJsons();
}

/**报备统计页面跳转**/
function tongji(lx,jgj,time,qylx,jgj_name,spindex, psize){
	pindex = spindex;
	var htmlCt="";
	 if(jgj_name!=null&&time!=null&&lx!==null){
		htmlCt +="<a href='javascript:void(0);'>"+jgj_name+time+lx+"</a>";
     $(".content-title").html(htmlCt);
	}else{
   	 $(".content-title").html("");
    }
	$("table tbody").children().remove();
	$("table tbody").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;'><img src='../style/image/load.gif' alt='' /></td></tr>");
	$("#mySelect").css("display","none");
	$("#daochu").css("display","none");
	var wxjson = new webjson("9");
	wxjson.AddParam("jgj", jgj);
	wxjson.AddParam("time", time);
	wxjson.AddParam("qylx", qylx);
	wxjson.AddParam("jgj_name", jgj_name);
	wxjson.AddParam("lx", lx);
	if(getQueryString('zx')=="zx"){
		wxjson.AddParam("zx", 'zx');
	}
	wxjson.AddParam("page_index", pindex);
	wxjson.AddParam("page_size", psize);
	WebRequestAsync(wxjson, bookList);
	jsonParam=wxjson.GetJsons();
}

function bookList(res){
var html = "";
var data = GetOjson(json_parse(res));
console.log(data);
pcount = data.paramcentcount;
var ps = pcent.GetCentPage(pindex, pcount, psize);
$("#page").html(ps);
if(data.status == 0) {
	   if(pcount!="0"){
			$("#daochu").css("display","");
			$("#mySelect").css("display","");
			}else{
			 $("#daochu").css("display","none");
			 $("#mySelect").css("display","none");
			}
	for(var i = 0; i < data.param.length; i++){
		var cname1=escape(data.param[i].cname);
		//c_id=data.param[i].c_id;
		if(data.param[i].bbtype == 0) {
			data.param[i].bbtype = '食品采购报备';
		} else {
			data.param[i].bbtype = '食品销售报备';
		}
	/**	if(data.param[i].szstatus==0){
			data.param[i].szstatus='已索证';
		}else if(data.param[i].szstatus==1){
			data.param[i].szstatus='索证中';
		}else if(data.param[i].szstatus==2){
			data.param[i].szstatus='未索证';
		}else if(data.param[i].szstatus==3){
			data.param[i].szstatus='被举报';
		}**/
		html += "<tr>";
		html += '<td class="hs">' +data.param[i].cname+
		'</td><td class="hs">'+data.param[i].foodname+'</td>'+
		'<td class="hs">'+data.param[i].barcode+
		"</td><td class='hs'>" +data.param[i].bbtime +
		"</td><td class='hs'>" +data.param[i].djnum +
		"</td><td class='hs'>" +data.param[i].bbtype +
		'</td><td class="hs">' +data.param[i].jycname +
		"</td><td class='hs'>" +data.param[i].jytime;
		//"</td><td class='hs'>" +data.param[i].pnum +"</td>"
		/**if(data.param[i].szstatus=='未索证'){
		    html +="<td class='rs'>" +data.param[i].szstatus +"</td>";
		}else if(data.param[i].szstatus=='被举报'){
			html +="<td class='rs'>" +data.param[i].szstatus +"</td>";
		}else{
			html +="<td class='hs'>" +data.param[i].szstatus +"</td>";
		}**/
		html +='<td class="ls"><a href="StandingBook_check.html?bbid='+data.param[i].bbid+'" target="_blank">查看</a></td>';
	    html += "</tr>";
}
$("table tbody").html(html);
autoH();
}else if(data.status == 9){
	window.location.href="index.html?loginOut=true";
}else{
	$("#daochu").css("display","none");
	$("#mySelect").css("display","none");
	$("table tbody").html("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;font-size:14px;'>没有相关数据</td></tr>");
}
}

/**select选择框**/
function select() {
pindex="1";
//获取下拉框选中项的text属性值
var selectText = $("#mySelect").find("option:selected").text();
//获取下拉框选中项的value属性值
var selectValue = $("#mySelect").val();
console.log(selectValue);
psize = selectValue;
CentPageOper(pindex);
if(chuanzf!=null&&chuanzf!=undefined){
	   var jgj=chuanzf.jgj;
	   var time=chuanzf.time;
	   var qylx=chuanzf.qylx;
	   var jgj_name=chuanzf.jgj_name;
	  tongji(lx,jgj,time,qylx,jgj_name,pindex, psize);
}else{
      book(zdgz,typeId,type,cType,pindex, psize);
}
}

//模拟select
		$(".selectedB").on('click', '.sel-wrap', function(event) {
			var listH=$("#mySelectS").find(".optionB").height();
			if($(this).is(":hover")){
				console.log($(".selectedB .optionB").not($(this).next('.optionB')))
				$(".selectedB .optionB").not($(this).next('.optionB')).hide(20);
				$(this).next('.optionB').slideToggle(20);
			}
			if($(this).next(".selectedB").find(".optionB").css("display") != "none"){
				var offsetBottom=document.documentElement.clientHeight + $(document).scrollTop() - $(this).offset().top-$(this).height();
				if(offsetBottom < listH){
					console.log($(this).height())
					$("#mySelectS").find(".optionB").css({"left":"0","top":-listH})
				}
			}
			return false;
		});
		document.onclick = function(){
			$(".optionB").hide();
		};
	var selectText="20条/页";
		$("#mySelectS").on('click', '.op-item', function(event) {
			$("#mySelectS").find('.selected-item').text($(this).text());
			if(selectText != $(this).text()){
				pindex=1;
				selectText=$(this).text();
				if($(this).text()=="10条/页"){
					psize=10;
					if(chuanzf!=null&&chuanzf!=undefined){
					   var jgj=chuanzf.jgj;
					   var time=chuanzf.time;
					   var qylx=chuanzf.qylx;
					   var jgj_name=chuanzf.jgj_name;
					  tongji(lx,jgj,time,qylx,jgj_name,pindex, psize);
					}else{
					      book(zdgz,typeId,type,cType,pindex, psize);
					}
				}else if($(this).text()=="20条/页"){
					psize=20;
					if(chuanzf!=null&&chuanzf!=undefined){
					   var jgj=chuanzf.jgj;
					   var time=chuanzf.time;
					   var qylx=chuanzf.qylx;
					   var jgj_name=chuanzf.jgj_name;
					  tongji(lx,jgj,time,qylx,jgj_name,pindex, psize);
					}else{
					      book(zdgz,typeId,type,cType,pindex, psize);
					}
				}else if($(this).text()=="30条/页"){
					psize=30;
					if(chuanzf!=null&&chuanzf!=undefined){
					   var jgj=chuanzf.jgj;
					   var time=chuanzf.time;
					   var qylx=chuanzf.qylx;
					   var jgj_name=chuanzf.jgj_name;
					  tongji(lx,jgj,time,qylx,jgj_name,pindex, psize);
					}else{
					      book(zdgz,typeId,type,cType,pindex, psize);
					}
				}else if($(this).text()=="40条/页"){
					psize=40;
					if(chuanzf!=null&&chuanzf!=undefined){
					   var jgj=chuanzf.jgj;
					   var time=chuanzf.time;
					   var qylx=chuanzf.qylx;
					   var jgj_name=chuanzf.jgj_name;
					  tongji(lx,jgj,time,qylx,jgj_name,pindex, psize);
					}else{
					      book(zdgz,typeId,type,cType,pindex, psize);
					}
				}else if($(this).text()=="50条/页"){
					psize=50;
					if(chuanzf!=null&&chuanzf!=undefined){
					   var jgj=chuanzf.jgj;
					   var time=chuanzf.time;
					   var qylx=chuanzf.qylx;
					   var jgj_name=chuanzf.jgj_name;
					  tongji(lx,jgj,time,qylx,jgj_name,pindex, psize);
					}else{
					      book(zdgz,typeId,type,cType,pindex, psize);
					}
				}else{
				}

			}

			$(this).closest('.optionB').slideUp(20);
		});

/**导出**/
$("#daochu").click(function(){
var excelName=$(".content-title a").text();
var pattern = new RegExp('[\/:*?"<>|]');
if(pattern.test(excelName)){
    for (var i = 0; i < excelName.length; i++) {
    	excelName = excelName.replace(pattern, '-');
    	console.log(excelName);
    }
}
var listType="ledgerCountList";
var header="报备企业"+","+"商品名称"+","+"商品条码"+","+"报备日期"+","+"单据号"+","+"报备类型"+","+"交易对象"+","+"交易日期";
if(pcount<1001){
	var exportExcelParam={
		excelName:escape(excelName),
		listType:listType,
		header:header,
		jsonParam:jsonParam
	}
	postExportExcel(dcUrl,exportExcelParam);
}else{
	layer.open({
		title: '系统提示'
		,content: '当前数据量超过1000条，为了数据的安全，我们无法为您导出该数据，如需导出请联系客服。'
		,btn: ['确定']
		,yes: function(){
			layer.closeAll();
		}
	});
	return false;
}
})