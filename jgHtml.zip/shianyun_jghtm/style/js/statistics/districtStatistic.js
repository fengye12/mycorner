/*
* @Author: anchen
* @Date:   2017-09-06 16:28:32
* @Last Modified by:   anchen
* @Last Modified time: 2017-09-27 16:02:30
*/

'use strict';
/*
* @Author: anchen
* @Date:   2017-08-02 20:21:15
* @Last Modified by:   anchen
* @Last Modified time: 2017-09-07 12:42:30
*/


var a1='a12',a2='a1202';
getActiveN("a12","a1202");

//ÏÂÏ½µØÇø³õÊ¼Öµ
  var data = [];
var departmentid=$.cookie("departmentid");
var isLock=0;

var de_idName=[];
var de_idCode=[];
var organList=[];//监管局名称和id

 $(function(){

DefaultDate(2);
getDefaultGroup();

})


    //ÉèÖÃ×îÐ¡¸ß¶È
     var mainHeight=$('body').height()-110;
     $(".mainContent").css('min-height', mainHeight);

           var end = {
                 format: 'YYYY-MM',
                 isToday:true,
                isClear:false,
                 maxDate:$.nowDate({DD:0}), //×î´óÈÕÆÚ
                 choosefun: function(elem,datas){
                  }
             };
    $('#to').jeDate(end);
    function DefaultDate(){
          var today=new Date();
         var Month=+today.getMonth()+1;
         var Datet=today.getDate();
         if(Month<10){
          Month='0'+Month;
         }
         if(Datet<10){
           Datet='0'+Datet;
         }
         var toDate=today.getFullYear()+'-'+Month;
            $("#to").val(toDate)
    }
    function getDefaultGroup(){

             var wxjson = new webjson("22");
             wxjson.AddParam("departmentid",departmentid);//ÓÃ»§id×éºÏ
             wxjson.AddParam("nowdeptid",' ');//ÓÃ»§id×éºÏ
             wxjson.AddParam("flag",'yes');//ÓÃ»§id×éºÏ
             WebRequestAsync(wxjson, successGroup);
             function successGroup(res){
               console.log(res)
                 var data = GetOjson(json_parse(res));
                 console.log(data);
                 if(data.status == 0){
                   if(data.param.length>0){
                    organList=[];
                     for(var i=0;i<data.param.length;i++){
                        var singleData={'id':data.param[i].departmentid,'text':data.param[i].department}
                        organList.push(singleData);
                     }

                    //lected2³õÖµ»¯
                     var selects= $(".js-example-data-array").select2({
                        data: organList,
                        language: "Zh-CN"
                      })
                     // .select2()
                   $(".js-example-data-array").val(departmentid).select2();
                   getData(departmentid,0,$("#to").val().split("-").join
                    (''))

                   }
             }else if(data.status == 9){//³¬Ê±ÖØÐÂµÇÂ¼
               window.location.href="index.html?loginOut=true";
               return;
           }else{
            layer.close(layer1)
            layer.msg(data.info);
        }
       }
    }

//Ä£Äâselect
  $(".selectedB").on('click', '.sel-wrap', function(event) {
    if($(this).is(":hover")){
      console.log($(".selectedB .optionB").not($(this).next('.optionB')))
      $(".selectedB .optionB").not($(this).next('.optionB')).hide(20);
      $(this).next('.optionB').slideToggle(20);
    }
   return false;
 });

  $(".selectedB").on('click', '.op-item', function(event) {
    $(this).closest('.selectedB').find('.selected-item').text($(this).text());
    $(this).closest('.optionB').slideUp(20);
  });


 document.onclick = function(){
   $(".optionB").hide();
 };


function getData(deptId,seltype,month){
  $(".table-body").empty();
  if(seltype==0){
    $(".tTable thead").empty();
    $(".tTable thead").append('<tr><th rowspan="2">下辖地区</th><th colspan="3">生产企业</th><th colspan="3">流通企业</th><th colspan="3">餐饮企业</th><th colspan="3">单位食堂</th><th colspan="3">合计</th></tr><tr><th>入网企业</th><th>报备企业</th><th>报备率</th><th>入网企业</th><th>报备企业</th><th>报备率</th><th>入网企业</th><th>报备企业</th><th>报备率</th><th>入网企业</th><th>报备企业</th><th>报备率</th><th>入网企业</th><th>报备企业</th><th>报备率</th></tr>');
  }else{
    $(".tTable thead").empty();
    $(".tTable thead").append('<tr><th rowspan="2">下辖地区</th><th colspan="3">生产企业</th><th colspan="3">流通企业</th><th colspan="3">餐饮企业</th><th colspan="3">单位食堂</th><th colspan="3">合计</th></tr><tr><th>台账报备</th><th>票据报备</th><th>经营备案</th><th>台账报备</th><th>票据报备</th><th>经营备案</th><th>台账报备</th><th>票据报备</th><th>经营备案</th><th>台账报备</th><th>票据报备</th><th>经营备案</th><th>台账报备</th><th>票据报备</th><th>经营备案</th></tr>');

  }
  $(".table-body").append("<tr class='loading' style='width:100%;height:80px;'><td colspan='16' style='text-align:center'><img src='../style/image/load.gif' width='32px' height='32px'/></td></tr>");
  var wxjson = new webjson("4");
  wxjson.AddParam("deptId",deptId);//ÓÃ»§id×éºÏ
  wxjson.AddParam("seltype",seltype);//ÓÃ»§id×éºÏ
  wxjson.AddParam("month",month);//ÓÃ»§id×éºÏ
  WebRequestAsync(wxjson, successGetData);
  function successGetData(res){
    var data = GetOjson(json_parse(res));
    console.log(data);
    if(data.status==0){
      if(data.param.length>0){
            if(seltype == 0){
               $(".table-body").empty();
               var html="";
               $.each(data.param, function(index, val) {
                if(val.jgsname=="直辖"){
                    html += '<tr>'
                   +'<td>'+val.jgsname+'</td>'
                   +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","0","'+val.jgsname+'","入网企业","","zx");>'+val.scqyrws+'</td>'
                   +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","0","'+val.jgsname+'","报备企业","","zx");>'+val.scqybbs+'</td>'
                   +'<td class="">'+val.scqybbl+'</td>'
                   +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","1","'+val.jgsname+'","入网企业","","zx")>'+val.ltqyrws+'</td>'
                   +'<td class=" activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","1","'+val.jgsname+'","报备企业","","zx")>'+val.ltqybbs+'</td>'
                   +'<td class=" ">'+val.ltqybbl+'</td>'
                   +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","2","'+val.jgsname+'","入网企业","","zx")>'+val.cyqyrws+'</td>'
                   +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","2","'+val.jgsname+'","报备企业","","zx")>'+val.cyqybbs+'</td>'
                   +'<td class="">'+val.cyqybbl+'</td>'
                   +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","3","'+val.jgsname+'","入网统计","","zx")>'+val.stqyrws+'</td>'
                   +'<td class=" activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","3","'+val.jgsname+'","报备企业","","zx")>'+val.stqybbs+'</td>'
                   +'<td class="">'+val.stqybbl+'</td>'
                   +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","","'+val.jgsname+'","入网企业","","zx")>'+(parseInt(val.stqyrws)+parseInt(val.scqyrws)+parseInt(val.ltqyrws)+parseInt(val.cyqyrws))+'</td>'
                   +'<td class=" activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","","'+val.jgsname+'","报备企业","","zx")>'+(parseInt(val.stqybbs)+parseInt(val.scqybbs)+parseInt(val.ltqybbs)+parseInt(val.cyqybbs)+parseInt(val.stqybbs))+'</td>'
                   +'<td class="">';
                    var rwsl=parseInt(val.stqyrws)+parseInt(val.scqyrws)+parseInt(val.ltqyrws)+parseInt(val.cyqyrws);
                   if(rwsl==0){
                     var bbsl=parseInt(val.stqybbs)+parseInt(val.scqybbs)+parseInt(val.ltqybbs)+parseInt(val.cyqybbs);
                    html+='0%</td>'

                   }else{
                     var bbsl=parseInt(val.stqybbs)+parseInt(val.scqybbs)+parseInt(val.ltqybbs)+parseInt(val.cyqybbs);
                     var bbbl=(bbsl/rwsl)*100;
                    html+=bbbl.toFixed(2)+'%</td>'

                   }
                   html+='</td>'
                 +'</tr>'
               }else{
                html += '<tr>'
                  +'<td>'+val.jgsname+'</td>'
                  +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","0","'+val.jgsname+'","入网企业","","");>'+val.scqyrws+'</td>'
                  +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","0","'+val.jgsname+'","报备企业","","");>'+val.scqybbs+'</td>'
                  +'<td class="">'+val.scqybbl+'</td>'
                  +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","1","'+val.jgsname+'","入网企业","","")>'+val.ltqyrws+'</td>'
                  +'<td class=" activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","1","'+val.jgsname+'","报备企业","","")>'+val.ltqybbs+'</td>'
                  +'<td class=" ">'+val.ltqybbl+'</td>'
                  +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","2","'+val.jgsname+'","入网企业","","")>'+val.cyqyrws+'</td>'
                  +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","2","'+val.jgsname+'","报备企业","","")>'+val.cyqybbs+'</td>'
                  +'<td class="">'+val.cyqybbl+'</td>'
                  +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","3","'+val.jgsname+'","入网企业","","")>'+val.stqyrws+'</td>'
                  +'<td class=" activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","3","'+val.jgsname+'","报备企业","","")>'+val.stqybbs+'</td>'
                  +'<td class="">'+val.stqybbl+'</td>'
                  +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","","'+val.jgsname+'","入网企业","","")>'+(parseInt(val.stqyrws)+parseInt(val.scqyrws)+parseInt(val.ltqyrws)+parseInt(val.cyqyrws))+'</td>'
                  +'<td class=" activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","","'+val.jgsname+'","报备企业","","")>'+(parseInt(val.stqybbs)+parseInt(val.scqybbs)+parseInt(val.ltqybbs)+parseInt(val.cyqybbs))+'</td>'
                  +'<td class="">';
                   var rwsl=parseInt(val.stqyrws)+parseInt(val.scqyrws)+parseInt(val.ltqyrws)+parseInt(val.cyqyrws);
                  if(rwsl==0){
                    // var bbsl=parseInt(val.stqybbs)+parseInt(val.scqybbs)+parseInt(val.ltqybbs)+parseInt(val.cyqybbs);
                   html+='0%</td>'

                  }else{
                    var bbsl=parseInt(val.stqybbs)+parseInt(val.scqybbs)+parseInt(val.ltqybbs)+parseInt(val.cyqybbs);
                    var bbbl=(bbsl/rwsl)*100;
                   html+=bbbl.toFixed(2)+'%</td>'

                  }
                    html+='</td>'
                  +'</tr>'
               }

               });

               $(".table-body").append(html);
               var zhixia=$(".table-body").find('tr').last().clone().remove();
               var zhixia=$(".table-body").find('tr').last().remove();
               $(".table-body").prepend(zhixia);
               $(".table-body .activeA").each(function(index, el) {
                 if($(this).text()==0){
                  $(this).removeClass('activeA');
                  $(this).attr('onclick',"");
                 }
               });

            }else{
              $(".table-body").empty();
              var html="";
              $.each(data.param, function(index, val) {
                if(val.jgsname=="直辖"){
                     html += '<tr>'
                    +'<td class="">'+val.jgsname+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","0","'+val.jgsname+'","台账报备","0","zx")>'+val.scqytz+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","0","'+val.jgsname+'","票据报备","1","zx")>'+val.scqypj+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","0","'+val.jgsname+'","经营备案","2","zx")>'+val.scqyjyba+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","1","'+val.jgsname+'","台账报备","0","zx")>'+val.ltqytz+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","1","'+val.jgsname+'","票据报备","1","zx")>'+val.ltqypj+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","1","'+val.jgsname+'","经营备案","2","zx")>'+val.ltqyjyba+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","2","'+val.jgsname+'","台账报备","0","zx")>'+val.cyqytz+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","2","'+val.jgsname+'","票据报备","1","zx")>'+val.cyqypj+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","2","'+val.jgsname+'","经营备案","2","zx")>'+val.cyqyjyba+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","3","'+val.jgsname+'","台账报备","0","zx")>'+val.stqytz+'</td>'
                    +'<td class=" activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","3","'+val.jgsname+'","票据报备","1","zx")>'+val.stqypj+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","3","'+val.jgsname+'","经营备案","2","zx")>'+val.stqyjyba+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","","'+val.jgsname+'","台账报备","0","zx")>'+(parseInt(val.scqytz)+parseInt(val.ltqytz)+parseInt(val.cyqytz)+parseInt(val.stqytz))+'</td>'
                    +'<td class=" activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","","'+val.jgsname+'","票据报备","1","zx")>'+(parseInt(val.scqypj)+parseInt(val.ltqypj)+parseInt(val.cyqypj)+parseInt(val.stqypj))+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","","'+val.jgsname+'","经营备案","2","zx")>'+(parseInt(val.scqyjyba)+parseInt(val.ltqyjyba)+parseInt(val.cyqyjyba)+parseInt(val.stqyjyba))+'</td>'
                  +'</tr>'
                }else{
                     html += '<tr>'
                    +'<td class="">'+val.jgsname+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","0","'+val.jgsname+'","台账报备","0","")>'+val.scqytz+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","0","'+val.jgsname+'","票据报备","1","")>'+val.scqypj+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","0","'+val.jgsname+'","经营备案","2","")>'+val.scqyjyba+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","1","'+val.jgsname+'","台账报备","0","")>'+val.ltqytz+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","1","'+val.jgsname+'","票据报备","1","")>'+val.ltqypj+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","1","'+val.jgsname+'","经营备案","2","")>'+val.ltqyjyba+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","2","'+val.jgsname+'","台账报备","0","")>'+val.cyqytz+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","2","'+val.jgsname+'","票据报备","1","")>'+val.cyqypj+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","2","'+val.jgsname+'","经营备案","2","")>'+val.cyqyjyba+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","3","'+val.jgsname+'","台账报备","0","")>'+val.stqytz+'</td>'
                    +'<td class=" activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","3","'+val.jgsname+'","票据报备","1","")>'+val.stqypj+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","3","'+val.jgsname+'","经营备案","2","")>'+val.stqyjyba+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","","'+val.jgsname+'","台账报备","0","")>'+(parseInt(val.scqytz)+parseInt(val.ltqytz)+parseInt(val.cyqytz)+parseInt(val.stqytz))+'</td>'
                    +'<td class=" activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","","'+val.jgsname+'","票据报备","1","")>'+(parseInt(val.scqypj)+parseInt(val.ltqypj)+parseInt(val.cyqypj)+parseInt(val.stqypj))+'</td>'
                    +'<td class="activeA" onclick=getDetail2("'+val.deptid+'","'+month+'","","'+val.jgsname+'","经营备案","2","")>'+(parseInt(val.scqyjyba)+parseInt(val.ltqyjyba)+parseInt(val.cyqyjyba)+parseInt(val.stqyjyba))+'</td>'
                  +'</tr>'
                }

              });

              $(".table-body").append(html);
              var zhixia=$(".table-body").find('tr').last().clone().remove();
              var zhixia=$(".table-body").find('tr').last().remove();
              $(".table-body").prepend(zhixia);
              $(".table-body .activeA").each(function(index, el) {
                if($(this).text()==0){
                 $(this).removeClass('activeA');
                 $(this).attr('onclick',"");
                }
              });

            }
          }else{
            noData(13);
          }
    }else if(data.status==1){
      noData(13);
    }else if(data.status == 9){//³¬Ê±ÖØÐÂµÇÂ¼
               window.location.href="index.html?loginOut=true";
        }else{
            layer.msg(data.info);
        }
  }
}

//²éÑ¯²»µ½Êý¾Ý
function noData(data){
  $(".table-body").empty();
  $(".table-body").append("<tr class='loading' style='width:100%;height:80px;'><td colspan='"+data+"' style='text-align:center'>没有相关数据</td></tr>");
}
// function getDetail(countWay,flag,liTitle,neTitle,qyType,sum,time,zone_code){

//      var objSting={"neTitle":neTitle,"liTitle":liTitle,"zone_code":zone_code,"qyType":qyType,"countWay":countWay,"time":time,"flag":flag,"sum":sum};
//     objSting=JSON.stringify(objSting);
//     if(sum!="0"){
//       window.open('look_company.html?objSting='+escape(objSting),'_blank')
//     }

// }
// 查看详细
function getDetail2(zone_code,time,qyType,jgj_name,FLAG,type,zx){
  if(jgj_name=="直辖" || jgj_name=="合计"){

    $.each(organList, function(index, val) {
      var selId=$(".js-example-data-array").val();
      if(selId==val.id){
        jgj_name=val.text+jgj_name;
        return false
      }

    });

  }
   var chuanzf={'jgj':zone_code,'time':time,'qylx':qyType,'jgj_name':jgj_name}
    chuanzf=JSON.stringify(chuanzf);
    // console.log($(target))
    // if($(this).text()!=0){
    if(type==""){
    window.open('look_company.html?chuanzf='+escape(chuanzf)+'&lx='+escape(FLAG)+'&zx='+zx,'_blank')
    }if(type==0){
      window.open('look_book.html?chuanzf='+escape(chuanzf)+'&lx='+escape(FLAG)+'&zx='+zx,'_blank')
    }else if(type==1){
        window.open('look_bill.html?chuanzf='+escape(chuanzf)+'&lx='+escape(FLAG)+'&zx='+zx,'_blank')
    }else if(type==2){
       window.open('look_record.html?chuanzf='+escape(chuanzf)+'&lx='+escape(FLAG)+'&zx='+zx,'_blank')
    }
  // }
}

                $("#comfire").click(function(event) {
                  var endDate=$("#to").val().split("-").join('');
                  var depid=$(".js-example-data-array").val();
                  var type= $("#seT_type").text()=="按企业"?0:1;
                  getData(depid,type,endDate);

                });
