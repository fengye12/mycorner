autoH();
var a1 = "a12",
	a2 = "a1202";
var chuanzf="",lx="",pindex = "1",psize = "20",jgj="",time="",qylx="",jgj_name="",billcode="";
var photo="";
/**分页设置**/
var pcent = new CentPage();
var pcount = ""; //总条数
var ps = pcent.GetCentPage(pindex, pcount, psize);
$("#page").html(ps);
function CentPageOper(spindex) {
	bill(lx,jgj,time,qylx,jgj_name,spindex, psize);
}

/**页面加载时**/
$(function() {
	getActiveN("a12", "a1201");//当前页标志
	//$("img.qh").trigger('click');
	chuanzf=JSON.parse(getQueryString("chuanzf"));
	lx=getQueryString("lx");
	jgj=chuanzf.jgj;
	time=chuanzf.time;
	qylx=chuanzf.qylx;
	jgj_name=chuanzf.jgj_name;
    var htmlCt="";
    	var zx=getQueryString("zx");
    if(zx=="" || zx == "zx"){
    	getActiveN("a12", "a1202");//当前页标志
    	a1="a12";a2="a1202";
    }
 /**获取页面头部信息**/
  if(jgj_name!=null&&time!=null&&lx!==null){
     htmlCt +="<a href='javascript:void(0);'>"+jgj_name+time+lx+"</a>";
	 $(".content-title").html(htmlCt);
     }else{
    	 $(".content-title").html("");
     }
     if(zx=="" || zx == "zx"){
         	var html ="<a href='javascript:void(0);'>统计分析</a>><a href='districtStatistics.html'>辖区统计</a>><a href='javascript:void(0);'>查看相关票据</a>";
         	$(".bread-nav").html(html);
          }
    bill(lx,jgj,time,qylx,jgj_name,pindex, psize);
});

/**列表**/
function bill(lx,jgj,time,qylx,jgj_name,spindex, psize) {
	pindex = spindex;
	$("table tbody").children().remove();
	$("table tbody").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;'><img src='../style/image/load.gif' alt='' /></td></tr>");
	$("#mySelect").css("display","none");
	var wxjson = new webjson("31"); //设置action值
	//新增param键值
	wxjson.AddParam("jgj", jgj);
	wxjson.AddParam("time", time);
	wxjson.AddParam("lx", lx);
	wxjson.AddParam("qylx", qylx);
	if(getQueryString('zx')=="zx"){
		wxjson.AddParam("zx", 'zx');
	}
	wxjson.AddParam("jgj_name", jgj_name);
	wxjson.AddParam("page_index", pindex);
	wxjson.AddParam("page_size", psize);
	WebRequestAsync(wxjson, billList);
}
function billList(res){
	var html = "";
	var data = GetOjson(json_parse(res));
	console.log(data);
	pcount = data.paramcentcount;
	var ps = pcent.GetCentPage(pindex, pcount, psize);
	$("#page").html(ps);
	if(data.status == 0) {
		if(pcount!="0"){
			$("#mySelect").css("display","");
			}else{
			 $("#mySelect").css("display","none");
			}
		for(var i = 0; i < data.param.length; i++){
			var cname1=escape(data.param[i].cname);
			var jytype="";
			if(data.param[i].jytype == "0"){
				jytype="食品采购报备";
			}else{
				jytype="食品销售报备";
			}
			html += "<tr>";
			html+='<td class="hs">' +data.param[i].cname +
			'</td><td class="hs">'+data.param[i].bbdate+
			'</td><td class="hs">'+jytype+
			'</td><td class="hs">' +data.param[i].jycname +
			'</td><td class="hs">'+data.param[i].jydate+
			'</td><td class="ls" onclick="ck(this)" style="cursor: pointer;">查看<span style="display:none">' +
			data.param[i].billcode+ '</span></td>';
		    html += "</tr>";
	}
	$("table tbody").html(html);
	autoH();
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else {
		$("table tbody").html("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;font-size:14px;'>没有相关数据</td></tr>");
		$("#mySelect").css("display","none");
	}
}

/**select选择框**/
/**function select() {
	//获取下拉框选中项的text属性值
	pindex="1";
	var selectText = $("#mySelect").find("option:selected").text();
	//获取下拉框选中项的value属性值
	var selectValue = $("#mySelect").val();
	console.log(selectValue);
	psize = selectValue;
	CentPageOper(pindex);
	bill(lx,jgj,time,qylx,jgj_name,pindex, psize);
}**/

/**点击查看**/
function ck(c){
	billcode=$(c).find("span").text();
	console.log(billcode);
	layer.open({
		type: 1,
		title: '查看票据',
		shadeClose: true,
		shade: 0.5,
		area: ['650px', '700px'],
		content: '\<div class="warpperBox"><\/div><script> photoLook(billcode);</script>'
	});
}
function photoLook(billcode) {
	var wxjson = new webjson("32"); //设置action值
	//新增param键值
	wxjson.AddParam("billcode", billcode);
	WebRequestAsync(wxjson, photoRead);
}
function photoRead(res){
	 var html="";
	 var data = GetOjson(json_parse(res));
	 console.log(data);
	 if(data.status == 0){
	  html += "<div class='imgDiv' style='width: 600px;height: 610px; margin:20px;border:none;'>" +
		"<ul class='images' style='list-style: none;'>";
	  for(var i = 0; i < data.param.length; i++) {
	   if(data.param[i].bppath.length>0){
			photo = (data.param[i].bppath).split(",");
		}else{
			photo=data.param[i].bppath;
		}
	   console.log(photo);
	  for(var j = 0; j < photo.length; j++) {
			html += "<li><img src='" + photo[j] + "'></li>";
		}
	  }
	     html +="</ul></div>";
	     $(".warpperBox").html(html);
			console.log($(".images"))
			$(".images").viewer({
				inline: true
			});
}
}

//模拟select
$(".selectedB").on('click', '.sel-wrap', function(event) {
	var listH=$("#mySelectS").find(".optionB").height();
	if($(this).is(":hover")){
		console.log($(".selectedB .optionB").not($(this).next('.optionB')))
		$(".selectedB .optionB").not($(this).next('.optionB')).hide(20);
		$(this).next('.optionB').slideToggle(20);
	}
	if($(this).next(".selectedB").find(".optionB").css("display") != "none"){
		var offsetBottom=document.documentElement.clientHeight + $(document).scrollTop() - $(this).offset().top-$(this).height();
		if(offsetBottom < listH){
			console.log($(this).height())
			$("#mySelectS").find(".optionB").css({"left":"0","top":-listH})
		}
	}
	return false;
});
document.onclick = function(){
	$(".optionB").hide();
};
var selectText="20条/页";
$("#mySelectS").on('click', '.op-item', function(event) {
	$("#mySelectS").find('.selected-item').text($(this).text());
	if(selectText != $(this).text()){
		pindex=1;
		selectText=$(this).text();
		if($(this).text()=="10条/页"){
			psize=10;
		}else if($(this).text()=="20条/页"){
			psize=20;
		}else if($(this).text()=="30条/页"){
			psize=30;
		}else if($(this).text()=="40条/页"){
			psize=40;
		}else if($(this).text()=="50条/页"){
			psize=50;
		}else{
		}
		bill(lx,jgj,time,qylx,jgj_name,pindex, psize);
	}

	$(this).closest('.optionB').slideUp(20);
});

