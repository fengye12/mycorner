autoH();
var a1 = "a12",
	a2 = "a1202";
var zdgz="",typeId="",type="",cType="",pindex = "1",psize = "20",name="";
/**分页设置**/
var pcent = new CentPage();
var pcount = ""; //总条数
var jsonParam="";//导出时需要传的参数
var ps = pcent.GetCentPage(pindex, pcount, psize);
$("#page").html(ps);
function CentPageOper(spindex) {
	food(zdgz,typeId,type,cType,spindex, psize);
}

/**页面加载时**/
$(function() {
	getActiveN("a12", "a1202");//当前页标志
	//$("img.qh").trigger('click');
	name=$.cookie('dept_name');//监管所name
	var zt1="";
	zdgz=getQueryString("zdgz");
	typeId=getQueryString("typeId");
	type=getQueryString("type");
	cType=getQueryString("cType");
	if(cType=="0"||cType=="1"){
		zt1="相关已入网生产企业";
	}else if(cType=="2"){
		zt1="相关已入网企业";
	}else if(cType=="3"){
		zt1="";
	}else if(cType=="4"){
		zt1="相关台账";
	}
	//console.log("zt1:"+zt1,"lbname:"+lbname,"name:"+name);
  var htmlCt="";
 /**获取页面头部信息**/
  if(zt1!=null&&type!=null&&name!==null){
    	htmlCt +="<a href='javascript:void(0);'>"+name+type+zt1+"</a>";
	 $(".content-title").html(htmlCt);
     }else{
    	 $(".content-title").html("");
     }
    food(zdgz,typeId,type,cType,pindex, psize);
});

/**食品列表**/
function food(zdgz,typeId,type,cType,spindex, psize) {
	pindex = spindex;
	$("table tbody").children().remove();
	$("table tbody").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;'><img src='../style/image/load.gif' alt='' /></td></tr>");
	$("#daochu").css("display","none");
	$("#mySelectS").css("display","none");
	var wxjson = new webjson("7"); //设置action值
	//新增param键值
	wxjson.AddParam("zdgz", zdgz);
	wxjson.AddParam("typeId", typeId);
	wxjson.AddParam("type", type);
	wxjson.AddParam("cType", cType);
	wxjson.AddParam("page_index", pindex);
	wxjson.AddParam("page_size", psize);
	WebRequestAsync(wxjson, foodList);
	jsonParam=wxjson.GetJsons();
}
function foodList(res){
	var html = "";
	var data = GetOjson(json_parse(res));
	console.log(data);
	pcount = data.paramcentcount;
	var ps = pcent.GetCentPage(pindex, pcount, psize);
	$("#page").html(ps);
	if(data.status == 0) {
		if(pcount!="0"){
			$("#daochu").css("display","");
			$("#mySelectS").css("display","");
			}else{	
			 $("#daochu").css("display","none");
			 $("#mySelectS").css("display","none");
			}
		for(var i = 0; i < data.param.length; i++){
			if(data.param[i].time==undefined){
				data.param[i].time="";
			}
			var pname=escape(data.param[i].pname);
			var ycountry1=escape(data.param[i].ycountry);
			html += "<tr>";
			html += "<td class='hs'>" +data.param[i].pname + 
			"</td><td class='hs'>" +data.param[i].barcode + 
			"</td><td class='hs'>" +data.param[i].ycountry + 
			"</td><td class='hs'>" +data.param[i].time + 		
			'</td><td class="hs ls"><a href="Food_company.html?barcode='+data.param[i].barcode+'&pname='+pname+'&ycountry='+ycountry1+'&pid='+data.param[i].pid+'" target="_blank">'+data.param[i].xgqy+'</a></td>'+
            '<td class="hs ls"><a href="Food_info.html?pid='+data.param[i].pid+'&barcode='+data.param[i].barcode+'&pname='+pname+'&ycountry='+ycountry1+'" target="_blank">详情<span style="display:none;">'+data.param[i].pid+'</span></a></td>'			
		    html += "</tr>";
	}
	$("table tbody").html(html);
	autoH();
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else {
		$("table tbody").html("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;font-size:14px;'>没有相关数据</td></tr>");
		$("#daochu").css("display","none");
		$("#mySelectS").css("display","none");
	}  
}  

/**select选择框**/
// function select() {
// 	//获取下拉框选中项的text属性值
// 	pindex="1";
// 	var selectText = $("#mySelect").find("option:selected").text();
// 	//获取下拉框选中项的value属性值
// 	var selectValue = $("#mySelect").val();
// 	console.log(selectValue);
// 	psize = selectValue;
// 	CentPageOper(pindex);
// 	food(zdgz,typeId,type,cType,pindex, psize);
// }

//模拟select
		$(".selectedB").on('click', '.sel-wrap', function(event) {
			var listH=$("#mySelectS").find(".optionB").height();
			if($(this).is(":hover")){
				console.log($(".selectedB .optionB").not($(this).next('.optionB')))
				$(".selectedB .optionB").not($(this).next('.optionB')).hide(20);
				$(this).next('.optionB').slideToggle(20);
			}
			if($(this).next(".selectedB").find(".optionB").css("display") != "none"){
				var offsetBottom=document.documentElement.clientHeight + $(document).scrollTop() - $(this).offset().top-$(this).height();
				if(offsetBottom < listH){
					console.log($(this).height())
					$("#mySelectS").find(".optionB").css({"left":"0","top":-listH})
				}
			}
			return false;
		});
		document.onclick = function(){
			$(".optionB").hide();
		};
	var selectText="20条/页";
		$("#mySelectS").on('click', '.op-item', function(event) {
			$("#mySelectS").find('.selected-item').text($(this).text());
			if(selectText != $(this).text()){
				pindex=1;
				selectText=$(this).text();
				if($(this).text()=="10条/页"){
					psize=10;
				}else if($(this).text()=="20条/页"){
					psize=20;
				}else if($(this).text()=="30条/页"){
					psize=30;
				}else if($(this).text()=="40条/页"){
					psize=40;
				}else if($(this).text()=="50条/页"){
					psize=50;
				}else{
				}
				food(zdgz,typeId,type,cType,pindex, psize);
			}
			
			$(this).closest('.optionB').slideUp(20);
		});

/**导出**/
$("#daochu").click(function(){
	console.log(jsonParam);
	var excelName=$(".content-title a").text();
	var pattern = new RegExp('[\/:*?"<>|]');  
	if(pattern.test(excelName)){  
        for (var i = 0; i < excelName.length; i++) { 
        	excelName = excelName.replace(pattern, '-'); 
        	console.log(excelName);
        } 
    }     
	var listType="goodsList"; 
	var header="食品名称"+","+"商品条码"+","+"原产国"+","+"商标"+","+"贮存条件"+","+"相关企业"+","+"保质期"+","+"规格"+","+"包装方式";
	if(pcount<1001){
		var exportExcelParam={
			excelName:escape(excelName),
			listType:listType,
			header:header,
			jsonParam:jsonParam
		}
		postExportExcel(dcUrl,exportExcelParam);
	}else{
		layer.open({
			title: '系统提示'
			,content: '当前数据量超过1000条，为了数据的安全，我们无法为您导出该数据，如需导出请联系客服。'
			,btn: ['确定']
			,yes: function(){
				layer.closeAll();
			}
		});	
		return false;
	}
})


	