/*
* @Author: anchen
* @Date:   2017-08-02 20:21:15
* @Last Modified by:   anchen
* @Last Modified time: 2017-08-18 19:27:40
*/
//定义图表初始值
// var ecount = $("#mySelect").val();//一页数据条数
// var cpage = new CentPage();//初始化分页
// var pagenum = 1;//第几页
// var paramcentcount=0;//总数据条数
var leftxAxis = [];
var leftrw = [];
var leftxz=[];
var leftrwqy=[];
var leftwrw=[];

var a1='a12',a2='a1200';
getActiveN("a12","a1200");
//下辖地区初始值
  var data = [];
var departmentid=$.cookie("departmentid");
var isLock=0;

var de_idName=[];
var de_idCode=[];

 $(function(){
  if(GetQueryString('de_id')){
      $("input[name='showtype']").get(2).checked=true
    $(".radioL").eq(2).click();

  }
    $(window).resize(function() {
      location.reload();
  });
         var today=new Date();
             var Month=+today.getMonth()+1;
             var Datet=today.getDate();
             if(Month<10){
              Month='0'+Month;
             }
             if(Datet<10){
               Datet='0'+Datet;
             }
             toDate=today.getFullYear()+'-'+Month+'-'+Datet;
            today.setDate(today.getDate()-30);
             var Month2=+today.getMonth()+1;
             var Datet2=today.getDate();
             if(Month2<10){
              Month2='0'+Month2;
             }
             if(Datet2<10){
               Datet2='0'+Datet2;
             }
        fromDate=today.getFullYear()+'-'+Month2+'-'+Datet2;
      $(".start1").text(fromDate);
      $(".end1").text(toDate);

      //初始化图表
    setAnyChartFun(leftrw,'line','入网率');

//下辖单位
    getDefaultGroup();
})
     // 切换日月年改变date
 $("#seT_type").closest('.selectedB').find('.op-item').click(function(event) {
   var T_type=$("#seT_type").text();
     if(!($(this).text()==T_type)){
        if($(this).text()=="按日"){
          DefaultDate(1)
        }else if($(this).text()=="按月"){
          DefaultDate(2)
        }else if($(this).text()=="按年"){
          DefaultDate(3)
        }
     }
   });
var start,end;
start = {
         format: 'YYYY-MM-DD',
         isinitVal:true,
         ishmsVal:false,
         isClear:false,
         isToday:true,
             maxDate: $.nowDate({DD:0}), //最大日期
             choosefun: function(elem,datas){
              var type=$("#seT_type").text();
                if(type=="按日"){
                    $("#from").val(datas)
                }else if(type=="按月"){
                    $("#from").val(datas+'-01')
                }else if(type=="按年"){
                    $("#from").val(datas+'-01-01')
                }
    }
         };
         end = {
             format: 'YYYY-MM-DD',
             isToday:true,
            isClear:false,
             maxDate:$.nowDate({DD:0}), //最大日期
             choosefun: function(elem,datas){
              var type=$("#seT_type").text();
            if(type=="按日"){
                $("#to").val(datas)
            }else if(type=="按月"){
                $("#to").val(datas+'-01')
            }else if(type=="按年"){
                $("#to").val(datas+'-01-01')
            }
    }
         };
$('#fromReal').jeDate(start);
$('#toReal').jeDate(end);
DefaultDate(1);
function DefaultDate(type){
    if(type==1){
     var today=new Date();
          var Month=+today.getMonth()+1;
          var Datet=today.getDate();
          if(Month<10){
           Month='0'+Month;
          }
          if(Datet<10){
            Datet='0'+Datet;
          }
          toDate=today.getFullYear()+'-'+Month+'-'+Datet;
          today.setDate(today.getDate()-29);
          var Month2=+today.getMonth()+1;
          var Datet2=today.getDate();
          if(Month2<10){
           Month2='0'+Month2;
          }
          if(Datet2<10){
            Datet2='0'+Datet2;
          }
           fromDate=today.getFullYear()+'-'+Month2+'-'+Datet2;
          today.setDate(today.getDate()+2);
           toDate2=today.getFullYear()+'-'+(+today.getMonth()+1)+'-'+today.getDate();
        $("#fromReal").val(fromDate);
        $("#toReal").val(toDate)
        $("#from").val(fromDate)
        $("#to").val(toDate)
start.format="YYYY-MM-DD";
end.format="YYYY-MM-DD";
    }else if(type==2){
         var today=new Date();
     var Month=+today.getMonth()+1;
     var Datet=today.getDate();
     if(Month<10){
      Month='0'+Month;
     }
     if(Datet<10){
       Datet='0'+Datet;
     }
     toDate=today.getFullYear()+'-'+Month+'-01';
          var toDate1=today.getFullYear()+'-'+Month;
          today.setMonth(today.getMonth()-11);
      var Month2=+today.getMonth()+1;
      var Datet2=today.getDate();
      if(Month2<10){
       Month2='0'+Month2;
      }
      if(Datet2<10){
        Datet2='0'+Datet2;
      }
       fromDate=today.getFullYear()+'-'+Month2+'-01';
       // fromDate=today.getFullYear()+'-'+(+today.getMonth()+1)+'-'+today.getDate();
         var fromDate2=today.getFullYear()+'-'+Month2;
          today.setMonth(today.getMonth()+2);
           toDate2=today.getFullYear()+'-'+(+today.getMonth()+1)+'-'+today.getDate();
        $("#fromReal").val(fromDate2);
        $("#toReal").val(toDate1)
        $("#from").val(fromDate)
        $("#to").val(toDate)
        start.format="YYYY-MM";
        end.format="YYYY-MM";
    }else if(type==3){
         var today=new Date();
       toDate=today.getFullYear()+'-01-01';
           toDate1=today.getFullYear()
          today.setFullYear(today.getFullYear()-9);
       fromDate=today.getFullYear()+'-01-01';
           fromDate2=today.getFullYear();
          today.setFullYear(today.getFullYear()+2);
           toDate2=today.getFullYear()+'-'+(+today.getMonth()+1)+'-'+today.getDate();
        $("#fromReal").val(fromDate2);
        $("#toReal").val(toDate1)
        $("#from").val(fromDate)
        $("#to").val(toDate)
      start.format="YYYY";
        end.format="YYYY";
    }
}

function ComparetIME(beginDate,endDate){
    var d1 = new Date(beginDate).getTime();
   var d2 = new Date(endDate).getTime();
   var type=$("#seT_type").text();
   if(beginDate!=""&&endDate!="" &&d1 >=d2)
   {
    layer.msg('开始日期不能大于或等于结束日期');
    return false;
}else{
    var d3=d2-d1;
   if(type=="按日"){
    if(d3<1*24*60*60*1000){
     layer.msg('开始和结束的时间差不能少于1天');
     return false;
   }else if(d3>29*24*60*60*1000){
     layer.msg('开始和结束的时间差不能大于30天');
     return false;
   }else{
    return true;
   }
}else if(type=="按月"){
if(!completeDate(new Date(beginDate), new Date(endDate),12)){
     layer.msg('开始和结束的时间差不能大于12个月');
     return false;
}else{
    return true;
   }
}else if(type=="按年"){
    var d4=new Date(endDate).getFullYear()-new Date(beginDate).getFullYear();
if(d4>=10){
  layer.msg('开始和结束的时间差不能大于10年');
  return false;
}else{
    return true;
   }
}
}
}
function completeDate(time1 , time2 , m)
{
    var diffyear = time2.getFullYear() - time1.getFullYear() ;
    var diffmonth = diffyear * 12 + time2.getMonth() - time1.getMonth() ;
    if(diffmonth < m){
        return true ;
    }else{
      return false ;
    }

}


    //设置最小高度
     var mainHeight=$('body').height()-110;
     $(".mainContent").css('min-height', mainHeight);

//模拟select
  $(".selectedB").on('click', '.sel-wrap', function(event) {
    if($(this).is(":hover")){
      console.log($(".selectedB .optionB").not($(this).next('.optionB')))
      $(".selectedB .optionB").not($(this).next('.optionB')).hide(20);
      $(this).next('.optionB').slideToggle(20);
    }
   return false;
 });

  $(".selectedB").on('click', '.op-item', function(event) {
    $(this).closest('.selectedB').find('.selected-item').text($(this).text());
    $(this).closest('.optionB').slideUp(20);
  });


 document.onclick = function(){
   $(".optionB").hide();
 };

function getDefaultGroup(){
  myChart.showLoading({
                  text : '数据获取中',
                  effect: 'whirling',
                  color:'#56b4f8'
              });
  $(".checkStyle").hide();
  $(".table-body").empty();
  $(".table-body").append("<div class='loading' style='width:100%'><div style='padding:20px 0; width:100%; text-align:center'><img src='../style/image/load.gif' width='32px' height='32px'/></div></div>");
         var wxjson = new webjson("22");
         wxjson.AddParam("departmentid",departmentid);//用户id组合
         wxjson.AddParam("nowdeptid",' ');//用户id组合
         wxjson.AddParam("flag",'yes');//用户id组合
         WebRequestAsync(wxjson, successGroup);
         function successGroup(res){
           console.log(res)
             var data = GetOjson(json_parse(res));
             console.log(data);
             if(data.status == 0){
               if(data.param.length>0){
                var organList=[];
                var de_id=[];
                var nowId=""
                 for(var i=0;i<data.param.length;i++){
                    var singleData={'id':data.param[i].departmentzone_code,'text':data.param[i].department}
                    organList.push(singleData);
                    de_id.push(data.param[i].departmentid);
                    de_idCode.push(data.param[i].departmentzone_code);
                    de_idName.push(data.param[i].department);
                 }
                 $.each(de_id, function(index, val) {
                     if(val==departmentid){
                        nowId=organList[index].id;
                        return false;
                     }
                 });
                //selected2初值化
                 var selects= $(".js-example-data-array").select2({
                    data: organList,
                    language: "Zh-CN"
                  })
                 // .select2()
               $(".js-example-data-array").val(nowId).select2();
               if(GetQueryString('de_id')){
                $(".js-example-data-array").val(GetQueryString('de_id')).select2();
                getChartData(GetQueryString('de_id'),"",0,$("#from").val(),$("#to").val())
               }else if(GetQueryString('qyType')){
                var type=+GetQueryString('qyType');
                if(type==0){
                   $('.c_type .selected-item').text('生产企业');
                }else if(type==1){
                   $('.c_type .selected-item').text('销售经营企业');
                }else if(type==2){
                   $('.c_type .selected-item').text('餐饮企业');
                }else if(type==3){
                   $('.c_type .selected-item').text('单位食堂');
                }
                  getChartData(nowId,GetQueryString('qyType'),0,$("#from").val(),$("#to").val())
               }else{
                  getChartData(nowId,"",0,$("#from").val(),$("#to").val())
               }

               }
         }else if(data.status == 9){//超时重新登录
           window.location.href="index.html?loginOut=true";
           return;
       }else{
        layer.close(layer1)
        layer.msg(data.info);
    }
   }
}

//获取图表数据
function getChartData(zone_code,qyType,countWay,startTime,endtTime){
    if(isLock==1){
        return false;
    }
    isLock=1;
    myChart.showLoading({
                    text : '数据获取中',
                    effect: 'whirling',
                    color:'#56b4f8'
                });
    $(".checkStyle").hide();
    $(".table-body").empty();
    $(".table-body").append("<div class='loading' style='width:100%'><div style='padding:20px 0; width:100%; text-align:center'><img src='../style/image/load.gif' width='32px' height='32px'/></div></div>");
          var wxjson = new webjson("35");
          wxjson.AddParam("zone_code",zone_code);
          wxjson.AddParam("qyType",qyType);
          wxjson.AddParam("countWay",countWay);
          wxjson.AddParam("startTime",startTime);
          wxjson.AddParam("endtTime",endtTime);
          WebRequestAsync(wxjson, successGroup);
          function successGroup(res){
            console.log(res)
              var data = GetOjson(json_parse(res));
              console.log(data);
              if(data.status == 0){
                  $(".checkStyle").show();
                if(data.param.length>0){
                    isLock=0;
                    $(".start1").text($("#fromReal").val());
                    $(".end1").text($("#toReal").val());
                    leftxAxis=[];
                    leftrw=[],leftxz=[],leftrwqy=[],leftwrw=[];
                    $(".table-body").empty();
                    var HTML="";
                $.each(data.param.reverse(), function(index, val) {
                    leftxAxis.push(val.date);
                    leftrw.push(val.raw.slice(0, -1));
                    leftxz.push(val.countToday);
                    leftrwqy.push(val.countYMD);
                    leftwrw.push(val.NoNet);
                    HTML+='<div class="table_tr clearfix">'+
                      '<div class="table_td timeD">'+val.date+'</div>'+
                      '<div class="table_td active">'+val.raw+'</div>'
                      if(val.countToday==0){
                        HTML+= '<div class="table_td " onclick="getDetail(1,$(this))">'+val.countToday+'</div>'
                      }else{
                        HTML+= '<div class="table_td activeA" onclick="getDetail(1,$(this))">'+val.countToday+'</div>'
                      }
                     if(val.countYMD==0){
                      HTML+='<div class="table_td " onclick="getDetail(2,$(this))">'+val.countYMD+'</div>'
                     }else{
                      HTML+='<div class="table_td activeA" onclick="getDetail(2,$(this))">'+val.countYMD+'</div>'

                     }

                     HTML+= '<div class="table_td">'+val.NoNet+'</div>'+
                    '</div>';
                    // $(".table-body").prepend(HTML)
                  });
                leftxAxis.reverse();
                leftrw.reverse();
                leftxz.reverse();
                leftrwqy.reverse();
                leftwrw.reverse();
                 $(".table-body").append(HTML);
                 myChart.hideLoading();
                 if(GetQueryString('de_id')){
                   $(".table .table_tr").find(".table_td:eq(3)").addClass('active').siblings().removeClass('active');
                 }
                var checkedV=$(".radioL.checked input").val();
                if(checkedV=="入网率"){
                setAnyChartFun(leftrw,'line','入网率');
            }else if(checkedV=="新增企业"){
                setAnyChartFun(leftxz,'bar','新增企业');
                }else if(checkedV=="入网企业"){
                setAnyChartFun(leftrwqy,'line','入网企业');
                }else if(checkedV=="未入网企业"){
                setAnyChartFun(leftwrw,'bar','未入网企业');
                }
            }
          }else if(data.status == 9){//超时重新登录
            window.location.href="index.html?loginOut=true";
            return;
        }else{
         // layer.close(layer1)
         layer.msg(data.info);
     }
    }
}

function getDetail(flag,$this){
    var FLAG="add";
    if(flag==1){
        FLAG="add"
    }else if(flag==2){
        FLAG="alreadynet"
    }
      var zone_code=$(".js-example-data-array").val();
      // cosole.log($this)
      var sum=$this.text();
      var qyTypeText=$(".c_type .selected-item").text();
      console.log($this.closest('.table_tr'))
      var time=$this.closest('.table_tr').find('.timeD').text();
      var qyType="";
      var countWay=0;
      if(qyTypeText=="所有企业"){
          qyType="";
      }else if(qyTypeText=="生产企业"){
          qyType=0;
      }else if(qyTypeText=="销售经营企业"){
          qyType=1;
      }else if(qyTypeText=="餐饮企业"){
          qyType=2;
      }else if(qyTypeText=="单位食堂"){
          qyType=3;
      }
      var countWayText=$("#seT_type").text();
      if(countWayText=="按日"){
          countWay=0;
      }else if(countWayText=="按月"){
          countWay=1;
      }else if(countWayText=="按年"){
          countWay=2;
      }
      var neTitle="";
      var TITLE="";
      var liTitle="";
      $.each(de_idCode, function(index, val) {
         if(val==zone_code){
            neTitle=de_idName[index];
            return false;
         }
      });

      if(FLAG=="add"){
      liTitle='新增企业'
      }else{
         liTitle='入网企业'
      }
    var objSting={"neTitle":neTitle,"liTitle":liTitle,"zone_code":zone_code,"qyType":qyType,"countWay":countWay,"time":time,"flag":FLAG,"sum":sum};
    objSting=JSON.stringify(objSting);
    if(sum!="0"){
    	window.open('look_company.html?objSting='+escape(objSting),'_blank')
    }


}
  var myChart = echarts.init(document.getElementById('chartMain'));
//图表调用
 function setAnyChartFun(dataA,type,name){
  var amax=Math.max.apply(null, dataA);
  amax=Math.ceil(amax);
  var length=amax.toString().length;
  var bai=1;
  for(var i=0;i<length-1;i++){
    bai=bai*10
  }
   var max;
  if(length>1){
  max=(+amax.toString().split('')[0]+1)*bai;
  }else{
max=10;
  }
  var code="";
  if(name=="入网率"){
  code="%"
  }
  option = {
    color: ['#f47564'],
    tooltip : {
      trigger: 'axis',
                              axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                                  type : 'line'        // 默认为直线，可选为：'line' | 'shadow'
                                },
                               formatter:function (params, ticket, callback) {
                                             var dataIndex=params[0].dataIndex;

                                               return leftxAxis[dataIndex]+'<br><span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:#f47564;"></span>'+name+':'+params[0].value+code
                                }
                              },
                              grid: {
                                left: '0',
                                right: '20px',
                                bottom: '40px',
                                top:'10px',
                                containLabel: true
                              },
                              calculable : true,
                              xAxis : [
                              {
                                type : 'category',
                                data : leftxAxis,
                          axisLine:{
                           lineStyle:{
                            color:'#333'
                          }
                        },
                        axisTick: {
                                  show:false,//坐标轴刻度
                                  alignWithLabel: true
                                },
                              }
                              ],
                              yAxis : [
                              {
                                type: 'value',
                                 minInterval: 1,
                                // min:'1',
                                max:max,
                                 interval:Math.ceil(max/5),
                                axisLine:{
                                 lineStyle:{
                                  color:'#333'
                                }
                              },
                              nameGap:25,
                              axisTick: {
                             show:false,//坐标轴刻度
                             alignWithLabel: true
                           },
                           min: 0,
                           position: 'left',
                           axisLabel: {
                            formatter: '{value}'+code
                          }
                        },
                        ],
                        series : [
                        {
                          name:name,
                          type:type,
                          barWidth:'40%',
                          // barMinHeight:2,
                          barMaxWidth:20,
                          data:dataA
                        }
                        ]
                      };
                       // 使用刚指定的配置项和数据显示图表。
                       myChart.setOption(option);
                     }
                                 $("body").on('click', '.radioL', function(event) {
                                   $('.radioL').each(function(index, el) {
                                     $('.radioL').removeClass('checked').addClass('noCheck');
                                     if($(this).find('input').prop("checked")){
                                       $(this).removeClass('noCheck').addClass('checked');
                                       if($(this).text()=="入网率"){
                                         $(".checkStyle").css('left', '20%');
                                         $('.table .table_th').eq(1).addClass('active').siblings().removeClass('active')
                                         $(".table .table_tr").find(".table_td:eq(1)").addClass('active').siblings().removeClass('active');
                                         $(".end1").text($('#toReal').val())
                                         $(".start1").text($('#fromReal').val())
                                         $(".st_type").text('入网率')
                                              setAnyChartFun(leftrw,'line','入网率');
                                       }else if($(this).text()=="新增企业"){
                                        $(".checkStyle").css('left', '40%');
                                        $('.table .table_th').eq(2).addClass('active').siblings().removeClass('active')
                                        $(".table .table_tr").find(".table_td:eq(2)").addClass('active').siblings().removeClass('active');
                                        $(".end1").text($('#toReal').val())
                                        $(".start1").text($('#fromReal').val())
                                        $(".st_type").text('新增企业')
                                         setAnyChartFun(leftxz,'bar','新增企业');
                                      }else if($(this).text()=="入网企业"){
                                        $(".checkStyle").css('left', '60%');
                                        $('.table .table_th').eq(3).addClass('active').siblings().removeClass('active')
                                        $(".table .table_tr").find(".table_td:eq(3)").addClass('active').siblings().removeClass('active');
                                        $(".end1").text($('#toReal').val())
                                        $(".start1").text($('#fromReal').val())
                                        $(".st_type").text('入网企业')

                                        setAnyChartFun(leftrwqy,'line','入网企业');
                                      }else if($(this).text()=="未入网企业"){
                                        $(".checkStyle").css('left', '80%');
                                        $('.table .table_th').eq(4).addClass('active').siblings().removeClass('active')
                                        $(".table .table_tr").find(".table_td:eq(4)").addClass('active').siblings().removeClass('active');
                                        $(".end1").text($('#toReal').val())
                                        $(".start1").text($('#fromReal').val())
                                        $(".st_type").text('未入网企业')

                                        setAnyChartFun(leftwrw,'bar','未入网企业');
                                      }
                                      return false;
                                    }
                                  });

                     });
                $("#comfire").click(function(event) {
                  var startDate=$("#from").val();
                  var endDate=$("#to").val();
                   if(ComparetIME(startDate,endDate)){

                    var zone_code=$(".js-example-data-array").val();
                    var qyTypeText=$(".c_type .selected-item").text();
                    var qyType="";
                    var countWay=0;
                    if(qyTypeText=="所有企业"){
                        qyType="";
                    }else if(qyTypeText=="生产企业"){
                        qyType=0;
                    }else if(qyTypeText=="销售经营企业"){
                        qyType=1;
                    }else if(qyTypeText=="餐饮企业"){
                        qyType=2;
                    }else if(qyTypeText=="单位食堂"){
                        qyType=3;
                    }
                    var countWayText=$("#seT_type").text();
                    if(countWayText=="按日"){
                        countWay=0;
                    }else if(countWayText=="按月"){
                        countWay=1;
                    }else if(countWayText=="按年"){
                        countWay=2;
                    }
                    var formDatev=$("#from").val();
                    var toDatev=$("#to").val();
                    if(formDatev==""){
                        layer.msg('请选择开始日期')
                    }else if(toDatev==""){
                         layer.msg('请选择结束日期')
                    }else{
                        getChartData(zone_code,qyType,countWay,formDatev,toDatev)
                    }
                  }

                });
