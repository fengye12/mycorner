autoH();
var a1 = "a12",
	a2 = "a1202";
var chuanzf="",lx="",pindex = "1",psize = "20";
/**分页设置**/
var pcent = new CentPage();
var pcount = ""; //总条数
var jsonParam="";//导出时需要传的参数
var ps = pcent.GetCentPage(pindex, pcount, psize);
$("#page").html(ps);
function CentPageOper(spindex) {
	var jgj=chuanzf.jgj;
	var time=chuanzf.time;
	var qylx=chuanzf.qylx;
	var jgj_name=chuanzf.jgj_name;
	record(lx,jgj,time,qylx,jgj_name,spindex, psize);
}
$(function(){
	getActiveN("a12", "a1201");//当前页标志
	//$("img.qh").trigger('click');
	chuanzf=JSON.parse(getQueryString("chuanzf"));
	console.log(chuanzf);
	lx=getQueryString("lx");
	var jgj=chuanzf.jgj;
	var time=chuanzf.time;
	var qylx=chuanzf.qylx;
	var jgj_name=chuanzf.jgj_name;
    var htmlCt="";
    	var zx=getQueryString("zx");
    if(zx=="" || zx == "zx"){
    	getActiveN("a12", "a1202");//当前页标志
    	a1="a12";a2="a1202";

    }
    /**获取页面头部信息**/
    if(jgj_name!=null&&time!=null&&lx!==null){
    	htmlCt +="<a href='javascript:void(0);'>"+jgj_name+time+lx+"</a>";
	 $(".content-title").html(htmlCt);
     }else{
     	 $(".content-title").html("");
     }
     if(zx=="" || zx == "zx"){
         	var html ="<a href='javascript:void(0);'>统计分析</a>><a href='districtStatistics.html'>辖区统计</a>><a href='javascript:void(0);'>查看相关备案</a>";
         	$(".bread-nav").html(html);
          }

    record(lx,jgj,time,qylx,jgj_name,pindex, psize);
})
/**列表**/
function record(lx,jgj,time,qylx,jgj_name,spindex, psize){
	pindex = spindex;
	$("table tbody").children().remove();
	$("table tbody").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;'><img src='../style/image/load.gif' alt='' /></td></tr>");
	$("#daochu").css("display","none");
	$("#mySelect").css("display","none");
	var wxjson = new webjson("11"); //设置action值
	//新增param键值
	wxjson.AddParam("jgj", jgj);
	wxjson.AddParam("time", time);
	wxjson.AddParam("lx", lx);
	wxjson.AddParam("qylx", qylx);
	wxjson.AddParam("jgj_name", jgj_name);
	if(getQueryString('zx')=="zx"){
		wxjson.AddParam("zx", 'zx');
	}
	wxjson.AddParam("page_index", pindex);
	wxjson.AddParam("page_size", psize);
	WebRequestAsync(wxjson, recordList);
	jsonParam=wxjson.GetJsons();
}
function recordList(res){
	var html="";
	var data = GetOjson(json_parse(res));
	console.log(data);
	pcount = data.paramcentcount;
	console.log(pcount);
	var ps = pcent.GetCentPage(pindex, pcount, psize);
	$("#page").html(ps);
	if(data.status == 0) {
		   if(pcount!="0"){
				$("#daochu").css("display","");
				$("#mySelect").css("display","");
				}else{
				 $("#daochu").css("display","none");
				 $("#mySelect").css("display","none");
				}
		   for(var i = 0; i < data.param.length; i++){
				var bbtype1="",bstatus1="";
				if(data.param[i].bbtype == "0"){
					bbtype1="无进货行为备案";
				}else if(data.param[i].bbtype == "1"){
					bbtype1="无销售行为备案";
				}else if(data.param[i].bbtype == "2"){
					bbtype1="停止生产经营备案";
				}else if(data.param[i].bbtype == "3"){
					bbtype1="企业转让备案";
				}else if(data.param[i].bbtype == "4"){
					bbtype1="恢复生产经营备案";
				}else{
					bbtype1="";
				}
				if(data.param[i].bstatus == "0"){
					bstatus1="备案中";
				}else if(data.param[i].bstatus == "1"){
					bstatus1="已备案";
				}else if(data.param[i].bstatus == "2"){
					bstatus1="已作废";
				}else{
					bstatus1="";
				}
				html +="<tr>";
				html +='<td class="hs">'+data.param[i].cname+
				'</td><td class="hs">'+data.param[i].addtime+'</td>'+
				'<td class="hs">'+bbtype1+'</td>'+
				'<td class="hs text-left short" style="width:550px">'+data.param[i].bbsm+'</td>'+
				'<td class="hs">'+bstatus1+'</td>'+
				'<td class="ls"><span class="lookDetail" data-jbid='+data.param[i].jbid+' style="cursor: pointer;">查看</span></td>';
				html +="</tr>";
				$("table tbody").html(html);
			}
	autoH();
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else{
		$("#daochu").css("display","none");
		$("#mySelect").css("display","none");
		$("table tbody").html("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;font-size:14px;'>没有相关数据</td></tr>");
	}
	}

/**点击查看**/
$("table tbody").on("click",".lookDetail",function(){//图片查看
	var jbid=$(this).data("jbid");
	function recordInfo(res){
		var data = GetOjson(json_parse(res));
		if(data.status == "0"){
			var beian="",zrBeian="",zfbeian="",btype="",zfzrBeian="",content1="";
			if(data.param[0].bbtype == "0"){
				btype="无进货行为备案";
			}else if(data.param[0].bbtype == "1"){
				btype="无销售行为备案";
			}else if(data.param[0].bbtype == "2"){
				btype="停止生产经营备案";
			}else if(data.param[0].bbtype == "3"){
				btype="企业转让备案";
			}else if(data.param[0].bbtype == "4"){
				btype="恢复生产经营备案";
			}else{
				btype="";
			}
			if(data.param[0].bbtype == "2"){
				beian='<div class="toast-warp">'+
				'<form>'+
				'<ul class="record-form">'+
				'<li>'+
				'<label for="">备案类型</label>'+
				'<input type="text" value='+btype+' class="input-init" readonly />'+
				'</li>'+
				'<li><h3 class="h3-title mt10">备案说明</h3></li>'+
				'<li>'+
				'<label for="">停产日期</label>'+
				'<input type="text" value='+data.param[0].bbtime+' class="input-init" readonly />'+
				'</li>'+
				'<li>'+
				'<textarea name="" id="recordDetail" rows="5" readonly>'+data.param[0].bbsm+'</textarea>'+
				'</li>'+
				'</ul>'+
				'</form>'+
				'</div>';
				zfbeian='<div class="toast-warp">'+
				'<form>'+
				'<ul class="record-form">'+
				'<li>'+
				'<label for="">备案类型</label>'+
				'<input type="text" value='+btype+' class="input-init" readonly />'+
				'</li>'+
				'<li><h3 class="h3-title mt10">备案说明</h3></li>'+
				'<li>'+
				'<label for="">停产日期</label>'+
				'<input type="text" value='+data.param[0].bbtime+' class="input-init" readonly />'+
				'</li>'+
				'<li>'+
				'<textarea name="" id="recordDetail" rows="5" readonly>'+data.param[0].bbsm+'</textarea>'+
				'</li>'+
				'<li id="zfyy">'+
				'<h3 class="h3-title mt10">作废原因</h3>'+
				'<textarea name="" rows="5" readonly>'+data.param[0].zfsm+'</textarea>'+
				'</li>'+
				'</ul>'+
				'</form>'+
				'</div>';
			}else{
				beian='<div class="toast-warp">'+
				'<form>'+
				'<ul class="record-form">'+
				'<li>'+
				'<label for="">备案类型</label>'+
				'<input type="text" value='+btype+' class="input-init" readonly />'+
				'</li>'+
				'<li><h3 class="h3-title mt10">备案说明</h3></li>'+
				'<li>'+
				'<label for="">报备月份</label>'+
				'<input type="text" value='+data.param[0].bbtime+' class="input-init" readonly />'+
				'</li>'+
				'<li>'+
				'<textarea name="" id="recordDetail" rows="5" readonly>'+data.param[0].bbsm+'</textarea>'+
				'</li>'+
				'</ul>'+
				'</form>'+
				'</div>';
				zfbeian='<div class="toast-warp">'+
				'<form>'+
				'<ul class="record-form">'+
				'<li>'+
				'<label for="">备案类型</label>'+
				'<input type="text" value='+btype+' class="input-init" readonly />'+
				'</li>'+
				'<li><h3 class="h3-title mt10">备案说明</h3></li>'+
				'<li>'+
				'<label for="">报备月份</label>'+
				'<input type="text" value='+data.param[0].bbtime+' class="input-init" readonly />'+
				'</li>'+
				'<li>'+
				'<textarea name="" id="recordDetail" rows="5" readonly>'+data.param[0].bbsm+'</textarea>'+
				'</li>'+
				'<li id="zfyy">'+
				'<h3 class="h3-title mt10">作废原因</h3>'+
				'<textarea name="" rows="5" readonly>'+data.param[0].zfsm+'</textarea>'+
				'</li>'+
				'</ul>'+
				'</form>'+
				'</div>';
			}
			zrBeian='<div class="toast-warp">'+
			'<form>'+
			'<ul class="record-form">'+
			'<li>'+
			'<label for="">备案类型</label>'+
			'<input type="text" value='+btype+' class="input-init" readonly />'+
			'</li>'+
			'<li>'+
			'<h3 class="h3-title mt10">备案说明</h3>'+
			'</li>'+
			'<li>'+
			'<label for="">转让日期</label>'+
			'<input type="text" value='+data.param[0].bbtime+' class="input-init" readonly />'+
			'</li>'+
			'<li>'+
			'<label for="">受让人</label>'+
			'<input type="text" value='+data.param[0].srs+' class="input-init" readonly />'+
			'</li>'+
			'<li>'+
			'<label for="">身份证号</label>'+
			'<input type="text" value='+data.param[0].idcard+' class="input-init" readonly />'+
			'</li>'+
			'<li>'+
			'<label for="">手机号</label>'+
			'<input type="text" value='+data.param[0].phone+' class="input-init" readonly />'+
			'</li>'+
			'<li>'+
			'<textarea name="" id="recordDetail" rows="5" readonly>'+data.param[0].bbsm+'</textarea>'+
			'</li>'+
			'</ul>'+
			'</form>'+
			'</div>';

			zfzrBeian='<div class="toast-warp">'+
			'<form>'+
			'<ul class="record-form">'+
			'<li>'+
			'<label for="">备案类型</label>'+
			'<input type="text" value='+btype+' class="input-init" readonly />'+
			'</li>'+
			'<li>'+
			'<h3 class="h3-title mt10">备案说明</h3>'+
			'</li>'+
			'<li>'+
			'<label for="">转让日期</label>'+
			'<input type="text" value='+data.param[0].bbtime+' class="input-init" readonly />'+
			'</li>'+
			'<li>'+
			'<label for="">受让人</label>'+
			'<input type="text" value='+data.param[0].srs+' class="input-init" readonly />'+
			'</li>'+
			'<li>'+
			'<label for="">身份证号</label>'+
			'<input type="text" value='+data.param[0].idcard+' class="input-init" readonly />'+
			'</li>'+
			'<li>'+
			'<label for="">手机号</label>'+
			'<input type="text" value='+data.param[0].phone+' class="input-init" readonly />'+
			'</li>'+
			'<li>'+
			'<textarea name="" id="recordDetail" rows="5" readonly>'+data.param[0].bbsm+'</textarea>'+
			'</li>'+
			'<li id="zfyy">'+
			'<h3 class="h3-title mt10">作废原因</h3>'+
			'<textarea name="" rows="5" readonly>'+data.param[0].zfsm+'</textarea>'+
			'</li>'+
			'</ul>'+
			'</form>'+
			'</div>';

			if(data.param[0].bstatus == "2" && data.param[0].bbtype == "3"){
				content1=zfzrBeian;
			}else if(data.param[0].bstatus == "2" && data.param[0].bbtype != "3"){
				content1=zfbeian;
			}else if(data.param[0].bstatus != "2" && data.param[0].bbtype == "3"){
				content1=zrBeian;
			}else if(data.param[0].bstatus != "2" && data.param[0].bbtype != "3"){
				content1=beian;
			}else{
				content1="";
			}
			layer.open({
				title: '查看经营备案'
				,content: content1
				,area: ['543px', 'auto']
				,btn: []
				,cancel: function(){
					//右上角关闭回调
					//return false 开启该代码可禁止点击该按钮关闭
				}
			});
		}else if(data.status == "9"){
			window.location.href="index.html?loginOut=true";
			return;
		}else if(data.status== "10"){
			console.log(data.info);
		}else{
			layer.open({
				title: '提示'
				,content: data.info
				,btn: ['确定']
				,yes: function(index, layero){
					layer.close(index);
				}
				,cancel: function(){
					//右上角关闭回调
					//return false 开启该代码可禁止点击该按钮关闭
				}
			});
		}
	}
	var wxjson = new webjson("12"); //设置action值
	//新增param键值
	wxjson.AddParam("jbid", jbid);
	WebRequestAsync(wxjson, recordInfo);//读取经营备案信息
})

/**select选择框**/
/**function select() {
	//获取下拉框选中项的text属性值
	pindex="1";
	var selectText = $("#mySelect").find("option:selected").text();
	//获取下拉框选中项的value属性值
	var selectValue = $("#mySelect").val();
	console.log(selectValue);
	psize = selectValue;
	CentPageOper(pindex);
	var jgj=chuanzf.jgj;
	var time=chuanzf.time;
	var qylx=chuanzf.qylx;
	var jgj_name=chuanzf.jgj_name;
	record(lx,jgj,time,qylx,jgj_name,pindex, psize);
}**/

//模拟select
		$(".selectedB").on('click', '.sel-wrap', function(event) {
			var listH=$("#mySelectS").find(".optionB").height();
			if($(this).is(":hover")){
				console.log($(".selectedB .optionB").not($(this).next('.optionB')))
				$(".selectedB .optionB").not($(this).next('.optionB')).hide(20);
				$(this).next('.optionB').slideToggle(20);
			}
			if($(this).next(".selectedB").find(".optionB").css("display") != "none"){
				var offsetBottom=document.documentElement.clientHeight + $(document).scrollTop() - $(this).offset().top-$(this).height();
				if(offsetBottom < listH){
					console.log($(this).height())
					$("#mySelectS").find(".optionB").css({"left":"0","top":-listH})
				}
			}
			return false;
		});
		document.onclick = function(){
			$(".optionB").hide();
		};
	var selectText="20条/页";
		$("#mySelectS").on('click', '.op-item', function(event) {
			$("#mySelectS").find('.selected-item').text($(this).text());
			if(selectText != $(this).text()){
				pindex=1;
				selectText=$(this).text();
				if($(this).text()=="10条/页"){
					psize=10;
				}else if($(this).text()=="20条/页"){
					psize=20;
				}else if($(this).text()=="30条/页"){
					psize=30;
				}else if($(this).text()=="40条/页"){
					psize=40;
				}else if($(this).text()=="50条/页"){
					psize=50;
				}else{
				}
				var jgj=chuanzf.jgj;
				var time=chuanzf.time;
				var qylx=chuanzf.qylx;
				var jgj_name=chuanzf.jgj_name;
				record(lx,jgj,time,qylx,jgj_name,pindex, psize);
			}

			$(this).closest('.optionB').slideUp(20);
		});

/**导出**/
$("#daochu").click(function(){
var excelName=$(".content-title a").text();
var pattern = new RegExp('[\/:*?"<>|]');
if(pattern.test(excelName)){
    for (var i = 0; i < excelName.length; i++) {
    	excelName = excelName.replace(pattern, '-');
    	console.log(excelName);
    }
}
var listType="onfilingListLook";
var header="备案企业"+","+"备案日期"+","+"备案类型"+","+"备案信息"+","+"状态";
if(pcount<1001){
	var exportExcelParam={
		excelName:escape(excelName),
		listType:listType,
		header:header,
		jsonParam:jsonParam
	}
	postExportExcel(dcUrl,exportExcelParam);
}else{
	layer.open({
		title: '系统提示'
		,content: '当前数据量超过1000条，为了数据的安全，我们无法为您导出该数据，如需导出请联系客服。'
		,btn: ['确定']
		,yes: function(){
			layer.closeAll();
		}
	});
	return false;
}
})