var pindex = "1",psize = "20";
var departmentid="",cId="",zoneCode="",type="",saveCodes="",packageModes="",proPlaces="",goodName="";
/**分页设置**/
var pcent = new CentPage();
var pcount = ""; //总条数
var ps = pcent.GetCentPage(pindex, pcount, psize);
$("#page").html(ps);
function CentPageOper(spindex) {
	search1(cId,zoneCode,departmentid,type,saveCodes,packageModes,proPlaces,goodName,spindex, psize);
}
/**页面加载时**/
$(function() {
	departmentid=$.cookie("departmentid");
	cId= getQueryString("cId"); /**将url中传过来的值进行解码**/
	zoneCode= getQueryString("zoneCode");
	console.log("cId:"+cId+"zoneCode:"+zoneCode);
	search1(cId,zoneCode,departmentid,type,saveCodes,packageModes,proPlaces,goodName,pindex,psize);
 	autoH();
});

/**页面显示数据调用的方法**/
function search1(cId,zoneCode,departmentid,type,saveCodes,packageModes,proPlaces,goodName,spindex, psize){
	pindex = spindex;
	$("#mySelectS").css("display","none");
	$("table tbody").children().remove();
	$("table tbody").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;'><img src='../style/image/load.gif' alt='' /></td></tr>");
	//$(".gz").css("display","none");
	var wxjson = new webjson("63"); //设置action值
	//新增param键值	
	wxjson.AddParam("cId", cId);
	wxjson.AddParam("zoneCode",zoneCode);
	wxjson.AddParam("departmentid",departmentid);
	wxjson.AddParam("type","YC");
	wxjson.AddParam("saveCodes","");
	wxjson.AddParam("packageModes","");
	wxjson.AddParam("proPlaces","");
	wxjson.AddParam("goodName","");
	wxjson.AddParam("page_index", pindex);
	wxjson.AddParam("page_size", psize);
	WebRequestAsync(wxjson, searchInfo);
}

function searchInfo(res){
	var html = "";
	var data = GetOjson(json_parse(res));
	console.log(data);
	pcount = data.paramcentcount;
	$(".totalNum1").html("共"+pcount+"条");
	var ps = pcent.GetCentPage(pindex, pcount, psize);
	$("#page").html(ps);
	if(data.status == 0) {
		if(pcount!="0"){
			$("#mySelectS").css("display","");
			}else{
			 $("#mySelectS").css("display","none");
			}
	  for(var i = 0; i < data.param.length; i++){
		var pid="",pname="",packageMode="",zsl="",ysc="",barCoce="";
		pid=data.param[i].goodsCode;
		zsl=data.param[i].zsl;
		ysc=data.param[i].ysc;
		packageMode=data.param[i].packageMode;
		pname=escape(data.param[i].goodsName);
		barCoce=data.param[i].barCoce;
		var ycountry1=escape(data.param[i].proPlace);
		var gz=data.param[i].isAttention;
		if(data.param[i].isAttention=="0"){
			gz="取消关注";
		}else{
			gz="关注";
		}
		sessionStorage.setItem("gz",gz);
		if(packageMode=="null"){
			packageMode="";
		}
		if(zsl=="null"){
			zsl="0";
		}
		if(ysc=="null"){
			ysc="0";
		}
		if(barCoce=="null"){
			barCoce="";
		}
		html += "<tr>";
		html +='<td class="hs">' +data.param[i].goodsName +
		"</td><td class='hs'>" +barCoce +
		"</td><td class='hs'>" +packageMode +'</td>';
	  if(data.param[i].isSera=="0"){
		  if(data.param[i].zsl=="0"){
			  html +='<td class="hs">' +ysc+'/'+zsl +'</td>'; 
		  }else{
		      html +='<td class="rs"><a href="Food_BatchNumber.html?pid='+pid+'&barcode='+barCoce+'&pname='+pname+'&ycountry='+ycountry1+'" target="_blank" style="color:#ef2121;">' +ysc+'/'+zsl +'</a></td>';
		  }
		  }else{
			  if(data.param[i].zsl=="0"){
				  html +='<td class="hs">' +ysc+'/'+zsl +'</td>';   
			  }else{
		        html +='<td class="hs"><a href="Food_BatchNumber.html?pid='+pid+'&barcode='+barCoce+'&pname='+pname+'&ycountry='+ycountry1+'" target="_blank">' +ysc+'/'+zsl +'</a></td>'; 
			  }
		 }
            html +='<td class="hs ls"><a href="javascript:void(0);" onclick="removeList(this)"><span style="display:none;">'+data.param[i].goodsCode+'</span>取消移除</a></td>';
		    html += "</tr>";
		}
		$("table tbody").html(html);
	}else if(data.status == 9){
		//window.location.href="index.html?loginOut=true";
	}else {
		$("table tbody").html("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;font-size:14px;'>没有相关数据</td></tr>");
		$("#mySelectS").css("display","none");
	}
}

/**取消移除调用的方法**/
function removeList(thi){
	var goodsCode=$(thi).children("span").text();
	var wxjson = new webjson("65"); //设置action值
	//新增param键值	
	wxjson.AddParam("goodsCode",goodsCode);
	wxjson.AddParam("departmentid",departmentid);
	wxjson.AddParam("typeId",cId);
	//wxjson.AddParam("flag", "1");//flag:0移除，1取消移除
	WebRequestAsync(wxjson, qxData);
}
function qxData(res){
	var data = GetOjson(json_parse(res));
	console.log(data);
	if(data.status == 0) {
		$("#remove1").val("1");
		layer.msg("取消成功！");		
		search1(cId,zoneCode,departmentid,type,saveCodes,packageModes,proPlaces,goodName,pindex, psize);
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else {
		layer.msg(data.info);
	}
}