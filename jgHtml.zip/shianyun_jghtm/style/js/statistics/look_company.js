autoH();
var a1 = "a12",
	a2 = "a1202";
var zdgz="",typeId="",type="",cType="",objSting="",pindex="1",psize="20",chuanzf="",lx="",name="";
var jsonParam="";//导出时需要传的参数
/**分页设置**/
var pcent = new CentPage();
var pcount = ""; //总条数
var ps = pcent.GetCentPage(pindex, pcount, psize);
$("#page").html(ps);
function CentPageOper(spindex) {
	if(objSting!=null&&objSting!=undefined){
		   var neTitle=objSting.neTitle;
		   var liTitle=objSting.liTitle;
		   var zone_code=objSting.zone_code;
		   var qyType=objSting.qyType;
		   var countWay=objSting.countWay;
		   var time=objSting.time;
		   var flag=objSting.flag;
		   var sum=objSting.sum;
		ruwang(neTitle,liTitle,zone_code,qyType,countWay,time,flag,sum,spindex, psize);
	}else if(chuanzf!=null&&chuanzf!=undefined){
		var jgj=chuanzf.jgj;
		console.log(jgj);
		var time=chuanzf.time;
		var qylx=chuanzf.qylx;
		var jgj_name=chuanzf.jgj_name;
		tongji(lx,jgj,time,qylx,jgj_name,spindex, psize);
	}else{
		company(zdgz,typeId,type,cType,spindex, psize);
	}
}
$(function(){
	var htmlTitle="";
	objSting=JSON.parse(getQueryString("objSting"));
	console.log(objSting);
	chuanzf=JSON.parse(getQueryString("chuanzf"));
	console.log("chuanzf:"+chuanzf);
	lx=getQueryString("lx");
	name=$.cookie('dept_name');//监管所name
	console.log(name);

	if(objSting!=null&&objSting!=undefined){
		a1="a12";a2="a1200";
		   getActiveN("a12", "a1200");//当前页标志
		   //$("img.qh").trigger('click');
		   var neTitle=objSting.neTitle;
		   var liTitle=objSting.liTitle;
		   var zone_code=objSting.zone_code;
		   var qyType=objSting.qyType;
		   var countWay=objSting.countWay;
		   var time=objSting.time;
		   var flag=objSting.flag;
		   var sum=objSting.sum;
		   htmlTitle +="<a href='javascript:void(0);'>统计分析</a>><a href='netStatistics.html'>入网统计</a>><a href='javascript:void(0);'>查看相关企业</a>";
		   $(".bread-nav").html(htmlTitle);
		ruwang(neTitle,liTitle,zone_code,qyType,countWay,time,flag,sum,pindex,psize);
	}else if(chuanzf!=null&&chuanzf!=undefined){
		a1="a12";a2="a1201";
		getActiveN("a12", "a1201");//当前页标志
		//$("img.qh").trigger('click');
		var jgj=chuanzf.jgj;
		var time=chuanzf.time;
		var qylx=chuanzf.qylx;
		var jgj_name=chuanzf.jgj_name;
		htmlTitle +="<a href='javascript:void(0);'>统计分析</a>><a href='ReportedCompany.html'>报备统计</a>><a href='javascript:void(0);'>查看相关企业</a>";
		$(".bread-nav").html(htmlTitle);
		tongji(lx,jgj,time,qylx,jgj_name,pindex, psize);
	}else{
		getActiveN("a12", "a1202");//当前页标志
		a1="a12";a2="a1202";
		//$("img.qh").trigger('click');
		zdgz=getQueryString("zdgz");
		typeId=getQueryString("typeId");
		type=getQueryString("type");
		cType=getQueryString("cType");
		htmlTitle +="<a href='javascript:void(0);'>统计分析</a>><a href='focusStatistics.html'>重点关注统计</a>><a href='javascript:void(0);'>查看相关企业</a>";
		$(".bread-nav").html(htmlTitle);
		company(zdgz,typeId,type, cType,pindex, psize);
	}
		var zx=getQueryString("zx");
	if(zx=="" || zx == "zx"){
		getActiveN("a12", "a1202");//当前页标志
		a1="a12";a2="a1202";
	}
	// 查看详情
	$("body").on("click",".lookdetail",function(){
		var isConcern=$(this).parent(".hs").children(".concern").text();
		$.cookie('THE_SET_CONCERN', isConcern, { path: '/' });
		var urlParam="Enterprise_archivesInfo.html?c_id="+$(this).parent("td").data("enterid");
		$(this).attr("href",urlParam);
	})
	/**导出**/
	$("#daochu").click(function(){
		if(objSting!=null&&objSting!=undefined){
			if(pcount<1001){
				var comName=$(".content-title").text();
				comName=encodeURI(comName);
				console.log(comName);
				var exportEnterpriseUrl=systemUrl+"/request1/exportInfo?name="+comName;
		    $(this).attr("href",exportEnterpriseUrl);
			}else{
				layer.open({
					type:1
					,title: '系统提示'
					,content: '<div class="removeTip"><p>当前数据量超过1000条，为了数据的安全，我们无法为您导出该数据，如需导出请联系客服。</p></div>'
					,btn: ['确定']
					,yes: function(){
						layer.closeAll();
					}
				});
				return false;
			}
		}else{
		console.log(jsonParam);
		var excelName=$(".content-title a").text();
		console.log(excelName);
		var pattern = new RegExp('[\/:*?"<>|]');
		if(pattern.test(excelName)){
	        for (var i = 0; i < excelName.length; i++) {
	        	excelName = excelName.replace(pattern, '-');
	        	console.log(excelName);
	        }
	    }
		var listType="foodEnterpriseList";
		var header="企业名称"+","+"营业执照"+","+"经营地址"+","+"法定代表人"+","+"监管单位"+","+"企业类型"+","+"经营方式"+","+"联系电话"+","+"许可证到期时间";
		if(pcount<1001){
			var exportExcelParam={
				excelName:escape(excelName),
				listType:listType,
				header:header,
				jsonParam:jsonParam
			}
			postExportExcel(dcUrl,exportExcelParam);
		}else{
			layer.open({
				title: '系统提示'
				,content: '当前数据量超过1000条，为了数据的安全，我们无法为您导出该数据，如需导出请联系客服。'
				,btn: ['确定']
				,yes: function(){
					layer.closeAll();
				}
			});
			return false;
		}
		}
	})

	/*关注*/
	$("body").on("click",".concern",function(){
		var _this=$(this);
		if(_this.text() == "关注"){
			var wxjson = new webjson("53"); //设置action值
			//新增param键值
			wxjson.AddParam("enterpriseid", _this.data("cid"));//企业id
			wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
			var res=WebRequest(wxjson);
			var data = GetOjson(json_parse(res));
			console.log(data);
			if(data.status == "0"){
				var list="";
				$.each(data.param,function(i,item){
					list+='<li data-id="'+item.c_id+'">'+
					'<input name="" type="checkbox" value="" id="type'+i+'" />'+
					'<label class="label1" for="type'+i+'"><pre>'+item.typename+'</pre></label>'+
					'</li>';
				})
				var cname1=_this.parents("tr").children("td").eq(0).text();
				var html='<div class="toast-warp">'+
				'<form>'+
				'<ul class="record-form">'+
				'<li>'+
				'<h3 class="h3-title2">为<b>'+cname1+'</b>选择分类</h3>'+
				'</li>'+
				'<li>'+
				'<span class="sbtn gz-add">创建新分类</span>'+
				'<div class="add-type">'+
				'<input type="text" value="" maxlength="20" placeholder="请输入分类名称" class="foodName" />'+
				'<span class="sbtn" id="cancel">取消</span>'+
				'<span class="sbtn" id="save">保存</span>'+
				'</div>'+
				'</li>'+
				'<li>'+
				'<ul class="type-list clearfix">'+
				list+
				'</ul>'+
				'</li>'+
				'</ul>'+
				'</form>'+
				'</div>';
				layer.open({
					type:1
					,title: ' '
					,content: html
					,area: ['530px', 'auto']
					,btn: ['取消', '确认']
					,yes: function(index, layero){
						layer.close(index);
						
				    	//按钮【按钮二】的回调
				    	//return false 开启该代码可禁止点击该按钮关闭
					}
					,btn2: function(index, layero){
						var typesArr=[];
						$.each($(".type-list li"),function(){
							if($(this).find("input[type='checkbox']").prop("checked")){
								typesArr.push($(this).data("id"));
							}
						})
						console.log(typesArr);
							var wxjson = new webjson("54"); //设置action值
							//新增param键值
							wxjson.AddParam("enterpriseid", _this.data("cid"));//企业id
							wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
							wxjson.AddParam("flag", "qy");
							if(typesArr.length > 0){
								wxjson.AddParam("types", typesArr.join(","));//选中的类别id,拼接成逗号隔开的字符串"
							}else{
								wxjson.AddParam("types", "");//选中的类别id,拼接成逗号隔开的字符串"
							}
							
							var res=WebRequest(wxjson);
							var data2 = GetOjson(json_parse(res));
							if(data2.status == "0"){
								//刷新列表
								_this.text("取消关注");
								//$.cookie('THE_SET_CONCERN', '取消关注', { path: '/' });
								
								layer.msg(data2.info);
								layer.close(index);
							}else if(data2.status == "9"){
								window.location.href="index.html?loginOut=true";
								return;
							}else{
								layer.msg(data2.info);
							}
						
					}
					,cancel: function(index, layero){
				    	//右上角关闭回调
				    	//return false 开启该代码可禁止点击该按钮关闭
					}
				});

				
				$(".gz-add").on("click",function(){
					$(this).hide();
					$(this).next().show();
				})
				$("#cancel").on("click",function(){
					$(this).parent(".add-type").hide();
					$(this).parent(".add-type").prev().show();
					$(this).parent(".add-type").children(".foodName").val("");
				})
				$(".add-type .foodName").on("keydown",function(event){
					var event=event || window.event;
				    if(event.keyCode == "13") {//判断如果按下的是回车键则执行下面的代码
				    	return false;
				    }
				})
				$("#save").on("click",function(){//创建新分类
					var tname1=$(this).parent(".add-type").children(".foodName").val();
					console.log(tname1);
					var typesNameArr=[];
					$.each($(".type-list li"),function(){
						if($(this).find(".label1").text()){
							typesNameArr.push(Trim($(this).find(".label1").text()));
						}
					})
					console.log(typesNameArr);
					if(typesNameArr.indexOf(tname1) >= 0){
						layer.msg('企业分类名称不能重复！');
					}else{
						var wxjson = new webjson("49"); //设置action值 创建新分类
						//新增param键值
						wxjson.AddParam("c_id", "");//类别id
						wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
						wxjson.AddParam("typename", Trim(tname1));//:类别名称
						wxjson.AddParam("keywords", "");//搜索关键字，以空格隔开
						wxjson.AddParam("zone_code", $.cookie('dep_code'));//:当前监管单位code编码

						var res=WebRequest(wxjson);
						var data5 = GetOjson(json_parse(res));
						if(data5.status == "0"){
							//layer.msg(data.info);
							var wxjson = new webjson("53"); //设置action值
							//新增param键值
							wxjson.AddParam("enterpriseid", _this.data("cid"));//企业id
							wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
							var res=WebRequest(wxjson);
							var data = GetOjson(json_parse(res));
							console.log(data);
							if(data.status == "0"){//读取分类信息

								var list="";
								$.each(data.param,function(i,item){
									list+='<li data-id="'+item.c_id+'">'+
									'<input name="" type="checkbox" value="" id="type'+i+'" />'+
									'<label class="label1" for="type'+i+'"><pre>'+item.typename+'</pre></label>'+
									'</li>';	
									
								})
								$(".type-list").children().remove();
								$(".type-list").append(list);

							}else if(data.status == "9"){
								window.location.href="index.html?loginOut=true";
								return;
							}else{
								layer.msg(data.info);
							}
						}else if(data5.status == "9"){
							window.location.href="index.html?loginOut=true";
							return;
						}else{
							layer.msg(data5.info);
						}
					}
				})
			}else if(data.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else{
				layer.msg(data.info);
			}
			
		}else{//取消关注
			var wxjson = new webjson("55"); //设置action值
			//新增param键值
			wxjson.AddParam("enterpriseid", _this.data("cid"));//企业id
			wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
			var res=WebRequest(wxjson);
			var data4 = GetOjson(json_parse(res));
			if(data4.status == "0"){
				//刷新列表
				_this.text("关注");
				//$.cookie('THE_SET_CONCERN', '关注', { path: '/' });
				
				layer.msg(data4.info);
				//layer.close(index);
			}else if(data4.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else{
				layer.msg(data4.info);
			}
		}
		
	})
})

/**重点关注统计页面跳转过来的方法**/
function company(zdgz,typeId,type, cType,spindex, psize){
	pindex = spindex;
	var zt1="";
	if(cType=="0"||cType=="1"){
		zt1="相关已入网生产企业";
	}else if(cType=="2"){
		zt1="相关已入网企业";
	}else if(cType=="3"){
		zt1="";
	}else if(cType=="4"){
		zt1="相关台账";
	}
	console.log("name:"+name,"zt1:"+zt1,"type:"+type);
	var htmlCt="";
	 if(zt1!=null&&type!=null&&name!==null){
		htmlCt +="<a href='javascript:void(0);'>"+name+type+zt1+"</a>";
     $(".content-title").html(htmlCt);
	}else{
   	 $(".content-title").html("");
    }
	$("table tbody").children().remove();
	$("table tbody").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;'><img src='../style/image/load.gif' alt='' /></td></tr>");
	$("#mySelectS").css("display","none");
	$("#daochu").css("display","none");
	var wxjson = new webjson("5");
	wxjson.AddParam("deptid", $.cookie('departmentid'));//监管单位id
	wxjson.AddParam("zdgz", zdgz);
	wxjson.AddParam("typeId", typeId);
	wxjson.AddParam("type", type);
	wxjson.AddParam("cType", cType);
	wxjson.AddParam("page_index", pindex);
	wxjson.AddParam("page_size", psize);
	WebRequestAsync(wxjson, companyList);
	jsonParam=wxjson.GetJsons();
}
function companyList(res){
	var html = "";
	var data = GetOjson(json_parse(res));
	console.log(data);
	pcount = data.paramcentcount;
	var ps = pcent.GetCentPage(pindex, pcount, psize);
	$("#page").html(ps);
	if(data.status == 0) {
	     autoH();
		if(pcount!="0"){
			$("#daochu").css("display","");
			$("#mySelectS").css("display","");
			}else{
			 $("#daochu").css("display","none");
			 $("#mySelectS").css("display","none");
			}
		for(var i = 0; i < data.param.length; i++){
			c_id=data.param[i].c_id;
			if(data.param[i].c_type == "0") {
				data.param[i].c_type = '生产企业';
			} else if(data.param[i].c_type=="1"){
				data.param[i].c_type = '销售经营企业';
			}else if(data.param[i].c_type=="2"){
				data.param[i].c_type = '餐饮服务企业';
			}else{
				data.param[i].c_type = '单位食堂';
			}
		 /**  var o_type1=data.param[i].o_type;
		   var o_typeTotal="";
		   if(o_type1==""){
			   o_typeTotal="";
		   }else{
			   o_type1=data.param[i].o_type.split(",");
		   }
		   for(var j=0;j<o_type1.length;j++){
			if(o_type1[j] == "0") {
				o_typeTotal = o_typeTotal+'批发,';
			} else if(o_type1[j]=="1"){
				o_typeTotal = o_typeTotal+'零售,';
			}else if(o_type1[j]=="2"){
				o_typeTotal = o_typeTotal+'批发兼零售,';
			}else if(o_type1[j]=="3"){
				o_typeTotal = o_typeTotal+'网络经营,';
			}else if(o_type1[j]=="4"){
				o_typeTotal = o_typeTotal+'内设中央厨房,';
			}else if(o_type1[j]=="5"){
				o_typeTotal = o_typeTotal+'集体用餐配送,';
			}else{
				o_typeTotal = "";
			}
		   }
		   o_typeTotal=o_typeTotal.substr(0,o_typeTotal.length-1);**/
			var cstatus="";
			if(data.param[i].cstatus=="0"){
				cstatus="正常经营";
			}else if(data.param[i].cstatus=="1"){
				cstatus="未注册";
			}else if(data.param[i].cstatus=="2"){
				cstatus="停产";
			}else if(data.param[i].cstatus=="3"){
				cstatus="转让";
			}else{
				cstatus="";
			}
			var attention="";
			if(data.param[i].is_attention =="0"){
				attention="取消关注";
			}else{
				attention="关注";
			}
			html += "<tr>";
			html += "<td class='hs'>" +data.param[i].cname +
			"</td><td class='hs'>" +data.param[i].license +
			"</td><td class='hs'>" +data.param[i].jaddress +
			"</td><td class='hs'>" +data.param[i].legal +
			"</td><td class='hs'>" +data.param[i].scompany +
			"</td><td class='hs'>" +data.param[i].c_type +
			"</td><td class='hs'>" +data.param[i].cnumber +
			"</td> <td class='hs'>"+cstatus +
			'<td class="hs ls" data-enterid="'+data.param[i].c_id+'"><a href="javascript:void(0);" class="lookdetail" target="_blank">详情</a></td>';
			//'<td class="hs ls" data-enterid="'+data.param[i].c_id+'"><a href="javascript:void(0);" class="lookdetail" target="_blank">详情</a><span class="fg-line ls">|</span><span class="concern ls" data-cid="'+data.param[i].c_id+'">'+attention+'</span></td>';
		    html += "</tr>";
	}
	$("table tbody").html(html);
	autoH();
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else {
		$("table tbody").html("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;font-size:14px;'>没有相关数据</td></tr>");
		$("#mySelectS").css("display","none");
		$("#daochu").css("display","none");
	}
}

/**入网页面跳转过来的**/
function ruwang(neTitle,liTitle,zone_code,qyType,countWay,time,flag,sum,spindex, psize){
	   pindex = spindex;
	   var htmlCt="";
		 if(neTitle!=null&&time!=null&&liTitle!==null){
			htmlCt +="<a href='javascript:void(0);'>"+neTitle+time+liTitle+"</a>";
	    $(".content-title").html(htmlCt);
		}else{
	  	 $(".content-title").html("");
	   }
	   $("table tbody").children().remove();
		$("table tbody").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;'><img src='../style/image/load.gif' alt='' /></td></tr>");
		$("#mySelectS").css("display","none");
		$("#daochu").css("display","none");
		var wxjson = new webjson("39");
		//wxjson.AddParam("neTitle",neTitle);
		//wxjson.AddParam("liTitle",liTitle);
		wxjson.AddParam("zone_code",zone_code);
		wxjson.AddParam("deptid", $.cookie('departmentid'));//监管单位id
		wxjson.AddParam("qyType", qyType);
		wxjson.AddParam("countWay",countWay);
		wxjson.AddParam("time", time);
		wxjson.AddParam("flag", flag);
		wxjson.AddParam("sum",sum);
		wxjson.AddParam("page_index", pindex);
		wxjson.AddParam("page_size", psize);
		WebRequestAsync(wxjson, companyList);
		jsonParam=wxjson.GetJsons();
}

/**报备统计过来的**/
function tongji(lx,jgj,time,qylx,jgj_name,spindex, psize){
	pindex = spindex;
	var htmlCt="";
	 if(jgj_name!=null&&time!=null&&lx!==null){
		htmlCt +="<a href='javascript:void(0);'>"+jgj_name+time+lx+"</a>";
    $(".content-title").html(htmlCt);
	}else{
  	 $(".content-title").html("");
   }
	$("table tbody").children().remove();
	$("table tbody").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;'><img src='../style/image/load.gif' alt='' /></td></tr>");
	$("#mySelectS").css("display","none");
	$("#daochu").css("display","none");
	if(getQueryString('zx')=="" || getQueryString('zx') == "zx"){
		var htmlTitle ="<a href='javascript:void(0);'>统计分析</a>><a href='districtStatistics.html'>辖区统计</a>><a href='javascript:void(0);'>查看相关企业</a>";
		$(".bread-nav").html(htmlTitle);
	}
	var wxjson = new webjson("5");
	wxjson.AddParam("deptid", $.cookie('departmentid'));//监管单位id
	wxjson.AddParam("jgj", jgj);
	wxjson.AddParam("time", time);
	wxjson.AddParam("qylx", qylx);
	wxjson.AddParam("jgj_name", jgj_name);
	wxjson.AddParam("lx", lx);
	if(getQueryString('zx')=="zx"){
		wxjson.AddParam("zx", 'zx');
	}
	wxjson.AddParam("page_index", pindex);
	wxjson.AddParam("page_size", psize);
	WebRequestAsync(wxjson, companyList);
	jsonParam=wxjson.GetJsons();
}

/**select选择框**/
// function select() {
// 	//获取下拉框选中项的text属性值
// 	pindex="1";
// 	var selectText = $("#mySelect").find("option:selected").text();
// 	//获取下拉框选中项的value属性值
// 	var selectValue = $("#mySelect").val();
// 	console.log(selectValue);
// 	psize = selectValue;
// 	CentPageOper(pindex);
// 	if(objSting!=null&&objSting!=undefined){
// 		  var neTitle=objSting.neTitle;
// 		   var liTitle=objSting.liTitle;
// 		   var zone_code=objSting.zone_code;
// 		   var qyType=objSting.qyType;
// 		   var countWay=objSting.countWay;
// 		   var time=objSting.time;
// 		   var flag=objSting.flag;
// 		   var sum=objSting.sum;
// 		ruwang(neTitle,liTitle,zone_code,qyType,countWay,time,flag,sum,pindex, psize);
// 	}else if(chuanzf!=null&&lx!=null&&chuanzf!=undefined&&lx!=undefined){
// 		var jgj=chuanzf.jgj;
// 		var time=chuanzf.time;
// 		var qylx=chuanzf.qylx;
// 		var jgj_name=chuanzf.jgj_name;
// 		tongji(lx,jgj,time,qylx,jgj_name,pindex, psize);
// 	}else{
// 		company(zdgz,typeId,type,cType,pindex, psize);
// 	}
// }
//模拟select
		$(".selectedB").on('click', '.sel-wrap', function(event) {
			var listH=$("#mySelectS").find(".optionB").height();
			if($(this).is(":hover")){
				console.log($(".selectedB .optionB").not($(this).next('.optionB')))
				$(".selectedB .optionB").not($(this).next('.optionB')).hide(20);
				$(this).next('.optionB').slideToggle(20);
			}
			if($(this).next(".selectedB").find(".optionB").css("display") != "none"){
				var offsetBottom=document.documentElement.clientHeight + $(document).scrollTop() - $(this).offset().top-$(this).height();
				if(offsetBottom < listH){
					console.log($(this).height())
					$("#mySelectS").find(".optionB").css({"left":"0","top":-listH})
				}
			}
			return false;
		});
		document.onclick = function(){
			$(".optionB").hide();
		};
		var selectText="20条/页";
		$("#mySelectS").on('click', '.op-item', function(event) {
			$("#mySelectS").find('.selected-item').text($(this).text());
			if(selectText != $(this).text()){
				pindex=1;
				selectText=$(this).text();
				if($(this).text()=="10条/页"){
					psize=10;
					if(objSting!=null&&objSting!=undefined){
					  var neTitle=objSting.neTitle;
					   var liTitle=objSting.liTitle;
					   var zone_code=objSting.zone_code;
					   var qyType=objSting.qyType;
					   var countWay=objSting.countWay;
					   var time=objSting.time;
					   var flag=objSting.flag;
					   var sum=objSting.sum;
					ruwang(neTitle,liTitle,zone_code,qyType,countWay,time,flag,sum,pindex, psize);
					}else if(chuanzf!=null&&lx!=null&&chuanzf!=undefined&&lx!=undefined){
						var jgj=chuanzf.jgj;
						var time=chuanzf.time;
						var qylx=chuanzf.qylx;
						var jgj_name=chuanzf.jgj_name;
						tongji(lx,jgj,time,qylx,jgj_name,pindex, psize);
					}else{
						company(zdgz,typeId,type,cType,pindex, psize);
					}
				}else if($(this).text()=="20条/页"){
					psize=20;
					if(objSting!=null&&objSting!=undefined){
					  var neTitle=objSting.neTitle;
					   var liTitle=objSting.liTitle;
					   var zone_code=objSting.zone_code;
					   var qyType=objSting.qyType;
					   var countWay=objSting.countWay;
					   var time=objSting.time;
					   var flag=objSting.flag;
					   var sum=objSting.sum;
					ruwang(neTitle,liTitle,zone_code,qyType,countWay,time,flag,sum,pindex, psize);
					}else if(chuanzf!=null&&lx!=null&&chuanzf!=undefined&&lx!=undefined){
						var jgj=chuanzf.jgj;
						var time=chuanzf.time;
						var qylx=chuanzf.qylx;
						var jgj_name=chuanzf.jgj_name;
						tongji(lx,jgj,time,qylx,jgj_name,pindex, psize);
					}else{
						company(zdgz,typeId,type,cType,pindex, psize);
					}
				}else if($(this).text()=="30条/页"){
					psize=30;
					if(objSting!=null&&objSting!=undefined){
					  var neTitle=objSting.neTitle;
					   var liTitle=objSting.liTitle;
					   var zone_code=objSting.zone_code;
					   var qyType=objSting.qyType;
					   var countWay=objSting.countWay;
					   var time=objSting.time;
					   var flag=objSting.flag;
					   var sum=objSting.sum;
					ruwang(neTitle,liTitle,zone_code,qyType,countWay,time,flag,sum,pindex, psize);
					}else if(chuanzf!=null&&lx!=null&&chuanzf!=undefined&&lx!=undefined){
						var jgj=chuanzf.jgj;
						var time=chuanzf.time;
						var qylx=chuanzf.qylx;
						var jgj_name=chuanzf.jgj_name;
						tongji(lx,jgj,time,qylx,jgj_name,pindex, psize);
					}else{
						company(zdgz,typeId,type,cType,pindex, psize);
					}
				}else if($(this).text()=="40条/页"){
					psize=40;
					if(objSting!=null&&objSting!=undefined){
					  var neTitle=objSting.neTitle;
					   var liTitle=objSting.liTitle;
					   var zone_code=objSting.zone_code;
					   var qyType=objSting.qyType;
					   var countWay=objSting.countWay;
					   var time=objSting.time;
					   var flag=objSting.flag;
					   var sum=objSting.sum;
					ruwang(neTitle,liTitle,zone_code,qyType,countWay,time,flag,sum,pindex, psize);
					}else if(chuanzf!=null&&lx!=null&&chuanzf!=undefined&&lx!=undefined){
						var jgj=chuanzf.jgj;
						var time=chuanzf.time;
						var qylx=chuanzf.qylx;
						var jgj_name=chuanzf.jgj_name;
						tongji(lx,jgj,time,qylx,jgj_name,pindex, psize);
					}else{
						company(zdgz,typeId,type,cType,pindex, psize);
					}
				}else if($(this).text()=="50条/页"){
					psize=50;
					if(objSting!=null&&objSting!=undefined){
					  var neTitle=objSting.neTitle;
					   var liTitle=objSting.liTitle;
					   var zone_code=objSting.zone_code;
					   var qyType=objSting.qyType;
					   var countWay=objSting.countWay;
					   var time=objSting.time;
					   var flag=objSting.flag;
					   var sum=objSting.sum;
					ruwang(neTitle,liTitle,zone_code,qyType,countWay,time,flag,sum,pindex, psize);
					}else if(chuanzf!=null&&lx!=null&&chuanzf!=undefined&&lx!=undefined){
						var jgj=chuanzf.jgj;
						var time=chuanzf.time;
						var qylx=chuanzf.qylx;
						var jgj_name=chuanzf.jgj_name;
						tongji(lx,jgj,time,qylx,jgj_name,pindex, psize);
					}else{
						company(zdgz,typeId,type,cType,pindex, psize);
					}
				}else{
				}

			}

			$(this).closest('.optionB').slideUp(20);
		});
