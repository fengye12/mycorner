//服务器返回json对象
var systemUrl='';
var lowerUrl=systemUrl+"/request/belongtreeaction?code=";
var areaUrl=systemUrl+"/request/treeaction?deptid=";
var exportUrl=systemUrl+"/request1/exportaction";
var dcUrl=systemUrl+"/request/export";//导出url
function ojson() {
	this.action = "";
	this.status = 0;
	this.info = "";
	this.md5ver = "";
	this.sessid = "";
	this.paramcentcount = 0;
	this.param = new Array();
	this.datas = null;
};

//服务器请求json对象
function webjson(act) {
	this.url =systemUrl+"/request/action";
	this.action = act;
	this.time = "";
	this.sessid = "";
	this.rannum = "";
	this.md5ver = "";
	this.param = new Array();
	this.datas = null;
};

//新增param键值
webjson.prototype.AddParam = function(keyname, keyval) {
	var pars = "";
	if(this.param.length <= 0) {
		this.param[0] = "";
	} else {
		pars = this.param[this.param.length - 1];
	}
	if(pars != "") {
		pars += ","
	}
	pars += '"' + keyname + '":"' + escape(keyval) + '"';
	this.param[this.param.length - 1] = pars;
};

//指定索引param行新增param键值
webjson.prototype.AddParamAt = function(keyname, keyval, pindex) {
	var pars = "";
	if(this.param.length <= 0) {
		this.param[0] = "";
		pindex = 0;
	} else {
		if(pindex < this.param.length) {
			pars = this.param[pindex];
		} else {
			pars = this.param[this.param.length - 1];
			pindex = this.param.length - 1;
		}
	}
	if(pars != "") {
		pars += ","
	}
	pars += '"' + keyname + '":"' + escape(keyval) + '"';
	this.param[pindex] = pars;
};

//新增param行
webjson.prototype.AddParamLine = function() {
	if(this.param.length <= 0) {
		this.param[0] = "";
	} else {
		this.param[this.param.length] = "";
	}
};

//新增Datas键值
webjson.prototype.AddDatas = function(dname, keyname, keyval) {
	if(this.datas == null) {
		this.datas = function() {};
	}
	if(this.datas[dname] == null) {
		this.datas[dname] = new Array();
	}
	var pars = "";
	if(this.datas[dname].length <= 0) {
		this.datas[dname][0] = "";
	} else {
		pars = this.datas[dname][this.datas[dname].length - 1];
	}
	if(pars != "") {
		pars += ","
	}
	pars += '"' + keyname + '":"' + escape(keyval) + '"';
	this.datas[dname][this.datas[dname].length - 1] = pars;
};

//指定索引Datas行新增Datas键值
webjson.prototype.AddDatasAt = function(dname, keyname, keyval, pindex) {
	if(this.datas == null) {
		this.datas = function() {};
	}
	if(this.datas[dname] == null) {
		this.datas[dname] = new Array();
	}
	var pars = "";
	if(this.datas[dname].length <= 0) {
		this.datas[dname][0] = "";
		pindex = 0;
	} else {
		if(pindex < this.datas[dname].length) {
			pars = this.datas[dname][pindex];
		} else {
			pars = this.datas[dname][this.datas[dname].length - 1];
			pindex = this.datas[dname].length - 1;
		}
	}
	if(pars != "") {
		pars += ","
	}
	pars += '"' + keyname + '":"' + escape(keyval) + '"';
	this.datas[dname][pindex] = pars;
};

//新增Datas行
webjson.prototype.AddDatasLine = function(dname) {
	if(this.datas == null) {
		this.datas = function() {};
	}
	if(this.datas[dname] == null) {
		this.datas[dname] = new Array();
	}
	if(this.datas[dname].length <= 0) {
		this.datas[dname][0] = "";
	} else {
		this.datas[dname][this.datas[dname].length] = "";
	}
};

//返回Json字符串值
webjson.prototype.GetJsons = function() {
	var jstr = "";
	jstr += '"action":"' + this.action + '"';
	jstr += ',"time":"' + escape(this.time) + '"';
	jstr += ',"sessid":"' + escape(this.sessid) + '"';
	jstr += ',"rannum":"' + escape(this.rannum) + '"';
	jstr += ',"md5ver":"' + escape(this.md5ver) + '"';
	var pint = 0;
	var pars = "";
	for(var i = 0; i < this.param.length; i++) {
		var ps = Trim(this.param[i]);
		if(ps != "") {
			if(pars != "") {
				pars += ",";
			}
			pars += "{" + ps + "}";
			pint += 1;
		}
	}
	if(pint > 0) {
		jstr += ',"param":[' + pars + ']';
	} else {
		jstr += ',"param":[]';
	}
	var dpars = "";
	if(this.datas != null) {
		for(var dname in this.datas) {
			var sdpint = 0;
			var spars = "";
			var darr = this.datas[dname];
			for(var i = 0; i < darr.length; i++) {
				var ps = Trim(darr[i]);
				if(ps != "") {
					if(spars != "") {
						spars += ",";
					}
					spars += "{" + ps + "}";
					sdpint += 1;
				}
			}
			if(dpars != "") {
				dpars += ",";
			}
			if(sdpint > 0) {
				dpars += '"' + dname + '":[' + spars + ']';
			} else {
				dpars += '"' + dname + '":[]';
			}
		}
	}
	if(dpars != "") {
		jstr += ',"datas":{' + dpars + '}';
	} else {
		jstr += ',"datas":{}';
	}
	return "{" + jstr + "}";
};

webjson.prototype.GetUrl = function() {
	return this.url + "?rannum=" + GetReDate();
};

function GetOjson(jos) {
	var sobj = jos;
	var os = new ojson();
	if(sobj.hasOwnProperty("action")) {
		os.action = sobj.action;
	}
	if(sobj.hasOwnProperty("status")) {
		os.status = sobj.status;
	}
	if(sobj.hasOwnProperty("info")) {
		os.info = UnTrim(sobj.info);
	}
	if(sobj.hasOwnProperty("md5ver")) {
		os.md5ver = UnTrim(sobj.md5ver);
	}
	if(sobj.hasOwnProperty("sessid")) {
		os.sessid = UnTrim(sobj.sessid);
	}
	if(sobj.hasOwnProperty("paramcentcount")) {
		os.paramcentcount = sobj.paramcentcount;
	}
	if(sobj.hasOwnProperty("param")) {
		if(isArray(sobj.param)) {
			os.param = sobj.param;
			for(var i = 0; i < os.param.length; i++) {
				for(var key in os.param[i]) {
					os.param[i][key] = UnTrim(os.param[i][key]);
				}
			}
		}
	}
	if(sobj.hasOwnProperty("datas")) {
		if(os.datas == null) {
			os.datas = function() {};
		}
		for(var okey in sobj.datas) {
			var odarr = sobj.datas[okey];
			if(isArray(odarr)) {
				os.datas[okey] = odarr;
				for(var i = 0; i < os.datas[okey].length; i++) {
					for(var key in os.datas[okey][i]) {
						os.datas[okey][i][key] = UnTrim(os.datas[okey][i][key]);
					}
				}
			}
		}
	}
	return os;
};

function TestJson() {
	var wxjson = new webjson("0"); //传入action
	wxjson.AddParam("username", "user1"); //设置 param 键值对
	wxjson.AddParam("password", "123456"); //设置 param 键值对

	wxjson.AddDatas("a1", "username11", "user11");  //设置 datas 的 a1数组  键值对
	wxjson.AddDatas("a1", "username12", "user12");  //设置 datas 的 a1数组  键值对
	wxjson.AddDatasLine("a1"); //新增 datas 的 a1  数组行
	wxjson.AddDatas("a1", "username13", "user13");
	wxjson.AddDatas("a1", "username14", "user14");

	wxjson.AddDatas("a2", "username11", "user11");//设置 datas 的 a2数组  键值对
	wxjson.AddDatas("a2", "username12", "user12");
	wxjson.AddDatas("a2", "username13", "user13");
	wxjson.AddDatasLine("a2");//新增 datas 的 a2  数组行
	wxjson.AddDatas("a2", "username14", "user14");

	wxjson.AddDatas("a3", "username11", "user11");//设置 datas 的 a3数组  键值对
	wxjson.AddDatasLine("a3");//新增 datas 的 a3  数组行
	wxjson.AddDatas("a3", "username12", "user12");
	wxjson.AddDatas("a3", "username13", "user13");
	wxjson.AddDatas("a3", "username14", "user14");

	var myJson = wxjson.GetJsons();//返回json字符串
	var ojson = GetOjson(json_parse(myJson));//根据json生成对象
}

function WebRequestAsync(wjson, fun) {
	var myJson = wjson.GetJsons();
	console.log(myJson);
	$.ajax({
		async: true,
		url: wjson.url,
		data: myJson,
		method: 'POST',
		contentType: 'application/json;charset=UTF-8',
		success: function(res, tstatus, jqxhr) {
			// console.log(res);
			fun(res);
		},
		error: function(jqxhr, tstatus, errmsg) {
			// console.log(errmsg);
		}
	});
}

function WebRequest(wjson) {
	var myJson = wjson.GetJsons();
	console.log(myJson);
	var res = $.ajax({
		async: false,
		url: wjson.url,
		data: myJson,
		method: 'POST',
		contentType: 'application/json;charset=UTF-8'
	}).responseText;
	// console.log(res);
	return res;
}

function GetQueryString(name)
{
     var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
     var r = window.location.search.substr(1).match(reg);
     if(r!=null)return  unescape(r[2]); return null;
}
function autoH(){//自动左右高度
	var wh=$(window).height();
	$(".left-nav").height(wh);
	$(".left-nav").css({'position':'fixed'});
}