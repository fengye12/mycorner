/*
* @Author: yangjy
* @Date:   2017-07-12 11:45:51
* @Last Modified time: 2017-09-26 19:16:38
*/
autoH();//左右高度自适应autoH();//左右高度自适应
var a1 = "a12",a2 = "a1203";//当前页代码
var ecount = $("#inputmySelect").val();//每页显示的记录数
var cpage01 = new CentPage();//实例化分页插件
var pagenum = 1;//初始当前页
var paramcentcount=0;//总记录数
var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);//初始化分页设置
$("#page").html(cents);

function CentPageOper(pnum){//点击某一页时调用此方法
	cents = cpage01.GetCentPage(pnum,paramcentcount,ecount);
	$("#page").html(cents);
	pagenum=pnum;
	companyList(pagenum,ecount);//调用企业分类列表
}

function companyData(res){//获取企业列表数据
	$("#comList").children().remove();
	var data = GetOjson(json_parse(res));
	paramcentcount=data.paramcentcount;
	//$(".total-num").text("共"+paramcentcount+"条");
	var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);
	$("#page").html(cents);
	if(data.status == "0"){
		console.log(data)
		$.each(data.param,function(i,item){
			var html="";
			html='<tr>'+
			'<td class="hs"><pre>'+item.typename+'<pre></td>'+
			'<td class="hs">'+item.entercount+'</td>';
			if(item.bbCount == "0"){
				html+='<td class="hs">'+item.bbCount+'</td>'
			}else{
				html+='<td class="hs"><a href="Enterprise_statisticBaobei.html?c_id='+item.c_id+'&status=1&typename1='+escape(item.typename)+'" target="_blank">'+item.bbCount+'</a></td>';
			}
			if(item.nobbCount == "0"){
				html+='<td class="hs">'+item.nobbCount+'</td>';
			}else{
				html+='<td class="hs"><a href="Enterprise_statisticBaobei.html?c_id='+item.c_id+'&status=2&typename1='+escape(item.typename)+'" target="_blank">'+item.nobbCount+'</a></td>';
			}


			html+='<td class="hs">'+item.bbRate+'</td>';
			//<td class="hs text-red">'+item.warning+'</td>
			if(item.basic == "0" && item.attention == "0"){
				if(item.entercount == "0"){
					html+='<td class="hs"><a href="javascript:void(0);" class="lookDetail">查看</a></td>'+
				'</tr>';
				}else{
					html+='<td class="hs" data-c_id="'+item.c_id+'"><a href="Enterprise_statisticConcern.html?c_id='+item.c_id+'" target="_blank">查看</a></td>'+
				'</tr>';
				}

			}else if(item.basic == "0" && item.attention == "1"){
				if(item.entercount == "0"){
					html+='<td class="hs" data-c_id="'+item.c_id+'"><a href="javascript:void(0);" class="lookDetail">查看</a><span class="fg-line ls">|</span><a href="javascript:void(0);" class="editType">编辑</a></td>'+
				'</tr>';
				}else{
					html+='<td class="hs" data-c_id="'+item.c_id+'"><a href="Enterprise_statisticCompany.html?c_id='+item.c_id+'&typename='+escape(item.typename)+'" target="_blank">查看</a><span class="fg-line ls">|</span><a href="javascript:void(0);" class="editType">编辑</a></td>'+
				'</tr>';
				}

			}else{
				if(item.entercount == "0"){
					html+='<td class="hs" data-c_id="'+item.c_id+'"><a href="javascript:void(0);" class="lookDetail">查看</a><span class="fg-line ls">|</span><a href="javascript:void(0);" class="editType">编辑</a><span class="fg-line ls">|</span><a href="javascript:void(0);" class="removeType">删除</a></td>'+
				'</tr>';
				}else{
					html+='<td class="hs" data-c_id="'+item.c_id+'"><a href="Enterprise_statisticCompany.html?c_id='+item.c_id+'&typename='+escape(item.typename)+'" target="_blank">查看</a><span class="fg-line ls">|</span><a href="javascript:void(0);" class="editType">编辑</a><span class="fg-line ls">|</span><a href="javascript:void(0);" class="removeType">删除</a></td>'+
				'</tr>';
				}
			}
			$("#comList").append(html);
		})

		$("#mySelect").css("display","");
		autoH();
	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else{
		$("#comList").append("<tr class='loading'><td colspan='6' style='padding:20px 0;text-align: center;'>"+data.info+"</td></tr>");
	}
}

function companyList(pagenum,ecount){//请求企业列表
	$("#comList").children().remove();
	$("#mySelect").css("display","none");
	$("#comList").append("<tr class='loading'><td colspan='6' style='padding:20px 0;text-align: center;'><img src='../style/image/load.gif' width='32px' height='32px' /></td></tr>");
	var wxjson = new webjson("48"); //设置action值
	//新增param键值

	wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
	wxjson.AddParam("zone_code", $.cookie('dep_code'));//监管单位code
	wxjson.AddParam("page_index", pagenum);
	wxjson.AddParam("page_size", ecount);
	WebRequestAsync(wxjson, companyData);
}

/*关注企业分类--关键字*/
function keywords1(){
	$(".downcon .circle").click(function(event) {//问号提示框
		$(this).next('.downtext').fadeToggle(10);
	});
	$(document).click(function(e){
	    var _con = $(".downcon .circle");   // 设置目标区域
	    if(!_con.is(e.target) && _con.has(e.target).length === 0){
	        _con.next('.downtext').hide();
	    }
	});
    $(".t-list").on("click",function(){
      $(this).find(".input-write").focus();
    })
    $(".input-write").on("keyup",function(event){
      var event=event || window.event;
      var inputVal=$(this).val();
          // if(Trim(inputVal).length == 0){
          //  $(this).val("");
          // }
      var lastVal=inputVal.substr(inputVal.length-1,1);
      if((lastVal == " " || event.keyCode == 13) && TrimAll(inputVal).length > 0){
        var html='<a href="javascript:void(0);">'+
        '<span class="span-tname">'+TrimAll($(this).val())+'</span>'+
        '<img src="../style/image/delete.png" class="delT">'+
        '</a>';
        var flag=true;
        $.each($(".key-list .span-tname"),function(i,item){
          if($(this).text() == TrimAll(inputVal)){
            flag=false;
          };
        })
        if(flag){
          $(this).before(html);
        }
        $(this).val("").css("width",120);

      }else{
        var len=$(this).val().length*14;
        if(len > 120){
          $(this).css("width",120);
        }else if(len < 120){
          $(this).css("width",120);
        }else{
        	$(this).css("width",len);
        }
      }
    })
    $(".t-list").on("click",".delT",function(){
    	$(this).parent("a").remove();
    })
}

$(function(){
	$.divselect("#mySelect","#inputmySelect");
	$("#mySelect li").on("click",function(){
		//切换每页显示的记录数
		if($("#inputmySelect").val() != ecount){
			ecount = $("#inputmySelect").val();
			pagenum=1;
			companyList(pagenum,ecount);//调用企业分类列表
		}
	})
	companyList(pagenum,ecount);//调用企业分类列表

	$("#comList").on("click",".lookDetail",function(){
		layer.msg('该分类没有企业！');
	})

	getActiveN("a12", "a1203");//当前页标志
	function addNewType(isEdit,c_id){
		if(isEdit == "0"){//新建分类
			var html='<div class="toast-warp">'+
			'<form>'+
			'<ul class="record-form">'+
			'<li>'+
			'<label for="">企业分类名称</label>'+
			'<input type="text" value="" maxlength="20" class="t-name input-init" />'+
			'</li>'+
			'<li><h3 class="h3-title mt10"><span>筛选方式</span>'+
			'<span class="downcon">'+
            '<i class="circle"><img src="../style/image/cir.png" /></i>'+
            '<p class="downtext"><span>根据关键字找出相关食品,并将这些食品的经营企业筛选出来;多个关键字用空格隔开。</span></p>'+
          	'</span>'+
			'</h3></li>'+
			'<li>'+
			'<label for="" class="w140">经营食品名称关键字'+
			'</label>'+
			//'<select class="t-list js-example-tokenizer clearfix" multiple="multiple"></select>'+
			// '<textarea name="" id="recordDetail" rows="3" style="margin-top:-1px;"></textarea>'+

			'<div class="t-list clearfix">'+
			'<div class="ty-content clearfix">'+

			'<div class="key-list">'+
			//'<a href="javascript:void(0);"><span class="span-tname">乳制品</span><img src="../style/image/delete.png" class="delT"></a>'+
			//'<a href="javascript:void(0);"><span class="span-tname">婴幼儿奶粉</span><img src="../style/image/delete.png" class="delT"></a>'+
			'<input type="text" value="" placeholder="多个关键字用空格隔开" class="input-write" />'+
			'</div>'+

			'</div>'+
			'</div>'+

			'</li>'+
			'</ul>'+
			'</form>'+
			'</div>';
			layer.open({
				type:1
				,title: ' '
				,content: html
				,area: ['518px', 'auto']
				,btn: ['取消', '确认']
				,yes: function(index, layero){
					layer.close(index);
			    	//按钮【按钮二】的回调
			    	//return false 开启该代码可禁止点击该按钮关闭
				}
				,btn2: function(index, layero){
					//console.log($(".js-example-tokenizer").select2("data"));
					var arrA=[];
					$.each($(".key-list .span-tname"),function(i,item){
						console.log($(this).text());
						arrA.push($(this).text());
					})
					if(Trim($(".t-name").val()).length == 0){
						layer.msg('请输入企业分类名称！');

					}//else if(arrA.length == 0){
					// 	layer.msg('请输入经营食品名称关键字！')
					// }
					else{
						var flag1=true;
						$.each($("#comList tr"),function(i,item){
							var tname=$(this).find("td").eq(0).text();
							if(Trim(tname) == Trim($(".t-name").val())){
								flag1=false;
								return;
							}
						})
						if(flag1){
							var wxjson = new webjson("49"); //设置action值
							//新增param键值
							wxjson.AddParam("c_id", c_id);//类别id
							wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
							wxjson.AddParam("typename", Trim($(".t-name").val()));//:类别名称
							wxjson.AddParam("keywords", arrA.join(" "));//搜索关键字，以空格隔开
							wxjson.AddParam("zone_code", $.cookie('dep_code'));//:当前监管单位code编码

							var res=WebRequest(wxjson);
							var data = GetOjson(json_parse(res));
							if(data.status == "0"){
								layer.msg(data.info);
								companyList(pagenum,ecount);
								layer.close(index);
							}else if(data.status == "9"){
								window.location.href="index.html?loginOut=true";
								return;
							}else{
								layer.msg(data.info);
							}
						}else{
							layer.msg('企业分类名称不能重复！');
						}
					}
				return false;
				}

				,cancel: function(){
			    	//右上角关闭回调
			    	//return false 开启该代码可禁止点击该按钮关闭
				}
			});
			// $(".js-example-tokenizer").select2({
			// 	tags: true,
			// 	tokenSeparators: [' ']
			// });
			keywords1();
		}else{//编辑分类
			console.log(c_id);

			var wxjson = new webjson("50"); //设置action值
			//新增param键值
			wxjson.AddParam("c_id", c_id);//类别id
			var res=WebRequest(wxjson);
			var data = GetOjson(json_parse(res));
			console.log(data);
			if(data.status == "0"){
				var keywords=[];
				if(data.param[0].keywords.length > 0){
					keywords=data.param[0].keywords.split(" ");
				}
				var keyList="",typename=data.param[0].typename;
				for(var i=0;i<keywords.length;i++){
					keyList+='<a href="javascript:void(0);">'+
					'<span class="span-tname">'+keywords[i]+'</span>'+
					'<img src="../style/image/delete.png" class="delT">'+
					'</a>';
				}
				var html="";
				html='<div class="toast-warp">'+
				'<form>'+
				'<ul class="record-form">'+
				'<li>'+
				'<label for="">企业分类名称</label>'+
				'<input type="text" value="'+typename+'" maxlength="20" class="t-name input-init" />'+
				'</li>'+
				'<li><h3 class="h3-title mt10"><span>筛选方式</span>'+
				'<span class="downcon">'+
	            '<i class="circle"><img src="../style/image/cir.png" /></i>'+
	            '<p class="downtext"><span>根据关键字找出相关食品,并将这些食品的经营企业筛选出来;多个关键字用空格隔开</span></p>'+
	          	'</span>'+
				'</h3></li>'+
				'<li>'+
				'<label for="" class="w140">经营食品名称关键字'+
				'</label>'+
				//'<select class="t-list js-example-tokenizer clearfix" multiple="multiple"></select>'+
				// '<textarea name="" id="recordDetail" rows="3" style="margin-top:-1px;"></textarea>'+
				'<div class="t-list clearfix">'+
				'<div class="ty-content clearfix">'+

				'<div class="key-list">'+
				keyList+
				'<input type="text" value="" placeholder="多个关键字用空格隔开" class="input-write" />'+
				'</div>'+

				'</div>'+
				'</div>'+

				'</li>'+
				'</ul>'+
				'</form>'+
				'</div>';

				layer.open({
					type:1
					,title: ' '
					,content: html
					,area: ['518px', 'auto']
					,btn: ['取消', '确认']
					,yes: function(index, layero){
						layer.close(index);
				    	//按钮【按钮二】的回调
				    	//return false 开启该代码可禁止点击该按钮关闭
					}
					,btn2: function(index, layero){
						var arrA=[];
						$.each($(".key-list .span-tname"),function(i,item){
							console.log($(this).text());
							arrA.push($(this).text());
						})
						if(Trim($(".t-name").val()).length == 0){
							layer.msg('请输入企业分类名称！');

						//}else if(arrA.length == 0){
							//layer.msg('请输入经营食品名称关键字！')
						}else{
							var flag1=true;
							$.each($("#comList tr"),function(i,item){
								var tname=$(this).find("td").eq(0).text();
								if(Trim(tname) == Trim($(".t-name").val())){
									if(typename != Trim(tname)){
										flag1=false;
										return;
									}

								}
							})
							if(flag1){
								var wxjson = new webjson("49"); //设置action值
								//新增param键值
								wxjson.AddParam("c_id", c_id);//类别id
								wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
								wxjson.AddParam("typename", Trim($(".t-name").val()));//:类别名称
								wxjson.AddParam("keywords", arrA.join(" "));//搜索关键字，以空格隔开
								wxjson.AddParam("zone_code", $.cookie('dep_code'));//:当前监管单位code编码

								var res=WebRequest(wxjson);
								var data = GetOjson(json_parse(res));
								if(data.status == "0"){
									layer.msg(data.info);
									companyList(pagenum,ecount);
									layer.close(index);
								}else if(data.status == "9"){
									window.location.href="index.html?loginOut=true";
									return;
								}else{
									layer.msg(data.info);
								}
							}else{
								layer.msg('企业分类名称不能重复！');
							}
						}
						return false;
					}

					,cancel: function(){
				    	//右上角关闭回调
				    	//return false 开启该代码可禁止点击该按钮关闭
					}
				});
				keywords1();

			}else if(data.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else{
				layer.msg(data.info);
			}

			// var html='<a href="javascript:void(0);">'+
			// 	'<span class="span-tname">'+Trim($(this).val())+'</span>'+
			// 	'<img src="../style/image/delete.png" class="delT">'+
			// 	'</a>';


			// var _data=["1","2","3"]
			// $(".js-example-tokenizer").select2({
			// 	data:_data,
			// 	tags: true,
			// 	tokenSeparators: [' ']
			// }).val(["1","2"]).trigger("change");
		}
	}
	$("#addClass").on("click",function(){//创建新分类
		addNewType("0","");
	});
	$("#comList").on("click",".editType",function(){//编辑分类
		addNewType("1",$(this).parent("td").data("c_id"));
	})
	$("#comList").on("click",".removeType",function(){//删除分类
		var _this=$(this);
		layer.open({
			type:1
			,title: ' '
			,content: '<div class="delType"><p>点击确认将此分类删除。</p><p></p></div>'
			,area: ['390px', '150px']
			,btn: ['取消', '确认']
			,yes: function(index, layero){
				layer.close(index);
			    //按钮【按钮二】的回调
			    //return false 开启该代码可禁止点击该按钮关闭
			}
			,btn2: function(index, layero){
				var wxjson = new webjson("51"); //设置action值
				//新增param键值
				wxjson.AddParam("c_id", _this.parent("td").data("c_id"));//类别id
				var res=WebRequest(wxjson);
				var data = GetOjson(json_parse(res));
				if(data.status == "0"){
					layer.msg(data.info);
					companyList(pagenum,ecount);

				}else if(data.status == "9"){
					window.location.href="index.html?loginOut=true";
					return;
				}else{
					layer.msg(data.info);
				}
				layer.close(index);

			}
			,cancel: function(){
			    //右上角关闭回调
			    //return false 开启该代码可禁止点击该按钮关闭
			}
		});
	})

})



