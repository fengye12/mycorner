/*
* @Author: yangjy
* @Date:   2017-07-12 11:45:51
* @Last Modified time: 2017-08-19 16:42:58
*/
autoH();//左右高度自适应autoH();//左右高度自适应
var a1 = "a11",a2 = "a1100";//当前页代码
var c_id="",cname="",jyid="";//企业id,企业名称
var zjphoto=[];//资质证件信息

function getQueryString(name) {//获取url传递的参数：name为需要获取的参数名称
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var search = window.location.search.substr(1);
	var href = window.location.href;
	if(href.indexOf("?") >= 0) {
		search = href.substr(href.indexOf("?") + 1);
	}
	var r = search.match(reg);
	if(r != null) return unescape(r[2]);
	return null;
}

if(!GetAddNew(getQueryString("jyid"))){//判断url有参数(jycid)读取交易对象企业id
	jyid=getQueryString("jyid");
}

if(!GetAddNew(getQueryString("c_id"))){//台账报备页面点击交易对象会传递报备企业id和企业name
	c_id=getQueryString("c_id");
	$.cookie('THE_SET_COMPANYID', c_id, { path: '/' });
}

if(!GetAddNew(getQueryString("cname"))){//台账报备页面点击交易对象会传递报备企业id和企业name
	cname=getQueryString("cname");
	$.cookie('THE_SET_COMPANYNAME', cname, { path: '/' });
}
function companyInfoData(res){
	var data = GetOjson(json_parse(res));
	if(data.status == "0"){
		var photo="";
		$(".e-license").val(data.param[0].jylicense);
		$(".e-baddress").val(data.param[0].jyaddress);
		$(".e-cname").val(data.param[0].jycname);
		$(".e-legal").val(data.param[0].jylegal);
		$(".e-cnumber").val(data.param[0].jynumber);

		if(data.param[0].jyphotos.length > 0){
			photo=data.param[0].jyphotos.split(",");
			$(".base-info .li-img").html('<label for="">资质证件</label>');
			for(var m=0;m<photo.length;m++){
				var html="";
				html='<img src='+photo[m]+' alt="资质证件" />'
				$(".base-info .li-img").append(html);
			}
			autoH();
		}else{
			$(".base-info .li-img").html('<label for="">资质证件</label>暂无');
		}

	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else{
		layer.open({
			title: '提示'
			,content: data.info
			,btn: ['确定']
			,yes: function(index, layero){
				layer.close(index);
			}
			,cancel: function(){
					//右上角关闭回调
					//return false 开启该代码可禁止点击该按钮关闭
				}
			});
	}
}

function companyInfo(jyid){
	var wxjson = new webjson("20"); //设置action值
		//新增param键值
	wxjson.AddParam("jyid", jyid);
	WebRequestAsync(wxjson, companyInfoData);
}

$(function(){
	//从内存中获取企业名称
	if(!GetAddNew($.cookie('THE_SET_COMPANYNAME'))){
		$(".companyName").text($.cookie('THE_SET_COMPANYNAME'));
	}

	companyInfo(jyid);//获取企业信息,参数:企业id

	$(".li-img").on("click","img",function(){//资质证件图片查看
		var imgContent="",imgPhoto="";
		for(var i=0;i<$(".li-img img").length;i++){
			var src=$(".li-img img")[i].src;
			imgPhoto+='<li><img src='+src+' alt="Picture"></li>'
		}
		imgContent='<div class="img-warp">'+
		'<div class="imgDiv">'+
		'<ul class="images">'+
		imgPhoto+
		'</ul>'+
		'</div>'+
		'</div>'
		layer.open({
			title: '资质证件查看'
			,content: imgContent
			,area: ['550px', '420px']
			,btn: []
			,cancel: function(){
				//右上角关闭回调
				//return false 开启该代码可禁止点击该按钮关闭
			}
		});
		$('.images').viewer({
			inline:true
		});
	});

	// getActiveN("a11", "a1100");//当前页标志
})