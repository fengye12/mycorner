autoH();
var a1 = "a11",
	a2 = "a1100";
var sskey="",cid="",cname="",zttype="",yjtime="",pindex = "1",psize = "20",yjid="";
/**分页设置**/
var pcent = new CentPage();
var pcount = ""; //总条数
var jsonParam="";//导出时需要传的参数
var ps = pcent.GetCentPage(pindex, pcount, psize);
$("#page").html(ps);
function CentPageOper(spindex) {
	search(sskey,cid,yjtime,zttype,spindex, psize);
}

/**页面加载时**/
$(function() {
	cid=$.cookie('THE_SET_COMPANYID');
	cname=$.cookie('THE_SET_COMPANYNAME');
	console.log(cname);
	console.log(cid);
	$(".companyName").html(cname);
 	if(sskey=="请输入关键字进行查询"){
 		sskey="";
 	}else{
 		$(".foodname").val(sskey);
 	}
 	console.log(sskey);
	search(sskey,cid,yjtime,zttype, pindex, psize);
 	getActiveN("a11", "a1100");//当前页标志
 	autoH();
});

/**搜索**/
function search(sskey,cid,time,zttype,spindex, psize) {
	pindex = spindex;
	$("table tbody").children().remove();
	$("table tbody").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;'><img src='../style/image/load.gif' alt='' /></td></tr>");
	$("#daochu").css("display","none");
	$("#mySelectS").css("display","none");
	var wxjson = new webjson("47"); //设置action值
	//新增param键值
	wxjson.AddParam("sskey", sskey);
	wxjson.AddParam("c_id", cid);
	wxjson.AddParam("time", yjtime);
	wxjson.AddParam("zttype", zttype);
	wxjson.AddParam("page_index", pindex);
	wxjson.AddParam("page_size", psize);
	WebRequestAsync(wxjson, searchInfo);
	jsonParam=wxjson.GetJsons();
}
function searchInfo(res){
	var html = "";
	$(".content-title .concern").text($.cookie('THE_SET_CONCERN'));//是否关注
	var data = GetOjson(json_parse(res));
	console.log(data);
	pcount = data.paramcentcount;
	$(".totalNum1").html("共"+pcount+"条");
	var ps = pcent.GetCentPage(pindex, pcount, psize);
	$("#page").html(ps);
	if(data.status == 0) {
		if(pcount!="0"){
			$("#daochu").css("display","");
			$("#mySelectS").css("display","");
			}else{
			 $("#daochu").css("display","none");
			 $("#mySelectS").css("display","none");
			}
		for(var i = 0; i < data.param.length; i++){
			yjid=data.param[i].yjid;
			//pname=escape(data.param[i].pname);
			html +='<tr>';
			if(data.param[i].type=="8"){
			  html +='<td class="hs">'+data.param[i].yc+'</td>';
			}else{
			  html +='<td class="rs">'+data.param[i].yc+'</td>';	
			}
			html +='<td class="hs">'+data.param[i].time+'</td>';
			if(data.param[i].status=="0"){
			html +='<td class="hs" style="color:#EF2121;font-size:12px;">未处置</td>';
			}else{
				html +='<td class="hs">已处置</td>';
			}if(data.param[i].type=="0"||data.param[i].type=="1"){
			    html +='<td class="ls lookdetail" onclick="lookdetail(this)"><i style="display:none;">'+yjid+'</i><s style="display:none;">'+data.param[i].status+'</s><span style="display:none;" class="s1">'+data.param[i].type+'</span><span style="display:none;" class="s2">'+data.param[i].warnType+","+data.param[i].enterName+","+data.param[i].enterType+","+data.param[i].contact+","+data.param[i].address+","+data.param[i].result+","+data.param[i].enterlink+","+data.param[i].yjid+","+data.param[i].enterid+","+data.param[i].yc+'</span>查看</td>'+
				'</tr>';
			}else if(data.param[i].type=="4"){
				html +='<td class="ls lookdetail" onclick="lookdetail(this)"><i style="display:none;">'+yjid+'</i><s style="display:none;">'+data.param[i].status+'</s><span style="display:none;" class="s1">'+data.param[i].type+'</span><span style="display:none;" class="s2">'+data.param[i].enterid+","+data.param[i].enterName+","+data.param[i].ledgerid+","+data.param[i].djnum+","+data.param[i].result+","+data.param[i].yjid+'</span>查看</td>'+
				'</tr>';
			}else if(data.param[i].type=="5"){
				html +='<td class="ls lookdetail" onclick="lookdetail(this)"><i style="display:none;">'+yjid+'</i><s style="display:none;">'+data.param[i].status+'</s><span style="display:none;" class="s1">'+data.param[i].type+'</span><span style="display:none;" class="s2">'+data.param[i].enterid+","+data.param[i].enterName+","+data.param[i].yc+","+data.param[i].cname+","+data.param[i].barcode+","+data.param[i].foodname+","+data.param[i].result+","+data.param[i].yjid+","+data.param[i].foodId+'</span>查看</td>'+
				'</tr>';
			}else{
			  html +='<td class="ls lookdetail" onclick="lookdetail(this)"><i style="display:none;">'+yjid+'</i><s style="display:none;">'+data.param[i].status+'</s><span style="display:none;" class="s1">'+data.param[i].type+'</span>查看</td>'+
			  '</tr>';
			}
	}	
	$("table tbody").html(html);
	autoH();
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else {
		$("table tbody").html("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;font-size:14px;'>没有相关数据</td></tr>");
		$("#daochu").css("display","none");
		$("#mySelectS").css("display","none");
	}
}

/**点击查看**/
function lookdetail(t){
	var type=$(t).children(".s1").text();
	console.log(type);
	var status=$(t).children("s").text();
	console.log(status);
	var yjid1=$(t).children("i").text();
	console.log("yjid1:"+yjid1);
	var content1="",content2="";
	var warnType="",enterName="",enterType="",contact="",address="",result="",enterlink="",pid="",enterid="",ledgerid="",djnum="",barcode="",foodname="",foodtype="",scope="",result="",dealid="",dealname="",reportdate="",context="",billdate="",foodId="",yc="";
    if(type=="0"){
	  /**疑似无证经营预警**/
    /**	var wxjson = new webjson("41"); //设置action值
		wxjson.AddParam("pid", yjid1);
		wxjson.AddParam("type", "0");
		var res=WebRequest(wxjson);
		var data = GetOjson(json_parse(res));
		if(data.status == "0"){
		 for(var i=0;i<data.param.length;i++){
			if(cid==data.param[i].enterid){
				warnType=data.param[i].warnType;
				enterName=data.param[i].enterName;
				enterType=data.param[i].enterType;
				contact=data.param[i].contact;
				address=data.param[i].address;
				result=data.param[i].result;
				pid=data.param[i].pid;
				enterlink="Enterprise_archivesInfo.html?c_id="+data.param[i].enterid;
			}else{
				warnType="";
				enterName="";
				enterType="";
				contact="";
				address="";
				result="";
				enterlink="";
				pid="";
			}
		 }**/
    	  var Arr=$(t).children(".s2").text();
    	  var paramArr=Arr.split(",");
    	    warnType=paramArr[0];
			enterName=paramArr[1];
			enterType=paramArr[2];
			if(enterType=="0"){
				enterType="生产企业";
			}else if(enterType=="1"){
				enterType="销售经营者";
			}else if(enterType=="2"){
				enterType="餐饮服务";
			}else if(enterType=="3"){
				enterType="单位食堂";
			}
			contact=paramArr[3];
			address=paramArr[4];
			result=paramArr[5];
			enterlink=paramArr[6];
			pid=paramArr[7];
			enterid=paramArr[8];
			yc=paramArr[9];
			enterlink="Enterprise_archivesInfo.html?c_id="+cid;
		  content1='<div class="warnToast">'
	          +'<div class="tablew">'
	            +'<table class="layertable">'
	            +'<thead></thead>'
	            +'<tbody>'
	              +'<tr class="headerTip">'
	              +'<td>异常情况</td>'
	              +'<td><a class="" href="'+enterlink+'" target="_blank">'+yc+'</a></td>'
	              +'</tr>'
	              +'<tr>'
	              +'<td>违规企业</td>'
	              +'<td><a class="linkA" href="'+enterlink+'" target="_blank">'+enterName+'</a></td>'
	              +'</tr>'
	              +'<tr>'
	              +'<td>企业类型</td>'
	              +'<td>'+enterType+'</td>'
	              +'</tr>'
	              +'<tr>'
	              +'<td>联系方式</td>'
	              +'<td>'+contact+'</td>'
	              +'</tr>'
	              +'<tr>'
	              +'<td>经营地址</td>'
	              +'<td>'+address+'</td>'
	              +'</tr>'
	            +'</tbody>'
	            +'</table>'
	            +'<div class="handle">'
	              +'<p><span >处置结果</span></p>'
	              +'<textarea class="textarea" placeholder="处置结果描述">'+result+'</textarea>'
	            +'</div>'
	          +'</div>'
	          +'</div>';
	        if(status == "0"){
	        	layer.open({
				title: ' '
				,content: content1
				,area: ['auto', 'auto']
				,btn: ['取消','保存处置结果']
				,yes: function(index, layero){
	                layer.closeAll();
				}
	            ,btn2:function(){
	                var wxjson = new webjson("42"); //设置action值
	                //新增param键值
	                wxjson.AddParam("pid", pid);
	                wxjson.AddParam("type", "0");
	                wxjson.AddParam("jb_descption", "");
	                wxjson.AddParam("cz_result", $(".textarea").val());
	                var res=WebRequest(wxjson);
	                var obj=GetOjson(json_parse(res));
	                if(obj.status == "0"){
	                    layer.closeAll();
	                    window.location.reload();
	                }else if(obj.status == "9"){
	                    window.location.href="index.html?loginOut=true";
	                    return;
	                }else{
	                    layer.msg(obj.info);
	                }
	                  return false;
	            }
				,cancel: function(){
					//右上角关闭回调
					//return false 开启该代码可禁止点击该按钮关闭
				}
			});
	        }else{
	        	layer.open({
                    title: ' '
                    ,content: content1
                    ,area: ['auto', 'auto']
                    ,btn:false

                });
	        }
		/**}else if(data.status=="9"){
	   		window.location.href="index.html?loginOut=true";
			return;
		}else{
			console.log(data.info);
		}**/
   }else if(type=="1"){
	   /**许可证过期预警**/
	 /**  var wxjson = new webjson("41"); //设置action值
		wxjson.AddParam("pid", yjid1);
		wxjson.AddParam("type", "1");
		var res=WebRequest(wxjson);
		var data = GetOjson(json_parse(res));
		if(data.status == "0"){
		 for(var i=0;i<data.param.length;i++){
			if(cid==data.param[i].enterid){
				warnType=data.param[i].warnType;
				enterName=data.param[i].enterName;
				enterType=data.param[i].enterType;
				contact=data.param[i].contact;
				address=data.param[i].address;
				result=data.param[i].result;
				pid=data.param[i].pid;
				enterlink="Enterprise_archivesInfo.html?c_id="+data.param[i].enterid;
			}else{
				warnType="";
				enterName="";
				enterType="";
				contact="";
				address="";
				result="";
				enterlink="";
				pid="";
			}
		 }**/
	   var Arr=$(t).children(".s2").text();
 	   var paramArr=Arr.split(",");
 	        warnType=paramArr[0];
			enterName=paramArr[1];
			enterType=paramArr[2];
			if(enterType=="0"){
				enterType="生产企业";
			}else if(enterType=="1"){
				enterType="销售经营者";
			}else if(enterType=="2"){
				enterType="餐饮服务";
			}else if(enterType=="3"){
				enterType="单位食堂";
			}
			contact=paramArr[3];
			address=paramArr[4];
			result=paramArr[5];
			enterlink=paramArr[6];
			pid=paramArr[7];
			enterid=paramArr[8];
			yc=paramArr[9];
			enterlink="Enterprise_archivesInfo.html?c_id="+cid;
	   content1='<div class="warnToast">'
	          +'<div class="tablew">'
	            +'<table class="layertable">'
	            +'<thead></thead>'
	            +'<tbody>'
	              +'<tr class="headerTip">'
	              +'<td>异常情况</td>'
	              +'<td><a class="" href="'+enterlink+'" target="_blank">'+yc+'</a></td>'
	              +'</tr>'
	              +'<tr>'
	              +'<td>违规企业</td>'
	              +'<td><a class="linkA" href="'+enterlink+'" target="_blank">'+enterName+'</a></td>'
	              +'</tr>'
	              +'<tr>'
	              +'<td>企业类型</td>'
	              +'<td>'+enterType+'</td>'
	              +'</tr>'
	              +'<tr>'
	              +'<td>联系方式</td>'
	              +'<td>'+contact+'</td>'
	              +'</tr>'
	              +'<tr>'
	              +'<td>经营地址</td>'
	              +'<td>'+address+'</td>'
	              +'</tr>'
	            +'</tbody>'
	            +'</table>'
	            +'<div class="handle">'
	              +'<p><span >处置结果</span></p>'
	              +'<textarea class="textarea" placeholder="处置结果描述">'+result+'</textarea>'
	            +'</div>'
	          +'</div>'
	          +'</div>';
	                if(status=="0"){
	                	layer.open({
	        			title: ' '
	        			,content: content1
	        			,area: ['auto', 'auto']
	        			,btn: ['取消','保存处置结果']
	        			,yes: function(index, layero){
	                        layer.closeAll();

	        			}
	                    ,btn2:function(){

	                        var wxjson = new webjson("42"); //设置action值
	                        //新增param键值
	                        wxjson.AddParam("pid", pid);
	                        wxjson.AddParam("type", "1");
	                        wxjson.AddParam("jb_descption", "");
	                        wxjson.AddParam("cz_result", $(".textarea").val());

	                        var res=WebRequest(wxjson);
	                        var obj=GetOjson(json_parse(res));
	                        if(obj.status == "0"){
	                            layer.closeAll();
	                            window.location.reload();
	                        }else if(obj.status == "9"){
	                            window.location.href="index.html?loginOut=true";
	                            return;
	                        }else{
	                            layer.msg(obj.info);
	                        }
	                          return false;
	                    }
	        			,cancel: function(){
	        				//右上角关闭回调
	        				//return false 开启该代码可禁止点击该按钮关闭
	        			}
	        		});
	                }else{
	                            layer.open({
	                            title: ' '
	                            ,content: content1
	                            ,area: ['auto', 'auto']
	                            ,btn:false
	                          });
	                }
	              /**  }else if(data.status=="9"){
	        	   		window.location.href="index.html?loginOut=true";
	        			return;
	        		}else{
	        			console.log(data.info);
	        		}**/
   }else if(type=="2"){
	   /**疑似超范围经营预警**/
	   var wxjson = new webjson("43"); //设置action值
		//新增param键值
	    wxjson.AddParam("pid", yjid1);
		wxjson.AddParam("type", "2");
		var res=WebRequest(wxjson);
		var data = GetOjson(json_parse(res));
		if(data.status == "0"){
				warnType=data.param[0].warnType;
				enterName=data.param[0].entername;
				enterType=data.param[0].entertype;
				if(enterType=="0"){
					enterType="生产企业";
				}else if(enterType=="1"){
					enterType="销售经营者";
				}else if(enterType=="2"){
					enterType="餐饮服务";
				}else if(enterType=="3"){
					enterType="单位食堂";
				}
				contact=data.param[0].contact;
				address=data.param[0].address;
				result=data.param[0].result;
				pid=data.param[0].yjid;
				enterid=data.param[0].enterid;
				ledgerid=data.param[0].ledgerid;
				djnum=data.param[0].djnum;
				barcode=data.param[0].barcode;
				foodname=data.param[0].foodname;
				foodtype=data.param[0].foodtype;
				scope=data.param[0].scope;
				result=data.param[0].result;
				console.log("type=2:"+pid);
	     content1='<div class="warnToast">'
	          +'<div class="tablew">'
	            +'<table class="layertable">'
	            +'<thead></thead>'
	            +'<tbody>'
	              +'<tr>'
	              +'<td>违规企业</td>'
	              +'<td><a class="linkA" href="Enterprise_archivesInfo.html?c_id='+enterid+'" target="_blank">'+enterName+'</a></td>'
	              +'</tr>'
	              +'<tr>'
	              +'<td>企业类型</td>'
	              +'<td>'+enterType+'</td>'
	              +'</tr>'
	              +'<tr>'
	              +'<td>相关台账</td>'
	              +'<td><a class="linkA" href="StandingBook_check.html?bbid='+ledgerid+'" target="_blank">'+djnum+'</a></td>'
	              +'</tr>'
	              +'<tr>'
	              +'<td>超范围食品</td>'
	             // +'<td><a class="linkA" href="Food_info.html?pid='+foodId+'&pname='+escape(foodname)+'&barcode='+barcode+'" target="_blank">'+foodname+'</a></td>'
	              +'<td>'+foodname+'</td>'
	              +'</tr>'
	              +'<tr style="height:80px;">'
	              +'<td>经营食品标签</td>'
	              +'<td>'+foodtype+'</td>'
	              +'</tr>'
	              +'<tr style="height:80px;">'
	              +'<td>许可证经营范围</td>'
	              +'<td>'+scope+'</td>'
	              +'</tr>'
	            +'</tbody>'
	            +'</table>'
	            +'<div class="handle">'
	              +'<p><span >处置结果</span></p>'
	              +'<textarea class="textarea" placeholder="处置结果描述">'+result+'</textarea>'
	            +'</div>'
	          +'</div>'
	          +'</div>';
	                if(status== "0"){
	                	layer.open({
	        			title: ' '
	        			,content: content1
	        			,area: ['auto', 'auto']
	        			,btn: ['取消','保存处置结果']
	        			,yes: function(index, layero){
	                        layer.closeAll();
	        			}
	                    ,btn2:function(){
	                        var wxjson = new webjson("42"); //设置action值
	                        //新增param键值	                       
	                        wxjson.AddParam("pid", pid);
	                        wxjson.AddParam("type", "2");
	                        wxjson.AddParam("jb_descption", "");
	                        wxjson.AddParam("cz_result", $(".textarea").val());
	                        var res=WebRequest(wxjson);
	                        var obj=GetOjson(json_parse(res));
	                        if(obj.status == "0"){
	                            layer.closeAll();
	                            window.location.reload();
	                        }else if(obj.status == "9"){
	                            window.location.href="index.html?loginOut=true";
	                            return;
	                        }else{
	                            layer.msg(obj.info);
	                        }
	                          return false;
	                    }
	        			,cancel: function(){
	        				//右上角关闭回调
	        				//return false 开启该代码可禁止点击该按钮关闭
	        			}
	        		});
	                }else{
	                            layer.open({
	                            title: ' '
	                            ,content: content1
	                            ,area: ['auto', 'auto']
	                            ,btn:false
	                          });
	                }
		}else if(data.status=="9"){
	   		window.location.href="index.html?loginOut=true";
			return;
		}else{
			console.log(data.info);
		}
   }else if(type=="3"){
	  /**异常备案预警**/
	   var wxjson = new webjson("44"); //设置action值
		//新增param键值
		wxjson.AddParam("pid", yjid1);
		wxjson.AddParam("type", "3");
		var res=WebRequest(wxjson);
		var data = GetOjson(json_parse(res));
		if(data.status == "0"){
				enterid=data.param[0].enterid;
				ledgerid=data.param[0].ledgerid;
				enterName=data.param[0].entername;
				djnum=data.param[0].djnum;
				dealid=data.param[0].dealid;
				contact=data.param[0].contact;
				address=data.param[0].address;
				result=data.param[0].result;
				dealname=data.param[0].dealname;
				reportdate=data.param[0].reportdate;
				context=data.param[0].context;
				pid=data.param[0].yjid;
		content1='<div class="warnToast">'
         +'<div class="tablew">'
           +'<table class="layertable">'
           +'<thead></thead>'
           +'<tbody>'
             +'<tr>'
             +'<td>单据号</td>'
             +'<td><a class="linkA" href="Enterprise_accountInfo.html?c_id='+enterid+'&bbid='+ledgerid+'&cname='+escape(enterName)+'" target="_blank">'+djnum+'</a></td>'
             +'</tr>'
             +'<tr>'
             +'<td>被举报企业</td>'
             +'<td><a class="linkA" href="Enterprise_archivesInfo.html?c_id='+enterid+'" target="_blank">'+enterName+'</a></td>'
             +'</tr>'
             +'<tr>'
             +'<td>联系方式</td>'
             +'<td>'+contact+'</td>'
             +'</tr>'
             +'<tr>'
             +'<td>经营地址</td>'
             +'<td>'+address+'</td>'
             +'</tr>'
             +'<tr>'
             +'<td>举报企业</td>'
             +'<td><a class="linkA" href="Enterprise_archivesInfo.html?c_id='+dealid+'" target="_blank">'+dealname+'</a></td>'
             +'</tr>'
             +'<tr>'
             +'<td>举报日期</td>'
             +'<td>'+reportdate+'</td>'
             +'</tr>'
             +'<tr style="height:80px;">'
             +'<td>举报描述</td>'
             +'<td>'+context+'</td>'
             +'</tr>'
           +'</tbody>'
           +'</table>'
           +'<div class="handle">'
             +'<p><span >处置结果</span></p>'
             +'<textarea class="textarea" placeholder="处置结果描述">'+result+'</textarea>'
           +'</div>'
         +'</div>'
         +'</div>';
        if(status == "0"){
	        	layer.open({
					title: '异常情况'
					,content: content1
					,area: ['500px', 'auto']
					,btn: ['处理']
					,yes: function(index, layero){
						var wxjson = new webjson("42"); //设置action值
						//新增param键值
						wxjson.AddParam("pid", pid);
						wxjson.AddParam("type", "3");
						wxjson.AddParam("jb_descption", $(".jbms").val());
						wxjson.AddParam("cz_result", $(".czjg").val());

						var res=WebRequest(wxjson);
						var obj=GetOjson(json_parse(res));
						if(obj.status == "0"){
							layer.close(index);
							window.location.reload();
						}else if(obj.status == "9"){
							window.location.href="index.html?loginOut=true";
							return;
						}else{
							console.log(obj.info);
						}
					}
					,cancel: function(){ 
						//右上角关闭回调
						//return false 开启该代码可禁止点击该按钮关闭
					}
				});	    	
	        }else{
	        	layer.open({
					title: '异常情况'
					,content: content1
					,area: ['500px', 'auto']
					,btn: []
					,cancel: function(){ 
						//右上角关闭回调
						//return false 开启该代码可禁止点击该按钮关闭
					}
				});
	        }
		}else if(data.status=="9"){
	   		window.location.href="index.html?loginOut=true";
			return;
		}else{
			console.log(data.info);
		}
		/**}else if(type=="4"){
	   /**索证索票监控**/
		/**var wxjson = new webjson("41"); //设置action值
		wxjson.AddParam("pid", yjid1);
		wxjson.AddParam("type", "4");
		var res=WebRequest(wxjson);
		var data = GetOjson(json_parse(res));
		if(data.status == "0"){
		 for(var i=0;i<data.param.length;i++){
			if(cid==data.param[i].enterid){
				enterid=data.param[i].enterid;
				enterName=data.param[i].enterName;
				ledgerid=data.param[i].ledgerid;
				djnum=data.param[i].djnum;
				result=data.param[i].result;
				pid=data.param[i].pid;
			}else{
				enterid="";
				enterName="";
				ledgerid="";
				djnum="";
				result="";
				pid="";		
			}
		 }
		var Arr=$(t).children(".s2").text();
  	    var paramArr=Arr.split(",");
  	        enterid=paramArr[0];
			enterName=paramArr[1];
			ledgerid=paramArr[2];
			djnum=paramArr[3];
			result=paramArr[4];
			pid=paramArr[5];
		 content1='<div class="warnToast">'
		        +'<div class="tablew">'
		          +'<table class="layertable">'
		          +'<thead></thead>'
		          +'<tbody>'
		            +'<tr class="headerTip">'
		            +'<td>异常情况</td>'
		            +'<td>未索证索票</td>'
		            +'</tr>'
		            +'<tr>'
		            +'<td>单据号</td>'
		            +'<td><a class="linkA" href="Enterprise_accountInfo.html?c_id='+enterid+'&bbid='+ledgerid+'&cname='+escape(enterName)+'">'+djnum+'</a></td>'
		            +'</tr>'
		            +'<tr>'
		            +'<td>报备企业</td>'
		            +'<td><a class="linkA" href="Enterprise_archivesInfo.html?c_id='+enterid+'">'+enterName+'</a></td>'
		            +'</tr>'
		          +'</tbody>'
		          +'</table>'
		          +'<div class="handle">'
		            +'<p><span >处置结果</span></p>'
		            +'<textarea class="textarea" placeholder="处置结果描述">'+result+'</textarea>'
		          +'</div>'
		        +'</div>'
		        +'</div>';
        if(status == "0"){
	        	layer.open({
					title: '异常情况'
					,content: content1
					,area: ['500px', 'auto']
					,btn: ['处理']
					,yes: function(index, layero){
						var wxjson = new webjson("42"); //设置action值
						//新增param键值
						wxjson.AddParam("pid", pid);
						wxjson.AddParam("type", "4");
						wxjson.AddParam("jb_descption", "");
	                    wxjson.AddParam("cz_result", $(".textarea").val());
						var res=WebRequest(wxjson);
						var obj=GetOjson(json_parse(res));
						if(obj.status == "0"){
							layer.close(index);
							window.location.reload();
						}else if(obj.status == "9"){
							window.location.href="index.html?loginOut=true";
							return;
						}else{
							console.log(obj.info);
						}
					}
					,cancel: function(){ 
						//右上角关闭回调
						//return false 开启该代码可禁止点击该按钮关闭
					}
				});	    	
	        }else{
	        	layer.open({
					title: '异常情况'
					,content: content1
					,area: ['500px', 'auto']
					,btn: []
					,cancel: function(){ 
						//右上角关闭回调
						//return false 开启该代码可禁止点击该按钮关闭
					}
				});
	        }	
		/**}else if(data.status=="9"){
	   		window.location.href="index.html?loginOut=true";
			return;
		}else{
			console.log(data.info);
		}**/
   }else if(type=="5"){
	   /**生产企业监控**/
	/**   var wxjson = new webjson("41"); //设置action值
	   wxjson.AddParam("pid", yjid1);
	   wxjson.AddParam("type", "5");
		var res=WebRequest(wxjson);
		var data = GetOjson(json_parse(res));
		if(data.status == "0"){
		 for(var i=0;i<data.param.length;i++){
			if(cid==data.param[i].enterid){
				enterid=data.param[i].enterid;
				enterName=data.param[i].enterName;
				yc=data.param[i].yc;
				cname=data.param[i].cname;
				barcode=data.param[i].barcode;
				foodname=data.param[i].foodname;
				result=data.param[i].result;
				pid=data.param[i].pid;
			}else{
				enterid="";
				enterName="";
				yc="";
				cname="";
				barcode="";
				foodname="";
				result="";
				pid="";
			}
		 }**/
	   var Arr=$(t).children(".s2").text();
 	    var paramArr=Arr.split(",");
 	        enterid=paramArr[0];
			enterName=paramArr[1];
			yc=paramArr[2];
			cname=paramArr[3];
			barcode=paramArr[4];
			foodname=paramArr[5];
			result=paramArr[6];
			pid=paramArr[7];
			foodId=paramArr[8];
	   content1='<div class="warnToast">'
         +'<div class="tablew">'
           +'<table class="layertable">'
           +'<thead></thead>'
           +'<tbody>'
             +'<tr class="headerTip">'
             +'<td>异常情况</td>'
             +'<td><a class="" href="Enterprise_archivesInfo.html?c_id='+cid+'" target="_blank">'+yc+'</a></td>'
             +'</tr>'
             +'<tr>'
             +'<td>违规生产企业</td>'
             +'<td><a class="linkA" href="Enterprise_archivesInfo.html?c_id='+cid+'" target="_blank">'+enterName+'</a></td>'
             +'</tr>'
             +'<tr>'
             +'<td>食品名称</td>'
            // +'<td><a class="linkA" href="Food_info.html?cpid='+foodId+'&pname='+escape(foodname)+'&barcode='+barcode+'" target="_blank">'+foodname+'</a></td>'
             +'<td>'+foodname+'</td>'
             +'</tr>'
           +'</tbody>'
           +'</table>'
           +'<div class="handle">'
             +'<p><span >处置结果</span></p>'
             +'<textarea class="textarea" placeholder="处置结果描述">'+result+'</textarea>'
           +'</div>'
         +'</div>'
         +'</div>';
	   if(status == "0"){
	        	layer.open({
					title: '异常情况'
					,content: content1
					,area: ['500px', 'auto']
					,btn: ['处理']
					,yes: function(index, layero){
						var wxjson = new webjson("42"); //设置action值
						//新增param键值
						wxjson.AddParam("pid", pid);
		                wxjson.AddParam("type", "5");
		                wxjson.AddParam("jb_descption", "");
		                wxjson.AddParam("cz_result", $(".textarea").val());
						var res=WebRequest(wxjson);
						var obj=GetOjson(json_parse(res));
						if(obj.status == "0"){
							layer.close(index);
							window.location.reload();
						}else if(obj.status == "9"){
							window.location.href="index.html?loginOut=true";
							return;
						}else{
							console.log(obj.info);
						}
					}
					,cancel: function(){ 
						//右上角关闭回调
						//return false 开启该代码可禁止点击该按钮关闭
					}
				});	    	
	        }else{
	        	layer.open({
					title: '异常情况'
					,content: content1
					,area: ['500px', 'auto']
					,btn: []
					,cancel: function(){ 
						//右上角关闭回调
						//return false 开启该代码可禁止点击该按钮关闭
					}
				});
	        }
		/**}else if(data.status=="9"){
	   		window.location.href="index.html?loginOut=true";
			return;
		}else{
			console.log(data.info);
		}**/
	  }else if(type=="7"){
		  /**疑似转让**/
		  var wxjson = new webjson("45"); //设置action值
			//新增param键值
				wxjson.AddParam("pid", yjid1);
				wxjson.AddParam("type", "7");
				var res=WebRequest(wxjson);
				var data = GetOjson(json_parse(res));
				if(data.status == "0"){							
								// enterid=data.param[0].enterid;
								 address=data.param[0].address;
								 transname=data.param[0].transname;
								 legel=data.param[0].legel;
								 mobile=data.param[0].mobile;
								 beforeid=data.param[0].beforeid;
								 beforename=data.param[0].beforename;
								 beforelegel=data.param[0].beforelegel;
								 beforemobile=data.param[0].beforemobile;
								 result=data.param[0].result;
								 pid=data.param[0].pid;						
					content1='<div class="warnToast">'
						+'<div class="tablew">'
						  +'<table class="layertable">'
						  +'<thead></thead>'
						  +'<tbody>'
						    +'<tr class="">'
						    +'<td>异常经营地址</td>'
						    +'<td><span style="background:#f45858;color:#fff;padding:0 4px">'+address+'</td>'
						    +'</tr>'
						    +'<tr>'
						    +'<td>疑似转让企业</td>'
						    +'<td><a class="linkA" href="Enterprise_archivesInfo.html?c_id='+cid+'" target="_blank">'+transname+'</a></td>'
						    +'</tr>'
						    +'<tr>'
						    +'<td>法人</td>'
						    +'<td>'+legel+'</td>'
						    +'</tr>'
						    +'<tr>'
						    +'<td style="border-bottom:1px solid #56b4f8;position:relative;">联系方式<span style="position:absolute;width:4px;height:4px;background:#56b4f8;border-radius:50%;left:-2px;bottom:-2px;"></span></td>'
						    +'<td style="border-bottom:1px solid #56b4f8;position:relative;">'+mobile+'<span style="position:absolute;width:4px;height:4px;background:#56b4f8;border-radius:50%;right:-2px;bottom:-2px;"></span></td>'
						    +'</tr>'
						    +'<tr>'
						    +'<td>疑似受让企业</td>'
						    +'<td><a class="linkA" href="Enterprise_archivesInfo.html?c_id='+beforeid+'" target="_blank">'+beforename+'</a></td>'
						    +'</tr>'
						    +'<tr>'
						    +'<td>法人</td>'
						    +'<td>'+beforelegel+'</td>'
						    +'</tr>'
						    +'<tr>'
						    +'<td>联系方式</td>'
						    +'<td>'+beforemobile+'</td>'
						    +'</tr>'
						  +'</tbody>'
						  +'</table>'
						  +'<div class="handle">'
						    +'<p><span >处置结果</span></p>'
						    +'<textarea class="textarea" placeholder="处置结果描述">'+result+'</textarea>'
						  +'</div>'
						+'</div>'
						+'</div>';	
					if(status == "0"){
			        	layer.open({
							title: '异常情况'
							,content: content1
							,area: ['500px', 'auto']
							,btn: ['处理']
							,yes: function(index, layero){
								var wxjson = new webjson("42"); //设置action值
								//新增param键值
								wxjson.AddParam("pid", yjid1);
				                wxjson.AddParam("type", "7");
				                wxjson.AddParam("jb_descption", "");
				                wxjson.AddParam("cz_result", $(".textarea").val());
								var res=WebRequest(wxjson);
								var obj=GetOjson(json_parse(res));
								if(obj.status == "0"){
									layer.close(index);
									window.location.reload();
								}else if(obj.status == "9"){
									window.location.href="index.html?loginOut=true";
									return;
								}else{
									console.log(obj.info);
								}
							}
							,cancel: function(){ 
								//右上角关闭回调
								//return false 开启该代码可禁止点击该按钮关闭
							}
						});	    	
			        }else{
			        	layer.open({
							title: '异常情况'
							,content: content1
							,area: ['500px', 'auto']
							,btn: []
							,cancel: function(){ 
								//右上角关闭回调
								//return false 开启该代码可禁止点击该按钮关闭
							}
						});
			        }
	  }else if(data.status == "9"){
			window.location.href="index.html?loginOut=true";
			return;
		}else{
			console.log(data.info);
		}
	  }else if(type=="8"){
		  /**企业转让**/
		  var wxjson = new webjson("45"); //设置action值
			//新增param键值
				wxjson.AddParam("pid", yjid1);
				wxjson.AddParam("type", "8");
				var res=WebRequest(wxjson);
				var data = GetOjson(json_parse(res));
				if(data.status == "0"){
								//enterid=data.param[0].enterid;
								billtype=data.param[0].billtype;
								transname=data.param[0].transname;
								entername=data.param[0].entername;
								djnum=data.param[0].djnum;
								billdate=data.param[0].billdate;								
								result=data.param[0].result;
								pid=data.param[0].pid;
					 content1='<div class="warnToast">'
							+'<div class="tablew">'
							  +'<table class="layertable">'
							  +'<thead></thead>'
							  +'<tbody>'
							    +'<tr>'
							    +'<td>备案企业</td>'
							    +'<td><a class="linkA" href="Enterprise_archivesInfo.html?c_id='+cid+'" target="_blank">'+cname+'</a></td>'
							    +'</tr>'
							    +'<tr>'
							    +'<td>转让日期</td>'
							    +'<td>'+billtype+'</td>'
							    +'</tr>'

							    +'<tr>'
							    +'<td>受让人</td>'
							    +'<td>'+entername+'</td>'
							    +'</tr>'
							      +'<tr>'
							    +'<td>身份证号</td>'
							    +'<td>'+djnum+'</td>'
							    +'</tr>'
							      +'<tr>'
							    +'<td>手机号</td>'
							    +'<td>'+billdate+'</td>'
							    +'</tr>'
							  +'</tbody>'
							  +'</table>'
							  +'<div class="handle">'
							    +'<p><span >处置结果</span></p>'
							    +'<textarea class="textarea" placeholder="处置结果描述">'+result+'</textarea>'
							  +'</div>'
							+'</div>'
							+'</div>';
					if(status == "0"){
			        	layer.open({
							title: '异常情况'
							,content: content1
							,area: ['500px', 'auto']
							,btn: ['处理']
							,yes: function(index, layero){
								var wxjson = new webjson("42"); //设置action值
								//新增param键值
								wxjson.AddParam("pid", yjid1);
				                wxjson.AddParam("type", "8");
				                wxjson.AddParam("jb_descption", "");
				                wxjson.AddParam("cz_result", $(".textarea").val());
								var res=WebRequest(wxjson);
								var obj=GetOjson(json_parse(res));
								if(obj.status == "0"){
									layer.close(index);
									window.location.reload();
								}else if(obj.status == "9"){
									window.location.href="index.html?loginOut=true";
									return;
								}else{
									console.log(obj.info);
								}
							}
							,cancel: function(){ 
								//右上角关闭回调
								//return false 开启该代码可禁止点击该按钮关闭
							}
						});	    	
			        }else{
			        	layer.open({
							title: '异常情况'
							,content: content1
							,area: ['500px', 'auto']
							,btn: []
							,cancel: function(){ 
								//右上角关闭回调
								//return false 开启该代码可禁止点击该按钮关闭
							}
						});
			        }
				}
	  }else if(data.status == "9"){
			window.location.href="index.html?loginOut=true";
			return;
		}else{
			console.log(data.info);
		}
}
//关注、取消关注
	$(".content-title").on("click",".concern",function(){
		var _this=$(this);
		if(_this.text() == "关注"){
			var wxjson = new webjson("53"); //设置action值
			//新增param键值
			wxjson.AddParam("enterpriseid", $.cookie('THE_SET_COMPANYID'));//企业id
			wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
			var res=WebRequest(wxjson);
			var data = GetOjson(json_parse(res));
			console.log(data);
			if(data.status == "0"){
				var list="";
				$.each(data.param,function(i,item){
					list+='<li data-id="'+item.c_id+'">'+
					'<input name="" type="checkbox" value="" id="type'+i+'" />'+
					'<label class="label1" for="type'+i+'"><pre>'+item.typename+'</pre></label>'+
					'</li>';	
				})
				var cname1=$.cookie('THE_SET_COMPANYNAME');
				var html='<div class="toast-warp">'+
				'<form>'+
				'<ul class="record-form">'+
				'<li>'+
				'<h3 class="h3-title2">为<b>'+cname1+'</b>选择分类</h3>'+
				'</li>'+
				'<li>'+
				'<span class="sbtn gz-add">创建新分类</span>'+
				'<div class="add-type">'+
				'<input type="text" value="" maxlength="20" placeholder="请输入分类名称" class="foodName" />'+
				'<span class="sbtn" id="cancel">取消</span>'+
				'<span class="sbtn" id="save">保存</span>'+
				'</div>'+
				'</li>'+
				'<li>'+
				'<ul class="type-list clearfix">'+
				list+
				'</ul>'+
				'</li>'+
				'</ul>'+
				'</form>'+
				'</div>';
				layer.open({
					type:1
					,title: ' '
					,content: html
					,area: ['530px', 'auto']
					,btn: ['取消', '确认']
					,yes: function(index, layero){
						layer.close(index);
						
				    	//按钮【按钮二】的回调
				    	//return false 开启该代码可禁止点击该按钮关闭
					}
					,btn2: function(index, layero){
						var typesArr=[];
						$.each($(".type-list li"),function(){
							if($(this).find("input[type='checkbox']").prop("checked")){
								typesArr.push($(this).data("id"));
							}
						})
						console.log(typesArr);
						
							var wxjson = new webjson("54"); //设置action值
							//新增param键值
							wxjson.AddParam("enterpriseid", $.cookie('THE_SET_COMPANYID'));//企业id
							wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
							wxjson.AddParam("flag", "qy");
							if(typesArr.length > 0){
								wxjson.AddParam("types", typesArr.join(","));//选中的类别id,拼接成逗号隔开的字符串"
							}else{
								wxjson.AddParam("types", "");//选中的类别id,拼接成逗号隔开的字符串"
							}
							
							var res=WebRequest(wxjson);
							var data2 = GetOjson(json_parse(res));
							if(data2.status == "0"){
								$.cookie('THE_SET_CONCERN', '取消关注', { path: '/' });
								$(".content-title .concern").text($.cookie('THE_SET_CONCERN'));
								layer.msg(data2.info);
								layer.close(index);
							}else if(data2.status == "9"){
								window.location.href="index.html?loginOut=true";
								return;
							}else{
								layer.msg(data2.info);
							}
						
					}
					,cancel: function(index, layero){ 
				    	//右上角关闭回调
				    	//return false 开启该代码可禁止点击该按钮关闭
					}
				});

				
				$(".gz-add").on("click",function(){
					$(this).hide();
					$(this).next().show();
				})
				$("#cancel").on("click",function(){
					$(this).parent(".add-type").hide();
					$(this).parent(".add-type").prev().show();
					$(this).parent(".add-type").children(".foodName").val("");
				})
				$(".add-type .foodName").on("keydown",function(event){
					var event=event || window.event;
				    if(event.keyCode == "13") {//判断如果按下的是回车键则执行下面的代码
				    	return false;
				    }
				})
				$("#save").on("click",function(){//创建新分类
					var tname1=$(this).parent(".add-type").children(".foodName").val();
					console.log(tname1);
					var typesNameArr=[];
					$.each($(".type-list li"),function(){
						if($(this).find(".label1").text()){
							typesNameArr.push(Trim($(this).find(".label1").text()));
						}
					})
					console.log(typesNameArr);
					if(typesNameArr.indexOf(tname1) >= 0){
						layer.msg('企业分类名称不能重复！');
					}else{
						var wxjson = new webjson("49"); //设置action值 创建新分类
						//新增param键值
						wxjson.AddParam("c_id", "");//类别id
						wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
						wxjson.AddParam("typename", Trim(tname1));//:类别名称
						wxjson.AddParam("keywords", "");//搜索关键字，以空格隔开
						wxjson.AddParam("zone_code", $.cookie('dep_code'));//:当前监管单位code编码

						var res=WebRequest(wxjson);
						var data5 = GetOjson(json_parse(res));
						if(data5.status == "0"){
							//layer.msg(data.info);
							var wxjson = new webjson("53"); //设置action值
							//新增param键值
							wxjson.AddParam("enterpriseid", $.cookie('THE_SET_COMPANYID'));//企业id
							wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
							var res=WebRequest(wxjson);
							var data = GetOjson(json_parse(res));
							console.log(data);
							if(data.status == "0"){//读取分类信息

								var list="";
								$.each(data.param,function(i,item){
									list+='<li data-id="'+item.c_id+'">'+
									'<input name="" type="checkbox" value="" id="type'+i+'" />'+
									'<label class="label1" for="type'+i+'"><pre>'+item.typename+'</pre></label>'+
									'</li>';	
									
								})
								$(".type-list").children().remove();
								$(".type-list").append(list);

							}else if(data.status == "9"){
								window.location.href="index.html?loginOut=true";
								return;
							}else{
								layer.msg(data.info);
							}
						}else if(data5.status == "9"){
							window.location.href="index.html?loginOut=true";
							return;
						}else{
							layer.msg(data5.info);
						}
					}
				})
			}else if(data.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else{
				layer.msg(data.info);
			}
			
		}else{//取消关注
			var wxjson = new webjson("55"); //设置action值
			//新增param键值
			wxjson.AddParam("enterpriseid", $.cookie('THE_SET_COMPANYID'));//企业id
			wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
			var res=WebRequest(wxjson);
			var data4 = GetOjson(json_parse(res));
			if(data4.status == "0"){
				$.cookie('THE_SET_CONCERN', '关注', { path: '/' });
				$(".content-title .concern").text($.cookie('THE_SET_CONCERN'));
				layer.msg(data4.info);
				//layer.close(index);
			}else if(data4.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else{
				layer.msg(data4.info);
			}
		}
		
	})

/**按enter键查询**/
$(".foodname").keydown(function(event){
 if(event.keyCode==13){
	$("#Search").click();
}
})

/**点击查询**/
$("#Search").click(function(){
	pindex="1";
	zttype="";
	yjtime="";
	sskey=$.trim($(".foodname").val());
	if(sskey=="请输入关键字进行查询"){
		sskey="";
	}
	search(sskey, cid, zttype,yjtime, pindex, psize);
})

/**点击高级查询**/
$("#confirBtn").click(function(){
	pindex="1";
	var startQydate=$("#qydate").children("input.dateStart").val();
	var endQydate = $("#qydate").children("input.dateEnd").val();
	if(datenews()) {
		if(startQydate == "" && endQydate == "") {
			yjtime = "";
			console.log(yjtime);
		} else {
			yjtime = startQydate + "," + endQydate;
			console.log(yjtime);
		}
	}
	sskey=$.trim($(".foodname").val());
	if(sskey=="请输入关键字进行查询"){
		sskey="";
	}
	zttype=checkBoxFormat($(".zt"));
	console.log("sskey:"+sskey+",zttype:"+zttype);
	search(sskey, cid, yjtime,zttype, pindex, psize);
})

/**导出**/
$("#daochu").click(function(){
	console.log(jsonParam);
	var name=$.cookie('dept_name');//监管所name
	console.log(name);
	var excelName=name+"预警信息表";
	var pattern = new RegExp('[\/:*?"<>|]');
	if(pattern.test(excelName)){
        for (var i = 0; i < excelName.length; i++) {
        	excelName = excelName.replace(pattern, '-');
        	console.log(excelName);
        }
    }
	var listType="goodsList";
	var header="异常情况"+","+"时间"+","+"状态";
	if(pcount<1001){
		var exportExcelParam={
			excelName:escape(excelName),
			listType:listType,
			header:header,
			jsonParam:jsonParam
		}
		postExportExcel(dcUrl,exportExcelParam);
	}else{
		layer.open({
			title: '系统提示'
			,content: '当前数据量超过1000条，为了数据的安全，我们无法为您导出该数据，如需导出请联系客服。'
			,btn: ['确定']
			,yes: function(){
				layer.closeAll();
			}
		});
		return false;
	}
})


