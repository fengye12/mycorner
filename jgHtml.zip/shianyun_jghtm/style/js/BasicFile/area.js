/*
* @Author: yangjy
* @Date:   2017-07-12 11:45:51
* @Last Modified time: 2017-08-07 12:48:16
*/
var ltype="0";
function areaData(res){
	var data = GetOjson(json_parse(res));
	if(data.status == "0"){
		if(ltype == "0"){
			$(".sel-province").html("<option value=''>选择省</option>");
			var html="";
			$.each(data.param,function(i,item){
				html+='<option value='+item.did+'>'+item.dname+'</option>'
			})
			$(".sel-province").append(html);
			$(".sel-city").html("<option value=''>选择市</option>");
			$(".sel-district").html("<option value=''>选择区/县</option>");
			$(".sel-street").html("<option value=''>选择街道</option>");
		}else if(ltype == "1"){
			$(".sel-city").html("<option value=''>选择市</option>");
			var html="";
			$.each(data.param,function(i,item){
				html+='<option value='+item.did+'>'+item.dname+'</option>'
			})
			$(".sel-city").append(html);
			$(".sel-district").html("<option value=''>选择区/县</option>");
			$(".sel-street").html("<option value=''>选择街道</option>");
		}else if(ltype == "2"){
			$(".sel-district").html("<option value=''>选择区/县</option>");
			var html="";
			$.each(data.param,function(i,item){
				html+='<option value='+item.did+'>'+item.dname+'</option>'
			})
			$(".sel-district").append(html);
			$(".sel-street").html("<option value=''>选择街道</option>");
		}else if(ltype == "3"){
			$(".sel-street").html("<option value=''>选择街道</option>");
			var html="";
			$.each(data.param,function(i,item){
				html+='<option value='+item.did+'>'+item.dname+'</option>'
			})
			$(".sel-street").append(html);
		}
		
	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else{
		console.log(data.info);
	}
	
	
}

function area(ltype,skey){
	var wxjson = new webjson("17"); //设置action值
	//新增param键值
	wxjson.AddParam("ltype", ltype);
	wxjson.AddParam("skey", skey);
	WebRequestAsync(wxjson, areaData);
}

$(function(){
	area(ltype,"");//调用地区列表

	$(".sel-province").on("change",function(){//选择省
		ltype="1";
		if(GetAddNew($(this).val())){
			$(".sel-city").html("<option value=''>选择市</option>");
			$(".sel-district").html("<option value=''>选择区/县</option>");
			$(".sel-street").html("<option value=''>选择街道</option>");
		}else{
			area(ltype,$(this).val());
		}
		
	})
	$(".sel-city").on("change",function(){//选择市
		ltype="2";
		if(GetAddNew($(this).val())){
			$(".sel-district").html("<option value=''>选择区/县</option>");
			$(".sel-street").html("<option value=''>选择街道</option>");
		}else{
			area(ltype,$(this).val());
		}
		
	})
	$(".sel-district").on("change",function(){//选择区县
		ltype="3";
		if(GetAddNew($(this).val())){
			$(".sel-street").html("<option value=''>选择街道</option>");
		}else{
			area(ltype,$(this).val());
		}
	})
})
