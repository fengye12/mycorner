/*
* @Author: yangjy
* @Date:   2017-07-13 11:45:51
* @Last Modified time: 2017-09-08 13:33:54
*/
autoH();//左右高度自适应autoH();//左右高度自适应
var a1 = "a11",a2 = "a1100";//当前页代码
//getActiveN("a11", "a1100");//当前页标志
var spid="",//食品id
	pname="",//食品名称
	jycid="",//交易对象id
	sskey="",//用户输入的搜索关键字
	ssmode=$("#inputssmode").val(),//搜索：0精确查询，1模糊查询
	sssel=$("#inputsssel").val(),//搜索类型：0所有类型，
	bbtype=checkBoxFormat($(".f-bbtype")),//报备类型
	jytime="",
	bbtime="",
	jynum="",
	jsonParam;//导出

var ecount = $("#inputmySelect").val();//每页显示的记录数
var cpage01 = new CentPage();//实例化分页插件
var pagenum = 1;//初始当前页
var paramcentcount=0;//总记录数
var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);//初始化分页设置
$("#page").html(cents);

function getQueryString(name) {//获取url传递的参数：name为需要获取的参数名称
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var search = window.location.search.substr(1);
	var href = window.location.href;
	if(href.indexOf("?") >= 0) {
		search = href.substr(href.indexOf("?") + 1);
	}
	var r = search.match(reg);
	if(r != null) return unescape(r[2]);
	return null;
}

if(!GetAddNew(getQueryString("spid"))){//获取食品id
	spid=getQueryString("spid");
	$.cookie('THE_SET_FOODSPID', spid, { path: '/' });
}

if(!GetAddNew(getQueryString("pname"))){//获取食品名称
	pname=getQueryString("pname");
	// $.cookie('THE_SET_FOODBARCODE', barcode, { path: '/' });
}

if(!GetAddNew(getQueryString("jycid"))){//获取交易对象企业id
	jycid=getQueryString("jycid");
	$.cookie('THE_SET_FOODJYCID', jycid, { path: '/' });
}

function CentPageOper(pnum){//点击某一页时调用此方法
	cents = cpage01.GetCentPage(pnum,paramcentcount,ecount);
	$("#page").html(cents);
	pagenum=pnum;
	foodAccountList(sskey,ssmode,sssel,jytime,bbtime,jynum,bbtype,pagenum,ecount);
}

function accountData(res){//获取台账列表数据
	$("#inquiry").attr("disabled",false);
	$("#confirBtn").attr("disabled",false);
	$("#foodAccountList").children().remove();
	$(".content-title .concern").text($.cookie('THE_SET_CONCERN'));//是否关注
	var data = GetOjson(json_parse(res));
	paramcentcount=data.paramcentcount;
	$(".total-num").text("共"+paramcentcount+"条");
	var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);
	$("#page").html(cents);
	if(data.status =="0"){
		$.each(data.param,function(i,item){
			var html="",bbtype="";
			var cname1=escape(item.cname);
			if(item.bbtype == "0"){
				bbtype="食品采购报备";
			}else{
				bbtype="食品销售报备";
			}
			if(item.pnum != "0"){
				html='<tr>'+
				'<td class="hs">'+item.bbtime+'</td>'+
				'<td class="hs">'+item.foodname+'</td>'+
				'<td class="hs">'+item.barcode+'</td>'+
				'<td class="hs">'+item.djnum+'</td>'+
				'<td class="hs">'+bbtype+'</td>'+
				'<td class="hs">'+item.jycname+'</td>'+
				'<td class="hs">'+item.jytime+'</td>';
				//'<td class="hs">'+item.pnum+'</td>'
				if(bbtype=="食品采购报备"){
				html +='<td class="hs" style="color:#EF2121;font-size:12px;">未索证</td>';
				}else{
					html +='<td class="hs">无需索证</td>';
				}
				html +='<td class="hs"><span class="ls tz-detail" data-bbid='+item.bbid+' data-jyid='+item.jypk+'>查看</span></td>'+
				'</tr>'
				$("#foodAccountList").append(html);
			}

		})
		$("#daochu").css("display","");
		$("#mySelect").css("display","");
		autoH();
	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else{
		$("#foodAccountList").append("<tr class='loading'><td colspan='9' style='padding:20px 0;text-align: center;'>"+data.info+"</td></tr>");
	}
}

function foodAccountList(sskey,ssmode,sssel,jytime,bbtime,jynum,bbtype,pagenum,ecount){//请求企业列表
	$("#inquiry").attr("disabled",true);//查询按钮
	$("#confirBtn").attr("disabled",true);//高级搜索查询按钮
	$("#daochu").css("display","none");
	$("#mySelect").css("display","none");
	$("#foodAccountList").children().remove();
	$("#foodAccountList").append("<tr class='loading'><td colspan='9' style='padding:20px 0;text-align: center;'><img src='../style/image/load.gif' width='32px' height='32px' /></td></tr>");
	var wxjson = new webjson("9"); //设置action值
	//新增param键值
	if(sskey == "请输入关键字进行查询"){
		sskey="";
	}
	wxjson.AddParam("cid", $.cookie('THE_SET_COMPANYID'));
	wxjson.AddParam("jycid", jycid);
	// wxjson.AddParam("barcode", barcode);
	wxjson.AddParam("pname", pname);
	wxjson.AddParam("spid", spid);

	wxjson.AddParam("sskey", Trim(sskey));
	wxjson.AddParam("ssmode", ssmode);
	wxjson.AddParam("sssel", sssel);

	wxjson.AddParam("pnum", jynum);
	wxjson.AddParam("bbtype", bbtype);
	wxjson.AddParam("bbtime", bbtime);
	wxjson.AddParam("jytime", jytime);
	wxjson.AddParam("page_index", pagenum);
	wxjson.AddParam("page_size", ecount);
	WebRequestAsync(wxjson, accountData);
	jsonParam=wxjson.GetJsons();
}

$(function(){
	$.divselect("#sssel","#inputsssel");
	$.divselect("#ssmode","#inputssmode");
	$.divselect("#mySelect","#inputmySelect");
	$("#mySelect li").on("click",function(){
		//切换每页显示的记录数
		if($("#inputmySelect").val() != ecount){
			ecount = $("#inputmySelect").val();
			pagenum=1;
			foodAccountList(sskey,ssmode,sssel,jytime,bbtime,jynum,bbtype,pagenum,ecount);
		}
	})
	$(".total-num").text("共"+paramcentcount+"条");
	foodAccountList(sskey,ssmode,sssel,jytime,bbtime,jynum,bbtype,pagenum,ecount);//调用企业列表
	//关注、取消关注
	$(".content-title").on("click",".concern",function(){
		var _this=$(this);
		if(_this.text() == "关注"){
			var wxjson = new webjson("53"); //设置action值
			//新增param键值
			wxjson.AddParam("enterpriseid", $.cookie('THE_SET_COMPANYID'));//企业id
			wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
			var res=WebRequest(wxjson);
			var data = GetOjson(json_parse(res));
			console.log(data);
			if(data.status == "0"){
				var list="";
				$.each(data.param,function(i,item){
					list+='<li data-id="'+item.c_id+'">'+
					'<input name="" type="checkbox" value="" id="type'+i+'" />'+
					'<label class="label1" for="type'+i+'"><pre>'+item.typename+'</pre></label>'+
					'</li>';	
				})
				var cname1=$.cookie('THE_SET_COMPANYNAME');
				var html='<div class="toast-warp">'+
				'<form>'+
				'<ul class="record-form">'+
				'<li>'+
				'<h3 class="h3-title2">为<b>'+cname1+'</b>选择分类</h3>'+
				'</li>'+
				'<li>'+
				'<span class="sbtn gz-add">创建新分类</span>'+
				'<div class="add-type">'+
				'<input type="text" value="" maxlength="20" placeholder="请输入分类名称" class="foodName" />'+
				'<span class="sbtn" id="cancel">取消</span>'+
				'<span class="sbtn" id="save">保存</span>'+
				'</div>'+
				'</li>'+
				'<li>'+
				'<ul class="type-list clearfix">'+
				list+
				'</ul>'+
				'</li>'+
				'</ul>'+
				'</form>'+
				'</div>';
				layer.open({
					type:1
					,title: ' '
					,content: html
					,area: ['530px', 'auto']
					,btn: ['取消', '确认']
					,yes: function(index, layero){
						layer.close(index);
				    	//按钮【按钮二】的回调
				    	//return false 开启该代码可禁止点击该按钮关闭
					}
					,btn2: function(index, layero){
						var typesArr=[];
						$.each($(".type-list li"),function(){
							if($(this).find("input[type='checkbox']").prop("checked")){
								typesArr.push($(this).data("id"));
							}
						})
						console.log(typesArr);
						
							var wxjson = new webjson("54"); //设置action值
							//新增param键值
							wxjson.AddParam("enterpriseid", $.cookie('THE_SET_COMPANYID'));//企业id
							wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
							wxjson.AddParam("flag", "qy");
							if(typesArr.length > 0){
								wxjson.AddParam("types", typesArr.join(","));//选中的类别id,拼接成逗号隔开的字符串"
							}else{
								wxjson.AddParam("types", "");//选中的类别id,拼接成逗号隔开的字符串"
							}
							
							var res=WebRequest(wxjson);
							var data2 = GetOjson(json_parse(res));
							if(data2.status == "0"){
								$.cookie('THE_SET_CONCERN', '取消关注', { path: '/' });
								$(".content-title .concern").text($.cookie('THE_SET_CONCERN'));
								layer.msg(data2.info);
								layer.close(index);
							}else if(data2.status == "9"){
								window.location.href="index.html?loginOut=true";
								return;
							}else{
								layer.msg(data2.info);
							}
							
						
					}
					,cancel: function(index, layero){
				    	//右上角关闭回调
				    	//return false 开启该代码可禁止点击该按钮关闭
					}
				});

				
				$(".gz-add").on("click",function(){
					$(this).hide();
					$(this).next().show();
				})
				$("#cancel").on("click",function(){
					$(this).parent(".add-type").hide();
					$(this).parent(".add-type").prev().show();
					$(this).parent(".add-type").children(".foodName").val("");
				})
				$(".add-type .foodName").on("keydown",function(event){
					var event=event || window.event;
				    if(event.keyCode == "13") {//判断如果按下的是回车键则执行下面的代码
				    	return false;
				    }
				})
				$("#save").on("click",function(){//创建新分类
					var tname1=$(this).parent(".add-type").children(".foodName").val();
					console.log(tname1);
					var typesNameArr=[];
					$.each($(".type-list li"),function(){
						if($(this).find(".label1").text()){
							typesNameArr.push(Trim($(this).find(".label1").text()));
						}
					})
					console.log(typesNameArr);
					if(typesNameArr.indexOf(tname1) >= 0){
						layer.msg('企业分类名称不能重复！');
					}else{
						var wxjson = new webjson("49"); //设置action值 创建新分类
						//新增param键值
						wxjson.AddParam("c_id", "");//类别id
						wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
						wxjson.AddParam("typename", Trim(tname1));//:类别名称
						wxjson.AddParam("keywords", "");//搜索关键字，以空格隔开
						wxjson.AddParam("zone_code", $.cookie('dep_code'));//:当前监管单位code编码

						var res=WebRequest(wxjson);
						var data5 = GetOjson(json_parse(res));
						if(data5.status == "0"){
							//layer.msg(data.info);
							var wxjson = new webjson("53"); //设置action值
							//新增param键值
							wxjson.AddParam("enterpriseid", $.cookie('THE_SET_COMPANYID'));//企业id
							wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
							var res=WebRequest(wxjson);
							var data = GetOjson(json_parse(res));
							console.log(data);
							if(data.status == "0"){//读取分类信息

								var list="";
								$.each(data.param,function(i,item){
									list+='<li data-id="'+item.c_id+'">'+
									'<input name="" type="checkbox" value="" id="type'+i+'" />'+
									'<label class="label1" for="type'+i+'"><pre>'+item.typename+'</pre></label>'+
									'</li>';	
									
								})
								$(".type-list").children().remove();
								$(".type-list").append(list);

							}else if(data.status == "9"){
								window.location.href="index.html?loginOut=true";
								return;
							}else{
								layer.msg(data.info);
							}
						}else if(data5.status == "9"){
							window.location.href="index.html?loginOut=true";
							return;
						}else{
							layer.msg(data5.info);
						}
					}
				})
			}else if(data.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else{
				layer.msg(data.info);
			}
			
		}else{//取消关注
			var wxjson = new webjson("55"); //设置action值
			//新增param键值
			wxjson.AddParam("enterpriseid", $.cookie('THE_SET_COMPANYID'));//企业id
			wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
			var res=WebRequest(wxjson);
			var data4 = GetOjson(json_parse(res));
			if(data4.status == "0"){
				$.cookie('THE_SET_CONCERN', '关注', { path: '/' });
				$(".content-title .concern").text($.cookie('THE_SET_CONCERN'));
				layer.msg(data4.info);
				//layer.close(index);
			}else if(data4.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else{
				layer.msg(data4.info);
			}
		}
		
	})

	$("#foodAccountList").on("click",".tz-detail",function(){
		//Enterprise_accountInfo.html?bbid='+item.bbid+'
		var indexPage=$(".tab-nav .active").children("a").text(),bbid=$(this).data("bbid"),jyid=$(this).data("jyid");
		if(indexPage == "经营食品"){
			window.open("StandingBook_check.html?bbid="+bbid+"&jyid="+jyid,'_blank');
		}else if(indexPage == "交易对象"){
			window.open("StandingBook_check.html?bbid="+bbid+"&jyid="+jyid,'_blank');
			// window.close();
		}else if(indexPage == "台账报备"){
			getTDetail();
			function getTDetail(){
				//iframe窗
				layer.open({
				  type: 2,
				  title:  ['台账查看 ', 'background:#fff;'],
				  // closeBtn: 1, //不显示关闭按钮
				  shade: [0],
				  area: ['1000px', '650px'],
				  anim: 2,
				  content: ['StandingBook_check2.html?bbid='+bbid+'&jyid='+jyid, 'yes']//iframe的url，no代表不显示滚动条
				});
			}
			// window.location.href="Enterprise_accountInfo.html?bbid="+bbid+"&jyid="+jyid;
		}else{
			window.location.reload();
		}
	})

	$(".companyName").text($.cookie('THE_SET_COMPANYNAME'));//从内存中获取企业名称
	//搜索
	$("#inquiry").on("click",function(){
		sskey=$(".inputWraper .foodName").val();//用户输入的搜索关键字
		ssmode=$("#inputssmode").val();//搜索：0精确查询，1模糊查询
		sssel=$("#inputsssel").val();//搜索类型：0所有类型，
		bbtype="";//贮存条件
		jytime="";
		bbtime="";
		jynum="";
		pagenum=1;
		foodAccountList(sskey,ssmode,sssel,jytime,bbtime,jynum,bbtype,pagenum,ecount);
	})
	//交易数量格式校验
	$(".jynum").on("keyup",function(event){
		var event=event || window.event;
		numberYz($(this),event);
	})
	//高级搜索
	$("#confirBtn").on("click",function(){
		if(date()){
			var startDaobei=$("#bbDate").children("input.dateStart").val();
			var endDaobei = $("#bbDate").children("input.dateEnd").val();
			//交易日期验证jyDate
			var startJy = $("#jyDate").children("input.dateStart").val();
			var endJy = $("#jyDate").children("input.dateEnd").val()
			//交易数量jyNum
			var startNum = $("#jyNum").children("input.jynumStart").val();
			var endNum = $("#jyNum").children("input.jynumEnd").val();
			if(startNum != "" && endNum != "" && startNum > endNum){
				layer.open({
					title: '系统提示'
					,content: '交易开始数量不能大于结束数量!'
					,btn: ['确定']
					,yes: function(){
						layer.closeAll();
					}
				});
		      	return false;
			}else{
				if(GetAddNew(startDaobei) && GetAddNew(endDaobei)){
					bbtime="";
				}else{
					bbtime=startDaobei+','+endDaobei;
				}
				if(GetAddNew(startJy) && GetAddNew(endJy)){
					jytime="";
				}else{
					jytime=startJy+','+endJy;
				}
				if(GetAddNew(startNum) && GetAddNew(endNum)){
					jynum="";
				}else{
					jynum=startNum+','+endNum;
				}


				sskey=$(".inputWraper .foodName").val();//用户输入的搜索关键字
				ssmode=$("#inputssmode").val();//搜索：0精确查询，1模糊查询
				sssel=$("#inputsssel").val();//搜索类型：0所有类型，
				bbtype=checkBoxFormat($(".f-bbtype")),//报备类型
				pagenum=1;
				foodAccountList(sskey,ssmode,sssel,jytime,bbtime,jynum,bbtype,pagenum,ecount);
			}

			//ecount = $("#mySelect option:selected").val();//每页显示的记录数
		}

	})

	$("#daochu").on("click",function(){//导出
		var name=$(".companyName").text();
		var excelName=name+"台账报备表";
		var listType="ledgerList";
		var header="商品名称"+","+"商品条码"+","+"报备日期"+","+"单据号"+","+"报备类型"+","+"交易对象"+","+"交易日期";
		if(paramcentcount<1001){
			var exportExcelParam={
				excelName:escape(excelName),
				listType:listType,
				header:header,
				jsonParam:jsonParam
			}
			postExportExcel(dcUrl,exportExcelParam);
		}else{
			layer.open({
				type:1
				,title: '系统提示'
				,content: '<div class="removeTip"><p>当前数据量超过1000条，为了数据的安全，我们无法为您导出该数据，如需导出请联系客服。</p></div>'
				,btn: ['确定']
				,yes: function(){
					layer.closeAll();
				}
			});
			return false;
		}

	});

	$(".inputWraper input").on("keydown",function(event){//按下回车执行查询
	    var event=event || window.event;
	    if(event.keyCode == "13") {//判断如果按下的是回车键则执行下面的代码
	    	$("#inquiry").click();
	    }
	})

	getActiveN("a11", "a1100");//当前页标志
	//$("img.qh").trigger('click');
})



