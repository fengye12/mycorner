/*
* @Author: yangjy
* @Date:   2017-07-14 11:45:51
* @Last Modified time: 2017-07-14 12:48:16
*/
autoH();//左右高度自适应autoH();
var a1 = "a11",a2 = "a1100";//当前页代码
var bbtime="",//报备日期
	bbtype=checkBoxFormat($(".o-bbtype")),//备案类型
	bstatus=checkBoxFormat($(".o-bstatus")),//备案状态
	jsonParam;//导出
var ecount = $("#inputmySelect").val();//每页显示的记录数
var cpage01 = new CentPage();//实例化分页插件
var pagenum = 1;//初始当前页
var paramcentcount=0;//总记录数
var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);//初始化分页设置
$("#page").html(cents);

function CentPageOper(pnum){//点击某一页时调用此方法
	cents = cpage01.GetCentPage(pnum,paramcentcount,ecount);
	$("#page").html(cents);
	pagenum=pnum;
	operateRecordList(bbtime,bbtype,bstatus,pagenum,ecount);
}

function operateRecordData(res){//获取备案列表数据
	$("#confirBtn").attr("disabled",false);
	$("#operateRecordList").children().remove();
	$(".content-title .concern").text($.cookie('THE_SET_CONCERN'));//是否关注
	var data = GetOjson(json_parse(res));
	paramcentcount=data.paramcentcount;
	var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);
	$("#page").html(cents);
	if(data.status =="0"){
		$.each(data.param,function(i,item){
			var html="",bbtype1="",bstatus1="";
			if(item.bbtype == "0"){
				bbtype1="无进货行为备案";
			}else if(item.bbtype == "1"){
				bbtype1="无销售行为备案";
			}else if(item.bbtype == "2"){
				bbtype1="停止生产经营备案";
			}else if(item.bbtype == "3"){
				bbtype1="企业转让备案";
			}else if(item.bbtype == "4"){
				bbtype1="恢复生产经营备案";
			}else{
				bbtype1="";
			}
			if(item.bstatus == "0"){
				bstatus1="备案中";
			}else if(item.bstatus == "1"){
				bstatus1="已备案";
			}else if(item.bstatus == "2"){
				bstatus1="已作废";
			}else{
				bstatus1="";
			}
			html='<tr>'+
			'<td class="hs">'+bbtype1+'</td>'+
			'<td class="hs">'+item.bbtime+'</td>'+
			'<td class="hs text-left recordInfo">'+item.bbsm+'</td>'+
			'<td class="hs">'+bstatus1+'</td>'+
			'<td class="hs"><span class="lookDetail" data-jbid='+item.jbid+'>查看</span></td>'+
			'</tr>'
			$("#operateRecordList").append(html);
		})
		$("#daochu").css("display","");
		$("#mySelect").css("display","");
		autoH();
	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else{
		$("#operateRecordList").append("<tr class='loading'><td colspan='5' style='padding:20px 0;text-align: center;'>"+data.info+"</td></tr>");
	}
}

function operateRecordList(bbtime,bbtype,bstatus,pagenum,ecount){//请求备案列表
	$("#confirBtn").attr("disabled",true);
	$("#daochu").css("display","none");
	$("#mySelect").css("display","none");
	$("#operateRecordList").children().remove();
	$("#operateRecordList").append("<tr class='loading'><td colspan='5' style='padding:20px 0;text-align: center;'><img src='../style/image/load.gif' width='32px' height='32px' /></td></tr>");
	var wxjson = new webjson("11"); //设置action值
	//新增param键值
	wxjson.AddParam("cid", $.cookie('THE_SET_COMPANYID'));
	wxjson.AddParam("sskey", "");
	wxjson.AddParam("ssmode", "");
	wxjson.AddParam("sssel", "");

	wxjson.AddParam("bbtype", bbtype);
	wxjson.AddParam("bbtime", bbtime);
	wxjson.AddParam("bstatus", bstatus);
	wxjson.AddParam("page_index", pagenum);
	wxjson.AddParam("page_size", ecount);
	WebRequestAsync(wxjson, operateRecordData);
	jsonParam=wxjson.GetJsons();
}

$(function(){
	$.divselect("#mySelect","#inputmySelect");
	$("#mySelect li").on("click",function(){
		//切换每页显示的记录数
		if($("#inputmySelect").val() != ecount){
			ecount = $("#inputmySelect").val();
			pagenum=1;
			operateRecordList(bbtime,bbtype,bstatus,pagenum,ecount);
		}
	})
	operateRecordList(bbtime,bbtype,bstatus,pagenum,ecount);
	//关注、取消关注
	$(".content-title").on("click",".concern",function(){
		var _this=$(this);
		if(_this.text() == "关注"){
			var wxjson = new webjson("53"); //设置action值
			//新增param键值
			wxjson.AddParam("enterpriseid", $.cookie('THE_SET_COMPANYID'));//企业id
			wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
			var res=WebRequest(wxjson);
			var data = GetOjson(json_parse(res));
			console.log(data);
			if(data.status == "0"){
				var list="";
				$.each(data.param,function(i,item){
					list+='<li data-id="'+item.c_id+'">'+
					'<input name="" type="checkbox" value="" id="type'+i+'" />'+
					'<label class="label1" for="type'+i+'"><pre>'+item.typename+'</pre></label>'+
					'</li>';	
				})
				var cname1=$.cookie('THE_SET_COMPANYNAME');
				var html='<div class="toast-warp">'+
				'<form>'+
				'<ul class="record-form">'+
				'<li>'+
				'<h3 class="h3-title2">为<b>'+cname1+'</b>选择分类</h3>'+
				'</li>'+
				'<li>'+
				'<span class="sbtn gz-add">创建新分类</span>'+
				'<div class="add-type">'+
				'<input type="text" value="" maxlength="20" placeholder="请输入分类名称" class="foodName" />'+
				'<span class="sbtn" id="cancel">取消</span>'+
				'<span class="sbtn" id="save">保存</span>'+
				'</div>'+
				'</li>'+
				'<li>'+
				'<ul class="type-list clearfix">'+
				list+
				'</ul>'+
				'</li>'+
				'</ul>'+
				'</form>'+
				'</div>';
				layer.open({
					type:1
					,title: ' '
					,content: html
					,area: ['530px', 'auto']
					,btn: ['取消', '确认']
					,yes: function(index, layero){
						layer.close(index);
					
				    	//按钮【按钮二】的回调
				    	//return false 开启该代码可禁止点击该按钮关闭
					}
					,btn2: function(index, layero){
						var typesArr=[];
						$.each($(".type-list li"),function(){
							if($(this).find("input[type='checkbox']").prop("checked")){
								typesArr.push($(this).data("id"));
							}
						})
						console.log(typesArr);
						
							var wxjson = new webjson("54"); //设置action值
							//新增param键值
							wxjson.AddParam("enterpriseid", $.cookie('THE_SET_COMPANYID'));//企业id
							wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
							wxjson.AddParam("flag", "qy");
							if(typesArr.length > 0){
								wxjson.AddParam("types", typesArr.join(","));//选中的类别id,拼接成逗号隔开的字符串"
							}else{
								wxjson.AddParam("types", "");//选中的类别id,拼接成逗号隔开的字符串"
							}
							
							var res=WebRequest(wxjson);
							var data2 = GetOjson(json_parse(res));
							if(data2.status == "0"){
								$.cookie('THE_SET_CONCERN', '取消关注', { path: '/' });
								$(".content-title .concern").text($.cookie('THE_SET_CONCERN'));
								layer.msg(data2.info);
								layer.close(index);
							}else if(data2.status == "9"){
								window.location.href="index.html?loginOut=true";
								return;
							}else{
								layer.msg(data2.info);
							}
							
					}
					,cancel: function(index, layero){
				    	//右上角关闭回调
				    	//return false 开启该代码可禁止点击该按钮关闭
					}
				});

				
				$(".gz-add").on("click",function(){
					$(this).hide();
					$(this).next().show();
				})
				$("#cancel").on("click",function(){
					$(this).parent(".add-type").hide();
					$(this).parent(".add-type").prev().show();
					$(this).parent(".add-type").children(".foodName").val("");
				})
				$(".add-type .foodName").on("keydown",function(event){
					var event=event || window.event;
				    if(event.keyCode == "13") {//判断如果按下的是回车键则执行下面的代码
				    	return false;
				    }
				})
				$("#save").on("click",function(){//创建新分类
					var tname1=$(this).parent(".add-type").children(".foodName").val();
					console.log(tname1);
					var typesNameArr=[];
					$.each($(".type-list li"),function(){
						if($(this).find(".label1").text()){
							typesNameArr.push(Trim($(this).find(".label1").text()));
						}
					})
					console.log(typesNameArr);
					if(typesNameArr.indexOf(tname1) >= 0){
						layer.msg('企业分类名称不能重复！');
					}else{
						var wxjson = new webjson("49"); //设置action值 创建新分类
						//新增param键值
						wxjson.AddParam("c_id", "");//类别id
						wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
						wxjson.AddParam("typename", Trim(tname1));//:类别名称
						wxjson.AddParam("keywords", "");//搜索关键字，以空格隔开
						wxjson.AddParam("zone_code", $.cookie('dep_code'));//:当前监管单位code编码

						var res=WebRequest(wxjson);
						var data5 = GetOjson(json_parse(res));
						if(data5.status == "0"){
							//layer.msg(data.info);
							var wxjson = new webjson("53"); //设置action值
							//新增param键值
							wxjson.AddParam("enterpriseid", $.cookie('THE_SET_COMPANYID'));//企业id
							wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
							var res=WebRequest(wxjson);
							var data = GetOjson(json_parse(res));
							console.log(data);
							if(data.status == "0"){//读取分类信息

								var list="";
								$.each(data.param,function(i,item){
									list+='<li data-id="'+item.c_id+'">'+
									'<input name="" type="checkbox" value="" id="type'+i+'" />'+
									'<label class="label1" for="type'+i+'"><pre>'+item.typename+'</pre></label>'+
									'</li>';	
									
								})
								$(".type-list").children().remove();
								$(".type-list").append(list);

							}else if(data.status == "9"){
								window.location.href="index.html?loginOut=true";
								return;
							}else{
								layer.msg(data.info);
							}
						}else if(data5.status == "9"){
							window.location.href="index.html?loginOut=true";
							return;
						}else{
							layer.msg(data5.info);
						}
					}
				})
			}else if(data.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else{
				layer.msg(data.info);
			}
			
		}else{//取消关注
			var wxjson = new webjson("55"); //设置action值
			//新增param键值
			wxjson.AddParam("enterpriseid", $.cookie('THE_SET_COMPANYID'));//企业id
			wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
			var res=WebRequest(wxjson);
			var data4 = GetOjson(json_parse(res));
			if(data4.status == "0"){
				$.cookie('THE_SET_CONCERN', '关注', { path: '/' });
				$(".content-title .concern").text($.cookie('THE_SET_CONCERN'));
				layer.msg(data4.info);
				//layer.close(index);
			}else if(data4.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else{
				layer.msg(data4.info);
			}
		}
		
	})

	$(".companyName").text($.cookie('THE_SET_COMPANYNAME'));//从内存中获取企业名称
	
	$("#confirBtn").on("click",function(){
		//报备日期验证bbDate
		 var startDaobei=$("#bbDate").children("input.dateStart").val();
		 var endDaobei = $("#bbDate").children("input.dateEnd").val();

		 if(startDaobei != "" && endDaobei != "" && new Date(startDaobei.replace(/-/g, "/")) > new Date(endDaobei.replace(/-/g, "/"))) {
		    layer.open({
				title: '系统提示'
				,content: '报备开始日期不能大于结束日期!'
				,area:["280px","150px"]
				,btn: ['确定']
				,yes: function(){
					layer.closeAll();
				}
			});
		    return false;
		}else{
			if(startDaobei == "" && endDaobei == ""){
				bbtime="";//报备日期
			}else{
				bbtime=startDaobei+","+endDaobei;
			}

			bbtype=checkBoxFormat($(".o-bbtype")),//备案类型
			bstatus=checkBoxFormat($(".o-bstatus"));//备案状态
			pagenum=1;
			operateRecordList(bbtime,bbtype,bstatus,pagenum,ecount);
		}
		
		
	})

	$("#operateRecordList").on("click",".lookDetail",function(){//图片查看
		var jbid=$(this).data("jbid");

		function operateRecordInfo(res){
			var data = GetOjson(json_parse(res));
			if(data.status == "0"){
				var beian="",zrBeian="",zfbeian="",btype="",zfzrBeian="",content1="";

				if(data.param[0].bbtype == "0"){
					btype="无进货行为备案";
				}else if(data.param[0].bbtype == "1"){
					btype="无销售行为备案";
				}else if(data.param[0].bbtype == "2"){
					btype="停止生产经营备案";
				}else if(data.param[0].bbtype == "3"){
					btype="企业转让备案";
				}else if(data.param[0].bbtype == "4"){
					btype="恢复生产经营备案";
				}else{
					btype="";
				}
				if(data.param[0].bbtype == "2"){
					beian='<div class="toast-warp">'+
					'<form>'+
					'<ul class="record-form">'+
					'<li>'+
					'<label for="">备案类型</label>'+
					'<input type="text" value='+btype+' class="input-init" disabled />'+
					'</li>'+
					'<li><h3 class="h3-title mt10"><span>备案说明</span></h3></li>'+
					'<li>'+
					'<label for="">停产日期</label>'+
					'<input type="text" value='+data.param[0].bbtime+' class="input-init" disabled />'+
					'</li>'+
					'<li>'+
					'<textarea name="" id="recordDetail" rows="3" disabled>'+data.param[0].bbsm+'</textarea>'+
					'</li>'+
					'</ul>'+
					'</form>'+
					'</div>';
					zfbeian='<div class="toast-warp">'+
					'<form>'+
					'<ul class="record-form">'+
					'<li>'+
					'<label for="">备案类型</label>'+
					'<input type="text" value='+btype+' class="input-init" disabled />'+
					'</li>'+
					'<li><h3 class="h3-title mt10"><span>备案说明</span></h3></li>'+
					'<li>'+
					'<label for="">停产日期</label>'+
					'<input type="text" value='+data.param[0].bbtime+' class="input-init" disabled />'+
					'</li>'+
					'<li>'+
					'<textarea name="" id="recordDetail" rows="3" disabled>'+data.param[0].bbsm+'</textarea>'+
					'</li>'+
					'<li id="zfyy">'+
					'<h3 class="h3-title"><span>作废原因</span></h3>'+
					'<textarea name="" rows="3" disabled>'+data.param[0].zfsm+'</textarea>'+
					'</li>'+
					'</ul>'+
					'</form>'+
					'</div>';
				}else{
					beian='<div class="toast-warp">'+
					'<form>'+
					'<ul class="record-form">'+
					'<li>'+
					'<label for="">备案类型</label>'+
					'<input type="text" value='+btype+' class="input-init" disabled />'+
					'</li>'+
					'<li><h3 class="h3-title mt10"><span>备案说明</span></h3></li>'+
					'<li>'+
					'<label for="">报备月份</label>'+
					'<input type="text" value='+data.param[0].bbtime+' class="input-init" disabled />'+
					'</li>'+
					'<li>'+
					'<textarea name="" id="recordDetail" rows="3" disabled>'+data.param[0].bbsm+'</textarea>'+
					'</li>'+
					'</ul>'+
					'</form>'+
					'</div>';
					zfbeian='<div class="toast-warp">'+
					'<form>'+
					'<ul class="record-form">'+
					'<li>'+
					'<label for="">备案类型</label>'+
					'<input type="text" value='+btype+' class="input-init" disabled />'+
					'</li>'+
					'<li><h3 class="h3-title mt10"><span>备案说明</span></h3></li>'+
					'<li>'+
					'<label for="">报备月份</label>'+
					'<input type="text" value='+data.param[0].bbtime+' class="input-init" disabled />'+
					'</li>'+
					'<li>'+
					'<textarea name="" id="recordDetail" rows="3" disabled>'+data.param[0].bbsm+'</textarea>'+
					'</li>'+
					'<li id="zfyy">'+
					'<h3 class="h3-title"><span>作废原因</span></h3>'+
					'<textarea name="" rows="3" disabled>'+data.param[0].zfsm+'</textarea>'+
					'</li>'+
					'</ul>'+
					'</form>'+
					'</div>';
				}
				

				

				zrBeian='<div class="toast-warp">'+
				'<form>'+
				'<ul class="record-form">'+
				'<li>'+
				'<label for="">备案类型</label>'+
				'<input type="text" value='+btype+' class="input-init" disabled />'+
				'</li>'+
				'<li>'+
				'<h3 class="h3-title mt10"><span>备案说明</span></h3>'+
				'</li>'+
				'<li>'+
				'<label for="">转让日期</label>'+
				'<input type="text" value='+data.param[0].bbtime+' class="input-init" disabled />'+
				'</li>'+
				'<li>'+
				'<label for="">受让人</label>'+
				'<input type="text" value='+data.param[0].srs+' class="input-init" disabled />'+
				'</li>'+
				'<li>'+
				'<label for="">身份证号</label>'+
				'<input type="text" value='+data.param[0].idcard+' class="input-init" disabled />'+
				'</li>'+
				'<li>'+
				'<label for="">手机号</label>'+
				'<input type="text" value='+data.param[0].phone+' class="input-init" disabled />'+
				'</li>'+
				'<li>'+
				'<textarea name="" id="recordDetail" rows="3" disabled>'+data.param[0].bbsm+'</textarea>'+
				'</li>'+
				'</ul>'+
				'</form>'+
				'</div>';

				zfzrBeian='<div class="toast-warp">'+
				'<form>'+
				'<ul class="record-form">'+
				'<li>'+
				'<label for="">备案类型</label>'+
				'<input type="text" value='+btype+' class="input-init" disabled />'+
				'</li>'+
				'<li>'+
				'<h3 class="h3-title mt10"><span>备案说明</span></h3>'+
				'</li>'+
				'<li>'+
				'<label for="">转让日期</label>'+
				'<input type="text" value='+data.param[0].bbtime+' class="input-init" disabled />'+
				'</li>'+
				'<li>'+
				'<label for="">受让人</label>'+
				'<input type="text" value='+data.param[0].srs+' class="input-init" disabled />'+
				'</li>'+
				'<li>'+
				'<label for="">身份证号</label>'+
				'<input type="text" value='+data.param[0].idcard+' class="input-init" disabled />'+
				'</li>'+
				'<li>'+
				'<label for="">手机号</label>'+
				'<input type="text" value='+data.param[0].phone+' class="input-init" disabled />'+
				'</li>'+
				'<li>'+
				'<textarea name="" id="recordDetail" rows="3" disabled>'+data.param[0].bbsm+'</textarea>'+
				'</li>'+
				'<li id="zfyy">'+
				'<h3 class="h3-title"><span>作废原因</span></h3>'+
				'<textarea name="" rows="3" disabled>'+data.param[0].zfsm+'</textarea>'+
				'</li>'+
				'</ul>'+
				'</form>'+
				'</div>';

				if(data.param[0].bstatus == "2" && data.param[0].bbtype == "3"){
					content1=zfzrBeian;
				}else if(data.param[0].bstatus == "2" && data.param[0].bbtype != "3"){
					content1=zfbeian;
				}else if(data.param[0].bstatus != "2" && data.param[0].bbtype == "3"){
					content1=zrBeian;
				}else if(data.param[0].bstatus != "2" && data.param[0].bbtype != "3"){
					content1=beian;
				}else{
					content1="";
				}
				layer.open({
					type:1
					,title: ' '
					,content: content1
					,area: ['520px', 'auto']
					,btn: []
					,cancel: function(){ 
						//右上角关闭回调
						//return false 开启该代码可禁止点击该按钮关闭
					}
				});
			}else if(data.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else if(data.status== "10"){
				console.log(data.info);
			}else{
				layer.open({
					title: '提示'
					,content: data.info
					,area:["280px","150px"]
					,btn: ['确定']
					,yes: function(index, layero){
						layer.close(index);
					}
					,cancel: function(){ 
						//右上角关闭回调
						//return false 开启该代码可禁止点击该按钮关闭
					}
				});
			}
		}

		var wxjson = new webjson("12"); //设置action值
		//新增param键值
		wxjson.AddParam("jbid", jbid);
		WebRequestAsync(wxjson, operateRecordInfo);//读取经营备案信息
		
	})

	getActiveN("a11", "a1100");//当前页标志
	//$("img.qh").trigger('click');

	$("#daochu").on("click",function(){
		var name=$(".companyName").text();
		var excelName=name+"经营备案表";
		var listType="onfilingList";
		var header="备案类型"+","+"备案日期"+","+"备案信息"+","+"状态";
		if(paramcentcount<1001){
			var exportExcelParam={
				excelName:escape(excelName),
				listType:listType,
				header:header,
				jsonParam:jsonParam
			}
			postExportExcel(dcUrl,exportExcelParam);
		}else{
			layer.open({
				type:1
				,title: '系统提示'
				,content: '<div class="removeTip"><p>当前数据量超过1000条，为了数据的安全，我们无法为您导出该数据，如需导出请联系客服。</p></div>'
				,btn: ['确定']
				,yes: function(){
					layer.closeAll();
				}
			});	
			return false;
		}

	})
})