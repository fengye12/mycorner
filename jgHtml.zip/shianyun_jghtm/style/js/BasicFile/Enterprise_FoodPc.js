/*
* @Author: yangjy
* @Date:   2017-07-14 11:45:51
* @Last Modified time: 2017-07-14 12:48:16
*/
//autoH();//左右高度自适应autoH();//左右高度自适应
//var a1 = "a11",a2 = "a1100";//当前页代码
var spid="",//食品id
	ycountrypd="",//原产国
	barcode="",//食品条码
	pname="",//食品名称
	sskey="";//用户输入的搜索关键字(商品批号精确查询，生产厂家)

var ecount = $("#inputmySelect").val();//每页显示的记录数
var cpage01 = new CentPage();//实例化分页插件
var pagenum = 1;//初始当前页
var paramcentcount=0;//总记录数
var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);//初始化分页设置
$("#page").html(cents);

function getQueryString(name) {//获取url传递的参数：name为需要获取的参数名称
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var search = window.location.search.substr(1);
	var href = window.location.href;
	if(href.indexOf("?") >= 0) {
		search = href.substr(href.indexOf("?") + 1);
	}
	var r = search.match(reg);
	if(r != null) return unescape(r[2]);
	return null;
}

if(!GetAddNew(getQueryString("spid"))){//获取食品id
	spid=getQueryString("spid");
}
if(!GetAddNew(getQueryString("barcode"))){//获取食品条码
	barcode=getQueryString("barcode");
}
if(!GetAddNew(getQueryString("pname"))){//获取食品名称
	pname=getQueryString("pname");
}
if(!GetAddNew(getQueryString("ycountry"))){//获取食品原产国
	ycountrypd=getQueryString("ycountry");
}

function CentPageOper(pnum){//点击某一页时调用此方法
	cents = cpage01.GetCentPage(pnum,paramcentcount,ecount);
	$("#page").html(cents);
	pagenum=pnum;
	foodPcList(barcode,spid,pagenum,ecount);
}

function foodPcData(res){//获取食品相关批次列表数据
	$("#inquiry").attr("disabled",false);
	$(".pc-table").children().remove();
	var data = GetOjson(json_parse(res));
	paramcentcount=data.paramcentcount;
	$(".total-num").text("共"+paramcentcount+"条");
	var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);
	$("#page").html(cents);
	if(data.status =="0"){
		var htmlt="";
		if(ycountrypd == "中国"){
			$(".pc-table").children().remove();
			htmlt='<table class="table">'+
			'<thead>'+
			'<tr>'+
			// '<th>食品名称</th>'+
			// '<th>商品条码</th>'+
			'<th>生产厂家</th>'+
			'<th>生产地址</th>'+
			'<th>商品批号</th>'+
			'<th>检验(检疫)合格证</th>'+
			'</tr>'+
			'</thead>'+
			'<tbody id="foodPcList">'+
			'</tbody>'+
			'</table>'
			$(".pc-table").html(htmlt);
			$.each(data.param,function(i,item){
				var html="";  
				html='<tr>'+
				// '<td class="hs">'+pname+'</td>'+
				// '<td class="hs">'+barcode+'</td>'+
				'<td class="hs">'+item.sccj+'</td>'+
				'<td class="hs">'+item.scdz+'</td>'+
				'<td class="hs">'+item.scpc+'</td>';
				if(item.bstatus == "0"){
					html+='<td class="hs"><span class="text-red">未上传</span></td></tr>';
				}else{
					html+='<td class="hs"><span class="ls" data-photos='+item.photos+'>已上传</span></td></tr>';
				}
				$("#foodPcList").append(html);
				
				//autoH();
			})

		}else{
			$(".pc-table").children().remove();
			htmlt='<table class="table">'+
			'<thead>'+
			'<tr>'+
			// '<th>食品名称</th>'+
			// '<th>商品条码</th>'+
			'<th>进口经销商</th>'+
			'<th>经营地址</th>'+
			'<th>经销商联系方式</th>'+
			'<th>生产厂家</th>'+
			'<th>生产地址</th>'+
			'<th>商品批号</th>'+
			'<th>检验(检疫)合格证</th>'+
			'</tr>'+
			'</thead>'+
			'<tbody id="foodPcList">'+
			'</tbody>'+
			'</table>'
			$(".pc-table").html(htmlt);
			$.each(data.param,function(i,item){
				var html="";
				html='<tr>'+
				// '<td class="hs">'+pname+'</td>'+
				// '<td class="hs">'+barcode+'</td>'+
				'<td class="hs">'+item.jkjsx+'</td>'+
				'<td class="hs">'+item.jydz+'</td>'+
				'<td class="hs">'+item.jxslxfs+'</td>'+
				'<td class="hs">'+item.sccj+'</td>'+
				'<td class="hs">'+item.scdz+'</td>'+
				'<td class="hs">'+item.scpc+'</td>';
				if(item.bstatus == "0"){
					html+='<td class="hs"><span class="text-red">未上传</span></td></tr>';
				}else{
					html+='<td class="hs"><span class="ls" data-photos='+item.photos+'>已上传</span></td></tr>'
				}
				$("#foodPcList").append(html);

				//autoH();
			})
		}
	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else{
		$(".pc-table").html('<div class="loading">'+data.info+'</div>');
	}
}

function foodPcList(barcode,spid,pagenum,ecount){//请求食品批次列表
	$("#inquiry").attr("disabled",true);
	$("#confirBtn").attr("disabled",true);
	$("#foodPcList").children().remove();
	$(".pc-table").html("<div class='loading'><img src='../style/image/load.gif' width='32px' height='32px' /></div>");
	var wxjson = new webjson("18"); //设置action值
	//新增param键值
	if(sskey == "商品批号(精确查询)"){
		sskey="";
	}
	wxjson.AddParam("spid", spid);
	wxjson.AddParam("sskey", Trim(sskey));
	wxjson.AddParam("ssmode", "1");
	wxjson.AddParam("sssel", "0");
	wxjson.AddParam("barcode", barcode);
	wxjson.AddParam("page_index", pagenum);
	wxjson.AddParam("page_size", ecount);
	WebRequestAsync(wxjson, foodPcData);
}

$(function(){
	$.divselect("#mySelect","#inputmySelect");
	$("#mySelect li").on("click",function(){
		//切换每页显示的记录数
		if($("#inputmySelect").val() != ecount){
			ecount = $("#inputmySelect").val();
			pagenum=1;
			foodPcList(barcode,spid,pagenum,ecount);//调用批次列表
		}
	})
	$(".total-num").text("共"+paramcentcount+"条");
	foodPcList(barcode,spid,pagenum,ecount);//调用批次列表
	//搜索
	$(".companyName").text($.cookie('THE_SET_COMPANYNAME'));//从内存中获取企业名称
	$("#inquiry").on("click",function(){
		sskey=$(".inputWraper .foodName").val(),//用户输入的搜索关键字
		ssmode="0",//搜索：0精确查询，1模糊查询
		sssel="",//搜索类型：0所有类型，
		pagenum=1;
		foodPcList(barcode,spid,pagenum,ecount);//调用批次列表
	})

	$(".pc-table").on("click",".ls",function(){//查看图片
		if(Trim($(this).text()) == "已上传"){
			if($(this).data("photos").length > 0){
				var photos=$(this).data("photos").split(",");
				var imgContent="",imgPhoto="";
				for(var i=0;i<photos.length;i++){
					imgPhoto+='<li><img src='+photos[i]+' alt="Picture"></li>'
				}
				imgContent='<div class="img-warp img-tip">'+
				'<div class="imgDiv">'+
				'<ul class="images">'+
				imgPhoto+
				'</ul>'+
				'</div>'+
				'</div>'
				layer.open({
					type:1
					,title: '图片查看'
					,content: imgContent
					,area: ['600px', 'auto']
					,btn: []
					,cancel: function(){ 
						//右上角关闭回调
						//return false 开启该代码可禁止点击该按钮关闭
					}
				});
				$('.images').viewer({
					inline:true,
					transition:false
				});
			}

		}
	})

	$(".inputWraper input").on("keydown",function(event){//按下回车执行查询
	    var event=event || window.event;
	    if(event.keyCode == "13") {//判断如果按下的是回车键则执行下面的代码
	    	$("#inquiry").click();
	    }
	})
	
	//getActiveN("a11", "a1100");//当前页标志
})



