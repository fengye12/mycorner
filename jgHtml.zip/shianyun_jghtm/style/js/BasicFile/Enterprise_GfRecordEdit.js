/*
* @Author: yangjy
* @Date:   2017-07-12 11:45:51
* @Last Modified time: 2017-07-12 12:48:16
*/
autoH();//左右高度自适应autoH();//左右高度自适应
//var a1 = "a11",a2 = "a1100";//当前页代码
var c_id="",title="",desc="";//企业id
var imgPath=[];//上传图片
var a1 = "a11",a2 = "a1100";//当前页代码
var pindex = 1; //当前页
var psize ="20"; //每页数据数量
var pcount = 0; //数据总数
var pcent = new CentPage();
var cents = pcent.GetCentPage(pindex,pcount,psize);//初始化分页设置
$("#page").html(cents);

function CentPageOper(pindex1) {
	var cents = pcent.GetCentPage(pindex1,pcount,psize);//初始化分页设置
	$("#page").html(cents);
	pindex=pindex1;
	companyInfo(c_id,pindex, psize);
}
// $("#tiaoshu").change(function () {  
// 	psize = $(this).children('option:selected').val();  
// 	console.log(psize);
// 	pindex=1;
// 	companyInfo(c_id,pindex, psize);
//            //CentPageOper(pindex);
// }); 
function getQueryString(name) {//获取url传递的参数：name为需要获取的参数名称
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var search = window.location.search.substr(1);
	var href = window.location.href;
	if(href.indexOf("?") >= 0) {
		search = href.substr(href.indexOf("?") + 1);
	}
	var r = search.match(reg);
	if(r != null) return unescape(r[2]);
	return null;
}

//if(GetAddNew(getQueryString("c_id"))){//优先判断url有参数(c_id)的话存进本地缓存，若没有则从缓存中读取企业c_id
	c_id=$.cookie('THE_SET_COMPANYID');
//}else{
	//c_id=getQueryString("c_id");
	//$.cookie('THE_SET_COMPANYLOOKID', c_id, { path: '/' });
//}
if(!GetAddNew(getQueryString("type"))){//企业规范类型
	type=getQueryString("type");
}
if(!GetAddNew(getQueryString("title"))){//标题
	title=getQueryString("title");
}
if(!GetAddNew(getQueryString("desc"))){//说明
	desc=getQueryString("desc");
}

// 删除图片
$("#recordGf").on('click', '.img-delete', function(event) {
	var self=this;
	var $inputImgPath=$(this).parents("td").find(".imgPath");
	var deleteImg=$(this).parents(".imgBox").find(".img-delete");
	$.each(deleteImg, function(index, val) {
		if(val==self){
			$(self).closest('.imgDiv').remove();
			imgPath=[];
			imgPath=$inputImgPath.val().split("|");
			imgPath.del(index);
			$inputImgPath.val(imgPath.join("|"));
			console.log("$inputImgPath: "+$inputImgPath.val());
					// filesArray.del(index);
					// console.log(filesArray);
			if(imgPath.length > 19){
				$(self).parents(".fileInput").css("display","none");
			}else{
				$(self).parents(".fileInput").css("display","");
			}
			return false;
		}
	});
});

function companyInfoData(res){
	var data = GetOjson(json_parse(res));
	
	console.log(data);
	if(data.status == "0"){

		autoH();
	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else{
		layer.open({
			type:1
			,title: '提示'
			,content: data.info
			,area:["280px","120px"]
			,btn: ['确定']
			,yes: function(index, layero){
				layer.close(index);
			}
			,cancel: function(){ 
					//右上角关闭回调
					//return false 开启该代码可禁止点击该按钮关闭
				}
			});
	}
}

function companyRecordData(res){
	$("#recordGf").children().remove();
	var data = GetOjson(json_parse(res));
	pcount = data.paramcentcount;
	var ps = pcent.GetCentPage(pindex, pcount, psize);
	$("#page").html(ps);
	console.log(data);
	if(data.status == "0"){
		$.each(data.param,function(i,item){
			var html="",htmlImg="";
			var imgList=item.path.split("|");
			console.log(imgList);
			for(var i=0;i<imgList.length;i++){
				htmlImg+='<a href="javascript:void(0)" class="img-list imgDiv" title="图片">'+
				'<img src="'+imgList[i]+'" class="img" alt="图片" />'+
				'</a>';
			}
			html='<tr>'+
				'<td class="hs" data-date="'+item.upDate2+'">'+item.upDate+'</td>'+
				'<td class="hs text-left">'+
				'<div class="imgBox">'+
				htmlImg+
				'</div>'+
				'<input type="hidden" value="'+item.path+'" class="imgPath" />'+
				'</td>';
				$("#recordGf").append(html);
				//dataFormat();
				autoH();
		})
		
		autoH();
	}else if(data.status == "9"){
		window.location.href="login.html";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else if(data.status == "1"){
		// var html="";
		// var dt=updateDate();		
		// html='<tr class="addT">'+
		// '<td class="hs" data-date="'+dt[1]+'">'+dt[0]+'</td>'+
		// '<td class="hs text-left">'+
		// '<div class="imgBox">'+
		// '<a href="javascript:void(0);" class="fileInput foodFileInfo">'+
		// '<input name="file" type="file" onchange="upLoad(this.files[0],this)" accept="image/gif,image/jpeg,image/jpg,image/png" value="" class="img-add" />'+
		// '</a>'+
		// '</div>'+
		// '<input type="hidden" value="" class="imgPath" />'+
		// '</td>'+
		// '<td class="hs ls"><a href="javascript:void(0);" class="save">保存</a>'+
		// '<span class="fg-line ls">|</span>'+
		// '<a href="javascript:void(0);" class="del">删除</a></td>'+
		// '</tr>';
		// $("#recordGf").append(html);
		// //dataFormat();
		// autoH();
	}else{
		layer.open({
			type:1
			,title: '提示'
			,content: data.info
			,area:["280px","140px"]
			,btn: ['确定']
			,yes: function(index, layero){
				layer.close(index);
			}
			,cancel: function(){ 
					//右上角关闭回调
					//return false 开启该代码可禁止点击该按钮关闭
				}
			});
	}
}
function companyInfo(c_id,pindex, psize){
	$("#recordGf").html("<tr class='loading'><td colspan='2' style='padding:20px 0;text-align: center;'><img src='../style/image/load.gif' width='32px' height='32px' /></td></tr>");
	var wxjson = new webjson("67"); //设置action值
		//新增param键值
	wxjson.AddParam("c_id", c_id);
	wxjson.AddParam("type", type);
	wxjson.AddParam("page_index", pindex);
	wxjson.AddParam("page_size", psize);
	WebRequestAsync(wxjson, companyRecordData);

}
//保存
//function companyRecordSave(res){
//	
//}
function updateDate(){
		var date = new Date();
		var year = date.getFullYear();
		var month = date.getMonth()+1;
		var day = date.getDate();
		var hour = date.getHours();
		var minute = date.getMinutes();
		var second = date.getSeconds();
		var dateArr=[];
		dateArr.push(year+'年'+month+'月'+day+'日');
		dateArr.push(year+'年'+month+'月'+day+'日 '+hour+':'+minute+':'+second);
		return dateArr;
	}
$(function(){
	$.divselect("#mySelect","#inputmySelect");
	$("#mySelect li").on("click",function(){
		//切换每页显示的记录数
		if($("#inputmySelect").val() != psize){
			psize = $("#inputmySelect").val();
			pindex=1;
			companyInfo(c_id,pindex, psize);
		}
	})
	//dataFormat();
	$(".companyName").text($.cookie('THE_SET_COMPANYNAME'));//从内存中获取企业名称
	$(".h3-title").text(title);
	$(".companyTitle").text(title);
	$(".desc").text(desc);
	companyInfo(c_id,pindex, psize);//获取记录信息,参数:企业id

	$("#recordGf").on("click",".save",function(){
		var update=$(this).parents("tr").find("td").eq(0);
		var currentImg=$(this).parents("tr").find("td").eq(1);
		if(update.text().length == 0){
			layer.msg("请选择更新日期");
		}else if(currentImg.find(".imgPath").val().length == 0){
			layer.msg("请选择图片");
		}else{
			var wxjson = new webjson("15"); //设置action值
				//新增param键值
			wxjson.AddParam("c_id", c_id);
			wxjson.AddParam("type", type);
			wxjson.AddParam("path", currentImg.find(".imgPath").val());
			wxjson.AddParam("upDate", update.data("date"));
			var res=WebRequest(wxjson);
			$(this).attr("disabled",false);
			var data = GetOjson(json_parse(res));
			
			console.log(data);
			if(data.status == "0"){
				//companyInfo(c_id);
				$(this).parents("tr").removeClass("addT");
				layer.msg(data.info);
			}else if(data.status == "9"){
				window.location.href="login.html";
				return;
			}else if(data.status== "10"){
				console.log(data.info);
			}else{
				layer.open({
					type:1
					,title: '提示'
					,content: data.info
					,area:["280px","140px"]
					,btn: ['确定']
					,yes: function(index, layero){
						layer.close(index);
					}
					,cancel: function(){ 
							//右上角关闭回调
							//return false 开启该代码可禁止点击该按钮关闭
						}
				});
			}
		}
	})
	$("#recordGf").on("click",".del",function(){//删除
		if($(this).parents("tr").hasClass("addT")){
			$(this).parents("tr").remove();
		}else{
			var update2=$(this).parents("tr").find("td").eq(0);
			var wxjson = new webjson("14"); //设置action值
					//新增param键值
			wxjson.AddParam("c_id", c_id);
			wxjson.AddParam("type", type);
			wxjson.AddParam("upDate", update2.data("date"));
			var res=WebRequest(wxjson);
			var data = GetOjson(json_parse(res));
		
			console.log(data);
			if(data.status == "0"){
				layer.msg(data.info);
				companyInfo(c_id,pindex, psize);
			}else if(data.status == "9"){
				window.location.href="login.html";
				return;
			}else if(data.status== "10"){
				console.log(data.info);
			}else{
				layer.open({
					type:1
					,title: '提示'
					,content: data.info
					,area:["280px","140px"]
					,btn: ['确定']
					,yes: function(index, layero){
						layer.close(index);
					}
					,cancel: function(){ 
							//右上角关闭回调
							//return false 开启该代码可禁止点击该按钮关闭
						}
				});
			}
		}
		
	})
	$("#addNew").on("click",function(){
		var htmlTr="";
		var dt=updateDate();
		htmlTr='<tr class="addT">'+
		'<td class="hs" data-date="'+dt[1]+'">'+dt[0]+'</td>'+
		'<td class="hs text-left">'+
		'<div class="imgBox">'+
		'<a href="javascript:void(0);" class="fileInput foodFileInfo">'+
		'<input name="file" type="file" onchange="upLoad(this.files[0],this)" accept="image/gif,image/jpeg,image/jpg,image/png" value="" class="img-add" />'+
		'</a>'+
		'</div>'+
		'<input type="hidden" value="" class="imgPath" />'+
		'</td>'+
		'<td class="hs ls"><a href="javascript:void(0);" class="save">保存</a>'+
		'<span class="fg-line ls">|</span>'+
		'<a href="javascript:void(0);" class="del">删除</a></td>'+
		'</tr>';
		if($("#recordGf").children().length > 0){
			var trFrist=$("#recordGf").find("tr").eq(0);
			trFrist.before(htmlTr);
		}else{
			$("#recordGf").append(htmlTr)
		}
		
		//dataFormat();
		autoH();
	})
	//预览图片
	$("#recordGf").on("click",".imgDiv .img",function(){
		var imgA=$(this).parents(".hs").find(".imgPath").val().split("|");
		console.log("-------------");
		console.log(imgA);
		var imgContent="",imgPhoto="";
		for(var i=0;i<imgA.length;i++){
		
			imgPhoto+='<li><img src='+imgA[i]+' alt="Picture"></li>'
		}
		imgContent='<div class="img-warp">'+
		'<div class="imgDiv">'+
		'<ul class="images">'+
		imgPhoto+
		'</ul>'+
		'</div>'+
		'</div>'
		layer.open({
			title: '图片查看'
			,content: imgContent
			,area: ['600px', 'auto']
			,btn: []
			,cancel: function(){ 
				//右上角关闭回调
				//return false 开启该代码可禁止点击该按钮关闭
			}
		});
		$('.images').viewer({
			inline:true
		});
	})
//	$("#recordGf").on("change",".img-add",function(){
//		upLoad(this.files[0],this);
//	})
	getActiveN("a11", "a1100");//当前页标志

})