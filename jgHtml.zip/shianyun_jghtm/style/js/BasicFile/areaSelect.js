/*
* @Author: yangjy
* @Date:   2017-08-05 11:45:51
* @Last Modified time: 2017-08-07 12:48:16
*/
var ltype="0";
function areaData(res){
  var data = GetOjson(json_parse(res));
  if(data.status == "0"){
    if(ltype == "0"){
      $(".province").html("");
      var html="";
      $.each(data.param,function(i,item){
        html+='<li class="li-dq" data-did="'+item.did+'">'+item.dname+'</li>';
      })
      $(".province").append(html);
      $(".city").html("");
      $(".district").html("");
      $(".street").html("");
    }else if(ltype == "1"){
      $(".city").html("");
      var html="";
      $.each(data.param,function(i,item){
        html+='<li class="li-dq" data-did="'+item.did+'">'+item.dname+'</li>';
      })
      $(".city").append(html);
      $(".district").html("");
      $(".street").html("");
    }else if(ltype == "2"){
      $(".district").html("");
      var html="";
      $.each(data.param,function(i,item){
        html+='<li class="li-dq" data-did="'+item.did+'">'+item.dname+'</li>';
      })
      $(".district").append(html);
      $(".street").html("");
    }else if(ltype == "3"){
      $(".street").html("");
      var html="";
      $.each(data.param,function(i,item){
        html+='<li class="li-dq" data-did="'+item.did+'">'+item.dname+'</li>';
      })
      $(".street").append(html);
    }
  }else if(data.status == "9"){
    window.location.href="index.html?loginOut=true";
    return;
  }else{
    console.log(data.info);
  }
}

function area(ltype,skey){//调用地区数据接口
  var wxjson = new webjson("17"); //设置action值
  //新增param键值
  wxjson.AddParam("ltype", ltype);
  wxjson.AddParam("skey", skey);
  WebRequestAsync(wxjson, areaData);
}
function areaReset(){//重置地区选择框
  $(".area-list").css("display","none");
    $(".area-list").eq(0).css("display","block");
    $(".area-list").find(".li-dq").removeClass("currentli");
    $(".area-choose span").text("请选择地区");
    $(".area-nav a").eq(0).addClass("current").siblings().removeClass("current");
    $("#inputChoose").val("");
}
$(function(){
    area(ltype,"");//调用地区列表
    $(".area-close").on("click",function(){//关闭按钮
      $(".area-content").css("display","none");
    })
    $(".area-reset").on("click",function(){//重置按钮
      areaReset();
    })
    $(".area-choose span").on("click",function(){//地区选择框展开收起
      if($(".area-content").css("display") == "none"){
        $(".area-content").css("display","block");
      }else{
        $(".area-content").css("display","none");
      }
    })
    $(".area-confirm").on("click",function(){//确定按钮
      var textSpan=$(".area-list").eq(0).find(".currentli").text()+$(".area-list").eq(1).find(".currentli").text()+$(".area-list").eq(2).find(".currentli").text()+$(".area-list").eq(3).find(".currentli").text()
      $(".area-choose span").text(textSpan);
      var textProvince="",textCity="",textDistrict="",textStreet="";
      if($(".area-list").eq(3).find(".li-dq").hasClass("currentli")){
        textProvince=$(".area-list").eq(0).find(".currentli").data("did")+","+$(".area-list").eq(0).find(".currentli").text();
        textCity=$(".area-list").eq(1).find(".currentli").data("did")+","+$(".area-list").eq(1).find(".currentli").text();
        textDistrict=$(".area-list").eq(2).find(".currentli").data("did")+","+$(".area-list").eq(2).find(".currentli").text();
        textStreet=$(".area-list").eq(3).find(".currentli").data("did")+","+$(".area-list").eq(3).find(".currentli").text();
        $("#inputChoose").val(textProvince+"|"+textCity+"|"+textDistrict+"|"+textStreet);
      }else if($(".area-list").eq(2).find(".li-dq").hasClass("currentli")){
        textProvince=$(".area-list").eq(0).find(".currentli").data("did")+","+$(".area-list").eq(0).find(".currentli").text();
        textCity=$(".area-list").eq(1).find(".currentli").data("did")+","+$(".area-list").eq(1).find(".currentli").text();
        textDistrict=$(".area-list").eq(2).find(".currentli").data("did")+","+$(".area-list").eq(2).find(".currentli").text();
        $("#inputChoose").val(textProvince+"|"+textCity+"|"+textDistrict);
      }else if($(".area-list").eq(1).find(".li-dq").hasClass("currentli")){
        textProvince=$(".area-list").eq(0).find(".currentli").data("did")+","+$(".area-list").eq(0).find(".currentli").text();
        textCity=$(".area-list").eq(1).find(".currentli").data("did")+","+$(".area-list").eq(1).find(".currentli").text();
        $("#inputChoose").val(textProvince+"|"+textCity);
      }else if($(".area-list").eq(0).find(".li-dq").hasClass("currentli")){
        textProvince=$(".area-list").eq(0).find(".currentli").data("did")+","+$(".area-list").eq(0).find(".currentli").text();
        $("#inputChoose").val(textProvince);
      }else{
        $("#inputChoose").val("");
        $(".area-choose span").text("请选择地区");
      }
      $(".area-content").css("display","none");
    })
    $(".area-list").on("click",".li-dq",function(){//点击某一地区
      var index=$(this).parent(".area-list").index();
      if(!$(this).hasClass("currentli")){
        $(this).addClass("currentli").siblings().removeClass("currentli");
        if(index < 3){
          $(".area-nav a").eq(index+1).addClass("current").siblings().removeClass("current");
          $(".area-list").css("display","none");
          $(".area-list").eq(index+1).css("display","block");
          ltype=index+1;
          if(GetAddNew($(this).data("did"))){
            $(".city").html("");
            $(".district").html("");
            $(".street").html("");
          }else{
            area(ltype,$(this).data("did"));
          }
        }
      }else{
        $(this).removeClass("currentli");
        if(index == 0){
          $(".area-list").eq(1).children().remove();
          $(".area-list").eq(2).children().remove();
          $(".area-list").eq(3).children().remove();
        }else if(index == 1){
          $(".area-list").eq(2).children().remove();
          $(".area-list").eq(3).children().remove();
        }else if(index == 2){
          $(".area-list").eq(3).children().remove();
        }else{}
        
      }
    })
    $(".area-nav a").on("click",function(){//点击地区导航条
      var aIndex=$(this).index();
      var currentIndex=$("a.current").index();
      if($(this).hasClass("current") || GetAddNew($(".area-list").eq(aIndex).html())){
        return;
      }
      if(aIndex < $(".area-nav a.current").index() || $(".area-list").eq(aIndex-1).find(".li-dq").hasClass("currentli")){
        $(".area-nav a").eq(aIndex).addClass("current").siblings().removeClass("current");
        $(".area-list").css("display","none");
        $(".area-list").eq(aIndex).css("display","block");
      }
    })
  })