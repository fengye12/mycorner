/*
* @Author: yangjy
* @Date:   2017-07-13 11:45:51
* @Last Modified time: 2017-08-29 12:48:16
*/
autoH();//左右高度自适应autoH();//左右高度自适应
var a1 = "a11",a2 = "a1105";//当前页代码
var sskey="",//用户输入的搜索关键字
	ssmode=$("#inputssmode").val(),//搜索：0精确查询，1模糊查询
	sssel=$("#inputsssel").val(),//搜索类型：0所有类型，
	bbtype=checkBoxFormat($(".f-bbtype")),//报备类型
	jytime="",
	bbtime="";

var ecount = $("#inputmySelect").val();//每页显示的记录数
var cpage01 = new CentPage();//实例化分页插件
var pagenum = 1;//初始当前页
var paramcentcount=0;//总记录数
var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);//初始化分页设置
$("#page").html(cents);

function getQueryString(name) {//获取url传递的参数：name为需要获取的参数名称
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var search = window.location.search.substr(1);
	var href = window.location.href;
	if(href.indexOf("?") >= 0) {
		search = href.substr(href.indexOf("?") + 1);
	}
	var r = search.match(reg);
	if(r != null) return unescape(r[2]);
	return null;
}

function CentPageOper(pnum){//点击某一页时调用此方法
	cents = cpage01.GetCentPage(pnum,paramcentcount,ecount);
	$("#page").html(cents);
	pagenum=pnum;
	billList(sskey,ssmode,sssel,jytime,bbtime,bbtype,pagenum,ecount);
}

function billData(res){//获取台账列表数据
	$("#inquiry").attr("disabled",false);
	$("#confirBtn").attr("disabled",false);
	$("#billList").children().remove();
	var data = GetOjson(json_parse(res));
	paramcentcount=data.paramcentcount;
	$(".total-num").text("共"+paramcentcount+"条");
	var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);
	$("#page").html(cents);
	if(data.status =="0"){
		$.each(data.param,function(i,item){
			var html="",jytype="";
			if(item.jytype == "0"){
				jytype="食品采购报备";
			}else{
				jytype="食品销售报备";
			}
			html='<tr>'+
			'<td class="hs">'+item.cname+'</td>'+
			'<td class="hs">'+item.bbdate+'</td>'+
			'<td class="hs">'+jytype+'</td>'+
			'<td class="hs">'+item.jycname+'</td>'+
			'<td class="hs">'+item.jydate+'</td>'+
			'<td class="hs"><span class="ls" data-billcode='+item.billcode+'>查看</span></td>'+
			'</tr>'
			$("#billList").append(html);
			
		})
		$("#mySelect").css("display","");
		autoH();
	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else{
		$("#billList").append("<tr class='loading'><td colspan='6' style='padding:20px 0;text-align: center;'>"+data.info+"</td></tr>");
	}
}

function billList(sskey,ssmode,sssel,jytime,bbtime,bbtype,pagenum,ecount){//请求企业列表
	$("#inquiry").attr("disabled",true);//查询按钮
	$("#confirBtn").attr("disabled",true);//高级搜索查询按钮
	$("#mySelect").css("display","none");
	$("#billList").children().remove();
	$("#billList").append("<tr class='loading'><td colspan='6' style='padding:20px 0;text-align: center;'><img src='../style/image/load.gif' width='32px' height='32px' /></td></tr>");
	var wxjson = new webjson("31"); //设置action值
	//新增param键值
	if(sskey == "请输入关键字进行查询"){
		sskey="";
	}
	wxjson.AddParam("cid", "");

	wxjson.AddParam("sskey", Trim(sskey));
	wxjson.AddParam("ssmode", ssmode);
	wxjson.AddParam("sssel", sssel);

	wxjson.AddParam("jytype", bbtype);
	wxjson.AddParam("bbdate", bbtime);
	wxjson.AddParam("jydate", jytime);
	wxjson.AddParam("page_index", pagenum);
	wxjson.AddParam("page_size", ecount);
	WebRequestAsync(wxjson, billData);
	jsonParam=wxjson.GetJsons();
}

function photoData(res){
	var data = GetOjson(json_parse(res));
	if(data.status =="0" && data.param.length > 0){
		//var photos=data.param[0].bppath.split(",");
		var imgContent="",imgPhoto="";
		for(var i=0;i<data.param.length;i++){
			imgPhoto+='<li><img src='+data.param[i].bppath+' alt="Picture"></li>'
		}
		imgContent='<div class="img-warp">'+
		'<div class="imgDiv">'+
		'<ul class="images">'+
		imgPhoto+
		'</ul>'+
		'</div>'+
		'</div>'
		layer.open({
			title: '图片查看'
			,content: imgContent
			,area: ['600px', 'auto']
			,btn: []
			,cancel: function(){ 
				//右上角关闭回调
				//return false 开启该代码可禁止点击该按钮关闭
			}
		});
		$('.images').viewer({
			inline:true
		});
	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else{
		layer.open({
			title: '提示'
			,content: data.info
			,btn: ['确定']
			,yes: function(index, layero){
				layer.close(index);
			}
			,cancel: function(){ 
				//右上角关闭回调
				//return false 开启该代码可禁止点击该按钮关闭
			}
		});
	}	
}

$(function(){
	$.divselect("#sssel","#inputsssel");
	$.divselect("#ssmode","#inputssmode");
	$.divselect("#mySelect","#inputmySelect");
	$("#mySelect li").on("click",function(){
		//切换每页显示的记录数
		if($("#inputmySelect").val() != ecount){
			ecount = $("#inputmySelect").val();
			pagenum=1;
			billList(sskey,ssmode,sssel,jytime,bbtime,bbtype,pagenum,ecount);
		}
	})
	$(".total-num").text("共"+paramcentcount+"条");
	billList(sskey,ssmode,sssel,jytime,bbtime,bbtype,pagenum,ecount);//调用票据列表
	
	$(".companyName").text($.cookie('THE_SET_COMPANYNAME'));//从内存中获取企业名称
	//搜索
	$("#inquiry").on("click",function(){
		sskey=$(".inputWraper .foodName").val();//用户输入的搜索关键字
		ssmode=$("#inputssmode").val();//搜索：0精确查询，1模糊查询
		sssel=$("#inputsssel").val();//搜索类型：0所有类型，
		bbtype="";//报备类型
		jytime="";
		bbtime="";
		pagenum=1;
		billList(sskey,ssmode,sssel,jytime,bbtime,bbtype,pagenum,ecount);
	})
	//高级搜索
	$("#confirBtn").on("click",function(){
		if(date()){
			var startDaobei=$("#bbDate").children("input.dateStart").val();
			var endDaobei = $("#bbDate").children("input.dateEnd").val();
			//交易日期验证jyDate
			var startJy = $("#jyDate").children("input.dateStart").val();
			var endJy = $("#jyDate").children("input.dateEnd").val()

			if(GetAddNew(startDaobei) && GetAddNew(endDaobei)){
				bbtime="";
			}else{
				bbtime=startDaobei+','+endDaobei;
			}
			if(GetAddNew(startJy) && GetAddNew(endJy)){
				jytime="";
			}else{
				jytime=startJy+','+endJy;
			}

			sskey=$(".inputWraper .foodName").val();//用户输入的搜索关键字
			ssmode=$("#inputssmode").val();//搜索：0精确查询，1模糊查询
			sssel=$("#inputsssel").val();//搜索类型：0所有类型，
			bbtype=checkBoxFormat($(".f-bbtype")),//报备类型
			pagenum=1;
			billList(sskey,ssmode,sssel,jytime,bbtime,bbtype,pagenum,ecount);
			
			//ecount = $("#mySelect option:selected").val();//每页显示的记录数
		}
		
	})
	
	$("#billList").on("click",".ls",function(){//查看票据
		var wxjson = new webjson("32"); //设置action值
		//新增param键值
		wxjson.AddParam("billcode", $(this).data("billcode"));
		WebRequestAsync(wxjson, photoData);
	})
	
	getActiveN("a11", "a1105");//当前页标志
	
	$(".inputWraper input").on("keydown",function(event){//按下回车执行查询
	    var event=event || window.event;
	    if(event.keyCode == "13") {//判断如果按下的是回车键则执行下面的代码
	    	$("#inquiry").click();
	    }
	})
})



