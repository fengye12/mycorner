/*
* @Author: yangjy
* @Date:   2017-07-12 11:45:51
* @Last Modified time: 2017-08-19 19:24:51
*/

//var a1 = "a12",a2 = "a1203";//当前页代码
var ecount = $("#inputmySelect").val();//每页显示的记录数
var cpage01 = new CentPage();//实例化分页插件
var pagenum = 1;//初始当前页
var paramcentcount=0;//总记录数
var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);//初始化分页设置
$("#page").html(cents);

function CentPageOper(pnum){//点击某一页时调用此方法
	cents = cpage01.GetCentPage(pnum,paramcentcount,ecount);
	$("#page").html(cents);
	pagenum=pnum;
	removeComList();
}


function getQueryString(name) {//获取url传递的参数：name为需要获取的参数名称
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var search = window.location.search.substr(1);
	var href = window.location.href;
	if(href.indexOf("?") >= 0) {
		search = href.substr(href.indexOf("?") + 1);
	}
	var r = search.match(reg);
	if(r != null) return unescape(r[2]);
	return null;
}

//移除企业列表
function removeComData(res){//获取移除企业列表数据
	$("#removeComList").children().remove();
	var data = GetOjson(json_parse(res));
	console.log(data);
	paramcentcount=data.paramcentcount;
	$(".total-num").text("共"+paramcentcount+"家企业");
	var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);
	$("#page").html(cents);
	if(data.status =="0"){
		$.each(data.param,function(i,item){

			var html="",ctype1="",cstatus1="";
			if(item.ENTERPRISE_TYPE == "0"){
				ctype1="生产企业";
			}else if(item.ENTERPRISE_TYPE == "1"){
				ctype1="销售经营企业";
			}else if(item.ENTERPRISE_TYPE == "2"){
				ctype1="餐饮服务企业";
			}else if(item.ENTERPRISE_TYPE == "3"){
				ctype1="单位食堂";
			}else{
				ctype1="";
			}
			
			if(item.ENTERPRISE_STATUS == "0"){
				cstatus1="正常经营";
			}else if(item.ENTERPRISE_STATUS == "1"){
				cstatus1="未注册";
			}else if(item.ENTERPRISE_STATUS == "2"){
				cstatus1="停产";
			}else if(item.ENTERPRISE_STATUS == "3"){
				cstatus1="转让";
			}else{
				cstatus1="";
			}

			html='<tr>'+
			'<td class="hs">'+item.ENTERPRISE_NAME+'</td>'+
			'<td class="hs">'+item.BUSSINESS_CODE+'</td>'+
			'<td class="hs">'+item.ADDRESS+'</td>'+
			'<td class="hs">'+item.LEGAL+'</td>'+
			'<td class="hs" data-deptcode="'+item.DEPT_CODE+'">'+item.DEPT_NAME+'</td>'+
			'<td class="hs">'+ctype1+'</td>'+
			'<td class="hs">'+cstatus1+'</td>'+
			'<td class="hs"><a href="javascript:void(0);" class="text-red">'+item.WARMING_INFO+'</a></td>'+
			'<td class="hs" data-enterpriseid="'+item.ENTERPRISE_ID+'"><span class="cancelRemove ls">取消移除</span></td>'+
			'</tr>';
			$("#removeComList").append(html);
		})
	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status== "10"){
		layer.msg(data.info);
	}else{
		$("#removeComList").append("<tr class='loading'><td colspan='9' style='padding:20px 0;text-align: center;'>"+data.info+"</td></tr>");
	}
}
/*移除名单*/
function removeComList(){
	$("#removeComList").children().remove();
	$("#removeComList").append("<tr class='loading'><td colspan='9' style='padding:20px 0;text-align: center;'><img src='../style/image/load.gif' width='32px' height='32px' /></td></tr>");
	var wxjson = new webjson("58"); //设置action值
	//新增param键值

	wxjson.AddParam("deptid", $.cookie('departmentid'));//监管单位id
	wxjson.AddParam("typeid", getQueryString("c_id"));//企业类型id
	//wxjson.AddParam("keyword", "");

	//wxjson.AddParam("status", "3");//0点击操作里面的查看,1查看报备企业,2查看未报备企业,3查看移除企业名单

	wxjson.AddParam("page_index", pagenum);
	wxjson.AddParam("page_size", ecount);
	WebRequestAsync(wxjson, removeComData);
}

$(function(){
	// $.divselect("#sssel","#inputsssel");
	// $.divselect("#ssmode","#inputssmode");
	/*移除名单*/
		$.divselect("#mySelect","#inputmySelect");
		$("#mySelect li").on("click",function(){
			//切换每页显示的记录数
			if($("#inputmySelect").val() != ecount){
				ecount = $("#inputmySelect").val();
				pagenum=1;
				removeComList();
			}
		})
		removeComList();
		//取消移除
		$("#removeComList").on("click",".cancelRemove",function(){
			var _this=$(this);
			var wxjson = new webjson("56"); //设置action值
					//新增param键值
			wxjson.AddParam("enterpriseid", _this.parent("td").data("enterpriseid"));//企业id
			wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
			wxjson.AddParam("typeid", getQueryString("c_id"));//企业类别id
			wxjson.AddParam("flag", "1");//flag:0移除，1取消移除
			var res=WebRequest(wxjson);
			var data = GetOjson(json_parse(res));
			console.log(data);
			if(data.status == "0"){
				$("#isRemove").val("1");
				removeComList();
				layer.msg(data.info);
			}else if(data.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else{
				layer.msg(data.info);
			}
		})	

	//getActiveN("a12", "a1203");//当前页标志


})



