/*
* @Author: yangjy
* @Date:   2017-07-12 11:45:51
* @Last Modified time: 2017-10-19 15:22:44
*/
autoH();//左右高度自适应autoH();//左右高度自适应
var a1 = "a11",a2 = "a1102";//当前页代码
var sskey="",//用户输入的搜索关键字
	ssmode=$("#inputssmode").val(),//搜索：0精确查询，1模糊查询
	sssel=$("#inputsssel").val();//搜索类型：0所有类型，

var ecount = $("#inputmySelect").val();//每页显示的记录数
var cpage01 = new CentPage();//实例化分页插件
var pagenum = 1;//初始当前页
var paramcentcount=0;//总记录数
var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);//初始化分页设置
$("#page").html(cents);

function CentPageOper(pnum){//点击某一页时调用此方法
	cents = cpage01.GetCentPage(pnum,paramcentcount,ecount);
	$("#page").html(cents);
	pagenum=pnum;
	personFilesList(sskey,ssmode,sssel,pagenum,ecount);
}

function personFilesData(res){//获取企业列表数据
	$("#inquiry").attr("disabled",false);
	$("#personFilesList").children().remove();
	var data = GetOjson(json_parse(res));
	paramcentcount=data.paramcentcount;
	$(".total-num").text("共"+paramcentcount+"条");
	var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);
	$("#page").html(cents);
	if(data.status =="0"){
		var html="";
		$.each(data.param,function(i,item){
			 var job1=item.job;
					   var jobTotal="",workStatus="";
					   if(job1==""){
						   jobTotal="";
					   }else{
						   job1=item.job.split(",");
					   }
					   if(item.workStatus==0){
					   	  workStatus="全职";
					   }else if(item.workStatus==1){
					   	  workStatus="兼职";
					   }else if(item.workStatus==2){
					   	  workStatus="离职";
					   }else{
					   	  workStatus="";
					   }
					   for(var j=0;j<job1.length;j++){
						if(job1[j] == 0) {
							jobTotal = jobTotal+'负责人、';
						} else if(job1[j] == 1) {
							jobTotal = jobTotal+'原辅料管理员、';
						}else if(job1[j] == 2) {
							jobTotal = jobTotal+'添加剂管理员、';
						}else if(job1[j] == 3) {
							jobTotal = jobTotal+'食品安全管理员、';
						}else if(job1[j] == 4) {
							jobTotal = jobTotal+'食品安全检验员、';
						}else if(job1[j] == 5) {
							jobTotal = jobTotal+'食品安全技术员、';
						}else{
							jobTotal="";
						}
						}
					    jobTotal=jobTotal.substr(0,jobTotal.length-1);
					    var cstatusStyle=item.cstatus==1?"":"color:red";
			html='<tr>'+
			'<td class="hs">'+item.name+'</td>'+
			'<td class="hs">'+item.enterprise_name+'</td>'+
			'<td class="hs">'+item.id_number+'</td>'+
			'<td class="hs">'+item.tel+'</td>'+
			'<td class="hs">'+jobTotal+'</td>'+
			'<td class="hs">'+workStatus+'</td>'+
			'<td class="hs" style="'+cstatusStyle+'">'+(item.cstatus==1?"已上传":"未上传")+'</td>'+
			'<td class="hs"><a href="personnel_filesInfo.html?cid='+item.c_id+'" target="_blank" class="person-detail">查看</a></td>'+
			'</tr>'
			$("#personFilesList").append(html);
		})
		$("#mySelect").css("display","");
		autoH();
	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else{
		$("#personFilesList").append("<tr class='loading'><td colspan='8' style='padding:20px 0;text-align: center;'>"+data.info+"</td></tr>");
	}
}

function personFilesList(sskey,ssmode,sssel,pagenum,ecount){//请求企业列表
	$("#inquiry").attr("disabled",true);
	$("#mySelect").css("display","none");
	$("#personFilesList").children().remove();
	$("#personFilesList").append("<tr class='loading'><td colspan='8' style='padding:20px 0;text-align: center;'><img src='../style/image/load.gif' width='32px' height='32px' /></td></tr>");
	var wxjson = new webjson("69"); //设置action值
	//新增param键值
	if(sskey == "请输入关键字进行查询"){
		sskey="";
	}
	var dept_code=$.cookie('dep_code')?$.cookie('dep_code'):"";
	wxjson.AddParam("cid", "");
	wxjson.AddParam("dept_code",dept_code );
	wxjson.AddParam("keyword", Trim(sskey));
	// wxjson.AddParam("ssmode", ssmode);
	// wxjson.AddParam("sskey", ssmode);
	// wxjson.AddParam("sssel", sssel);
	wxjson.AddParam("page_index", pagenum);
	wxjson.AddParam("page_size", ecount);
	WebRequestAsync(wxjson, personFilesData);
	jsonParam=wxjson.GetJsons();
}

$(function(){
	$.divselect("#sssel","#inputsssel");
	$.divselect("#ssmode","#inputssmode");
	$.divselect("#mySelect","#inputmySelect");
	$("#mySelect li").on("click",function(){
		//切换每页显示的记录数
		if($("#inputmySelect").val() != ecount){
			ecount = $("#inputmySelect").val();
			pagenum=1;
			personFilesList(sskey,ssmode,sssel,pagenum,ecount);//调用交易对象列表
		}
	})
	$(".total-num").text("共"+paramcentcount+"条");
	personFilesList(sskey,ssmode,sssel,pagenum,ecount);//调用交易对象列表
	//搜索
	$("#inquiry").on("click",function(){
		sskey=$(".inputWraper .foodName").val(),//用户输入的搜索关键字
		ssmode=$("#inputssmode").val(),//搜索：0精确查询，1模糊查询
		sssel=$("#inputsssel").val(),//搜索类型：0所有类型，
		personFilesList(sskey,ssmode,sssel,pagenum,ecount);
	})

	getActiveN("a11", "a1102");//当前页标志

	$(".inputWraper input").on("keydown",function(event){//按下回车执行查询
	    var event=event || window.event;
	    if(event.keyCode == "13") {//判断如果按下的是回车键则执行下面的代码
	    	$("#inquiry").click();
	    }
	})
})



