/*
* @Author: yangjy
* @Date:   2017-07-12 11:45:51
* @Last Modified time: 2017-07-12 12:48:16
*/
//var a1 = "a11",a2 = "a1100";//当前页代码
var c_id=$.cookie('THE_SET_COMPANYID');//企业id
autoH();//左右高度自适应autoH();//左右高度自适应
var a1 = "a11",a2 = "a1100";//当前页代码
function getQueryString(name) {//获取url传递的参数：name为需要获取的参数名称
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var search = window.location.search.substr(1);
	var href = window.location.href;
	if(href.indexOf("?") >= 0) {
		search = href.substr(href.indexOf("?") + 1);
	}
	var r = search.match(reg);
	if(r != null) return unescape(r[2]);
	return null;
}

// if(GetAddNew(getQueryString("c_id"))){//优先判断url有参数(c_id)的话存进本地缓存，若没有则从缓存中读取企业c_id
// 	c_id=$.cookie('THE_SET_COMPANYID')
// }else{
// 	c_id=getQueryString("c_id");
// 	$.cookie('THE_SET_COMPANYLOOKID', c_id, { path: '/' });
// }

function companyGfData(res){
	var data = GetOjson(json_parse(res));
	
	console.log(data);
	if(data.status == "0"){
		$.each(data.param,function(i,item){
			//var liData=$(".li-warp");
			var item=item;
			$.each($(".li-warp"),function(index,value){
				if(item.type == $(this).data("type")){
					$(this).find(".update-date").text(item.upDate);
					var img=item.path.split("|");
					for(var n=0;n<img.length;n++){
						var html="";
						if($(this).find(".addGf a").hasClass("record")){
							html='<li>'+
							'<a href="javascript:void(0);" class="record">'+
							'<img src="'+img[n]+'" alt="tp" />'+
							'</a>'+
							'</li>';
						}else if($(this).find(".addGf a").hasClass("system")){
							html='<li>'+
							'<a href="javascript:void(0);" class="system">'+
							'<img src="'+img[n]+'" alt="tp" />'+
							'</a>'+
							'</li>';
						}else{
							console.log("判断错误");
						}
						
						$(this).find(".addGf").before(html);
					}
					
				}
			})
			
		})

	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else if(data.status == "1"){
		console.log(data.info);
	}else{
		layer.open({
			type:1
			,title: '提示'
			,content: data.info
			,area:["280px","140px"]
			,btn: ['确定']
			,yes: function(index, layero){
				layer.close(index);
			}
			,cancel: function(){ 
					//右上角关闭回调
					//return false 开启该代码可禁止点击该按钮关闭
				}
			});
	}
}

function companyGf(c_id){
	
	$.each($(".img-warp li"),function(i,item){
		if(!$(this).hasClass("addGf")){
			$(this).remove();
		}
	})
	var wxjson = new webjson("66"); //设置action值
		//新增param键值
	wxjson.AddParam("c_id", c_id);
	WebRequestAsync(wxjson, companyGfData);
}

$(function(){
	
	$(".companyName").text($.cookie('THE_SET_COMPANYNAME'));//从内存中获取企业名称
	//规范类型:生产、销售、餐饮
	if($.cookie('THE_SET_COMPANYLOOKTYPE') == "0"){
		$(".productType").show();//生产企业
		$(".salesType").hide();//销售企业
		$(".foodType").hide();//餐饮企业
	}else if($.cookie('THE_SET_COMPANYLOOKTYPE') == "1"){
		$(".productType").hide();//生产企业
		$(".salesType").show();//销售企业
		$(".foodType").hide();//餐饮企业
	}else if($.cookie('THE_SET_COMPANYLOOKTYPE') == "2"){
		$(".productType").hide();//生产企业
		$(".salesType").hide();//销售企业
		$(".foodType").show();//餐饮企业
	}else{
		$(".productType").hide();//生产企业
		$(".salesType").hide();//销售企业
		$(".foodType").show();//餐饮企业
	}
	autoH();//左右高度自适应autoH();//左右高度自适应
	companyGf(c_id);//获取企业信息,参数:企业id

	$(".downcon .circle").click(function(event) {//问号提示框
		$(this).next('.downtext').fadeToggle(10);
	});
	//记录类查看添加
	$("body").on("click",".record",function(){
		var type=$(this).parents(".li-warp").data("type");
		var title=$(this).parents(".li-warp").find(".title-type").text();
		var desc=$(this).parents(".li-warp").find(".downtext span").text();
		var urlGl="Enterprise_GfRecordEdit.html?type="+type+"&title="+escape(title)+"&desc="+escape(desc);//添加
		$(this).attr("href",urlGl);

	})
	//制度类查看添加
	$("body").on("click",".system",function(){
		var type=$(this).parents(".li-warp").data("type");
		var title=$(this).parents(".li-warp").find(".title-type").text();
		var desc=$(this).parents(".li-warp").find(".downtext span").text();
		var urlGl="Enterprise_GfSystemEdit.html?type="+type+"&title="+escape(title)+"&desc="+escape(desc);//添加
//		if($(this).parent().hasClass("addGf")){
			$(this).attr("href",urlGl);
//		}else{
//			$(this).parents("a").attr("href",urlGl);
//		}
	})
	$(document).click(function(e){
	    var _con = $(".downcon .circle");   // 设置目标区域
	    if(!_con.is(e.target) && _con.has(e.target).length === 0){
	        _con.next('.downtext').hide();
	    }
	});
	getActiveN("a11", "a1100");//当前页标志

})