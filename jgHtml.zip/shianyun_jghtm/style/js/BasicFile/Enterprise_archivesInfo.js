/*
* @Author: yangjy
* @Date:   2017-07-12 11:45:51
* @Last Modified time: 2017-07-12 12:48:16
*/
autoH();//左右高度自适应autoH();//左右高度自适应
var a1 = "a11",a2 = "a1100";//当前页代码
var c_id="";//企业id
var zjphoto=[];//资质证件信息

function getQueryString(name) {//获取url传递的参数：name为需要获取的参数名称
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var search = window.location.search.substr(1);
	var href = window.location.href;
	if(href.indexOf("?") >= 0) {
		search = href.substr(href.indexOf("?") + 1);
	}
	var r = search.match(reg);
	if(r != null) return unescape(r[2]);
	return null;
}

if(GetAddNew(getQueryString("c_id"))){//优先判断url有参数(c_id)的话存进本地缓存，若没有则从缓存中读取企业c_id
	c_id=$.cookie('THE_SET_COMPANYID');
}else{
	c_id=getQueryString("c_id");
	$.cookie('THE_SET_COMPANYID', c_id, { path: '/' });
}

function companyInfoData(res){
	var data = GetOjson(json_parse(res));
	
	console.log(data);
	if(data.status == "0"){
		if(data.param[0].is_attention =="0"){
				$.cookie('THE_SET_CONCERN', '取消关注', { path: '/' });
				$(".content-title .concern").text("取消关注");//关注
		}else{
				$.cookie('THE_SET_CONCERN', '关注', { path: '/' });
				$(".content-title .concern").text("关注");//未关注
		}
		var photo="",otype="";
		$.cookie('THE_SET_COMPANYNAME', data.param[0].cname, { path: '/' });//本地缓存企业名称
		$(".companyName").text(data.param[0].cname);
		
		if(data.param[0].cstatus == "0"){
			$(".companyStatus").text("正常经营");
		}else if(data.param[0].cstatus == "1"){
			$(".companyStatus").text("未注册");
		}else if(data.param[0].cstatus == "2"){
			$(".companyStatus").text("停产");
		}else if(data.param[0].cstatus == "3"){
			$(".companyStatus").text("转让");
		}else if(data.param[0].cstatus == "4"){
			$(".companyStatus").text("注销");
		}else{
			$(".companyStatus").text("无");
		}
		$(".companyDate").val(data.param[0].zttime);
		$(".e-license").val(data.param[0].license);
		$(".e-raddress").text(data.param[0].raddress);
		$.cookie('THE_SET_COMPANYLOOKTYPE', data.param[0].c_type, { path: '/' });
		if(data.param[0].c_type == "0"){
			$(".e-ctype").val("食品生产企业");
		}else if(data.param[0].c_type == "1"){
			$(".e-ctype").val("销售经营企业");
		}else if(data.param[0].c_type == "2"){
			$(".e-ctype").val("餐饮服务企业");
		}else if(data.param[0].c_type == "3"){
			$(".e-ctype").val("单位食堂");
		}else{
			$(".e-ctype").val("");
		}
			
		$(".e-baddress").text(data.param[0].baddress);
		$(".e-cname").val(data.param[0].cname);
		$(".e-scompany").val(data.param[0].scompany);
		$(".e-legal").val(data.param[0].legal);
		$(".e-regtime").val(data.param[0].regtime);
		$(".e-contacts").val(data.param[0].contacts);
		$(".e-dltime").val(data.param[0].dltime);
		$(".e-cnumber").val(data.param[0].cnumber);
		$(".e-batime").val(data.param[0].batime);
		if(data.param[0].o_type.length > 0){
			otype=data.param[0].o_type.split(",");
			var otypeText="";
			for(var j=0;j<otype.length;j++){
				if(otype[j] == "0"){
					otypeText=otypeText+"批发,";
				}else if(otype[j] == "1"){
					otypeText=otypeText+"零售,";
				}else if(otype[j] == "2"){
					otypeText=otypeText+"批发兼零售,";
				}else if(otype[j] == "3"){
					otypeText=otypeText+"网络经营,";
				}else if(otype[j] == "4"){
					otypeText=otypeText+"内设中央厨房,";
				}else if(otype[j] == "5"){
					otypeText=otypeText+"集体用餐配送,";
				}else{
					otypeText=otypeText+"";
				}
			}
			otypeText=otypeText.substr(0,otypeText.length-1);
			$(".e-otype").val(otypeText);
		}else{
			$(".e-otype").val("无");
		}

		if(data.param[0].photo.length > 0){
			photo=data.param[0].photo.split(",");
			$(".base-info .li-img").html('<label for="">主体照片</label>');
			for(var i=0;i<photo.length;i++){
				var html="";
				html='<img src='+photo[i]+' alt="主体照片" />'
				$(".base-info .li-img").append(html);
			}
			autoH();
		}else{
			$(".base-info .li-img").html('<label for="">主体照片</label>暂无');
		}
		if(data.param[0].zjphoto.length > 0){
			zjphoto=data.param[0].zjphoto.split("|"); 
	        $(".zj-list").children().remove();      
			for(var i=0;i<zjphoto.length;i++){
				var zjInfo=zjphoto[i].split(","),html="";
				if(zjInfo[0] == "1"){
					html='<li data-zjtype="'+zjInfo[0]+'" data-xq="'+zjInfo+'">'+
					'<img src="'+zjInfo[5]+'" alt="'+zjInfo[2]+'" class="img-zj" />'+
					'<div class="detal-info">'+
					'<p>类型: '+zjInfo[2]+'</p>'+
					'<p>编号: '+zjInfo[1]+'</p>'+
					'</div>'
					'</li>'
					$(".zj-list").append(html);
				}else if(zjInfo[0] == "2" || zjInfo[0] == "3"){
					html='<li data-zjtype="'+zjInfo[0]+'" data-xq="'+zjInfo+'">'+
					'<img src="'+zjInfo[7]+'" alt="'+zjInfo[2]+'" class="img-zj" />'+
					'<div class="detal-info">'+
					'<p>类型: '+zjInfo[2]+'</p>'+
					'<p>编号: '+zjInfo[1]+'</p>'+
					'<p>有效期: '+zjInfo[6]+'</p>'+
					'</div>'
					'</li>'
					$(".zj-list").append(html);
				}else{
					html='<li data-zjtype="'+zjInfo[0]+'" data-xq="'+zjInfo+'">'+
					'<img src="'+zjInfo[6]+'" alt="'+zjInfo[2]+'" class="img-zj" />'+
					'<div class="detal-info">'+
					'<p>类型: '+zjInfo[2]+'</p>'+
					'<p>编号: '+zjInfo[1]+'</p>'+
					'<p>有效期: '+zjInfo[5]+'</p>'+
					'</div>'
					'</li>'
					$(".zj-list").append(html);
				}
			}
			autoH();
		}else{
			$(".zj-list").html("暂无");
		}
		

	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else{
		layer.open({
			type:1
			,title: '提示'
			,content: data.info
			,area:["280px","120px"]
			,btn: ['确定']
			,yes: function(index, layero){
				layer.close(index);
			}
			,cancel: function(){ 
					//右上角关闭回调
					//return false 开启该代码可禁止点击该按钮关闭
				}
			});
	}
}

function companyInfo(c_id){
	var wxjson = new webjson("6"); //设置action值
		//新增param键值
	wxjson.AddParam("c_id", c_id);
	WebRequestAsync(wxjson, companyInfoData);
}

$(function(){

	companyInfo(c_id);//获取企业信息,参数:企业id

	$(".li-img").on("click","img",function(){//主体图片查看
		var imgContent="",imgPhoto="";
		for(var i=0;i<$(".li-img img").length;i++){
			var src=$(".li-img img")[i].src;
			imgPhoto+='<li><img src='+src+' alt="Picture"></li>'
		}
		imgContent='<div class="img-warp">'+
		'<div class="imgDiv">'+
		'<ul class="images">'+
		imgPhoto+
		'</ul>'+
		'</div>'+
		'</div>'
		layer.open({
			type:1
			,title: '图片查看'
			,content: imgContent
			,area: ['600px', 'auto']
			,btn: []
			,cancel: function(){ 
				//右上角关闭回调
				//return false 开启该代码可禁止点击该按钮关闭
			}
		});
		$('.images').viewer({
			inline:true
		});
	})

	$(".zj-list").on("click","li",function(){//查看资质证件
		var zjContent="",zjContent1="",zjContent2="",_this=$(this);

		var zjphotoArr=[];
		//for(var i=0;i<zjphoto.length;i++){
			var zjtype=_this.data("zjtype"),imgHtml="",textHtml="";
			//zjphotoArr=zjphoto[i].split(",");
			zjphotoArr=_this.data("xq").split(",")
			if(zjtype == zjphotoArr[0]){
				if(zjtype == "1"){
					textHtml='<div class="info-init">'+
					'<label for="">证照编号</label>'+
					'<input type="text" value="'+zjphotoArr[1]+'" class="input-init" disabled />'+
					'</div>'+
					'<div class="info-init">'+
					'<label for="">证照名称</label>'+
					'<input type="text" value="'+zjphotoArr[2]+'" class="input-init" disabled />'+
					'</div>'+
					'<div class="info-init">'+
					'<label for="">单位名称</label>'+
					'<input type="text" value="'+zjphotoArr[3]+'" class="input-init" disabled />'+
					'</div>'+
					'<div class="info-init">'+
					'<label for="">法定代表人</label>'+
					'<input type="text" value="'+zjphotoArr[4]+'" class="input-init" disabled />'+
					'</div>'
					for(var n=5;n<zjphotoArr.length;n++){
						if(zjphotoArr[n].length > 0){
							imgHtml+='<li><img src="'+zjphotoArr[n]+'" alt="Picture"></li>';
						}else{
							imgHtml="暂无图片";
						}
						
					}
					zjContent1='<div class="zjzj-layer clearfix">'+
					'<div class="zjzj-top clearfix">'+
					'<div class="zjzj-leftImg">'+
					'<div class="imgDiv">'+
					'<ul class="images">'+
					imgHtml+
					'</ul>'+
					'</div></div>'+
					'<div class="zjzj-rightInfo">'+
					textHtml+
					'</div></div>'+
					'</div>';

				}else if(zjtype == "2" || zjtype == "3"){
					textHtml='<div class="info-init">'+
					'<label for="">证照编号</label>'+
					'<input type="text" value="'+zjphotoArr[1]+'" class="input-init" disabled />'+
					'</div>'+
					'<div class="info-init">'+
					'<label for="">证照名称</label>'+
					'<input type="text" value="'+zjphotoArr[2]+'" class="input-init" disabled />'+
					'</div>'+
					'<div class="info-init">'+
					'<label for="">营业执照号</label>'+
					'<input type="text" value="'+zjphotoArr[3]+'" class="input-init" disabled />'+
					'</div>'+
					'<div class="info-init">'+
					'<label for="">单位名称</label>'+
					'<input type="text" value="'+zjphotoArr[4]+'" class="input-init" disabled />'+
					'</div>'+
					'<div class="info-init">'+
					'<label for="">法定代表人</label>'+
					'<input type="text" value="'+zjphotoArr[5]+'" class="input-init" disabled />'+
					'</div>'+
					'<div class="info-init">'+
					'<label for="">有效期</label>'+
					'<input type="text" value="'+zjphotoArr[6]+'" class="input-init" disabled />'+
					'</div>'
					for(var n=7;n<zjphotoArr.length;n++){
						if(zjphotoArr[n].length > 0){
							imgHtml+='<li><img src="'+zjphotoArr[n]+'" alt="Picture"></li>';
						}else{
							imgHtml="暂无图片";
						}
					}
					zjContent1='<div class="zjzj-layer clearfix">'+
					'<div class="zjzj-top clearfix">'+
					'<div class="zjzj-leftImg">'+
					'<div class="imgDiv">'+
					'<ul class="images">'+
					imgHtml+
					'</ul>'+
					'</div></div>'+
					'<div class="zjzj-rightInfo">'+
					textHtml+
					'</div></div>'+
					'</div>';
				}else{
					textHtml='<div class="info-init">'+
					'<label for="">证照编号</label>'+
					'<input type="text" value="'+zjphotoArr[1]+'" class="input-init" disabled />'+
					'</div>'+
					'<div class="info-init">'+
					'<label for="">证照名称</label>'+
					'<input type="text" value="'+zjphotoArr[2]+'" class="input-init" disabled />'+
					'</div>'+
					'<div class="info-init">'+
					'<label for="">单位名称</label>'+
					'<input type="text" value="'+zjphotoArr[3]+'" class="input-init" disabled />'+
					'</div>'+
					'<div class="info-init">'+
					'<label for="">法定代表人</label>'+
					'<input type="text" value="'+zjphotoArr[4]+'" class="input-init" disabled />'+
					'</div>'+
					'<div class="info-init">'+
					'<label for="">有效期</label>'+
					'<input type="text" value="'+zjphotoArr[5]+'" class="input-init" disabled />'+
					'</div>'
					for(var n=6;n<zjphotoArr.length;n++){
						if(zjphotoArr[n].length > 0){
							imgHtml+='<li><img src="'+zjphotoArr[n]+'" alt="Picture"></li>';
						}else{
							imgHtml="暂无图片";
						}
					}
					zjContent1='<div class="zjzj-layer clearfix">'+
					'<div class="zjzj-top clearfix">'+
					'<div class="zjzj-leftImg">'+
					'<div class="imgDiv">'+
					'<ul class="images">'+
					imgHtml+
					'</ul>'+
					'</div></div>'+
					'<div class="zjzj-rightInfo">'+
					textHtml+
					'</div></div>'+
					'</div>';
				}
				
			}
		//}

		layer.open({
			type:1
			,title: '资质证件详情'
			,content: zjContent1
			,area: ['750px', '540px']
			,btn: []
			,cancel: function(){ 
				//右上角关闭回调
				//return false 开启该代码可禁止点击该按钮关闭
			}
		});
		$('.images').viewer({
			inline:true
		});
	})
	//关注、取消关注
	$(".content-title").on("click",".concern",function(){
		var _this=$(this);
		if(_this.text() == "关注"){
			var wxjson = new webjson("53"); //设置action值
			//新增param键值
			wxjson.AddParam("enterpriseid", c_id);//企业id
			wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
			var res=WebRequest(wxjson);
			var data = GetOjson(json_parse(res));
			console.log(data);
			if(data.status == "0"){
				var list="";
				$.each(data.param,function(i,item){
					list+='<li data-id="'+item.c_id+'">'+
					'<input name="" type="checkbox" value="" id="type'+i+'" />'+
					'<label class="label1" for="type'+i+'"><pre>'+item.typename+'</pre></label>'+
					'</li>';	
				})
				var cname1=$.cookie('THE_SET_COMPANYNAME');
				var html='<div class="toast-warp">'+
				'<form>'+
				'<ul class="record-form">'+
				'<li>'+
				'<h3 class="h3-title2">为<b>'+cname1+'</b>选择分类</h3>'+
				'</li>'+
				'<li>'+
				'<span class="sbtn gz-add">创建新分类</span>'+
				'<div class="add-type">'+
				'<input type="text" value="" maxlength="20" placeholder="请输入分类名称" class="foodName" />'+
				'<span class="sbtn" id="cancel">取消</span>'+
				'<span class="sbtn" id="save">保存</span>'+
				'</div>'+
				'</li>'+
				'<li>'+
				'<ul class="type-list clearfix">'+
				list+
				'</ul>'+
				'</li>'+
				'</ul>'+
				'</form>'+
				'</div>';
				layer.open({
					type:1
					,title: ' '
					,content: html
					,area: ['530px', 'auto']
					,btn: ['取消', '确认']
					,yes: function(index, layero){
							layer.close(index);
						
				    	//按钮【按钮二】的回调
				    	//return false 开启该代码可禁止点击该按钮关闭
					}
					,btn2: function(index, layero){
						var typesArr=[];
						$.each($(".type-list li"),function(){
							if($(this).find("input[type='checkbox']").prop("checked")){
								typesArr.push($(this).data("id"));
							}
						})
						console.log(typesArr);
						
							var wxjson = new webjson("54"); //设置action值
							//新增param键值
							wxjson.AddParam("enterpriseid", c_id);//企业id
							wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
							wxjson.AddParam("flag", "qy");
							if(typesArr.length > 0){
								wxjson.AddParam("types", typesArr.join(","));//选中的类别id,拼接成逗号隔开的字符串"
							}else{
								wxjson.AddParam("types", "");//选中的类别id,拼接成逗号隔开的字符串"
							}
							
							var res=WebRequest(wxjson);
							var data2 = GetOjson(json_parse(res));
							if(data2.status == "0"){
								$.cookie('THE_SET_CONCERN', '取消关注', { path: '/' });
								$(".content-title .concern").text($.cookie('THE_SET_CONCERN'));
								layer.msg(data2.info);
								layer.close(index);
							}else if(data2.status == "9"){
								window.location.href="index.html?loginOut=true";
								return;
							}else{
								layer.msg(data2.info);
							}

					}
					,cancel: function(index, layero){
						
				    	//右上角关闭回调
				    	//return false 开启该代码可禁止点击该按钮关闭
					}
				});

				
				$(".gz-add").on("click",function(){
					$(this).hide();
					$(this).next().show();
				})
				$("#cancel").on("click",function(){
					$(this).parent(".add-type").hide();
					$(this).parent(".add-type").prev().show();
					$(this).parent(".add-type").children(".foodName").val("");
				})
				$(".add-type .foodName").on("keydown",function(event){
					var event=event || window.event;
				    if(event.keyCode == "13") {//判断如果按下的是回车键则执行下面的代码
				    	return false;
				    }
				})
				$("#save").on("click",function(){//创建新分类
					var tname1=$(this).parent(".add-type").children(".foodName").val();
					console.log(tname1);
					var typesNameArr=[];
					$.each($(".type-list li"),function(){
						if($(this).find(".label1").text()){
							typesNameArr.push(Trim($(this).find(".label1").text()));
						}
					})
					console.log(typesNameArr);
					if(typesNameArr.indexOf(tname1) >= 0){
						layer.msg('企业分类名称不能重复！');
					}else{
						var wxjson = new webjson("49"); //设置action值 创建新分类
						//新增param键值
						wxjson.AddParam("c_id", "");//类别id
						wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
						wxjson.AddParam("typename", Trim(tname1));//:类别名称
						wxjson.AddParam("keywords", "");//搜索关键字，以空格隔开
						wxjson.AddParam("zone_code", $.cookie('dep_code'));//:当前监管单位code编码

						var res=WebRequest(wxjson);
						var data5 = GetOjson(json_parse(res));
						if(data5.status == "0"){
							//layer.msg(data.info);
							var wxjson = new webjson("53"); //设置action值
							//新增param键值
							wxjson.AddParam("enterpriseid", c_id);//企业id
							wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
							var res=WebRequest(wxjson);
							var data = GetOjson(json_parse(res));
							console.log(data);
							if(data.status == "0"){//读取分类信息

								var list="";
								$.each(data.param,function(i,item){
									list+='<li data-id="'+item.c_id+'">'+
									'<input name="" type="checkbox" value="" id="type'+i+'" />'+
									'<label class="label1" for="type'+i+'"><pre>'+item.typename+'</pre></label>'+
									'</li>';	
									
								})
								$(".type-list").children().remove();
								$(".type-list").append(list);

							}else if(data.status == "9"){
								window.location.href="index.html?loginOut=true";
								return;
							}else{
								layer.msg(data.info);
							}
						}else if(data5.status == "9"){
							window.location.href="index.html?loginOut=true";
							return;
						}else{
							layer.msg(data5.info);
						}
					}
				})
			}else if(data.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else{
				layer.msg(data.info);
			}
			
		}else{//取消关注
			var wxjson = new webjson("55"); //设置action值
			//新增param键值
			wxjson.AddParam("enterpriseid", c_id);//企业id
			wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
			var res=WebRequest(wxjson);
			var data4 = GetOjson(json_parse(res));
			if(data4.status == "0"){
				$.cookie('THE_SET_CONCERN', '关注', { path: '/' });
				$(".content-title .concern").text($.cookie('THE_SET_CONCERN'));
				layer.msg(data4.info);
				//layer.close(index);
			}else if(data4.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else{
				layer.msg(data4.info);
			}
		}
		
	})

	getActiveN("a11", "a1100");//当前页标志
	//$("img.qh").trigger('click');
})