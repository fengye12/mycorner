/*
* @Author: yangjy
* @Date:   2017-07-12 11:45:51
* @Last Modified time: 2017-10-19 18:30:01
*/
autoH();//左右高度自适应autoH();//左右高度自适应
var a1 = "a11",a2 = "a1102";//当前页代码
var cid="";//企业id,企业名称
var zjphoto=[];//资质证件信息

function getQueryString(name) {//获取url传递的参数：name为需要获取的参数名称
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var search = window.location.search.substr(1);
	var href = window.location.href;
	if(href.indexOf("?") >= 0) {
		search = href.substr(href.indexOf("?") + 1);
	}
	var r = search.match(reg);
	if(r != null) return unescape(r[2]);
	return null;
}

if(!GetAddNew(getQueryString("cid"))){//判断url有参数
	cid=getQueryString("cid");
}

function companyInfoData(res){
	var data = GetOjson(json_parse(res));
	if(data.status == "0"){
		var photo="";
		$(".name").val(data.param[0].name);
		$(".cname").val(data.param[0].enterprise_name);
		$(".p-idNumber").val(data.param[0].id_number);
		$(".p-contact").val(data.param[0].tel);
		 var job1=data.param[0].job;
				   var jobTotal="",workStatus="";
				   if(job1==""){
					   jobTotal="";
				   }else{
					   job1=data.param[0].job.split(",");
				   }
				   if(data.param[0].workStatus==0){
				   	  workStatus="全职";
				   }else if(data.param[0].workStatus==1){
				   	  workStatus="兼职";
				   }else if(data.param[0].workStatus==2){
				   	  workStatus="离职";
				   }else{
				   	  workStatus="";
				   }
				   for(var j=0;j<job1.length;j++){
					if(job1[j] == 0) {
						jobTotal = jobTotal+'负责人、';
					} else if(job1[j] == 1) {
						jobTotal = jobTotal+'原辅料管理员、';
					}else if(job1[j] == 2) {
						jobTotal = jobTotal+'添加剂管理员、';
					}else if(job1[j] == 3) {
						jobTotal = jobTotal+'食品安全管理员、';
					}else if(job1[j] == 4) {
						jobTotal = jobTotal+'食品安全检验员、';
					}else if(job1[j] == 5) {
						jobTotal = jobTotal+'食品安全技术员、';
					}else{
						jobTotal="";
					}
					}
				    jobTotal=jobTotal.substr(0,jobTotal.length-1);
				    $(".p-duty").val(jobTotal);
				    $(".p-status").val(workStatus);
		if(data.param[0].path.length > 0){
			photo=data.param[0].path.split(",");
			$(".base-info .li-img").html('<label for="">健康证</label>');
			for(var m=0;m<photo.length;m++){
				var html="";
				html='<img src='+photo[m]+' alt="健康证" />'
				$(".base-info .li-img").append(html);
			}
			autoH();
		}else{
			$(".base-info .li-img").html('<label for="">健康证</label>暂无');
		}

	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else{
		layer.open({
			title: '提示'
			,content: data.info
			,btn: ['确定']
			,yes: function(index, layero){
				layer.close(index);
			}
			,cancel: function(){
					//右上角关闭回调
					//return false 开启该代码可禁止点击该按钮关闭
				}
			});
	}
}

function companyInfo(cid){
	var wxjson = new webjson("68"); //设置action值
		//新增param键值
	wxjson.AddParam("c_id", cid);
	WebRequestAsync(wxjson, companyInfoData);
}

$(function(){
	//从内存中获取企业名称
	// if(!GetAddNew($.cookie('THE_SET_COMPANYNAME'))){
	// 	$(".companyName").text($.cookie('THE_SET_COMPANYNAME'));
	// }
	companyInfo(cid);//获取企业信息,参数:企业id

	$(".li-img").on("click","img",function(){//资质证件图片查看
		var imgContent="",imgPhoto="";
		for(var i=0;i<$(".li-img img").length;i++){
			var src=$(".li-img img")[i].src;
			imgPhoto+='<li><img src='+src+' alt="Picture"></li>'
		}
		imgContent='<div class="img-warp">'+
		'<div class="imgDiv">'+
		'<ul class="images">'+
		imgPhoto+
		'</ul>'+
		'</div>'+
		'</div>'
		layer.open({
			title: '资质证件查看'
			,content: imgContent
			,area: ['650px', 'auto']
			,btn: []
			,cancel: function(){
				//右上角关闭回调
				//return false 开启该代码可禁止点击该按钮关闭
			}
		});
		$('.images').viewer({
			inline:true
		});
	});

	getActiveN("a11", "a1102");//当前页标志
	//$("img.qh").trigger('click');
})