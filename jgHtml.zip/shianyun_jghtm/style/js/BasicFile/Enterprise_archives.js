/*
* @Author: yangjy
* @Date:   2017-07-12 11:45:51
* @Last Modified time: 2017-08-19 19:24:51
*/
autoH();//左右高度自适应autoH();//左右高度自适应
var a1 = "a11",a2 = "a1100";//当前页代码
var sskey="",//用户输入的搜索关键字
	ssmode=$("#inputssmode").val(),//搜索：0精确查询，1模糊查询
	sssel=$("#inputsssel").val(),//搜索类型：0所有类型，
	jaddress="",//地址
	ctype=checkBoxFormat($(".qy-type")),//企业类型
	otype=checkBoxFormat($(".jy-type")),//经营方式
	cstatus=checkBoxFormat($(".qy-status")),//企业状态
	yjstatus=checkBoxFormat($(".yj-status")),//预警状态
	jsonParam;//导出
var ecount = $("#inputmySelect").val();//每页显示的记录数
var cpage01 = new CentPage();//实例化分页插件
var pagenum = 1;//初始当前页
var paramcentcount=0;//总记录数
var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);//初始化分页设置
$("#page").html(cents);

function CentPageOper(pnum){//点击某一页时调用此方法
	cents = cpage01.GetCentPage(pnum,paramcentcount,ecount);
	$("#page").html(cents);
	pagenum=pnum;
	companyList(sskey,ssmode,sssel,jaddress,ctype,otype,cstatus,yjstatus,pagenum,ecount);
}

function getQueryString(name) {//获取url传递的参数：name为需要获取的参数名称
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var search = window.location.search.substr(1);
	var href = window.location.href;
	if(href.indexOf("?") >= 0) {
		search = href.substr(href.indexOf("?") + 1);
	}
	var r = search.match(reg);
	if(r != null) return unescape(r[2]);
	return null;
}

if(GetAddNew(getQueryString("sskey"))){//查询条件
	sskey="";
}else{
	sskey=getQueryString("sskey");
	$(".inputWraper .foodName").val(sskey);
}

function companyData(res){//获取企业列表数据
	$("#inquiry").attr("disabled",false);
	$("#confirBtn").attr("disabled",false);
	$("#comList").children().remove();
	var data = GetOjson(json_parse(res));
	paramcentcount=data.paramcentcount;
	$(".total-num").text("共"+paramcentcount+"条");
	var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);
	$("#page").html(cents);
	if(data.status =="0"){
		$.each(data.param,function(i,item){

			var html="",ctype1="",otype1="",otypetext="",cstatus1="",yjstatus1="",attention="";
			if(item.c_type == "0"){
				ctype1="生产企业";
			}else if(item.c_type == "1"){
				ctype1="销售经营企业";
			}else if(item.c_type == "2"){
				ctype1="餐饮服务企业";
			}else if(item.c_type == "3"){
				ctype1="单位食堂";
			}else{
				ctype1="";
			}
			if(item.o_type == ""){
				otypetext="";
			}else{
				otype1=item.o_type.split(",");
			}
			for(var n=0;n<otype1.length;n++){
				if(otype1[n] == "0"){
					otypetext=otypetext+"批发,";
				}else if(otype1[n] == "1"){
					otypetext=otypetext+"零售,";
				}else if(otype1[n] == "2"){
					otypetext=otypetext+"批发兼零售,";
				}else if(otype1[n] == "3"){
					otypetext=otypetext+"网络经营,";
				}else if(otype1[n] == "4"){
					otypetext=otypetext+"内设中央厨房,";
				}else if(otype1[n] == "5"){
					otypetext=otypetext+"集体用餐配送,";
				}else{
					otypetext="";
				}
			}
			otypetext=otypetext.substr(0,otypetext.length-1);
			if(item.cstatus == "0"){
				cstatus1="正常经营";
			}else if(item.cstatus == "1"){
				cstatus1="未注册";
			}else if(item.cstatus == "2"){
				cstatus1="停产";
			}else if(item.cstatus == "3"){
				cstatus1="转让";
			}else if(item.cstatus == "4"){
				cstatus1="注销";
			}else{
				cstatus1="";
			}
			if(item.is_attention =="0"){
				attention="取消关注";
			}else{
				attention="关注";
			}
			// if(item.yjstatus == "0"){
			// 	yjstatus1="未报备";
			// }else if(item.yjstatus == "1"){
			// 	yjstatus1="超范围经营";
			// }else if(item.yjstatus == "2"){
			// 	yjstatus1="无证经营";
			// }else if(item.yjstatus == "3"){
			// 	yjstatus1="许可证过期";
			// }else if(item.yjstatus == "4"){
			// 	yjstatus1="信息未完善";
			// }else{
			// 	yjstatus1="";
			// }
			html='<tr>'+
			'<td class="hs">'+item.cname+'</td>'+
			'<td class="hs">'+item.license+'</td>'+
			'<td class="hs">'+item.jaddress+'</td>'+
			'<td class="hs">'+item.legal+'</td>'+
			'<td class="hs">'+item.scompany+'</td>'+
			'<td class="hs">'+ctype1+'</td>'+
			'<td class="hs">'+otypetext+'</td>'+
			'<td class="hs">'+item.cnumber+'</td>'+
			'<td class="hs">'+cstatus1+'</td>'+
			'<td class="hs">'+item.dqtime+'</td>'+
			'<td class="hs ls"><a href="javascript:void(0);" data-cid="'+(item.c_id)+'" class="lookDetail" target="_blank">详情</a><span class="fg-line ls">|</span><span class="concern ls" data-cid="'+item.c_id+'">'+attention+'</span></td>'+
			'</tr>';
			$("#comList").append(html);
		})
		$("#daochu").css("display","");
		$("#mySelect").css("display","");
		autoH();
	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else{
		$("#comList").append("<tr class='loading'><td colspan='12' style='padding:20px 0;text-align: center;'>"+data.info+"</td></tr>");
	}
}

function companyList(sskey,ssmode,sssel,jaddress,ctype,otype,cstatus,yjstatus,pagenum,ecount){//请求企业列表
	$("#inquiry").attr("disabled",true);
	$("#confirBtn").attr("disabled",true);
	$("#daochu").css("display","none");
	$("#mySelect").css("display","none");
	$("#comList").children().remove();
	$("#comList").append("<tr class='loading'><td colspan='12' style='padding:20px 0;text-align: center;'><img src='../style/image/load.gif' width='32px' height='32px' /></td></tr>");
	var wxjson = new webjson("5"); //设置action值
	//新增param键值
	if(sskey == "请输入关键字进行查询"){
		sskey="";
	}
	
	wxjson.AddParam("deptid", $.cookie('departmentid'));//监管单位id
	wxjson.AddParam("sskey", Trim(sskey));
	wxjson.AddParam("ssmode", ssmode);
	wxjson.AddParam("sssel", sssel);

	wxjson.AddParam("barcode", "");
	wxjson.AddParam("jaddress", jaddress);
	wxjson.AddParam("c_type", ctype);
	wxjson.AddParam("o_type", otype);
	wxjson.AddParam("cstatus", cstatus);
	wxjson.AddParam("yjstatus", "");

	wxjson.AddParam("page_index", pagenum);
	wxjson.AddParam("page_size", ecount);
	WebRequestAsync(wxjson, companyData);
	jsonParam=wxjson.GetJsons();
}

$(function(){
	$.divselect("#sssel","#inputsssel");
	$.divselect("#ssmode","#inputssmode");
	$.divselect("#mySelect","#inputmySelect");
	$("#mySelect li").on("click",function(){
		//切换每页显示的记录数
		if($("#inputmySelect").val() != ecount){
			ecount = $("#inputmySelect").val();
			pagenum=1;
			companyList(sskey,ssmode,sssel,jaddress,ctype,otype,cstatus,yjstatus,pagenum,ecount);
		}
	})
	$(".total-num").text("共"+paramcentcount+"条");
	companyList(sskey,ssmode,sssel,jaddress,ctype,otype,cstatus,yjstatus,pagenum,ecount);//调用企业列表
	/*查看详情*/
	$("#comList").on("click",".lookDetail",function(){
		var isConcern=$(this).parent(".ls").children(".concern").text();
		$.cookie('THE_SET_CONCERN', isConcern, { path: '/' });
		var enterUrl="Enterprise_archivesInfo.html?c_id="+$(this).data("cid");
		$(this).attr("href",enterUrl);
	})
	/*关注*/
	$("#comList").on("click",".concern",function(){
		var _this=$(this);
		if(_this.text() == "关注"){
			var wxjson = new webjson("53"); //设置action值
			//新增param键值
			wxjson.AddParam("enterpriseid", _this.data("cid"));//企业id
			wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
			var res=WebRequest(wxjson);
			var data = GetOjson(json_parse(res));
			console.log(data);
			if(data.status == "0"){
				var list="";
				$.each(data.param,function(i,item){
					// if(i < data.param.length-1){
						// var fl=false,paramLen=data.param.length-1;
						// if(data.param[paramLen].selected.length > 0){
						// 	var selArr=data.param[paramLen].selected.split(",");
						// 	// for(var i=0;i<selArr.length;i++){
						// 	// 	if(selArr[i] == item.c_id){
						// 	// 		fl=true;
						// 	// 	}
						// 	// }
						// 	if(selArr.indexOf(item.c_id) >= 0){
						// 		list+='<li data-id="'+item.c_id+'">'+
						// 		'<input name="" type="checkbox" value="" id="type'+i+'" checked />'+
						// 		'<label class="label1" for="type'+i+'">'+item.typename+'</label>'+
						// 		'</li>';
						// 	}else{
						// 		list+='<li data-id="'+item.c_id+'">'+
						// 		'<input name="" type="checkbox" value="" id="type'+i+'" />'+
						// 		'<label class="label1" for="type'+i+'">'+item.typename+'</label>'+
						// 		'</li>';
						// 	}
						// }else{
							list+='<li data-id="'+item.c_id+'">'+
							'<input name="" type="checkbox" value="" id="type'+i+'" />'+
							'<label class="label1" for="type'+i+'"><pre>'+item.typename+'</pre></label>'+
							'</li>';
						//}
					// }	
					
				})
				var cname1=_this.parents("tr").children("td").eq(0).text();
				var html='<div class="toast-warp">'+
				'<form>'+
				'<ul class="record-form">'+
				'<li>'+
				'<h3 class="h3-title2">为<b>'+cname1+'</b>选择分类</h3>'+
				'</li>'+
				'<li>'+
				'<span class="sbtn gz-add">创建新分类</span>'+
				'<div class="add-type">'+
				'<input type="text" value="" maxlength="20" placeholder="请输入分类名称" class="foodName" />'+
				'<span class="sbtn" id="cancel">取消</span>'+
				'<span class="sbtn" id="save">保存</span>'+
				'</div>'+
				'</li>'+
				'<li>'+
				'<ul class="type-list clearfix">'+
				list+
				// '<li>'+
				// '<input name="" type="checkbox" value="" id="type0" />'+
				// '<label class="label1" for="type0">特殊医学用途配方食品相关企业</label>'+
				// '</li>'+

				'</ul>'+
				'</li>'+
				'</ul>'+
				'</form>'+
				'</div>';
				layer.open({
					type:1
					,title: ' '
					,content: html
					,area: ['530px', 'auto']
					,btn: ['取消', '确认']
					,yes: function(index, layero){
						layer.close(index);
				    	//按钮【按钮二】的回调
				    	//return false 开启该代码可禁止点击该按钮关闭
					}
					,btn2: function(index, layero){
					
						var typesArr=[];
						$.each($(".type-list li"),function(){
							if($(this).find("input[type='checkbox']").prop("checked")){
								typesArr.push($(this).data("id"));
							}
						})
						console.log(typesArr);
						
							var wxjson = new webjson("54"); //设置action值
							//新增param键值
							wxjson.AddParam("enterpriseid", _this.data("cid"));//企业id
							wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
							wxjson.AddParam("flag", "qy");
							if(typesArr.length > 0){
								wxjson.AddParam("types", typesArr.join(","));//选中的类别id,拼接成逗号隔开的字符串"
							}else{
								wxjson.AddParam("types", "");//选中的类别id,拼接成逗号隔开的字符串"
							}
							
							var res=WebRequest(wxjson);
							var data2 = GetOjson(json_parse(res));
							if(data2.status == "0"){
								//companyList(sskey,ssmode,sssel,jaddress,ctype,otype,cstatus,yjstatus,pagenum,ecount);
								_this.text("取消关注");
								$.cookie('THE_SET_CONCERN', '取消关注', { path: '/' });
								layer.msg(data2.info);
								layer.close(index);
							}else if(data2.status == "9"){
								window.location.href="index.html?loginOut=true";
								return;
							}else{
								layer.msg(data2.info);
							}
							
						
					}
					,cancel: function(index, layero){
						 
				    	//右上角关闭回调
				    	//return false 开启该代码可禁止点击该按钮关闭
					}
				});

				
				$(".gz-add").on("click",function(){
					$(this).hide();
					$(this).next().show();
				})
				$("#cancel").on("click",function(){
					$(this).parent(".add-type").hide();
					$(this).parent(".add-type").prev().show();
					$(this).parent(".add-type").children(".foodName").val("");
				})
				$(".add-type .foodName").on("keydown",function(event){
					var event=event || window.event;
				    if(event.keyCode == "13") {//判断如果按下的是回车键则执行下面的代码
				    	return false;
				    }
				})
				$("#save").on("click",function(){//创建新分类
					var tname1=$(this).parent(".add-type").children(".foodName").val();
					console.log(tname1);
					var typesNameArr=[];
					$.each($(".type-list li"),function(){
						if($(this).find(".label1").text()){
							typesNameArr.push(Trim($(this).find(".label1").text()));
						}
					})
					console.log(typesNameArr);
					if(typesNameArr.indexOf(tname1) >= 0){
						layer.msg('企业分类名称不能重复！');
					}else{
						var wxjson = new webjson("49"); //设置action值 创建新分类
						//新增param键值
						wxjson.AddParam("c_id", "");//类别id
						wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
						wxjson.AddParam("typename", Trim(tname1));//:类别名称
						wxjson.AddParam("keywords", "");//搜索关键字，以空格隔开
						wxjson.AddParam("zone_code", $.cookie('dep_code'));//:当前监管单位code编码

						var res=WebRequest(wxjson);
						var data5 = GetOjson(json_parse(res));
						if(data5.status == "0"){
							//layer.msg(data.info);
							var wxjson = new webjson("53"); //设置action值
							//新增param键值
							wxjson.AddParam("enterpriseid", _this.data("cid"));//企业id
							wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
							var res=WebRequest(wxjson);
							var data = GetOjson(json_parse(res));
							console.log(data);
							if(data.status == "0"){//读取分类信息

								var list="";
								$.each(data.param,function(i,item){
									list+='<li data-id="'+item.c_id+'">'+
									'<input name="" type="checkbox" value="" id="type'+i+'" />'+
									'<label class="label1" for="type'+i+'"><pre>'+item.typename+'</pre></label>'+
									'</li>';	
									
								})
								$(".type-list").children().remove();
								$(".type-list").append(list);

							}else if(data.status == "9"){
								window.location.href="index.html?loginOut=true";
								return;
							}else{
								layer.msg(data.info);
							}
						}else if(data5.status == "9"){
							window.location.href="index.html?loginOut=true";
							return;
						}else{
							layer.msg(data5.info);
						}
					}
				})
			}else if(data.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else{
				layer.msg(data.info);
			}
			
		}else{//取消关注
			var wxjson = new webjson("55"); //设置action值
			//新增param键值
			wxjson.AddParam("enterpriseid", _this.data("cid"));//企业id
			wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
			var res=WebRequest(wxjson);
			var data4 = GetOjson(json_parse(res));
			if(data4.status == "0"){
				//companyList(sskey,ssmode,sssel,jaddress,ctype,otype,cstatus,yjstatus,pagenum,ecount);
				_this.text("关注")
				$.cookie('THE_SET_CONCERN', '关注', { path: '/' });
				layer.msg(data4.info);
				//layer.close(index);
			}else if(data4.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else{
				layer.msg(data4.info);
			}
		}
		
	})

	//搜索
	$("#inquiry").on("click",function(){
		sskey=$(".inputWraper .foodName").val();//用户输入的搜索关键字
		ssmode=$("#inputssmode").val();//搜索：0精确查询，1模糊查询
		sssel=$("#inputsssel").val();//搜索类型：0所有类型，
		jaddress="";//地址
		ctype="";//企业类型
		otype="";//经营方式
		cstatus="";//企业状态
		yjstatus="";//预警状态
		pagenum=1;
		companyList(sskey,ssmode,sssel,jaddress,ctype,otype,cstatus,yjstatus,pagenum,ecount);
	})
	//高级搜索
	$("#confirBtn").on("click",function(){
		sskey=$(".inputWraper .foodName").val();//用户输入的搜索关键字
		ssmode=$("#inputssmode").val();//搜索：0精确查询，1模糊查询
		sssel=$("#inputsssel").val();//搜索类型：0所有类型，
		jaddress=$("#inputChoose").val();//地址

		ctype=checkBoxFormat($(".qy-type"));//企业类型
		otype=checkBoxFormat($(".jy-type"));//经营方式
		cstatus=checkBoxFormat($(".qy-status"));//企业状态
		yjstatus=checkBoxFormat($(".yj-status"));//预警状态
		pagenum=1;
		companyList(sskey,ssmode,sssel,jaddress,ctype,otype,cstatus,yjstatus,pagenum,ecount);
		//ecount = $("#mySelect option:selected").val();//每页显示的记录数
	})
	getActiveN("a11", "a1100");//当前页标志
	$("#daochu").on("click",function(){
		var name=$("#Faorgan").text();
		var excelName=name+"企业档案表";
		var listType="enterpriseList";
		var header="企业名称"+","+"营业执照"+","+"经营地址"+","+"法定代表人"+","+"监管单位"+","+"企业类型"+","+"经营方式"+","+"联系电话"+","+"企业状态"+","+"许可证到期时间";
		if(paramcentcount<1001){
			var exportExcelParam={
				excelName:escape(excelName),
				listType:listType,
				header:header,
				jsonParam:jsonParam
			}
			postExportExcel(dcUrl,exportExcelParam);
		}else{
			layer.open({
				type:1
				,title: '系统提示'
				,content: '<div class="removeTip"><p>当前数据量超过1000条，为了数据的安全，我们无法为您导出该数据，如需导出请联系客服。</p></div>'
				,btn: ['确定']
				,yes: function(){
					layer.closeAll();
				}
			});
			return false;
		}

	});

	$(".inputWraper .foodName").on("keydown",function(event){//按下回车执行查询
	    var event=event || window.event;
	    if(event.keyCode == "13") {//判断如果按下的是回车键则执行下面的代码
	    	$("#inquiry").click();
	    }
	})
})