/*
* @Author: yangjy
* @Date:   2017-07-12 11:45:51
* @Last Modified time: 2017-07-12 12:48:16
*/
autoH();//左右高度自适应autoH();//左右高度自适应
//var a1 = "a11",a2 = "a1100";//当前页代码
var c_id="",type="",title="",desc="";//企业id,isEdit=0添加，1查看添加
var imgPath=[];//上传图片
var a1 = "a11",a2 = "a1100";//当前页代码
function getQueryString(name) {//获取url传递的参数：name为需要获取的参数名称
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var search = window.location.search.substr(1);
	var href = window.location.href;
	if(href.indexOf("?") >= 0) {
		search = href.substr(href.indexOf("?") + 1);
	}
	var r = search.match(reg);
	if(r != null) return unescape(r[2]);
	return null;
}

//if(GetAddNew(getQueryString("c_id"))){//优先判断url有参数(c_id)的话存进本地缓存，若没有则从缓存中读取企业c_id
	c_id=$.cookie('THE_SET_COMPANYID');
//}else{
	//c_id=getQueryString("c_id");
	//$.cookie('THE_SET_COMPANYLOOKID', c_id, { path: '/' });
//}
if(!GetAddNew(getQueryString("type"))){//企业规范类型
	type=getQueryString("type");
}
if(!GetAddNew(getQueryString("title"))){//标题
	title=getQueryString("title");
}
if(!GetAddNew(getQueryString("desc"))){//说明
	desc=getQueryString("desc");
}
//上传图片

// 删除图片
$("#imgBox").on('click', '.img-delete', function(event) {
	var self=this;
	var deleteImg=$("#imgBox .img-delete");
	$.each(deleteImg, function(index, val) {
		if(val==self){
			$(self).closest('.imgDiv').remove();
			imgPath.del(index);
			// filesArray.del(index);
			// console.log(filesArray);
			if(imgPath.length > 19){
				$(".fileInput").css("display","none");
			}else{
				$(".fileInput").css("display","");
			}
			return false;
		}
	});
});

function companySysData(res){
	var data = GetOjson(json_parse(res));
	
	console.log(data);
	if(data.status == "0"){
		if(data.param[0].path.length > 0){
			var imgList=data.param[0].path.split("|");
			imgPath=imgList;
			console.log(imgList);
			for(var i=0;i<imgList.length;i++){
				var html="";		
				html='<a href="javascript:void(0)" class="img-list imgDiv" title="图片">'+
				'<img src="'+imgList[i]+'" class="img" alt="图片" />'+
				'</a>';
				$("#imgBox").append(html);
				
			}
		}
		
		autoH();
	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else if(data.status == "1"){
		console.log(data.info);
	}else{
		layer.open({
			type:1
			,title: '提示'
			,content: data.info
			,area:["280px","140px"]
			,btn: ['确定']
			,yes: function(index, layero){
				layer.close(index);
			}
			,cancel: function(){ 
					//右上角关闭回调
					//return false 开启该代码可禁止点击该按钮关闭
				}
			});
	}
}

function companySys(c_id){
	$.each($(".imgDiv"),function(i,item){
		$(this).remove();
	})
	var wxjson = new webjson("67"); //设置action值
		//新增param键值
	wxjson.AddParam("c_id", c_id);
	wxjson.AddParam("type", type);
	WebRequestAsync(wxjson, companySysData);
}
function companySysSave(res){//保存后返回的数据
	$(this).attr("disabled",false);
	var data = GetOjson(json_parse(res));
	
	console.log(data);
	if(data.status == "0"){
		layer.msg(data.info);
		window.location.href="companyGf.html";
		autoH();
	}else if(data.status == "9"){
		window.location.href="login.html";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else{
		layer.open({
			type:1
			,title: '提示'
			,content: data.info
			,area:["280px","140px"]
			,btn: ['确定']
			,yes: function(index, layero){
				layer.close(index);
			}
			,cancel: function(){ 
					//右上角关闭回调
					//return false 开启该代码可禁止点击该按钮关闭
				}
		});
	}
}

$(function(){
	
	$(".companyName").text($.cookie('THE_SET_COMPANYNAME'));//从内存中获取企业名称
	$(".h3-title").text(title);
	$(".companyTitle").text(title);
	$(".desc").text(desc);
	companySys(c_id);//获取企业信息,参数:企业id
	$("#save").on("click",function(){
		if(imgPath.length > 0){
			$(this).attr("disabled",true);
			var wxjson = new webjson("15"); //设置action值
			//新增param键值
			wxjson.AddParam("c_id", c_id);
			wxjson.AddParam("type", type);
			wxjson.AddParam("path", imgPath.join("|"));
			WebRequestAsync(wxjson, companySysSave);
		}else{
			layer.msg("请上传图片或文件");
		}
		
	})
	$("#imgBox").on('click', '.img', function(event) {
		var imgContent="",imgPhoto="";
		for(var i=0;i<imgPath.length;i++){
		
			imgPhoto+='<li><img src='+imgPath[i]+' alt="Picture"></li>'
		}
		imgContent='<div class="img-warp">'+
		'<div class="imgDiv">'+
		'<ul class="images">'+
		imgPhoto+
		'</ul>'+
		'</div>'+
		'</div>'
		layer.open({
			title: '图片查看'
			,content: imgContent
			,area: ['600px', 'auto']
			,btn: []
			,cancel: function(){ 
				//右上角关闭回调
				//return false 开启该代码可禁止点击该按钮关闭
			}
		});
		$('.images').viewer({
			inline:true
		});
	})
	getActiveN("a11", "a1100");//当前页标志

})