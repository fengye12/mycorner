/*
* @Author: yangjy
* @Date:   2017-07-12 11:45:51
* @Last Modified time: 2017-09-22 11:11:04
*/
//问号提示

  $(".downcon .circle").click(function(event) {
   $(this).next('.downtext').fadeToggle(10);
  });
  $(document).click(function(e){
    var _con = $(".downcon .circle");   // 设置目标区域
    if(!_con.is(e.target) && _con.has(e.target).length === 0){
        _con.next('.downtext').hide();
    }
  });

autoH();//左右高度自适应autoH();//左右高度自适应
var a1 = "a13",a2 = "a1303";//当前页代码
var sskey="",//用户输入的搜索关键字
    time="",//时间
    c_type=checkBoxFormat2($(".qy-type")),//企业类型
    c_status=checkBoxFormat2($(".jy-type")),//企业状态
    Abnormal_status=checkBoxFormat2($(".qy-status")),//异常情况
  jsonParam="";//导出
var ecount = $("#inputmySelect").val();//每页显示的记录数
var cpage01 = new CentPage();//实例化分页插件
var pagenum = 1;//初始当前页
var paramcentcount=0;//总记录数
var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);//初始化分页设置
$("#page").html(cents);


// 高级查询
function getList(){
	time=getTime();
	pagenum=1;
	ecount=$("#inputmySelect").val();
    sskey=$(".foodName").val();//用户输入的搜索关键字
    c_type=checkBoxFormat2($(".qy-type"));//企业类型
    c_status=checkBoxFormat2($(".jy-type"));//企业状态
    Abnormal_status=checkBoxFormat2($(".qy-status"));//异常情况
    tableList(sskey,time,c_type,c_status,Abnormal_status,pagenum,ecount)
}

function CentPageOper(pnum){//点击某一页时调用此方法
	cents = cpage01.GetCentPage(pnum,paramcentcount,ecount);
	$("#page").html(cents);
	pagenum=pnum;
	 sskey=$(".foodName").val();//用户输入的搜索关键字
	 time=getTime();
        c_type=checkBoxFormat2($(".qy-type"));//企业类型
        c_status=checkBoxFormat2($(".jy-type"));//企业状态
        Abnormal_status=checkBoxFormat2($(".qy-status"));//异常情况
        tableList(sskey,time,c_type,c_status,Abnormal_status,pagenum,ecount)
    }

function successTableList(res){//获取企业列表数据
	$("#inquiry").attr("disabled",false);
	$("#unusuallyRecordList").children().remove();
	var data = GetOjson(json_parse(res));
	paramcentcount=data.paramcentcount;
	$(".total-num").text("共"+paramcentcount+"条");
	var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);
	$("#page").html(cents);

	if(data.status =="0"){
		$.each(data.param,function(i,item){
			var html="",status="",dealstatus="";
			var classN="";
			if(item.status == "0"){
				status="未处置";
				classN="text-red"

			}else{
				classN=""
				status="已处置";
			}
			if(item.dealstatus == "1"){
				dealstatus='被举报';
			}else{
				dealstatus='';
			}

			html+='<tr>'+
			'<td class="hs">'+item.entername+'</td>'+
			'<td class="hs">'+item.entertype+'</td>';
			html+='<td class="hs">'+item.billdate+'</td>'+

			'<td class="hs">'+item.deptname+'</td>'+
			'<td class="hs">'+item.dealname+'</td>'+
			'<td class="hs text-red">'+dealstatus+'</td>'+
			'<td class="hs">'+item.warningtime+'</td>'+
			'<td class="hs '+classN+'">'+status+'</td>'+
			'<td class="hs"><span class="ls" data-status="'+item.status+'" data-pid="'+item.pid+'">查看</span></td>'+
			'</tr>';
			$("#unusuallyRecordList").append(html);
		})
		// $("#daochu").css("display","");
		$("#mySelect").css("display","");
		autoH();
	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else{
		$("#unusuallyRecordList").append("<tr class='loading'><td colspan='9' style='padding:20px 0;text-align: center;'>"+data.info+"</td></tr>");
	}
}

function tableList(sskey,time,c_type,c_status,Abnormal_status,pagenum,ecount){//请求企业列表
	$("#inquiry").attr("disabled",true);
	$("#mySelect").css("display","none");
	// $("#daochu").css("display","none");
	$("#unusuallyRecordList").children().remove();
	$("#unusuallyRecordList").append("<tr class='loading'><td colspan='9' style='padding:20px 0;text-align: center;'><img src='../style/image/load.gif' width='32px' height='32px' /></td></tr>");
	var wxjson = new webjson("41"); //设置action值
	//新增param键值
	if(sskey == "请输入关键字进行查询"){
		sskey="";
	}
	    wxjson.AddParam("word", Trim(sskey));
		wxjson.AddParam("type", "3");
	    wxjson.AddParam("time",time);
	    wxjson.AddParam("c_type",c_type);
	    wxjson.AddParam("c_status", c_status);
	    wxjson.AddParam("Abnormal_status", Abnormal_status);

		wxjson.AddParam("page_index", pagenum);
		wxjson.AddParam("page_size", ecount);
		WebRequestAsync(wxjson, successTableList);
		jsonParam=wxjson.GetJsons();
}

$(function(){
	$.divselect("#mySelect","#inputmySelect");
	$("#mySelect li").on("click",function(){
		//切换每页显示的记录数
		if($("#inputmySelect").val() != ecount){
			ecount = $("#inputmySelect").val();
			pagenum=1;
			sskey=$(".foodName").val();//用户输入的搜索关键字
			time=getTime();
                c_type=checkBoxFormat2($(".qy-type"));//企业类型
                c_status=checkBoxFormat2($(".jy-type"));//企业状态
                Abnormal_status=checkBoxFormat2($(".qy-status"));//异常情况
			tableList(sskey,time,c_type,c_status,Abnormal_status,pagenum,ecount)//调用企业动态列表
		}
	})
	$(".total-num").text("共"+paramcentcount+"条");
		tableList("","","","","",pagenum,ecount);//调用企业动态列表

	//查看弹出框
	$("#unusuallyRecordList").on("click",".ls",function(){
		var content1="",
		content2="",
		st=$(this).data("status"),
		pid=$(this).data("pid");
		var wxjson = new webjson("44"); //设置action值
		//新增param键值

		wxjson.AddParam("pid", pid);
		wxjson.AddParam("type", "3");
		var res=WebRequest(wxjson);
		var result1 = GetOjson(json_parse(res));
		if(result1.status == "0"){
	   content1='<div class="warnToast">'
	   +'<div class="tablew">'
	   +'<table class="layertable">'
	   +'<thead></thead>'
	   +'<tbody>'
	   +'<tr>'
	   +'<td>单据号</td>'
	   +'<td>'+result1.param[0].djnum+'</td>'
	   // +'<td><a class="linkA" href="StandingBook_check.html?c_id='+result1.param[0].enterid+'&cbbid='+result1.param[0].ledgerid+'&cname='+escape(result1.param[0].entername)+'" target="_blank">'+result1.param[0].djnum+'</a></td>'
	   +'</tr>'
	   +'<tr>'
	   +'<td>被举报企业</td>'
	   +'<td><a class="linkA" href="Enterprise_archivesInfo.html?c_id='+result1.param[0].enterid+'" target="_blank">'+result1.param[0].entername+'</a></td>'
	   +'</tr>'
	   +'<tr>'
	   +'<tr>'
	   +'<td>联系方式</td>'
	   +'<td>'+result1.param[0].contact+'</td>'
	   +'</tr>'
	   +'<tr>'
	   +'<tr>'
	   +'<td>经营地址</td>'
	   +'<td>'+result1.param[0].address+'</td>'
	   +'</tr>'
	   +'<tr>'
	   +'<td>举报企业</td>'
	   +'<td><a class="linkA" href="Enterprise_archivesInfo.html?c_id='+result1.param[0].dealid+'" target="_blank">'+result1.param[0].dealname+'</a></td>'
	   +'</tr>'
	   +'<tr>'
	   +'<td>举报日期</td>'
	   +'<td>'+result1.param[0].reportdate+'</td>'
	   +'</tr>'
	   +'<tr>'
	   +'<td>举报描述</td>'
	   +'<td><span style="background:#f45858;color:#fff;padding:0 4px;">'+result1.param[0].context+'</td>'
	   +'</tr>'
	   +'</tbody>'
	   +'</table>'
	   +'<div class="handle">'
	   +'<p><span >处置结果</span></p>'
	   +'<textarea class="textarea" placeholder="处置结果描述">'+result1.param[0].result+'</textarea>'
	   +'</div>'
	   +'</div>'
	   +'</div>';
	   if(st== "0"){

	   	layer.open({
	   		title: ' '
	   		,content: content1
	   		,area: ['auto', 'auto']
	   		,btn: ['取消','保存处置结果']
	   		,yes: function(index, layero){
	   			layer.closeAll();

	   		}
	   		,btn2:function(){

	                          var wxjson = new webjson("42"); //设置action值
	                          //新增param键值
	                          wxjson.AddParam("pid", pid);
	                          wxjson.AddParam("type", "3");
	                          wxjson.AddParam("jb_descption", "");
	                          wxjson.AddParam("cz_result", $(".textarea").val());

	                          var res=WebRequest(wxjson);
	                          var obj=GetOjson(json_parse(res));
	                          if(obj.status == "0"){
	                          	layer.closeAll();
	                          	window.location.reload();
	                          }else if(obj.status == "9"){
	                          	window.location.href="index.html?loginOut=true";
	                          	return;
	                          }else{
	                          	layer.msg(obj.info);
	                          }
	                          return false;
	                      }
	                      ,cancel: function(){
	          				//右上角关闭回调
	          				//return false 开启该代码可禁止点击该按钮关闭
	          			}
	          		});

	   }else{
	   	layer.open({
	   		title: ' '
	   		,content: content1
	   		,area: ['auto', 'auto']
	   		,btn:false

	   	});
	   }

	}else if(result1.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else{
		console.log(result1.info);
	}


})

	//搜索
	$("#inquiry").on("click",function(){
		sskey=$(".inputWraper .foodName").val();//用户输入的搜索关键字
		pagenum=1;
		ecount=$("#inputmySelect").val();
		 sskey=$(".foodName").val();//用户输入的搜索关键字
		            time="";
		            c_type="";//企业类型
		            c_status="";//企业状态
		            Abnormal_status="";//异常情况
		            tableList(sskey,time,c_type,c_status,Abnormal_status,pagenum,ecount)
		        })

	getActiveN("a13", "a1303");//当前页标志

	$(".inputWraper input").on("keydown",function(event){//按下回车执行查询
		var event=event || window.event;
	    if(event.keyCode == "13") {//判断如果按下的是回车键则执行下面的代码
	    	$("#inquiry").click();
	    }
	})
})



