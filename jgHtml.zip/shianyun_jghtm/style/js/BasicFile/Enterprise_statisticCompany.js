/*
* @Author: yangjy
* @Date:   2017-07-12 11:45:51
* @Last Modified time: 2017-08-19 19:24:51
*/
autoH();//左右高度自适应autoH();//左右高度自适应
var a1 = "a12",a2 = "a1203";//当前页代码
var sskey="",//用户输入的搜索关键字
	// ssmode=$("#inputssmode").val(),//搜索：0精确查询，1模糊查询
	// sssel=$("#inputsssel").val(),//搜索类型：0所有类型，
	// jaddress="",//地址
	ctype=checkBoxFormat($(".qy-type")),//企业类型
	// otype=checkBoxFormat($(".jy-type")),//经营方式
	cstatus=checkBoxFormat($(".qy-status"));//企业状态
	// yjstatus=checkBoxFormat($(".yj-status")),//预警状态
var ecount = $("#inputmySelect").val();//每页显示的记录数
var cpage01 = new CentPage();//实例化分页插件
var pagenum = 1;//初始当前页
var paramcentcount=0;//总记录数
var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);//初始化分页设置
$("#page").html(cents);

function CentPageOper(pnum){//点击某一页时调用此方法
	cents = cpage01.GetCentPage(pnum,paramcentcount,ecount);
	$("#page").html(cents);
	pagenum=pnum;
	companyList(sskey,ctype,cstatus,pagenum,ecount);
}
/*移除名单分页*/
// var ecount1 = $("#inputmySelect").val();//每页显示的记录数
// var pagenum1 = 1;//初始当前页
// var paramcentcount1=0;//总记录数
// var cpage1;//实例化分页插件
// var cents1;//初始化分页设置
// function CentPageOper1(pnum){//点击某一页时调用此方法
// 	cents1 = cpage1.GetCentPage(pnum,paramcentcount1,ecount1);
// 	$("#page1").html(cents1);
// 	pagenum1=pnum;
// 	removeComList()
// }

function getQueryString(name) {//获取url传递的参数：name为需要获取的参数名称
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var search = window.location.search.substr(1);
	var href = window.location.href;
	if(href.indexOf("?") >= 0) {
		search = href.substr(href.indexOf("?") + 1);
	}
	var r = search.match(reg);
	if(r != null) return unescape(r[2]);
	return null;
}

function companyData(res){//获取企业列表数据
	$("#inquiry").attr("disabled",false);
	$("#confirBtn").attr("disabled",false);
	$("#comList").children().remove();
	var data = GetOjson(json_parse(res));
	console.log(data);
	paramcentcount=data.paramcentcount;
	//$(".total-num").text("共"+paramcentcount+"家企业");
	$(".content-title .typename").text(getQueryString("typename")+" 共"+paramcentcount+"家企业");
	var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);
	$("#page").html(cents);
	if(data.status =="0"){

		$.each(data.param,function(i,item){

			var html="",ctype1="",cstatus1="";
			if(item.ENTERPRISE_TYPE == "0"){
				ctype1="生产企业";
			}else if(item.ENTERPRISE_TYPE == "1"){
				ctype1="销售经营企业";
			}else if(item.ENTERPRISE_TYPE == "2"){
				ctype1="餐饮服务企业";
			}else if(item.ENTERPRISE_TYPE == "3"){
				ctype1="单位食堂";
			}else{
				ctype1="";
			}
			
			if(item.ENTERPRISE_STATUS == "0"){
				cstatus1="正常经营";
			}else if(item.ENTERPRISE_STATUS == "1"){
				cstatus1="未注册";
			}else if(item.ENTERPRISE_STATUS == "2"){
				cstatus1="停产";
			}else if(item.ENTERPRISE_STATUS == "3"){
				cstatus1="转让";
			}else{
				cstatus1="";
			}

			html='<tr>'+
			'<td class="hs">'+item.ENTERPRISE_NAME+'</td>'+
			'<td class="hs">'+item.BUSSINESS_CODE+'</td>'+
			'<td class="hs">'+item.ADDRESS+'</td>'+
			'<td class="hs">'+item.LEGAL+'</td>'+
			'<td class="hs" data-deptcode="'+item.DEPT_CODE+'">'+item.DEPT_NAME+'</td>'+
			'<td class="hs">'+ctype1+'</td>'+
			// '<td class="hs">'+otypetext+'</td>'+
			// '<td class="hs">'+item.cnumber+'</td>'+
			'<td class="hs">'+cstatus1+'</td>';
			if(item.WARMING_INFO == "0"){
				html+='<td class="hs"><span class="text-red">'+item.WARMING_INFO+'</span></td>';
			}else{
				html+='<td class="hs"><a href="javascript:void(0);" class="text-red lookWarn" data-c_id="'+(item.ENTERPRISE_ID)+'" data-name="'+(item.ENTERPRISE_NAME)+'">'+item.WARMING_INFO+'</a></td>';
			}
			
			if(item.is_attention == "0"){
				html+='<td class="hs" data-enterid="'+(item.ENTERPRISE_ID)+'"><a href="javascript:void(0);" class="lookdetail" target="_blank">详情</a><span class="fg-line ls">|</span><span class="remove ls">移除</span><span class="fg-line ls">|</span><span class="concern ls">取消关注</span></td>'+
				'</tr>';
			}else{
				html+='<td class="hs" data-enterid="'+(item.ENTERPRISE_ID)+'"><a href="javascript:void(0);" class="lookdetail" target="_blank">详情</a><span class="fg-line ls">|</span><span class="remove ls">移除</span><span class="fg-line ls">|</span><span class="concern ls">关注</span></td>'+
				'</tr>';
			}
			
			$("#comList").append(html);
		})
		$("#mySelect").css("display","");
		autoH();
	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else{
		$("#comList").append("<tr class='loading'><td colspan='9' style='padding:20px 0;text-align: center;'>"+data.info+"</td></tr>");
	}
}

function companyList(sskey,ctype,cstatus,pagenum,ecount){//请求企业列表
	$("#inquiry").attr("disabled",true);
	$("#confirBtn").attr("disabled",true);
	$("#mySelect").css("display","none");
	$("#comList").children().remove();
	$("#comList").append("<tr class='loading'><td colspan='9' style='padding:20px 0;text-align: center;'><img src='../style/image/load.gif' width='32px' height='32px' /></td></tr>");
	var wxjson = new webjson("52"); //设置action值
	//新增param键值
	if(sskey == "请输入关键字进行查询"){
		sskey="";
	}
	wxjson.AddParam("deptid", $.cookie('departmentid'));//监管单位id
	wxjson.AddParam("typeid", getQueryString("c_id"));//企业类型id
	wxjson.AddParam("zone_code", $.cookie('dep_code'));//:当前监管单位code编码
	wxjson.AddParam("keyword", Trim(sskey));

	wxjson.AddParam("subject_trade", ctype);//企业类型
	wxjson.AddParam("cstatus", cstatus);//企业状态
	wxjson.AddParam("status", "0");//0点击操作里面的查看,1查看报备企业,2查看未报备企业,3查看移除企业名单

	wxjson.AddParam("page_index", pagenum);
	wxjson.AddParam("page_size", ecount);
	WebRequestAsync(wxjson, companyData);
}

$(function(){
	// $.divselect("#sssel","#inputsssel");
	// $.divselect("#ssmode","#inputssmode");
	
	$.divselect("#mySelect","#inputmySelect");
	$("#mySelect li").on("click",function(){
		//切换每页显示的记录数
		if($("#inputmySelect").val() != ecount){
			ecount = $("#inputmySelect").val();
			pagenum=1;
			companyList(sskey,ctype,cstatus,pagenum,ecount);
		}
	})

	$(".bread-nav .typename").text(getQueryString("typename"));
	$(".content-title .typename").text(getQueryString("typename")+" 共"+paramcentcount+"家企业");
	companyList(sskey,ctype,cstatus,pagenum,ecount);//调用企业列表
	// 查看详情
	$("#comList").on("click",".lookdetail",function(){
		var isConcern=$(this).parent(".hs").children(".concern").text();
		$.cookie('THE_SET_CONCERN', isConcern, { path: '/' });
		var urlParam="Enterprise_archivesInfo.html?c_id="+$(this).parent("td").data("enterid");
		$(this).attr("href",urlParam);
	});
	//查看企业预警
	$("#comList").on("click",".lookWarn",function(){
		$.cookie('THE_SET_COMPANYID', $(this).data("c_id"), { path: '/' });
		$.cookie('THE_SET_COMPANYNAME', $(this).data("name"), { path: '/' });
		var urlParam="Enterprise_warning.html";
		$(this).attr("href",urlParam);
	})

	$("#removeList").on("click",function(){//移除名单
		var removeUrl="Enterprise_statisticRemoveList.html?c_id="+getQueryString("c_id");
		layer.open({
			type:2
			,title: ' '
			,content: removeUrl
			,area: ['1020px', '500px']
			,btn: []
			// ,yes: function(index, layero){
				
			// 	layer.close(index);
			// }
			// ,btn2: function(index, layero){
		 //    	//按钮【按钮二】的回调
		 //    	//return false 开启该代码可禁止点击该按钮关闭
			// }
			,cancel: function(index, layero){
				var body1 = layer.getChildFrame('body', index);//iframe页body元素
				var isRemove=body1.find('#isRemove').val();
				if(isRemove == 1){ //如果isRemove == 1：执行过取消移除操作
					companyList(sskey,ctype,cstatus,pagenum,ecount); 
				}
		    	//右上角关闭回调
		    	//return false 开启该代码可禁止点击该按钮关闭
			}
		});

	})	

	//移除分类
	$("#comList").on("click",".remove",function(){
		var _this=$(this);
		//alert(_this.parent("td").data("enterid"));
		var html='<div class="removeTip">'+
		'<p>点击确认将该企业从当前分类中移除，移除后该企业将不会出现在当前分类中。</p>'+
		'<p>可在移除名单中查看或取消移除企业。</p>'+
		'</div>';
		layer.open({
			type:1
			,title: ' '
			,content: html
			,area: ['390px', 'auto']
			,btn: ['取消', '确认']
			,yes: function(index, layero){
				layer.close(index);
		    	//按钮【按钮二】的回调
		    	//return false 开启该代码可禁止点击该按钮关闭
			}
			,btn2: function(index, layero){
				
				var wxjson = new webjson("56"); //设置action值
				//新增param键值
				wxjson.AddParam("enterpriseid", _this.parent("td").data("enterid"));//企业id
				wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
				wxjson.AddParam("typeid", getQueryString("c_id"));//企业类别id
				wxjson.AddParam("flag", "0");//flag:0移除，1取消移除
				var res=WebRequest(wxjson);
				var data = GetOjson(json_parse(res));
				console.log(data);
				if(data.status == "0"){
					companyList(sskey,ctype,cstatus,pagenum,ecount);
					layer.msg(data.info);
				}else if(data.status == "9"){
					window.location.href="index.html?loginOut=true";
					return;
				}else{
					layer.msg(data.info);
				}
				layer.close(index);
			}
			,cancel: function(){ 
		    	//右上角关闭回调
		    	//return false 开启该代码可禁止点击该按钮关闭
			}
		});
	})
	//关注、取消关注
	$("#comList").on("click",".concern",function(){
		var _this=$(this);
		if(_this.text() == "关注"){
			var wxjson = new webjson("53"); //设置action值
			//新增param键值
			wxjson.AddParam("enterpriseid", _this.parent("td").data("enterid"));//企业id
			wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
			var res=WebRequest(wxjson);
			var data = GetOjson(json_parse(res));
			console.log(data);
			if(data.status == "0"){
				var list="";
				$.each(data.param,function(i,item){
					list+='<li data-id="'+item.c_id+'">'+
					'<input name="" type="checkbox" value="" id="type'+i+'" />'+
					'<label class="label1" for="type'+i+'"><pre>'+item.typename+'</pre></label>'+
					'</li>';	
					
				})
				var cname1=_this.parents("tr").children("td").eq(0).text();
				var html='<div class="toast-warp">'+
				'<form>'+
				'<ul class="record-form">'+
				'<li>'+
				'<h3 class="h3-title2">为<b>'+cname1+'</b>选择分类</h3>'+
				'</li>'+
				'<li>'+
				'<span class="sbtn gz-add">创建新分类</span>'+
				'<div class="add-type">'+
				'<input type="text" value="" maxlength="20" placeholder="请输入分类名称" class="foodName" />'+
				'<span class="sbtn" id="cancel">取消</span>'+
				'<span class="sbtn" id="save">保存</span>'+
				'</div>'+
				'</li>'+
				'<li>'+
				'<ul class="type-list clearfix">'+
				list+
				'</ul>'+
				'</li>'+
				'</ul>'+
				'</form>'+
				'</div>';
				layer.open({
					type:1
					,title: ' '
					,content: html
					,area: ['530px', 'auto']
					,btn: ['取消', '确认']
					,yes: function(index, layero){
						layer.close(index);
						
				    	//按钮【按钮二】的回调
				    	//return false 开启该代码可禁止点击该按钮关闭
					}
					,btn2: function(index, layero){
						var typesArr=[];
						$.each($(".type-list li"),function(){
							if($(this).find("input[type='checkbox']").prop("checked")){
								typesArr.push($(this).data("id"));
							}
						})
						console.log(typesArr);
						
							var wxjson = new webjson("54"); //设置action值
							//新增param键值
							wxjson.AddParam("enterpriseid", _this.parent("td").data("enterid"));//企业id
							wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
							wxjson.AddParam("flag", "qy");
							if(typesArr.length > 0){
								wxjson.AddParam("types", typesArr.join(","));//选中的类别id,拼接成逗号隔开的字符串"
							}else{
								wxjson.AddParam("types", "");//选中的类别id,拼接成逗号隔开的字符串"
							}
							
							var res=WebRequest(wxjson);
							var data2 = GetOjson(json_parse(res));
							if(data2.status == "0"){
								//companyList(sskey,ctype,cstatus,pagenum,ecount);
								_this.text("取消关注");
								//$.cookie('THE_SET_CONCERN', '取消关注', { path: '/' });
								layer.msg(data2.info);
								layer.close(index);
							}else if(data2.status == "9"){
								window.location.href="index.html?loginOut=true";
								return;
							}else{
								layer.msg(data2.info);
							}
							
					}
					,cancel: function(index, layero){
						
				    	//右上角关闭回调
				    	//return false 开启该代码可禁止点击该按钮关闭
					}
				});

				
				$(".gz-add").on("click",function(){
					$(this).hide();
					$(this).next().show();
				})
				$("#cancel").on("click",function(){
					$(this).parent(".add-type").hide();
					$(this).parent(".add-type").prev().show();
					$(this).parent(".add-type").children(".foodName").val("");
				})
				$(".add-type .foodName").on("keydown",function(event){
					var event=event || window.event;
				    if(event.keyCode == "13") {//判断如果按下的是回车键则执行下面的代码
				    	return false;
				    }
				})
				$("#save").on("click",function(){//创建新分类
					var tname1=$(this).parent(".add-type").children(".foodName").val();
					console.log(tname1);
					var typesNameArr=[];
					$.each($(".type-list li"),function(){
						if($(this).find(".label1").text()){
							typesNameArr.push(Trim($(this).find(".label1").text()));
						}
					})
					console.log(typesNameArr);
					if(typesNameArr.indexOf(tname1) >= 0){
						layer.msg('企业分类名称不能重复！');
					}else{
						var wxjson = new webjson("49"); //设置action值 创建新分类
						//新增param键值
						wxjson.AddParam("c_id", "");//类别id
						wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
						wxjson.AddParam("typename", Trim(tname1));//:类别名称
						wxjson.AddParam("keywords", "");//搜索关键字，以空格隔开
						wxjson.AddParam("zone_code", $.cookie('dep_code'));//:当前监管单位code编码

						var res=WebRequest(wxjson);
						var data5 = GetOjson(json_parse(res));
						if(data5.status == "0"){
							//layer.msg(data.info);
							var wxjson = new webjson("53"); //设置action值
							//新增param键值
							wxjson.AddParam("enterpriseid", _this.parent("td").data("enterid"));//企业id
							wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
							var res=WebRequest(wxjson);
							var data = GetOjson(json_parse(res));
							console.log(data);
							if(data.status == "0"){//读取分类信息
								var list="";
								$.each(data.param,function(i,item){
									list+='<li data-id="'+item.c_id+'">'+
									'<input name="" type="checkbox" value="" id="type'+i+'" />'+
									'<label class="label1" for="type'+i+'"><pre>'+item.typename+'</pre></label>'+
									'</li>';	
									
								})
								$(".type-list").children().remove();
								$(".type-list").append(list);

							}else if(data.status == "9"){
								window.location.href="index.html?loginOut=true";
								return;
							}else{
								layer.msg(data.info);
							}
						}else if(data5.status == "9"){
							window.location.href="index.html?loginOut=true";
							return;
						}else{
							layer.msg(data5.info);
						}
					}
				})
			}else if(data.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else{
				layer.msg(data.info);
			}
			
		}else{//取消关注
			var wxjson = new webjson("55"); //设置action值
			//新增param键值
			wxjson.AddParam("enterpriseid", _this.parent("td").data("enterid"));//企业id
			wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
			var res=WebRequest(wxjson);
			var data4 = GetOjson(json_parse(res));
			if(data4.status == "0"){
				//companyList(sskey,ctype,cstatus,pagenum,ecount);
				_this.text("关注");
				//$.cookie('THE_SET_CONCERN', '关注', { path: '/' });
				layer.msg(data4.info);
				//layer.close(index);
			}else if(data4.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else{
				layer.msg(data4.info);
			}
		}
		
	})

	//搜索
	$("#inquiry").on("click",function(){
		sskey=$(".inputWraper .foodName").val();//用户输入的搜索关键字
		//ssmode=$("#inputssmode").val();//搜索：0精确查询，1模糊查询
		//sssel=$("#inputsssel").val();//搜索类型：0所有类型，
		//jaddress="";//地址
		ctype="";//企业类型
		//otype="";//经营方式
		cstatus="";//企业状态
		//yjstatus="";//预警状态
		pagenum=1;
		companyList(sskey,ctype,cstatus,pagenum,ecount);
	})
	//高级搜索
	$("#confirBtn").on("click",function(){
		sskey=$(".inputWraper .foodName").val();//用户输入的搜索关键字
		//ssmode=$("#inputssmode").val();//搜索：0精确查询，1模糊查询
		//sssel=$("#inputsssel").val();//搜索类型：0所有类型，
		//jaddress=$("#inputChoose").val();//地址

		ctype=checkBoxFormat($(".qy-type"));//企业类型
		//otype=checkBoxFormat($(".jy-type"));//经营方式
		cstatus=checkBoxFormat($(".qy-status"));//企业状态
		//yjstatus=checkBoxFormat($(".yj-status"));//预警状态
		pagenum=1;
		companyList(sskey,ctype,cstatus,pagenum,ecount);
		//ecount = $("#mySelect option:selected").val();//每页显示的记录数
	})
	getActiveN("a12", "a1203");//当前页标志

	$(".inputWraper input").on("keydown",function(event){//按下回车执行查询
	    var event=event || window.event;
	    if(event.keyCode == "13") {//判断如果按下的是回车键则执行下面的代码
	    	$("#inquiry").click();
	    }
	})
})



