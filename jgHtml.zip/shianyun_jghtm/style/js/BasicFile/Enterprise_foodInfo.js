/*
* @Author: yangjy
* @Date:   2017-07-13 11:45:51
* @Last Modified time: 2017-07-13 12:48:16
*/
autoH();//左右高度自适应autoH();//左右高度自适应
var a1 = "a11",a2 = "a1100";//当前页代码
var barcode="",c_id="",pid="",pname="",ycountry="";//食品id
function getQueryString(name) {//获取url传递的参数：name为需要获取的参数名称
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var search = window.location.search.substr(1);
	var href = window.location.href;
	if(href.indexOf("?") >= 0) {
		search = href.substr(href.indexOf("?") + 1);
	}
	var r = search.match(reg);
	if(r != null) return unescape(r[2]);
	return null;
}

if(!GetAddNew(getQueryString("barcode"))){//获取食品id
	barcode=getQueryString("barcode");
}
if(!GetAddNew(getQueryString("c_id"))){//获取企业id
	c_id=getQueryString("c_id");
	$.cookie('THE_SET_COMPANYID', c_id, { path: '/' });
}else{
	c_id=$.cookie('THE_SET_COMPANYID');
}
if(!GetAddNew(getQueryString("cname"))){//获取企业id
	$.cookie('THE_SET_COMPANYNAME', getQueryString("cname"), { path: '/' });
}

function foodInfoData(res){
	var data = GetOjson(json_parse(res));
	if(data.status == "0"){
		var photo="";
		pid=data.param[0].pid,pname=escape(data.param[0].pname),ycountry=escape(data.param[0].ycountry);
		$(".food-name").text(data.param[0].pname);
		$(".food-code").text(data.param[0].barcode);

		$(".f-pname").val(data.param[0].pname);
		$(".f-packing").val(data.param[0].packing);
		$(".f-barcode").text(data.param[0].barcode);
		$(".f-storage").val(data.param[0].storage);
		$(".f-ycountry").val(data.param[0].ycountry);
		$(".f-shelflife").val(data.param[0].shelflife);
		$(".f-trademark").val(data.param[0].trademark);
		$(".f-spec").val(data.param[0].spec);
		$(".f-pname").val(data.param[0].pname);
		$(".f-sccj").val(data.param[0].sccj);
		

		if(data.param[0].photos.length > 0){
			photo=data.param[0].photos.split(",");
			$(".base-info .li-img").html('<label for="">食品照片</label>');
			for(var i=0;i<photo.length;i++){
				var html="";
				html='<img src='+photo[i]+' alt="食品照片" />'
				$(".base-info .li-img").append(html);
			}
		}else{
			$(".base-info .li-img").html('<label for="">食品照片</label>暂无');
		}
		
		autoH();
	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else{
		layer.open({
			title: '提示'
			,content: data.info
			,btn: ['确定']
			,yes: function(index, layero){
				layer.close(index);
			}
			,cancel: function(){ 
					//右上角关闭回调
					//return false 开启该代码可禁止点击该按钮关闭
				}
			});
	}
}

function foodInfo(){
	var wxjson = new webjson("8"); //设置action值
	//新增param键值
	wxjson.AddParam("barcode", barcode);
	wxjson.AddParam("c_id", c_id);
	WebRequestAsync(wxjson, foodInfoData);
}

$(function(){
	foodInfo();//获取食品信息,

	$(".li-img").on("click","img",function(){//图片查看
		var imgContent="",imgPhoto="";
		for(var i=0;i<$(".li-img img").length;i++){
			var src=$(".li-img img")[i].src;
			imgPhoto+='<li><img src='+src+' alt="Picture"></li>'
		}
		imgContent='<div class="img-warp">'+
		'<div class="imgDiv">'+
		'<ul class="images">'+
		imgPhoto+
		'</ul>'+
		'</div>'+
		'</div>'
		layer.open({
			title: '图片查看'
			,content: imgContent
			,area: ['600px', 'auto']
			,btn: []
			,cancel: function(){ 
				//右上角关闭回调
				//return false 开启该代码可禁止点击该按钮关闭
			}
		});
		$('.images').viewer({
			inline:true
		});
	})

	$(".f-barcode").on("click",function(){
		var href="Food_info.html?pid="+pid+"&barcode="+barcode+"&pname="+pname+"&ycountry="+ycountry;
		$(this).attr("href",href);
	})

	getActiveN("a11", "a1100");//当前页标志
})