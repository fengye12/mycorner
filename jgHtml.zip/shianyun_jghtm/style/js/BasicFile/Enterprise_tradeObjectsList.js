/*
* @Author: yangjy
* @Date:   2017-07-12 11:45:51
* @Last Modified time: 2017-08-19 17:37:40
*/
autoH();//左右高度自适应autoH();//左右高度自适应
var a1 = "a11",a2 = "a1100";//当前页代码
var sskey="",//用户输入的搜索关键字
	ssmode=$("#inputssmode").val(),//搜索：0精确查询，1模糊查询
	sssel=$("#inputsssel").val(),//搜索类型：0所有类型，
	sptype=checkBoxFormat($(".t-sptype")),//客户类型
	jsonParam;//导出

var ecount = $("#inputmySelect").val();//每页显示的记录数
var cpage01 = new CentPage();//实例化分页插件
var pagenum = 1;//初始当前页
var paramcentcount=0;//总记录数
var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);//初始化分页设置
$("#page").html(cents);

function CentPageOper(pnum){//点击某一页时调用此方法
	cents = cpage01.GetCentPage(pnum,paramcentcount,ecount);
	$("#page").html(cents);
	pagenum=pnum;
	tradeObjectsList(sskey,ssmode,sssel,sptype,pagenum,ecount);
}

function tradeObjectsData(res){//获取企业列表数据
	$("#inquiry").attr("disabled",false);
	$("#confirBtn").attr("disabled",false);
	$("#tradeObjectsList").children().remove();
	$(".content-title .concern").text($.cookie('THE_SET_CONCERN'));//是否关注
	var data = GetOjson(json_parse(res));
	paramcentcount=data.paramcentcount;
	$(".total-num").text("共"+paramcentcount+"条");
	var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);
	$("#page").html(cents);
	if(data.status =="0"){
		$.each(data.param,function(i,item){
			var html="",sptype1="",xgtz="";
			if(item.sptype.length == 0){
				sptype1="";
			}else if(item.sptype == "0"){
				sptype1="供货商";
			}else if(item.sptype == "1"){
				sptype1="采购商";
			}else if(item.sptype == "2"){
				sptype1="供货商、采购商";
			}else{
				sptype1="";
			};
			if(item.xgtz == "0"){
				xgtz="";
			}else{
				xgtz=item.xgtz;
			};
			html='<tr>'+
			'<td class="hs">'+sptype1+'</td>'+
			'<td class="hs">'+item.jycname+'</td>'+
			'<td class="hs">'+item.jylicense+'</td>'+
			'<td class="hs">'+item.jylegal+'</td>'+
			'<td class="hs">'+item.jycontacts+'</td>'+
			'<td class="hs">'+item.cnumber+'</td>'+
			//'<td class="hs"><a href="javascript:;" style="display:inline-block; width:100%;  cursor: pointer;" onclick=getTDetail("'+item.jycid+'")>'+xgtz+'</a></td>'+
			'<td class="hs"><a href="javascript:;" style="display:inline-block; width:100%; cursor: pointer;" onclick=getDetail("'+item.jyid+'")>查看</a></td>'+
			// href="Enterprise_tradeObjectsInfo.html?jyid='+item.jyid+'"
			'</tr>'
			$("#tradeObjectsList").append(html);
		})
		$("#daochu").css("display","");
		$("#mySelect").css("display","");
		autoH();
	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else{
		$("#tradeObjectsList").append("<tr class='loading'><td colspan='7' style='padding:20px 0;text-align: center;'>"+data.info+"</td></tr>");
	}
}

function tradeObjectsList(sskey,ssmode,sssel,sptype,pagenum,ecount){//请求企业列表
	$("#inquiry").attr("disabled",true);
	$("#confirBtn").attr("disabled",true);
	$("#daochu").css("display","none");
	$("#mySelect").css("display","none");
	$("#tradeObjectsList").children().remove();
	$("#tradeObjectsList").append("<tr class='loading'><td colspan='7' style='padding:20px 0;text-align: center;'><img src='../style/image/load.gif' width='32px' height='32px' /></td></tr>");
	var wxjson = new webjson("19"); //设置action值
	//新增param键值
	if(sskey == "请输入关键字进行查询"){
		sskey="";
	}
	wxjson.AddParam("cid", $.cookie('THE_SET_COMPANYID'));
	wxjson.AddParam("sskey", Trim(sskey));
	wxjson.AddParam("ssmode", ssmode);
	wxjson.AddParam("sssel", sssel);

	wxjson.AddParam("sptype", sptype);
	wxjson.AddParam("regtime", "");
	wxjson.AddParam("cstatus", "");
	wxjson.AddParam("page_index", pagenum);
	wxjson.AddParam("page_size", ecount);
	WebRequestAsync(wxjson, tradeObjectsData);
	jsonParam=wxjson.GetJsons();
}

$(function(){
	$.divselect("#sssel","#inputsssel");
	$.divselect("#ssmode","#inputssmode");
	$.divselect("#mySelect","#inputmySelect");
	$("#mySelect li").on("click",function(){
		//切换每页显示的记录数
		if($("#inputmySelect").val() != ecount){
			ecount = $("#inputmySelect").val();
			pagenum=1;
			tradeObjectsList(sskey,ssmode,sssel,sptype,pagenum,ecount);//调用交易对象列表
		}
	})
	$(".total-num").text("共"+paramcentcount+"条");
	tradeObjectsList(sskey,ssmode,sssel,sptype,pagenum,ecount);//调用交易对象列表
	//关注、取消关注
	$(".content-title").on("click",".concern",function(){
		var _this=$(this);
		if(_this.text() == "关注"){
			var wxjson = new webjson("53"); //设置action值
			//新增param键值
			wxjson.AddParam("enterpriseid", $.cookie('THE_SET_COMPANYID'));//企业id
			wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
			var res=WebRequest(wxjson);
			var data = GetOjson(json_parse(res));
			console.log(data);
			if(data.status == "0"){
				var list="";
				$.each(data.param,function(i,item){
					list+='<li data-id="'+item.c_id+'">'+
					'<input name="" type="checkbox" value="" id="type'+i+'" />'+
					'<label class="label1" for="type'+i+'"><pre>'+item.typename+'</pre></label>'+
					'</li>';	
				})
				var cname1=$.cookie('THE_SET_COMPANYNAME');
				var html='<div class="toast-warp">'+
				'<form>'+
				'<ul class="record-form">'+
				'<li>'+
				'<h3 class="h3-title2">为<b>'+cname1+'</b>选择分类</h3>'+
				'</li>'+
				'<li>'+
				'<span class="sbtn gz-add">创建新分类</span>'+
				'<div class="add-type">'+
				'<input type="text" value="" maxlength="20" placeholder="请输入分类名称" class="foodName" />'+
				'<span class="sbtn" id="cancel">取消</span>'+
				'<span class="sbtn" id="save">保存</span>'+
				'</div>'+
				'</li>'+
				'<li>'+
				'<ul class="type-list clearfix">'+
				list+
				'</ul>'+
				'</li>'+
				'</ul>'+
				'</form>'+
				'</div>';
				layer.open({
					type:1
					,title: ' '
					,content: html
					,area: ['530px', 'auto']
					,btn: ['取消', '确认']
					,yes: function(index, layero){
							layer.close(index);

				    	//按钮【按钮二】的回调
				    	//return false 开启该代码可禁止点击该按钮关闭
					}
					,btn2: function(index, layero){
						var typesArr=[];
						$.each($(".type-list li"),function(){
							if($(this).find("input[type='checkbox']").prop("checked")){
								typesArr.push($(this).data("id"));
							}
						})
						console.log(typesArr);
						
							var wxjson = new webjson("54"); //设置action值
							//新增param键值
							wxjson.AddParam("enterpriseid", $.cookie('THE_SET_COMPANYID'));//企业id
							wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
							wxjson.AddParam("flag", "qy");
							if(typesArr.length > 0){
								wxjson.AddParam("types", typesArr.join(","));//选中的类别id,拼接成逗号隔开的字符串"
							}else{
								wxjson.AddParam("types", "");//选中的类别id,拼接成逗号隔开的字符串"
							}
							
							var res=WebRequest(wxjson);
							var data2 = GetOjson(json_parse(res));
							if(data2.status == "0"){
								$.cookie('THE_SET_CONCERN', '取消关注', { path: '/' });
								$(".content-title .concern").text($.cookie('THE_SET_CONCERN'));
								layer.msg(data2.info);
								layer.close(index);
							}else if(data2.status == "9"){
								window.location.href="index.html?loginOut=true";
								return;
							}else{
								layer.msg(data2.info);
							}
						
					}		
					,cancel: function(index, layero){
				    	//右上角关闭回调
				    	//return false 开启该代码可禁止点击该按钮关闭
					}
				});

				
				$(".gz-add").on("click",function(){
					$(this).hide();
					$(this).next().show();
				})
				$("#cancel").on("click",function(){
					$(this).parent(".add-type").hide();
					$(this).parent(".add-type").prev().show();
					$(this).parent(".add-type").children(".foodName").val("");
				})
				$(".add-type .foodName").on("keydown",function(event){
					var event=event || window.event;
				    if(event.keyCode == "13") {//判断如果按下的是回车键则执行下面的代码
				    	return false;
				    }
				})
				$("#save").on("click",function(){//创建新分类
					var tname1=$(this).parent(".add-type").children(".foodName").val();
					console.log(tname1);
					var typesNameArr=[];
					$.each($(".type-list li"),function(){
						if($(this).find(".label1").text()){
							typesNameArr.push(Trim($(this).find(".label1").text()));
						}
					})
					console.log(typesNameArr);
					if(typesNameArr.indexOf(tname1) >= 0){
						layer.msg('企业分类名称不能重复！');
					}else{
						var wxjson = new webjson("49"); //设置action值 创建新分类
						//新增param键值
						wxjson.AddParam("c_id", "");//类别id
						wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
						wxjson.AddParam("typename", Trim(tname1));//:类别名称
						wxjson.AddParam("keywords", "");//搜索关键字，以空格隔开
						wxjson.AddParam("zone_code", $.cookie('dep_code'));//:当前监管单位code编码

						var res=WebRequest(wxjson);
						var data5 = GetOjson(json_parse(res));
						if(data5.status == "0"){
							//layer.msg(data.info);
							var wxjson = new webjson("53"); //设置action值
							//新增param键值
							wxjson.AddParam("enterpriseid", $.cookie('THE_SET_COMPANYID'));//企业id
							wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
							var res=WebRequest(wxjson);
							var data = GetOjson(json_parse(res));
							console.log(data);
							if(data.status == "0"){//读取分类信息

								var list="";
								$.each(data.param,function(i,item){
									list+='<li data-id="'+item.c_id+'">'+
									'<input name="" type="checkbox" value="" id="type'+i+'" />'+
									'<label class="label1" for="type'+i+'"><pre>'+item.typename+'</pre></label>'+
									'</li>';	
									
								})
								$(".type-list").children().remove();
								$(".type-list").append(list);

							}else if(data.status == "9"){
								window.location.href="index.html?loginOut=true";
								return;
							}else{
								layer.msg(data.info);
							}
						}else if(data5.status == "9"){
							window.location.href="index.html?loginOut=true";
							return;
						}else{
							layer.msg(data5.info);
						}
					}
				})
			}else if(data.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else{
				layer.msg(data.info);
			}
			
		}else{//取消关注
			var wxjson = new webjson("55"); //设置action值
			//新增param键值
			wxjson.AddParam("enterpriseid", $.cookie('THE_SET_COMPANYID'));//企业id
			wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
			var res=WebRequest(wxjson);
			var data4 = GetOjson(json_parse(res));
			if(data4.status == "0"){
				$.cookie('THE_SET_CONCERN', '关注', { path: '/' });
				$(".content-title .concern").text($.cookie('THE_SET_CONCERN'));
				layer.msg(data4.info);
				//layer.close(index);
			}else if(data4.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else{
				layer.msg(data4.info);
			}
		}
		
	})
	//搜索
	$(".companyName").text($.cookie('THE_SET_COMPANYNAME'));//从内存中获取企业名称
	$("#inquiry").on("click",function(){
		sskey=$(".inputWraper .foodName").val(),//用户输入的搜索关键字
		ssmode=$("#inputssmode").val(),//搜索：0精确查询，1模糊查询
		sssel=$("#inputsssel").val(),//搜索类型：0所有类型，
		sptype="";
		tradeObjectsList(sskey,ssmode,sssel,sptype,pagenum,ecount);
	})
	//高级搜索
	$("#confirBtn").on("click",function(){
		sskey=$(".inputWraper .foodName").val();//用户输入的搜索关键字
		ssmode=$("#inputssmode").val();//搜索：0精确查询，1模糊查询
		sssel=$("#inputsssel").val();//搜索类型：0所有类型，
		sptype=checkBoxFormat($(".t-sptype"));//客户类型
		pagenum=1;
		tradeObjectsList(sskey,ssmode,sssel,sptype,pagenum,ecount);
		//ecount = $("#mySelect option:selected").val();//每页显示的记录数
	})

	$("#daochu").on("click",function(){//导出
		var name=$(".companyName").text();
		var excelName=name+"交易对象表";
		var listType="enterpriseRelList";
		var header="客户类型"+","+"单位名称"+","+"营业执照"+","+"法定代表人"+","+"联系人"+","+"联系电话";
		if(paramcentcount<1001){
			var exportExcelParam={
				excelName:escape(excelName),
				listType:listType,
				header:header,
				jsonParam:jsonParam
			}
			postExportExcel(dcUrl,exportExcelParam);
		}else{
			layer.open({
				type:1
				,title: '系统提示'
				,content: '<div class="removeTip"><p>当前数据量超过1000条，为了数据的安全，我们无法为您导出该数据，如需导出请联系客服。</p></div>'
				,btn: ['确定']
				,yes: function(){
					layer.closeAll();
				}
			});
			return false;
		}

	});

	$(".inputWraper input").on("keydown",function(event){//按下回车执行查询
	    var event=event || window.event;
	    if(event.keyCode == "13") {//判断如果按下的是回车键则执行下面的代码
	    	$("#inquiry").click();
	    }
	})
	getActiveN("a11", "a1100");//当前页标志
	//$("img.qh").trigger('click');
})

function getTDetail(jyid){
	//iframe窗
	layer.open({
	  type: 2,
	  zIndex:100,
	  title:  [' 相关台账', 'background:#fff;'],
	  // closeBtn: 1, //不显示关闭按钮
	  shade: [0],
	  area: ['1000px', '600px'],
	  anim: 2,
	  content: ['Enterprise_tradeObjectsAccountList.html?jycid='+jyid, 'yes']//iframe的url，no代表不显示滚动条
	});
}
function getDetail(jyid){
	//iframe窗
	layer.open({
	  type: 2,
	   zIndex:100,
	  title:  ['交易对象查看 ', 'background:#fff;'],
	  // closeBtn: 1, //不显示关闭按钮
	  shade: [0],
	  area: ['650px', '500px'],
	  anim: 2,
	  content: ['Enterprise_tradeObjectsInfo.html?jyid='+jyid, 'yes']//iframe的url，no代表不显示滚动条
	});
}

