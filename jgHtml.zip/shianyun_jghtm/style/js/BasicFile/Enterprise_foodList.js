/*
* @Author: yangjy
* @Date:   2017-07-12 11:45:51
* @Last Modified time: 2017-07-12 12:48:16
*/
autoH();//左右高度自适应autoH();//左右高度自适应
var a1 = "a11",a2 = "a1100";//当前页代码
var departmentid="",zoneCode="",pname1="",keyWords="",foodType="",goodsCode1="";
var cheType="";/**添加食品分类的传参**/
var jj=0;/**设置动态生成id的初始值**/
var foodType1="";/**保存食品分类名称**/
var cskey="";/**关注中创建新分类的名称**/
var c_id="",
	sskey="",//用户输入的搜索关键字
	ssmode=$("#inputssmode").val(),//搜索：0精确查询，1模糊查询
	sssel=$("#inputsssel").val(),//搜索类型：0所有类型，
	storage=checkBoxFormat($(".storage")),//贮存条件
	ycountry=checkBoxFormat($(".ycountry")),
	jsonParam;//原产国

var ecount = $("#inputmySelect").val();//每页显示的记录数
var cpage01 = new CentPage();//实例化分页插件
var pagenum = 1;//初始当前页
var paramcentcount=0;//总记录数
var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);//初始化分页设置
$("#page").html(cents);

function CentPageOper(pnum){//点击某一页时调用此方法
	cents = cpage01.GetCentPage(pnum,paramcentcount,ecount);
	$("#page").html(cents);
	pagenum=pnum;
	foodList(sskey,ssmode,sssel,storage,ycountry,pagenum,ecount);
}

function foodData(res){//获取食品列表数据
	$("#inquiry").attr("disabled",false);
	$("#confirBtn").attr("disabled",false);
	$("#foodList").children().remove();
	$(".content-title .concern").text($.cookie('THE_SET_CONCERN'));//是否关注
	var data = GetOjson(json_parse(res));
	paramcentcount=data.paramcentcount;
	$(".total-num").text("共"+paramcentcount+"条");
	var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);
	$("#page").html(cents);
	if(data.status =="0"){
		$.each(data.param,function(i,item){
			var html="",xgpc="",xgtz="";
			if(item.xgpc == "0"){
				xgpc="";
			}else{
				xgpc=item.xgpc;
			};
			if(item.xgtz == "0"){
				xgtz="";
			}else{
				xgtz=item.xgtz;
			};  
			var gz=item.is_attentiongood;
			if(item.is_attentiongood=="0"){
				gz="取消关注";
			}else{
				gz="关注";
			}
			html='<tr>'+
			'<td class="hs">'+item.cGoodsName+'</td>'+
			'<td class="hs">'+item.barcode+'</td>'+
			'<td class="hs">'+item.ycountry+'</td>'+
			'<td class="hs">'+item.trademark+'</td>'+
			'<td class="hs">'+item.storage+'</td>'+
			'<td class="hs"><span data-ycountry="'+escape(item.ycountry)+'" data-pname="'+(escape(item.pname))+'" data-barcode="'+(escape(item.barcode))+'" data-spid="'+(item.pid)+'" class="ls xgpc">'+xgpc+'</span></td>'+
			//'<td class="hs"><span data-spid="'+(item.pid)+'" data-pname="'+(escape(item.cGoodsName))+'" class="ls xgtz">'+xgtz+'</span></td>'+
			'<td class="hs"><span data-cpid="'+(item.cpid)+'" data-barcode="'+(escape(item.barcode))+'" class="ls food-detail cc">查看</span><span class="fg-line ls">|</span><a href="javascript:void(0);" onclick="gz(this)"><s style="display:none;">'+item.cGoodsName+'</s><i style="display:none;">'+item.pid+'</i><span style="font-size:12px;">'+gz+'</span></a></td>'+
			'</tr>'
			$("#foodList").append(html);
		})
		$("#daochu").css("display","");
		$("#mySelect").css("display","");
		autoH();
	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else{
		$("#foodList").append("<tr class='loading'><td colspan='7' style='padding:20px 0;text-align: center;'>"+data.info+"</td></tr>");
	}
}

function foodList(sskey,ssmode,sssel,storage,ycountry,pagenum,ecount){//请求经营食品列表
	$("#inquiry").attr("disabled",true);
	$("#confirBtn").attr("disabled",true);
	$("#daochu").css("display","none");
	$("#mySelect").css("display","none");
	$("#foodList").children().remove();
	$("#foodList").append("<tr class='loading'><td colspan='7' style='padding:20px 0;text-align: center;'><img src='../style/image/load.gif' width='32px' height='32px' /></td></tr>");
	var wxjson = new webjson("7"); //设置action值
	//新增param键值
	if(sskey == "请输入关键字进行查询"){
		sskey="";
	}
	wxjson.AddParam("cid", $.cookie('THE_SET_COMPANYID'));
	wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
	wxjson.AddParam("sskey", Trim(sskey));
	wxjson.AddParam("ssmode", ssmode);
	wxjson.AddParam("sssel", sssel);

	wxjson.AddParam("storage", storage);
	wxjson.AddParam("ycountry", ycountry);
	wxjson.AddParam("cstatus", "");
	wxjson.AddParam("page_index", pagenum);
	wxjson.AddParam("page_size", ecount);
	WebRequestAsync(wxjson, foodData);
	jsonParam=wxjson.GetJsons();
}

$(function(){
	departmentid=$.cookie("departmentid");
	zoneCode=$.cookie("dep_code");
	$.divselect("#sssel","#inputsssel");
	$.divselect("#ssmode","#inputssmode");
	$.divselect("#mySelect","#inputmySelect");
	$("#mySelect li").on("click",function(){
		//切换每页显示的记录数
		if($("#inputmySelect").val() != ecount){
			ecount = $("#inputmySelect").val();
			pagenum=1;
			foodList(sskey,ssmode,sssel,storage,ycountry,pagenum,ecount);
		}
	})
	$(".total-num").text("共"+paramcentcount+"条");
	foodList(sskey,ssmode,sssel,storage,ycountry,pagenum,ecount);//调用食品列表
	//关注、取消关注
	$(".content-title").on("click",".concern",function(){
		var _this=$(this);
		if(_this.text() == "关注"){
			var wxjson = new webjson("53"); //设置action值
			//新增param键值
			wxjson.AddParam("enterpriseid", $.cookie('THE_SET_COMPANYID'));//企业id
			wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
			var res=WebRequest(wxjson);
			var data = GetOjson(json_parse(res));
			console.log(data);
			if(data.status == "0"){
				var list="";
				$.each(data.param,function(i,item){
					list+='<li data-id="'+item.c_id+'">'+
					'<input name="" type="checkbox" value="" id="type'+i+'" />'+
					'<label class="label1" for="type'+i+'"><pre>'+item.typename+'</pre></label>'+
					'</li>';	
				})
				var cname1=$.cookie('THE_SET_COMPANYNAME');
				var html='<div class="toast-warp">'+
				'<form>'+
				'<ul class="record-form">'+
				'<li>'+
				'<h3 class="h3-title2">为<b>'+cname1+'</b>选择分类</h3>'+
				'</li>'+
				'<li>'+
				'<span class="sbtn gz-add">创建新分类</span>'+
				'<div class="add-type">'+
				'<input type="text" value="" maxlength="20" placeholder="请输入分类名称" class="foodName" />'+
				'<span class="sbtn" id="cancel">取消</span>'+
				'<span class="sbtn" id="save">保存</span>'+
				'</div>'+
				'</li>'+
				'<li>'+
				'<ul class="type-list clearfix">'+
				list+
				'</ul>'+
				'</li>'+
				'</ul>'+
				'</form>'+
				'</div>';
				layer.open({
					type:1
					,title: ' '
					,content: html
					,area: ['530px', 'auto']
					,btn: ['取消', '确认']
					,yes: function(index, layero){
							layer.close(index);
						
				    	//按钮【按钮二】的回调
				    	//return false 开启该代码可禁止点击该按钮关闭
					}
					,btn2: function(index, layero){
						var typesArr=[];
						$.each($(".type-list li"),function(){
							if($(this).find("input[type='checkbox']").prop("checked")){
								typesArr.push($(this).data("id"));
							}
						})
						console.log(typesArr);
						
							var wxjson = new webjson("54"); //设置action值
							//新增param键值
							wxjson.AddParam("enterpriseid", $.cookie('THE_SET_COMPANYID'));//企业id
							wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
							wxjson.AddParam("flag", "qy");
							if(typesArr.length > 0){
								wxjson.AddParam("types", typesArr.join(","));//选中的类别id,拼接成逗号隔开的字符串"
							}else{
								wxjson.AddParam("types", "");//选中的类别id,拼接成逗号隔开的字符串"
							}
							
							var res=WebRequest(wxjson);
							var data2 = GetOjson(json_parse(res));
							if(data2.status == "0"){
								$.cookie('THE_SET_CONCERN', '取消关注', { path: '/' });
								$(".content-title .concern").text($.cookie('THE_SET_CONCERN'));
								layer.msg(data2.info);
								layer.close(index);
							}else if(data2.status == "9"){
								window.location.href="index.html?loginOut=true";
								return;
							}else{
								layer.msg(data2.info);
							}
						
					}
					,cancel: function(index, layero){
				    	//右上角关闭回调
				    	//return false 开启该代码可禁止点击该按钮关闭
					}
				});

				
				$(".gz-add").on("click",function(){
					$(this).hide();
					$(this).next().show();
				})
				$("#cancel").on("click",function(){
					$(this).parent(".add-type").hide();
					$(this).parent(".add-type").prev().show();
					$(this).parent(".add-type").children(".foodName").val("");
				})
				$(".add-type .foodName").on("keydown",function(event){
					var event=event || window.event;
				    if(event.keyCode == "13") {//判断如果按下的是回车键则执行下面的代码
				    	return false;
				    }
				})
				$("#save").on("click",function(){//创建新分类
					var tname1=$(this).parent(".add-type").children(".foodName").val();
					console.log(tname1);
					var typesNameArr=[];
					$.each($(".type-list li"),function(){
						if($(this).find(".label1").text()){
							typesNameArr.push(Trim($(this).find(".label1").text()));
						}
					})
					console.log(typesNameArr);
					if(typesNameArr.indexOf(tname1) >= 0){
						layer.msg('企业分类名称不能重复！');
					}else{
						var wxjson = new webjson("49"); //设置action值 创建新分类
						//新增param键值
						wxjson.AddParam("c_id", "");//类别id
						wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
						wxjson.AddParam("typename", Trim(tname1));//:类别名称
						wxjson.AddParam("keywords", "");//搜索关键字，以空格隔开
						wxjson.AddParam("zone_code", $.cookie('dep_code'));//:当前监管单位code编码

						var res=WebRequest(wxjson);
						var data5 = GetOjson(json_parse(res));
						if(data5.status == "0"){
							//layer.msg(data.info);
							var wxjson = new webjson("53"); //设置action值
							//新增param键值
							wxjson.AddParam("enterpriseid", $.cookie('THE_SET_COMPANYID'));//企业id
							wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
							var res=WebRequest(wxjson);
							var data = GetOjson(json_parse(res));
							console.log(data);
							if(data.status == "0"){//读取分类信息

								var list="";
								$.each(data.param,function(i,item){
									list+='<li data-id="'+item.c_id+'">'+
									'<input name="" type="checkbox" value="" id="type'+i+'" />'+
									'<label class="label1" for="type'+i+'"><pre>'+item.typename+'</pre></label>'+
									'</li>';	
									
								})
								$(".type-list").children().remove();
								$(".type-list").append(list);

							}else if(data.status == "9"){
								window.location.href="index.html?loginOut=true";
								return;
							}else{
								layer.msg(data.info);
							}
						}else if(data5.status == "9"){
							window.location.href="index.html?loginOut=true";
							return;
						}else{
							layer.msg(data5.info);
						}
					}
				})
			}else if(data.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else{
				layer.msg(data.info);
			}
			
		}else{//取消关注
			var wxjson = new webjson("55"); //设置action值
			//新增param键值
			wxjson.AddParam("enterpriseid", $.cookie('THE_SET_COMPANYID'));//企业id
			wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
			var res=WebRequest(wxjson);
			var data4 = GetOjson(json_parse(res));
			if(data4.status == "0"){
				$.cookie('THE_SET_CONCERN', '关注', { path: '/' });
				$(".content-title .concern").text($.cookie('THE_SET_CONCERN'));
				layer.msg(data4.info);
				//layer.close(index);
			}else if(data4.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else{
				layer.msg(data4.info);
			}
		}
		
	})
	//搜索
	$(".companyName").text($.cookie('THE_SET_COMPANYNAME'));//从内存中获取企业名称
	$("#inquiry").on("click",function(){
		sskey=$(".inputWraper .foodName").val(),//用户输入的搜索关键字
		ssmode=$("#inputssmode").val(),//搜索：0精确查询，1模糊查询
		sssel=$("#inputsssel").val(),//搜索类型：0所有类型，
		storage="",//贮存条件
		ycountry="",//原产国
		pagenum=1;
		foodList(sskey,ssmode,sssel,storage,ycountry,pagenum,ecount);
	})
	//高级搜索
	$("#confirBtn").on("click",function(){
		sskey=$(".inputWraper .foodName").val();//用户输入的搜索关键字
		ssmode=$("#inputssmode").val();//搜索：0精确查询，1模糊查询
		sssel=$("#inputsssel").val();//搜索类型：0所有类型，
		storage=checkBoxFormat($(".storage"));//贮存条件
		ycountry=checkBoxFormat($(".ycountry"));//原产国
		pagenum=1;
		foodList(sskey,ssmode,sssel,storage,ycountry,pagenum,ecount);
		//ecount = $("#mySelect option:selected").val();//每页显示的记录数
	})
	getActiveN("a11", "a1100");//当前页标志
	//$("img.qh").trigger('click');
	$("#daochu").on("click",function(){//导出
		var name=$(".companyName").text();
		var excelName=name+"经营食品表";
		var listType="goodsList";
		var header="食品名称"+","+"食品条码"+","+"原产国"+","+"商标"+","+"贮存条件"+","+"包装方式"+","+"保质期"+","+"规格"+","+"相关批次";
		if(paramcentcount<1001){
			var exportExcelParam={
				excelName:escape(excelName),
				listType:listType,
				header:header,
				jsonParam:jsonParam
			}
			postExportExcel(dcUrl,exportExcelParam);
		}else{
			layer.open({
				type:1
				,title: '系统提示'
				,content: '<div class="removeTip"><p>当前数据量超过1000条，为了数据的安全，我们无法为您导出该数据，如需导出请联系客服。</p></div>'
				,btn: ['确定']
				,yes: function(){
					layer.closeAll();
				}
			});	
			return false;
		}

	});
	/*查看食品详情*/
	$("#foodList").on("click",".food-detail",function(){
		var code=$(this).data("barcode");
		var cpid=$(this).data("cpid");
		var wxjson = new webjson("8"); //设置action值
		//新增param键值
		wxjson.AddParam("barcode", code);
		wxjson.AddParam("cpid", cpid);
		wxjson.AddParam("c_id", $.cookie('THE_SET_COMPANYID'));
		var res=WebRequest(wxjson);
		var data=GetOjson(json_parse(res));
		if(data.status == "0"){

			var content1='<div class="foodInfoTip">'+
			'<h3 class="h3-title">食品属性</h3>'+
			'<ul class="ul-warp base-info clearfix">'+
			'<li><label for="">食品名称</label><input type="text" class="input-init f-pname" disabled value="'+data.param[0].pname+'" /></li>'+
			'<li><label for="">包装方式</label><input type="text" class="input-init f-packing" disabled value="'+data.param[0].packing+'" /></li>'+
			'<li><label for="">商品条码</label><input type="text" class="input-init f-barcode" disabled value="'+data.param[0].barcode+'"></li>'+
			'<li><label for="">贮存条件</label><input type="text" class="input-init f-storage" disabled value="'+data.param[0].storage+'" /></li>'+
			'<li><label for="">原产国</label><input type="text" class="input-init f-ycountry" disabled value="'+data.param[0].ycountry+'" /></li>'+
			'<li><label for="">保质期</label><input type="text" class="input-init f-shelflife" disabled value="'+data.param[0].shelflife+'" /></li>'+
			'<li><label for="">商标</label><input type="text" class="input-init f-trademark" disabled value="'+data.param[0].trademark+'" /></li>'+
			'<li><label for="">规格</label><input type="text" class="input-init f-spec" disabled value="'+data.param[0].spec+'" /></li>'+
			'<li><label for="">生产厂家</label><input type="text" class="input-init f-sccj" disabled value="'+data.param[0].sccj+'" /></li>'+
			'<li class="li-img">'

			var contentimg="";
			if(data.param[0].photos.length > 0){
				var photo=data.param[0].photos.split(",");
				contentimg='<label for="">食品照片</label>';
				for(var i=0;i<photo.length;i++){
					contentimg+='<img src='+photo[i]+' alt="食品照片" />';
				}
			}else{
				contentimg='<label for="">食品照片</label>暂无';
			}

			var content2='</li>'+
			'</ul>'+
			'<h3 class="h3-title mt10">食品类别</h3>'+
			'<ul class="ul-warp food-type clearfix">'+
			'<li>暂无</li>'+
			'</ul>'+
			'<h3 class="h3-title mt10">食品标签</h3>'+
			'<ul class="ul-warp food-label clearfix">'+
			'<li>暂无</li>'+
			'</ul>'+
			'<h3 class="h3-title mt10">成分配料</h3>'+
			'<ul class="ul-warp food-ingredient clearfix">'+
			'<li>暂无</li>'+
			'</ul>'+
			'</div>'
			
		}
		layer.open({
			type:1
			,title: '食品详情'
			,content: content1+contentimg+content2
			,area: ['1020px', '600px']
			,btn: []
			,cancel: function(){ 
				//右上角关闭回调
				//return false 开启该代码可禁止点击该按钮关闭
				}
		});
		$(".li-img").on("click","img",function(){//食品图片查看
			// var imgContent="",imgPhoto="";
			// console.log($(".li-img img").length);
			// for(var i=0;i<$(".li-img img").length;i++){
			// 	var src=$(".li-img img")[i].src;
			// 	imgPhoto+='<li><img src='+src+' alt="Picture"></li>'
			// }
			// imgContent='<div class="img-warp">'+
			// '<div class="imgDiv">'+
			// '<ul class="images">'+
			// imgPhoto+
			// '</ul>'+
			// '</div>'+
			// '</div>'
			// layer.open({
			// 	type:1
			// 	,title: '图片查看'
			// 	,content: imgContent
			// 	,area: ['650px', '700px']
			// 	,btn: []
			// 	,cancel: function(){ 
			// 		//右上角关闭回调
			// 		//return false 开启该代码可禁止点击该按钮关闭
			// 	}
			// });
			// $('.images').viewer({
			// 	inline:true
			// });
			//console.log($(this).attr("src"));
			window.open($(this).attr("src"),"_blank")
		})
	})
	/*查看相关批次*/
	$("#foodList").on("click",".xgpc",function(){
		var ycountry=$(this).data("ycountry");
		var pname=$(this).data("pname");
		var barcode=$(this).data("barcode");
		var spid=$(this).data("spid");
		var url="Enterprise_foodPc.html?spid="+spid+"&barcode="+barcode+"&pname="+pname+"&ycountry="+ycountry;
		layer.open({
			type: 2
			,title: '相关批次'
			,content: url
			,area: ['1000px', '600px']
			,btn: []
			,cancel: function(){ 
				//右上角关闭回调
				//return false 开启该代码可禁止点击该按钮关闭
			}
		});
	})
	/*相关台账*/
	$("#foodList").on("click",".xgtz",function(){
		var pname=$(this).data("pname");
		var spid=$(this).data("spid");
		var url="Enterprise_foodAccountList.html?spid="+spid+"&pname="+pname;
		layer.open({
			type: 2
			,title: '相关台账'
			,content: url
			,area: ['1000px', '600px']
			,btn: []
			,cancel: function(){ 
				//右上角关闭回调
				//return false 开启该代码可禁止点击该按钮关闭
			}
		});
	})

	$(".inputWraper searchClick").on("keydown",function(event){//按下回车执行查询
	    var event=event || window.event;
	    if(event.keyCode == "13") {//判断如果按下的是回车键则执行下面的代码
	    	$("#inquiry").click();
	    }
	});
})

/**食品列表中关注**/
/**点击关注**/
function gz(t){
	pname1=$(t).children("s").text();
	goodsCode1=$(t).children("i").text();
	var text1=$(t).children("span").text();
	console.log(text1);
  if(text1=="关注"){
	var wxjson = new webjson("60"); //设置action值
	//新增param键值
	wxjson.AddParam("departmentid",departmentid);
	wxjson.AddParam("zoneCode",zoneCode);
	var res=WebRequest(wxjson);
	var data = GetOjson(json_parse(res));
	console.log(data);
	var html2="",content1="";
	if(data.status == 0) {	
		for(var i = 0; i < data.param.length; i++) {
		    foodType=data.param[i].typeName;
		    keyWords=data.param[i].keyWords;
		   // var selected=data.param[i].selected;
			html2 +='<div class="div-init foodType">'+
			//if(selected.indexOf(foodType)>-1){
			/**if(foodType==selected){
			  html2 +='<input name="" type="checkbox" value="'+foodType+'" id="foodSelect'+i+'" checked/>';
			}else{**/
			  '<input name="" type="checkbox" value="'+data.param[i].cId+'" id="foodSelect'+i+'"/>'+
			//}
			  '<label class="label1 label4" for="foodSelect'+i+'">'+foodType+'</label></div>';
		    foodType1=foodType1+foodType+",";		    
		}
		foodType1=foodType1.substr(0,foodType1.length-1);
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else{
	   layer.msg(data.info);
	}
	content1= '<div class="warpper" style="margin:0;">'+
		'<div class="guanzhu">'+
		'<div>为<span style="font-weight:bold;">'+pname1+'</span>选择分类<p style="float:right;color:#EE2121;font-size:12px;" class="rs"></p></div>'+
		'<div><button class="creatType" onclick="creatType()">创建新分类</button>'+
		'<div class="creatName" style="display:none;">'+
		'<input type="text" value="" placeholder="请输入新分类名称" />'+
		'<button class="sbtn btn-exit" onclick="creatName()">取消</button>'+
		'<button class="sbtn" onclick="creatBaoc()">保存</button></div>'+
		'</div><div class="select">'+html2+'</div></div></div>';
	 layer.open({
		title: '提示'
		,content:content1
		,area: ['560px', '500px']
		,btn: ['取消','确认']
		,yes: function(index, layero){			
			layer.close(index);
		}
	   ,btn2:function(index, layero){
		   var cheType1=checkBoxTable($(".select"));//勾选的分类值
			console.log(cheType1);
			cheType=cheType1;
			console.log(cheType);
			var wxjson = new webjson("54"); //设置action值
			//新增param键值
			wxjson.AddParam("departmentid",departmentid);
			wxjson.AddParam("enterpriseid",goodsCode1);
			wxjson.AddParam("types",cheType1);
			wxjson.AddParam("flag","sp");
			WebRequestAsync(wxjson, qurDate);
		function qurDate(res){
			var data = GetOjson(json_parse(res));
			console.log(data);
			if(data.status == 0) {	
				$(t).children("span").html("取消关注");
    			text1="取消关注";
				layer.msg("关注成功!");
			}else if(data.status == 9) {
				window.location.href = "index.html?loginOut=true";
			}else{
				$(t).children("span").html("关注");
    			text1="关注";
				layer.msg(data.info);
			}
		}
	   }
		,cancel: function(){ 
			//右上角关闭回调
			//return false 开启该代码可禁止点击该按钮关闭
		}
	});
 }else{
		var wxjson = new webjson("55"); //设置action值
		//新增param键值	
		wxjson.AddParam("departmentid",departmentid);
		wxjson.AddParam("enterpriseid",goodsCode1);
		WebRequestAsync(wxjson, qxGzData);
	function qxGzData(res){
		var data = GetOjson(json_parse(res));
		console.log(data);
		if(data.status == 0) {
			$(t).children("span").html("关注");
			text1="关注";
			layer.msg("取消成功！");
		}else if(data.status == 9){
			window.location.href="index.html?loginOut=true";
		}else {
			$(t).children("span").html("取消关注");
			text1="取消关注";
			layer.msg(data.info);
		}
	}
 }
}

/**关注中判断输入的分类是否和已存在的分类名称相同**/
function compare(){
	var inputs=$.trim($(".creatName input").val());//输入的值
	var ft=[];
	console.log("foodType1:"+foodType1);
	ft=foodType1.split(",");
	console.log("ft:"+ft);
	if(ft.length>0){
	 for(var i=0;i<ft.length;i++){
		console.log("数组："+ft[i]);
		    if(ft[i]==inputs){
			 $(".warpper p").html("此分类已存在，不能重复添加！");
			  $(".creatName").show();
			  $(".creatType").hide();
			  return true;
		}else if(inputs=="关注食品"){
			$(".warpper p").html("此分类已存在，不能重复添加！");
			$(".creatName").show();
			  $(".creatType").hide();
		  return true;
		}else{
			$(".warpper p").html("");
			  $(".creatType").show();
			  $(".creatName").hide();
			  $(".creatName input").val("");
		}
	}
}
}

/**关注中点击创建新分类**/
function creatType(){
	console.log("12");
	$(".creatType").hide();
	$(".creatName").show();
}

/**关注中创建新分类中取消按钮**/
function creatName(){
	$(".creatType").show();
	$(".creatName").hide();
	$(".creatName input").val("");
	$(".warpper p").css("display","none");
}

/**关注中创建新分类中保存按钮**/
function creatBaoc(){
	cskey=$.trim($(".creatName input").val());
	console.log(cskey);
	console.log(foodType1);
	if(cskey=="请输入新分类名称"||cskey==""){
		$(".warpper p").html("请输入新分类名称");
	}else if(compare()){
		return;
	}else{
	  	var wxjson = new webjson("61"); //设置action值
		//新增param键值	
		wxjson.AddParam("keywords","");	
		wxjson.AddParam("typename",cskey);
		wxjson.AddParam("departmentid",departmentid);
		wxjson.AddParam("type","INSERT");
		WebRequestAsync(wxjson, creatBaoDate);
	}
}

function creatBaoDate(res){
	var htmlL="";
	var data = GetOjson(json_parse(res));
	console.log(data);
	if(data.status == 0) {	
		htmlL +='<div class="div-init foodType">'+
	   '<input name="" type="checkbox" value="'+data.param[0].cId+'" id="foodSel'+jj+'"/>'+
	   '<label class="label1 label4" for="foodSel'+jj+'"><pre>'+cskey+'</pre></label></div>';
	   jj++;
	   $(".select").append(htmlL);
	   foodType1=foodType1+","+cskey;
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else{
	  $(".select").append("");
	}
}




