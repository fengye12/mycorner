var sskey="", ssmode=$("#ssmode").find("option:selected").val(), sssel=$("#sssel").find("option:selected").val(),bbtype="",bstatus="", bbtime="",cid="",sptype="";
autoH();//左右高度自适应autoH();
var a1="a11",a2="a1104";//用于nav

//sskey="",//用户输入的搜索关键字
//ssmode=$("#inputssmode").val(),//搜索：0精确查询，1模糊查询
//sssel=$("#inputsssel").val(),//搜索类型：0所有类型，
var bbtime="",//报备日期
	bbtype=checkBoxFormat($(".o-bbtype")),//备案类型
	bstatus=checkBoxFormat($(".o-bstatus"));//备案状态
var ecount = 20;//每页显示的记录数
var cpage01 = new CentPage();//实例化分页插件
var pagenum = 1;//初始当前页
var paramcentcount=0;//总记录数
var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);//初始化分页设置
$("#page").html(cents);

function CentPageOper(pnum){//点击某一页时调用此方法
	cents = cpage01.GetCentPage(pnum,paramcentcount,ecount);
	$("#page").html(cents);
	pagenum=pnum;
	operateRecordList(sskey,ssmode,sssel,bbtime,bbtype,bstatus,pagenum,ecount);
}

// function select(){//切换每页显示的记录数
// 	ecount = $("#mySelect option:selected").val();
// 	pagenum=1;
// 	operateRecordList(bbtime,bbtype,bstatus,pagenum,ecount);
// }

function operateRecordData(res){//获取备案列表数据
	$("#confirBtn").attr("disabled",false);
	$("#operateRecordList").children().remove();
	var data = GetOjson(json_parse(res));
	paramcentcount=data.paramcentcount;
	var cents = cpage01.GetCentPage(pagenum,paramcentcount,ecount);
	$("#page").html(cents);
	if(data.status =="0"){
		$.each(data.param,function(i,item){
			var html="",bbtype1="",bstatus1="";
			if(item.bbtype == "0"){
				bbtype1="无进货行为备案";
			}else if(item.bbtype == "1"){
				bbtype1="无销售行为备案";
			}else if(item.bbtype == "2"){
				bbtype1="停止生产经营备案";
			}else if(item.bbtype == "3"){
				bbtype1="企业转让备案";
			}else if(item.bbtype == "4"){
				bbtype1="恢复生产经营备案";
			}else{
				bbtype1="";
			}
			if(item.bstatus == "0"){
				bstatus1="备案中";
			}else if(item.bstatus == "1"){
				bstatus1="已备案";
			}else if(item.bstatus == "2"){
				bstatus1="已作废";
			}else{
				bstatus1="";
			}
			html='<tr>'+
			'<td class="hs">'+data.param[i].cname+'</td>'+
//			"<td class='hs'><a href='#' class='ls'  onclick='getcid(this)'>" +data.param[i].cname +
//			"<span style='display:none'>" + data.param[i].cid +
		//	"</a></td>"+

			'<td class="hs">'+item.bbtime+'</td>'+
			'<td class="hs">'+bbtype1+'</td>'+
			'<td class="hs text-left short" style="width:550px">'+item.bbsm+'</td>'+
			'<td class="hs">'+bstatus1+'</td>'+
			'<td class="hs"><span class="lookDetail" data-jbid='+item.jbid+'>查看</span></td>'+
			'</tr>'
			$("#operateRecordList").append(html);
		})
		$("#mySelectS").css("display","");
		autoH();
	}else if(data.status == "9"){
		window.location.href="index.html?loginOut=true";
		return;
	}else if(data.status== "10"){
		console.log(data.info);
	}else{
		$("#mySelectS").css("display","none");
		$("#operateRecordList").append("<tr class='loading'><td colspan='6' style='padding:20px 0;text-align: center;'>"+data.info+"</td></tr>");
	}
}

function operateRecordList(sskey,ssmode,sssel,bbtime,bbtype,bstatus,pagenum,ecount){//请求备案列表
	$("#mySelectS").css("display","none");
	$("#confirBtn").attr("disabled",true);
	$("#operateRecordList").children().remove();
	$("#operateRecordList").append("<tr class='loading'><td colspan='6' style='padding:20px 0;text-align: center;'><img src='../style/image/load.gif' width='32px' height='32px' /></td></tr>");
	var wxjson = new webjson("11"); //设置action值
	//新增param键值
	if(sskey == "请输入关键字进行查询"){
		sskey="";
	}
	wxjson.AddParam("cid","");
	wxjson.AddParam("sskey", Trim(sskey));
	wxjson.AddParam("ssmode", ssmode);
	wxjson.AddParam("sssel", sssel);
	wxjson.AddParam("bbtype", bbtype);
	wxjson.AddParam("bbtime", bbtime);
	wxjson.AddParam("bstatus", bstatus);
	wxjson.AddParam("page_index", pagenum);
	wxjson.AddParam("page_size", ecount);
	WebRequestAsync(wxjson, operateRecordData);
}

$(function(){
	operateRecordList(sskey,ssmode,sssel,bbtime,bbtype,bstatus,pagenum,ecount);

	$("#Search").click(function(){
		pindex=1;
		sskey=$(".foodName").val();
		sssel = $("#sssel").find("option:selected").val();
		ssmode = $("#ssmode").find("option:selected").val();
		bbtype="";
		bbtime="";
		bstatus="";
		//console.log("sskey:"+sskey+",sssel:"+sssel+",ssmode:"+ssmode);
		operateRecordList(sskey,ssmode,sssel,bbtime,bbtype,bstatus,pagenum,ecount);
	})
	$("#confirBtn").on("click",function(){
		//报备日期验证bbDate
		 var startDaobei=$("#bbDate").children("input.dateStart").val();
		 var endDaobei = $("#bbDate").children("input.dateEnd").val();

		 if(startDaobei != "" && endDaobei != "" && new Date(startDaobei.replace(/-/g, "/")) > new Date(endDaobei.replace(/-/g, "/"))) {
		    layer.open({
				title: '系统提示'
				,content: '报备开始日期不能大于结束日期!'
				,btn: ['确定']
				,yes: function(){
					layer.closeAll();
				}
			});
		    return false;
		}else{
			if(startDaobei == "" && endDaobei == ""){
				bbtime="";//报备日期
			}else{
				bbtime=startDaobei+","+endDaobei;
			}
			sskey=$(".foodName").val();
			sssel = $("#sssel").find("option:selected").val();
			ssmode = $("#ssmode").find("option:selected").val();
			bbtype=checkBoxFormat($(".o-bbtype")),//备案类型
			bstatus=checkBoxFormat($(".o-bstatus"));//备案状态
			pagenum=1;
			operateRecordList(sskey,ssmode,sssel,bbtime,bbtype,bstatus,pagenum,ecount);
		}
	})

	$("#operateRecordList").on("click",".lookDetail",function(){//图片查看
		var jbid=$(this).data("jbid");

		function operateRecordInfo(res){
			var data = GetOjson(json_parse(res));
			if(data.status == "0"){
				var beian="",zrBeian="",zfbeian="",btype="",zfzrBeian="",content1="";

				if(data.param[0].bbtype == "0"){
					btype="无进货行为备案";
				}else if(data.param[0].bbtype == "1"){
					btype="无销售行为备案";
				}else if(data.param[0].bbtype == "2"){
					btype="停止生产经营备案";
				}else if(data.param[0].bbtype == "3"){
					btype="企业转让备案";
				}else if(data.param[0].bbtype == "4"){
					btype="恢复生产经营备案";
				}else{
					btype="";
				}
				if(data.param[0].bbtype == "2"){
					beian='<div class="toast-warp">'+
					'<form>'+
					'<ul class="record-form">'+
					'<li>'+
					'<label for="">备案类型</label>'+
					'<input type="text" value='+btype+' class="input-init" disabled />'+
					'</li>'+
					'<li><h3 class="h3-title mt10"><span>备案说明</span></h3></li>'+
					'<li>'+
					'<label for="">停产日期</label>'+
					'<input type="text" value='+data.param[0].bbtime+' class="input-init" disabled />'+
					'</li>'+
					'<li>'+
					'<textarea name="" id="recordDetail" rows="3" disabled>'+data.param[0].bbsm+'</textarea>'+
					'</li>'+
					'</ul>'+
					'</form>'+
					'</div>';
					zfbeian='<div class="toast-warp">'+
					'<form>'+
					'<ul class="record-form">'+
					'<li>'+
					'<label for="">备案类型</label>'+
					'<input type="text" value='+btype+' class="input-init" disabled />'+
					'</li>'+
					'<li><h3 class="h3-title mt10"><span>备案说明</span></h3></li>'+
					'<li>'+
					'<label for="">停产日期</label>'+
					'<input type="text" value='+data.param[0].bbtime+' class="input-init" disabled />'+
					'</li>'+
					'<li>'+
					'<textarea name="" id="recordDetail" rows="3" disabled>'+data.param[0].bbsm+'</textarea>'+
					'</li>'+
					'<li id="zfyy">'+
					'<h3 class="h3-title"><span>作废原因</span></h3>'+
					'<textarea name="" rows="3" disabled>'+data.param[0].zfsm+'</textarea>'+
					'</li>'+
					'</ul>'+
					'</form>'+
					'</div>';
				}else{
					beian='<div class="toast-warp">'+
					'<form>'+
					'<ul class="record-form">'+
					'<li>'+
					'<label for="">备案类型</label>'+
					'<input type="text" value='+btype+' class="input-init" disabled />'+
					'</li>'+
					'<li><h3 class="h3-title mt10"><span>备案说明</span></h3></li>'+
					'<li>'+
					'<label for="">报备月份</label>'+
					'<input type="text" value='+data.param[0].bbtime+' class="input-init" disabled />'+
					'</li>'+
					'<li>'+
					'<textarea name="" id="recordDetail" rows="3" disabled>'+data.param[0].bbsm+'</textarea>'+
					'</li>'+
					'</ul>'+
					'</form>'+
					'</div>';
					zfbeian='<div class="toast-warp">'+
					'<form>'+
					'<ul class="record-form">'+
					'<li>'+
					'<label for="">备案类型</label>'+
					'<input type="text" value='+btype+' class="input-init" disabled />'+
					'</li>'+
					'<li><h3 class="h3-title mt10"><span>备案说明</span></h3></li>'+
					'<li>'+
					'<label for="">报备月份</label>'+
					'<input type="text" value='+data.param[0].bbtime+' class="input-init" disabled />'+
					'</li>'+
					'<li>'+
					'<textarea name="" id="recordDetail" rows="3" disabled>'+data.param[0].bbsm+'</textarea>'+
					'</li>'+
					'<li id="zfyy">'+
					'<h3 class="h3-title"><span>作废原因</span></h3>'+
					'<textarea name="" rows="3" disabled>'+data.param[0].zfsm+'</textarea>'+
					'</li>'+
					'</ul>'+
					'</form>'+
					'</div>';
				}




				zrBeian='<div class="toast-warp">'+
				'<form>'+
				'<ul class="record-form">'+
				'<li>'+
				'<label for="">备案类型</label>'+
				'<input type="text" value='+btype+' class="input-init" disabled />'+
				'</li>'+
				'<li>'+
				'<h3 class="h3-title mt10"><span>备案说明</span></h3>'+
				'</li>'+
				'<li>'+
				'<label for="">转让日期</label>'+
				'<input type="text" value='+data.param[0].bbtime+' class="input-init" disabled />'+
				'</li>'+
				'<li>'+
				'<label for="">受让人</label>'+
				'<input type="text" value='+data.param[0].srs+' class="input-init" disabled />'+
				'</li>'+
				'<li>'+
				'<label for="">身份证号</label>'+
				'<input type="text" value='+data.param[0].idcard+' class="input-init" disabled />'+
				'</li>'+
				'<li>'+
				'<label for="">手机号</label>'+
				'<input type="text" value='+data.param[0].phone+' class="input-init" disabled />'+
				'</li>'+
				'<li>'+
				'<textarea name="" id="recordDetail" rows="3" disabled>'+data.param[0].bbsm+'</textarea>'+
				'</li>'+
				'</ul>'+
				'</form>'+
				'</div>';

				zfzrBeian='<div class="toast-warp">'+
				'<form>'+
				'<ul class="record-form">'+
				'<li>'+
				'<label for="">备案类型</label>'+
				'<input type="text" value='+btype+' class="input-init" disabled />'+
				'</li>'+
				'<li>'+
				'<h3 class="h3-title mt10"><span>备案说明</span></h3>'+
				'</li>'+
				'<li>'+
				'<label for="">转让日期</label>'+
				'<input type="text" value='+data.param[0].bbtime+' class="input-init" disabled />'+
				'</li>'+
				'<li>'+
				'<label for="">受让人</label>'+
				'<input type="text" value='+data.param[0].srs+' class="input-init" disabled />'+
				'</li>'+
				'<li>'+
				'<label for="">身份证号</label>'+
				'<input type="text" value='+data.param[0].idcard+' class="input-init" disabled />'+
				'</li>'+
				'<li>'+
				'<label for="">手机号</label>'+
				'<input type="text" value='+data.param[0].phone+' class="input-init" disabled />'+
				'</li>'+
				'<li>'+
				'<textarea name="" id="recordDetail" rows="3" disabled>'+data.param[0].bbsm+'</textarea>'+
				'</li>'+
				'<li id="zfyy">'+
				'<h3 class="h3-title"><span>作废原因</span></h3>'+
				'<textarea name="" rows="3" disabled>'+data.param[0].zfsm+'</textarea>'+
				'</li>'+
				'</ul>'+
				'</form>'+
				'</div>';

				if(data.param[0].bstatus == "2" && data.param[0].bbtype == "3"){
					content1=zfzrBeian;
				}else if(data.param[0].bstatus == "2" && data.param[0].bbtype != "3"){
					content1=zfbeian;
				}else if(data.param[0].bstatus != "2" && data.param[0].bbtype == "3"){
					content1=zrBeian;
				}else if(data.param[0].bstatus != "2" && data.param[0].bbtype != "3"){
					content1=beian;
				}else{
					content1="";
				}
				layer.open({
					title: ' '
					,content: content1
					,area: ['500px', 'auto']
					,btn: []
					,cancel: function(){
						//右上角关闭回调
						//return false 开启该代码可禁止点击该按钮关闭
					}
				});
			}else if(data.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else if(data.status== "10"){
				console.log(data.info);
			}else{
				layer.open({
					title: '提示'
					,content: data.info
					,btn: ['确定']
					,yes: function(index, layero){
						layer.close(index);
					}
					,cancel: function(){
						//右上角关闭回调
						//return false 开启该代码可禁止点击该按钮关闭
					}
				});
			}
		}

		var wxjson = new webjson("12"); //设置action值
		//新增param键值
		wxjson.AddParam("jbid", jbid);
		WebRequestAsync(wxjson, operateRecordInfo);//读取经营备案信息

	})

	getActiveN("a11", "a1104");//当前页标志
})
function getcid(ttt) {
   var cid= $(ttt).find('span').text();
	window.location.href = 'Enterprise_archivesInfo.html?c_id=' + escape(cid);
}
$(".inputWraper .foodName").on("keydown",function(event){//按下回车执行查询
	    var event=event || window.event;
	    if(event.keyCode == "13") {//判断如果按下的是回车键则执行下面的代码
	    	$("#Search").click();
	    }
	})
