autoH();
var a1 = "a11",
	a2 = "a1101";
var sssel="0",sskey="",ssmode="1",cid="",storage="",ycountry="",pindex = "1",psize = "20",pid="",departmentid="",zoneCode="",pname1="",keyWords="",foodType="",goodsCode1="";
var cheType="";/**添加食品分类的传参**/
var jj=0;/**设置动态生成id的初始值**/
var foodType1="";/**保存食品分类名称**/
var cskey="";/**关注中创建新分类的名称**/

/**分页设置**/
var pcent = new CentPage();
var pcount = ""; //总条数
var jsonParam="";//导出时需要传的参数
var ps = pcent.GetCentPage(pindex, pcount, psize);
$("#page").html(ps);
function CentPageOper(spindex) {
	search(sssel, sskey, ssmode, cid, storage, ycountry,departmentid, spindex, psize);
}

/**页面加载时**/
$(function() {
	sskey = getQueryString("sskey"); /**将url中传过来的值进行解码**/
 	if(sskey==null){
 		sskey="";
 	}else{
 		$(".foodName").val(sskey);
 	}
 	console.log(sskey);
 	departmentid=$.cookie("departmentid");
	zoneCode=$.cookie("dep_code");
	search(sssel, sskey, ssmode, cid, storage, ycountry,departmentid,pindex, psize);
 	getActiveN("a11", "a1101");//当前页标志
 	autoH();
});

/**搜索**/
function search(sssel, sskey, ssmode, cid, storage, ycountry,departmentid,spindex, psize) {
	pindex = spindex;
	$("table tbody").children().remove();
	$("table tbody").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;'><img src='../style/image/load.gif' alt='' /></td></tr>");
	$("#daochu").css("display","none");
	$("#mySelectS").css("display","none");
	var wxjson = new webjson("7"); //设置action值
	//新增param键值
	wxjson.AddParam("sssel", sssel);
	wxjson.AddParam("sskey", sskey);
	wxjson.AddParam("ssmode", ssmode);
	wxjson.AddParam("cid", cid);
	wxjson.AddParam("storage", storage);
	wxjson.AddParam("ycountry", ycountry);
	wxjson.AddParam("departmentid", departmentid);
	wxjson.AddParam("page_index", pindex);
	wxjson.AddParam("page_size", psize);
	WebRequestAsync(wxjson, searchInfo);
	jsonParam=wxjson.GetJsons();
}
function searchInfo(res){
	var html = "";
	var data = GetOjson(json_parse(res));
	console.log(data);
	pcount = data.paramcentcount;
	$(".totalNum1").html("共"+pcount+"条");
	var ps = pcent.GetCentPage(pindex, pcount, psize);
	$("#page").html(ps);
	if(data.status == 0) {
		if(pcount!="0"){
			$("#daochu").css("display","");
			$("#mySelectS").css("display","");
			}else{
			 $("#daochu").css("display","none");
			 $("#mySelectS").css("display","none");
			}
		for(var i = 0; i < data.param.length; i++){
			pid=data.param[i].pid;
			pname=escape(data.param[i].pname);
			if(data.param[i].time==undefined){
				data.param[i].time="";
			}
			var ycountry1=escape(data.param[i].ycountry);
			var gz=data.param[i].is_attentiongood;
			if(data.param[i].is_attentiongood=="0"){
				gz="取消关注";
			}else{
				gz="关注";
			}
			html += "<tr>";
			html += '<td class="hs">' +data.param[i].pname +
			"</td><td class='hs'>" +data.param[i].barcode +
			"</td><td class='hs'>" +data.param[i].ycountry +			
            '</td><td class="hs ls"><a href="Food_info.html?pid='+data.param[i].pid+'&barcode='+data.param[i].barcode+'&pname='+pname+'" target="_blank">详情<span style="display:none;">'+data.param[i].pid+'</span></a><span class="ls">|</span><a href="javascript:void(0);" onclick="gz(this)"><s style="display:none;">'+data.param[i].pname+'</s><i style="display:none;">'+data.param[i].pid+'</i><span>'+gz+'</span></a></td>';
//			"</td><td><a href='#' style='display:inline-block;width:100%;' class='ls' onclick='qy(this)'><span style='display:none;'>"+data.param[i].barcode+"</span>"+data.param[i].xgqy +
//			"</a></td><td><a href='#' style='display:inline-block;width:100%;' class='ls' onclick='xq(this)'>详情<span style='display:none;'>"+data.param[i].pid+"</span></a></td>";
		    html += "</tr>";
	}
	$("table tbody").html(html);
	autoH();
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else {
		$("table tbody").html("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;font-size:14px;'>没有相关数据</td></tr>");
		$("#daochu").css("display","none");
		$("#mySelectS").css("display","none");
	}
}

/**select选择框**/


//重置按钮
$("#form .btn1").click(function(){
	$("#cc").find("input[type='checkbox']:checked").removeAttr('checked', 'checked');
	$("#ycg").find("input[type='checkbox']:checked").removeAttr('checked', 'checked');
})

//点击高级搜索下拉
$("#gjSearch").click(function(){
    $("#form").slideToggle();
});

/**按enter键查询**/
$(".foodName").keydown(function(event){
 if(event.keyCode==13){
	$("#Search").click();
}
})

/**点击查询**/
$("#Search").click(function(){
	pindex="1";
	sskey=$.trim($(".foodName").val());
	if(sskey=="请输入关键字进行查询"){
		sskey="";
	}
	sssel = $("#sssel").find("option:selected").val();
	ssmode = $(".sel1").find("option:selected").val();
	console.log("sskey:"+sskey+",sssel:"+sssel+",ssmode:"+ssmode);
	search(sssel, sskey, ssmode, cid, storage, ycountry,departmentid,pindex, psize);
})

/**点击高级查询**/
$("#confirBtn").click(function(){
	pindex="1";
	sskey=$.trim($(".foodName").val());
	if(sskey=="请输入关键字进行查询"){
		sskey="";
	}
	sssel = $("#sssel").find("option:selected").val();
	ssmode = $(".sel1").find("option:selected").val();
	storage=checkBoxFormat($("#cc"));
	ycountry=checkBoxFormat($("#ycg"));
	console.log("sskey:"+sskey+",sssel:"+sssel+",ssmode:"+ssmode+",storage:"+storage+",ycountry:"+ycountry);
	search(sssel, sskey, ssmode, cid, storage, ycountry,departmentid,pindex, psize);
})

/**导出**/
$("#daochu").click(function(){
	console.log(jsonParam);
	var name=$.cookie('dept_name');//监管所name
	console.log(name);
	var excelName=name+"食品档案表";
	var pattern = new RegExp('[\/:*?"<>|]');
	if(pattern.test(excelName)){
        for (var i = 0; i < excelName.length; i++) {
        	excelName = excelName.replace(pattern, '-');
        	console.log(excelName);
        }
    }
	var listType="goodsList";
	var header="食品名称"+","+"商品条码"+","+"原产国"+","+"商标"+","+"贮存条件"+","+"保质期"+","+"规格"+","+"包装方式";
	if(pcount<1001){
		var exportExcelParam={
			excelName:escape(excelName),
			listType:listType,
			header:header,
			jsonParam:jsonParam
		}
		postExportExcel(dcUrl,exportExcelParam);
	}else{
		layer.open({
			title: '系统提示'
			,content: '当前数据量超过1000条，为了数据的安全，我们无法为您导出该数据，如需导出请联系客服。'
			,btn: ['确定']
			,yes: function(){
				layer.closeAll();
			}
		});
		return false;
	}
})

/**点击关注**/
function gz(t){
	pname1=$(t).children("s").text();
	goodsCode1=$(t).children("i").text();
	var text1=$(t).children("span").text();
	console.log(text1);
  if(text1=="关注"){
	var wxjson = new webjson("60"); //设置action值
	//新增param键值
	wxjson.AddParam("departmentid",departmentid);
	wxjson.AddParam("zoneCode",zoneCode);
	var res=WebRequest(wxjson);
	var data = GetOjson(json_parse(res));
	console.log(data);
	var html2="",content1="";
	if(data.status == 0) {	
		for(var i = 0; i < data.param.length; i++) {
		    foodType=data.param[i].typeName;
		    keyWords=data.param[i].keyWords;
		   // var selected=data.param[i].selected;
			html2 +='<div class="div-init foodType">'+
			//if(selected.indexOf(foodType)>-1){
			/**if(foodType==selected){
			  html2 +='<input name="" type="checkbox" value="'+foodType+'" id="foodSelect'+i+'" checked/>';
			}else{**/
			  '<input name="" type="checkbox" value="'+data.param[i].cId+'" id="foodSelect'+i+'"/>'+
			//}
			  '<label class="label1 label4" for="foodSelect'+i+'">'+foodType+'</label></div>';
		    foodType1=foodType1+foodType+",";		    
		}
		foodType1=foodType1.substr(0,foodType1.length-1);
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else{
	   layer.msg(data.info);
	}
	content1= '<div class="warpper">'+
		'<div class="guanzhu">'+
		'<div>为<span style="font-weight:bold;">'+pname1+'</span>选择分类<p style="float:right;" class="rs"></p></div>'+
		'<div><button class="creatType" onclick="creatType()">创建新分类</button>'+
		'<div class="creatName" style="display:none;">'+
		'<input type="text" value="" placeholder="请输入新分类名称" />'+
		'<button class="sbtn btn-exit" onclick="creatName()">取消</button>'+
		'<button class="sbtn" onclick="creatBaoc()">保存</button></div>'+
		'</div><div class="select">'+html2+'</div></div></div>';
	 layer.open({
		title: '提示'
		,content:content1
		,area: ['560px', '500px']
		,btn: ['取消','确认']
		,yes: function(index, layero){			
			layer.close(index);
		}
	   ,btn2:function(index, layero){
		   var cheType1=checkBoxTable($(".select"));//勾选的分类值
			console.log(cheType1);
			cheType=cheType1;
			console.log(cheType);
			var wxjson = new webjson("54"); //设置action值
			//新增param键值
			wxjson.AddParam("departmentid",departmentid);
			wxjson.AddParam("enterpriseid",goodsCode1);
			wxjson.AddParam("types",cheType1);
			wxjson.AddParam("flag","sp");
			WebRequestAsync(wxjson, qurDate);
		function qurDate(res){
			var data = GetOjson(json_parse(res));
			console.log(data);
			if(data.status == 0) {	
				$(t).children("span").html("取消关注");
    			text1="取消关注";
				layer.msg("关注成功!");
				sessionStorage.setItem("gz", text1);
			}else if(data.status == 9) {
				window.location.href = "index.html?loginOut=true";
			}else{
				$(t).children("span").html("关注");
    			text1="关注";
				layer.msg(data.info);
			}
		}
	   }
		,cancel: function(){ 
			//右上角关闭回调
			//return false 开启该代码可禁止点击该按钮关闭
		}
	});
 }else{
		var wxjson = new webjson("55"); //设置action值
		//新增param键值	
		wxjson.AddParam("departmentid",departmentid);
		wxjson.AddParam("enterpriseid",goodsCode1);
		WebRequestAsync(wxjson, qxGzData);
	function qxGzData(res){
		var data = GetOjson(json_parse(res));
		console.log(data);
		if(data.status == 0) {
			$(t).children("span").html("关注");
			text1="关注";
			layer.msg("取消成功！");
			sessionStorage.setItem("gz", text1);
		}else if(data.status == 9){
			window.location.href="index.html?loginOut=true";
		}else {
			$(t).children("span").html("取消关注");
			text1="取消关注";
			layer.msg(data.info);
		}
	}
 }
}

/**关注中判断输入的分类是否和已存在的分类名称相同**/
function compare(){
	var inputs=$.trim($(".creatName input").val());//输入的值
	var ft=[];
	console.log("foodType1:"+foodType1);
	ft=foodType1.split(",");
	console.log("ft:"+ft);
	if(ft.length>0){
	 for(var i=0;i<ft.length;i++){
		console.log("数组："+ft[i]);
		    if(ft[i]==inputs){
			 $(".warpper p").html("此分类已存在，不能重复添加！");
			  $(".creatName").show();
			  $(".creatType").hide();
			  return true;
		}else if(inputs=="关注食品"){
			$(".warpper p").html("此分类已存在，不能重复添加！");
			$(".creatName").show();
			  $(".creatType").hide();
		  return true;
		}else{
			$(".warpper p").html("");
			  $(".creatType").show();
			  $(".creatName").hide();
			  $(".creatName input").val("");
		}
	}
}
}

/**关注中点击创建新分类**/
function creatType(){
	console.log("12");
	$(".creatType").hide();
	$(".creatName").show();
}

/**关注中创建新分类中取消按钮**/
function creatName(){
	$(".creatType").show();
	$(".creatName").hide();
	$(".creatName input").val("");
	$(".warpper p").css("display","none");
}

/**关注中创建新分类中保存按钮**/
function creatBaoc(){
	cskey=$.trim($(".creatName input").val());
	console.log(cskey);
	console.log(foodType1);
	if(cskey=="请输入新分类名称"||cskey==""){
		$(".warpper p").html("请输入新分类名称");
	}else if(compare()){
		return;
	}else{
	  	var wxjson = new webjson("61"); //设置action值
		//新增param键值	
		wxjson.AddParam("keywords","");	
		wxjson.AddParam("typename",cskey);
		wxjson.AddParam("departmentid",departmentid);
		wxjson.AddParam("type","INSERT");
		WebRequestAsync(wxjson, creatBaoDate);
	}
}

function creatBaoDate(res){
	var htmlL="";
	var data = GetOjson(json_parse(res));
	console.log(data);
	if(data.status == 0) {	
		htmlL +='<div class="div-init foodType">'+
	   '<input name="" type="checkbox" value="'+data.param[0].cId+'" id="foodSel'+jj+'"/>'+
	   '<label class="label1 label4" for="foodSel'+jj+'"><pre>'+cskey+'</pre></label></div>';
	   jj++;
	   $(".select").append(htmlL);
	   foodType1=foodType1+","+cskey;
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else{
	  $(".select").append("");
	}
}


