var a1 = "a11",
	a2 = "a1101";
var pid="",pname="",barcode="",ycountry="",departmentid="",zoneCode="",goodsCode1="",keyWords="",foodType="",cskey="",foodType1="",gz="";
var cheType="";/**添加食品分类的传参**/
var jj=0;/**设置动态生成id的初始值**/
var photo=[];//页面上显示的图片集合
/**页面加载**/
$(function() {
	var pid1=getQueryString("pid");
	var pname1=getQueryString("pname");
	var barcode1=getQueryString("barcode");
	//gz=getQueryString("gz");
	//console.log("gz:"+gz);
	departmentid=$.cookie("departmentid");
	zoneCode=$.cookie("dep_code");
	//var cpid1=getQueryString("cpid");
	//var ycountry1=getQueryString("ycountry");
	console.log(pname1);
	/**判断url中传过来的值是否有值，如果有，就从url中取，如果没有就从缓存中取值**/
	if(pid1==null||pid1==""||pid1==undefined){
		pid = sessionStorage.getItem("pid");
	}else{
	pid = pid1;
	}
	if(barcode1==null||barcode1==undefined){
		barcode= sessionStorage.getItem("barcode");
	}else{
		barcode= barcode1;
	}
	if(pname1==null||pname1==""||pname1==undefined){
		pname= sessionStorage.getItem("pname");
	}else{
		pname= pname1;
	}
	/**if(gz==null||gz==""||gz==undefined){
		gz= sessionStorage.getItem("gz");
	}else{
		gz= gz;
	}**/
	/**if(cpid1==null||cpid1==""||cpid1==undefined){
		cpid=sessionStorage.getItem("cpid");
	}else{
		cpid=cpid1;
	}**/
	/**if(ycountry1==null||ycountry1==undefined){
		ycountry= sessionStorage.getItem("ycountry");
	}else{
		ycountry= ycountry1;
	}**/
	sessionStorage.setItem("pname", pname);
    sessionStorage.setItem("barcode", barcode);
    sessionStorage.setItem("pid", pid);
   // sessionStorage.setItem("gz", gz);
   // sessionStorage.setItem("cpid", cpid);
 	console.log(pid);
	foodInfo(pid,barcode);
	getActiveN("a11", "a1101");//当前页标志
	//$("img.qh").trigger('click');
});

/**调用8接口**/
function foodInfo(pid,barcode){
	var wxjson = new webjson("8"); //设置action值
	//新增param键值
	/**if(cpid!=null&&cpid!=undefined){
		wxjson.AddParam("cpid", cpid);
	}else{**/
	wxjson.AddParam("pid", pid);
	//}
	wxjson.AddParam("barcode", barcode);
	wxjson.AddParam("departmentid",departmentid);
	WebRequestAsync(wxjson, foodInfoRead);
}
function foodInfoRead(res){
	var htmlCt="";//页面头部信息
	var html1 = "";//食品属性
	var html2="";//食品类别
	var html3="";//食品标签
	var html4="";//成分配料
	var htmlImg="";//存放图片
	//var pname1="";
	//var barcode1="";
	var data = GetOjson(json_parse(res));
	console.log(data);
	if(data.status==0){
		gz=data.param[0].is_attentiongood;
		if(data.param[0].is_attentiongood=="0"){
			gz="取消关注";
		}else{
			gz="关注";
		}
		    sessionStorage.setItem("gz", gz);
		    ycountry=data.param[0].ycountry;
		    sessionStorage.setItem("ycountry", ycountry);
		    /**获取页面头部信息**/
		    if(barcode==""){
		    	htmlCt +="<a href='javascript:void(0);'>"+pname+"</a><a href='javascript:void(0);' onclick='gz1(this)' style='float:right;margin-right:20px;color:#56BBF9;'><s style='display:none;'>"+pname+"</s><i style='display:none;'>"+data.param[0].pid+"</i><span>"+gz+"</span></a>";	
		    }else{
		        htmlCt +="<a href='javascript:void(0);'>"+pname+"<span style='font-size:18px;'>（"+barcode+"）</span></a><a href='javascript:void(0);' onclick='gz1(this)' style='float:right;margin-right:20px;color:#56BBF9;'><s style='display:none;'>"+pname+"</s><i style='display:none;'>"+data.param[0].pid+"</i><span>"+gz+"</span></a>";
		    }
		    $(".content-title").html(htmlCt);
		     autoH();
		    /**获取食品属性信息**/
			html1 +="<li><span>食品名称</span><input type='text'  disabled='disabled' value="+pname+"></li>"+
		           "<li><span>包装方式</span><input type='text' disabled='disabled' value="+data.param[0].packing+"></li>"+
		           "<li><span>商品条码</span><input type='text' disabled='disabled' value="+barcode+"></li>"+
		           "<li><span>贮存条件</span><input type='text' disabled='disabled' value="+data.param[0].storage+"></li>"+
		           "<li><span>原产国</span><input type='text' disabled='disabled' value="+data.param[0].ycountry+"></li>"+
		           "<li><span>保质期</span><input type='text' disabled='disabled' value="+data.param[0].shelflife+"></li>"+
		           "<li><span>商标</span><input type='text' disabled='disabled' value="+data.param[0].trademark+"></li>"+
		           "<li><span>规格</span><input type='text' disabled='disabled' value="+data.param[0].spec+"></li>"+
		           "<li><span>生产厂家</span><input type='text' disabled='disabled' value="+data.param[0].sccj+"></li>"+
		           "<li style='width:100%;font-size:14px;'>" +
		           "<span>食品图片</span>";
			    if(data.param[0].photos.length>0){
				  photo = (data.param[0].photos).split(",");
				}
			    if(photo.length==0){
			    	html1 += "暂无";
			    }else{
			        for(var j = 0; j < photo.length; j++) {
				    html1 += "<img src='" + photo[j] + "' onclick='ckImg(this)'>";
			        }
			    }
		        "</li>";
			//	var label=data.param[0].label;//食品标签的集合
		$(".spsx").html(html1);
		autoH();
		/**获取食品类别信息**/
			/**html2 +="<li>类别：<span>"+data.param[0].classify[0]+"</span></li>"+
			"<li>类别编号：<span>"+data.param[0].classify[1]+"</span></li>"+
			"<li>类别名称：<span>"+data.param[0].classify[2]+"</span></li>"+
			"<li>品种名称：<span>"+data.param[0].classify[3]+"</span></li>";
		$(".splb").html(html2);**/
	   /**获取食品标签信息**/
		 /** for(var i=0;i<label.length-1;i++){
			    html3 +="<li>"+label[i]+"</li>";
	   $(".spbq").append(html3);
		  }**/
	  /**获取成分配料信息**/
		  /**html4 +="<li>"+data.param[0].batching+"</li>";
	   $(".cfpl").append(html4);**/
	}else if(data.status==9){
		window.location.href="index.html?loginOut=true";
	}else{
		$(".content-title").html("");
		//$(".spsx").html("");
		$(".splb").append("");
		$(".spbq").append("");
		$(".cfpl").append("");
	}
}

/**点击图片**/
function ckImg(c){
	layer.open({
		type: 1,
		title: '查看图片',
		shadeClose: true,
		shade: 0.5,
		area: ['auto', 'auto'],
		content: '\<div class="warpperBox"><\/div><script> photoRead();</script>'
		//btn: ['取消']
	});
}

/**查看图片**/
function photoRead(){
	var html="";
	  html += "<div class='imgDiv' style='width: 600px;height: 610px; margin:20px;border:none;'>" +
		"<ul class='images' style='list-style: none;'>";
	  for(var j = 0; j < photo.length; j++) {
			html += "<li><img src='" + photo[j] + "'></li>";
		}
	     html +="</ul></div>";
	     $(".warpperBox").append(html);
			console.log($(".images"))
			$(".images").viewer({
				inline: true
			});
}

/**点击关注**/
function gz1(t){
	console.log("guanzhu");
	var pname1=$(t).children("s").text();
	goodsCode1=$(t).children("i").text();
	var text1=$(t).children("span").text();
	console.log(text1);
	if(text1=="关注"){
	 layer.open({
		title: '提示'
		,content: '\<div class="warpper"><div class="guanzhu"><div>为<span style="font-weight:bold;">'+pname1+'</span>选择分类<p style="float:right;" class="rs"></p></div><div><button class="creatType" onclick="creatType()">创建新分类</button><div class="creatName" style="display:none;"><input type="text" value="" placeholder="请输入新分类名称" /><button class="sbtn btn-exit" onclick="creatName()">取消</button><button class="sbtn" onclick="creatBaoc()">保存</button></div></div><div class="select"></div></div><\/div><script> addList();</script>'
		,area: ['560px', '500px']
		,btn: ['取消','确认']
		,yes: function(index, layero){		
			layer.close(index);
		}
	    ,btn2:function(index, layero){
	    	var cheType1=checkBoxTable($(".select"));//勾选的分类值
	    	console.log(cheType1);
	    	cheType=cheType1; 
	    	console.log(cheType);
	    	var wxjson = new webjson("54"); //设置action值
	    	//新增param键值
	    	wxjson.AddParam("departmentid",departmentid);
	    	wxjson.AddParam("enterpriseid",goodsCode1);
	    	wxjson.AddParam("types",cheType1);
	    	wxjson.AddParam("flag","sp");
	    	WebRequestAsync(wxjson, qurDate);
	    function qurDate(res){
	    	var data = GetOjson(json_parse(res));
	    	console.log(data);
	    	if(data.status == 0) {	
	    		$(t).children("span").html("取消关注");
    			text1="取消关注";
	    		layer.msg("关注成功!");
	    		sessionStorage.setItem("gz", text1);
	    	}else if(data.status == 9) {
	    		window.location.href = "index.html?loginOut=true";
	    	}else{
	    		$(t).children("span").html("关注");
    			text1="关注";
	    		layer.msg(data.info);
	    	}
	    }
	   }
		,cancel: function(){ 
			//右上角关闭回调
			//return false 开启该代码可禁止点击该按钮关闭
		}
	});
 }else{
		var wxjson = new webjson("55"); //设置action值
		//新增param键值	
		wxjson.AddParam("departmentid",departmentid);
		wxjson.AddParam("enterpriseid",goodsCode1);
		WebRequestAsync(wxjson, qxGzData);
	function qxGzData(res){
		var data = GetOjson(json_parse(res));
		console.log(data);
		if(data.status == 0) {
			$(t).children("span").html("关注");
			text1="关注";
			layer.msg("取消成功！");
			sessionStorage.setItem("gz", text1);
		}else if(data.status == 9){
			window.location.href="index.html?loginOut=true";
		}else {
			$(t).children("span").html("取消关注");
			text1="取消关注";
			layer.msg(data.info);
		}
	}
 }
}

/**点击关注，弹框中显示的内容调用的方法**/
function addList(){
	var wxjson = new webjson("60"); //设置action值
	//新增param键值
	wxjson.AddParam("departmentid",departmentid);
	wxjson.AddParam("zoneCode",zoneCode);
	var res=WebRequest(wxjson);
	var data = GetOjson(json_parse(res));
	console.log(data);
	var html2="";
	if(data.status == 0) {	
		for(var i = 0; i < data.param.length; i++) {
		    foodType=data.param[i].typeName;
		    keyWords=data.param[i].keyWords;
		   // var selected=data.param[i].selected;
			html2 +='<div class="div-init foodType">';
			//if(selected.indexOf(foodType)>-1){
			/**if(foodType==selected){
			  html2 +='<input name="" type="checkbox" value="'+foodType+'" id="foodSelect'+i+'" checked/>';
			}else{**/
			  html2 +='<input name="" type="checkbox" value="'+data.param[i].cId+'" id="foodSelect'+i+'"/>';
			//}
			html2 +='<label class="label1 label4" for="foodSelect'+i+'">'+foodType+'</label></div>';
		    foodType1=foodType1+foodType+",";		    
		}
		 $(".select").html(html2);
		foodType1=foodType1.substr(0,foodType1.length-1);
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else{
	    $(".select").html("");
	}
}

/**关注中判断输入的分类是否和已存在的分类名称相同**/
function compare(){
	var inputs=$.trim($(".creatName input").val());//输入的值
	var ft=[];
	console.log("foodType1:"+foodType1);
	ft=foodType1.split(",");
	console.log("ft:"+ft);
	if(ft.length>0){
	 for(var i=0;i<ft.length;i++){
		console.log("数组："+ft[i]);
		    if(ft[i]==inputs){
			 $(".warpper p").html("此分类已存在，不能重复添加！");
			  $(".creatName").show();
			  $(".creatType").hide();
			  return true;
		}else if(inputs=="关注食品"){
			$(".warpper p").html("此分类已存在，不能重复添加！");
			$(".creatName").show();
			  $(".creatType").hide();
		  return true;
		}else{
			$(".warpper p").html("");
			  $(".creatType").show();
			  $(".creatName").hide();
			  $(".creatName input").val("");
		}
	}
}
}

/**关注中点击创建新分类**/
function creatType(){
	console.log("12");
	$(".creatType").hide();
	$(".creatName").show();
}

/**关注中创建新分类中取消按钮**/
function creatName(){
	$(".creatType").show();
	$(".creatName").hide();
	$(".creatName input").val("");
	$(".warpper p").css("display","none");
}

/**关注中创建新分类中保存按钮**/
function creatBaoc(){
	cskey=$.trim($(".creatName input").val());
	console.log(cskey);
	console.log(foodType1);
	if(cskey=="请输入新分类名称"||cskey==""){
		$(".warpper p").html("请输入新分类名称");
	}else if(compare()){
		return;
	}else{
	  	var wxjson = new webjson("61"); //设置action值
		//新增param键值	
		wxjson.AddParam("keywords","");	
		wxjson.AddParam("typename",cskey);
		wxjson.AddParam("departmentid",departmentid);
		wxjson.AddParam("type","INSERT");
		WebRequestAsync(wxjson, creatBaoDate);
	}
}

function creatBaoDate(res){
	var htmlL="";
	var data = GetOjson(json_parse(res));
	console.log(data);
	if(data.status == 0) {	
		htmlL +='<div class="div-init foodType">'+
	   '<input name="" type="checkbox" value="'+data.param[0].cId+'" id="foodSel'+jj+'"/>'+
	   '<label class="label1 label4" for="foodSel'+jj+'"><pre>'+cskey+'</pre></label></div>';
	   jj++;
	   $(".select").append(htmlL);
	   foodType1=foodType1+","+cskey;
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else{
	  $(".select").append("");
	}
}
