autoH();
var a1 = "a11",
a2 = "a1101";
var bbid="";
var jypk="";
var photo="";//相关票据
var photo1="";//资质证件
/**页面加载**/
$(function() {
	bbid=getQueryString("bbid");
	console.log(bbid);
	jypk=getQueryString("jyid");
	console.log(jypk);
	getActiveN("a11", "a1101");//当前页标志
	ledger(bbid);
})

function ledger(bbid){
	$(".tbody1").children().remove();
//	$(".tbody1").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;'><img src='../style/image/load.gif' alt='' /></td></tr>");
	var wxjson = new webjson("10"); //设置action值
	//新增param键值
	wxjson.AddParam("bbid", bbid);
	WebRequestAsync(wxjson, ledgerList);
}
function ledgerList(res){
	var htmlLi = "";	
	var htmlImg="";//相关票据
	var data = GetOjson(json_parse(res));
	if(data.status == 0){
		if(data.param[0].bbtype == 0) {
			data.param[0].bbtype = '食品采购报备';
		} else{
			data.param[0].bbtype = '食品销售报备';
		}
		var c_id=data.param[0].cid;
		console.log(c_id);
		var cname1=escape(data.param[0].cname);
		htmlLi += "<li>单据号："+data.param[0].djnum+
		"</li><li>报备日期：<span>"+data.param[0].bbtime+
		"</li><li>交易日期：<span>"+data.param[0].jytime+
		'</li><li>报备企业：<a href="Enterprise_archivesInfo.html?c_id='+c_id+'" target="_blank">'+data.param[0].cname+
		'</a></li><li>交易对象：<a href="Enterprise_tradeObjectsInfo.html?jyid='+jypk+'&cname='+cname1+'&c_id='+c_id+'" target="_blank">'+data.param[0].jycname+
		"</a></li><li>报备类型："+data.param[0].bbtype+
		"</li>";	
		$(".list-com").html(htmlLi);
		   /**相关票据**/
		 htmlImg +="<span>相关票据：</span>";
		 if(data.param[0].photos.length>0){
			 photo = (data.param[0].photos).split(",");
			 for(var j=0;j<photo.length;j++){
			  htmlImg += "<img src='" + photo[j] + "' onclick='ckImg1(this)'>";
			  $(".xgbill").html(htmlImg);
			 }
			}else{
			   if(data.param[0].bbtype == '食品采购报备'){
				htmlImg +="<span style='color:#EF2121;'>未索票</span>";
				}else{
					htmlImg +="<span>暂无</span>";	
				}
				$(".xgbill").html(htmlImg);
			}
         /**资质证件**/
		 if(data.param[0].zjphoto.length > 0){
				zjphoto=data.param[0].zjphoto.split(",");
				console.log(zjphoto);				
				$(".zzzj").html("<span>资质证件：</span>");      
				for(var i=0;i<zjphoto.length;i++){
						html="<img src='" + zjphoto[i] + "'>";
						$(".zzzj").append(html);
					}
				autoH();
			}else{
				if(data.param[0].bbtype == '食品采购报备'){
				$(".zzzj").html('<span>资质证件：</span><span style="color:#EF2121;">未索证</span>');
				}else{
					$(".zzzj").html('<span>资质证件：</span><span>暂无</span>');
				}
			}
		 /**列表**/		
		for(var j=0;j<data.datas.plist.length;j++){
			var htmlTb="";
			var pid=data.datas.plist[j].pid;
			console.log("111111"+pid);
			htmlTb += "<tr>";
			htmlTb += '<td class="hs"><a href="Enterprise_foodInfo.html?c_id='+c_id+'&barcode='+data.datas.plist[j].barcode+'&cname='+cname1+'" target="_blank">' +data.datas.plist[j].pname + 
			"</a></td><td class='hs'>" +data.datas.plist[j].barcode + 
			"</td><td class='hs'>" +data.datas.plist[j].sctime + 
			"</td><td class='hs'>" +data.datas.plist[j].bzq + 
			"</td><td class='hs'>" +data.datas.plist[j].pnum + 
			"</td><td class='hs'>" +data.datas.plist[j].spec +
			"</td>";
			if(data.param[0].bbtype == '食品采购报备'){
			htmlTb +="<td class='hs rs'>未索证</td>";
			}else{
				htmlTb +="<td class='hs rs'>未上传</td>";	
			}
			/**if(data.datas.plist[j].jyhg=="0"){
				htmlTb +="<td class='rs'>未索证 </td>";
			}else{
				htmlTb +="<td class='ls'><a href='#'>已索证 </a></td>";
			}**/
		    htmlTb += "</tr>";
		    $(".tbody1").append(htmlTb);
		    autoH();
		}
	}else if(data.status==9){
		window.location.href="index.html?loginOut=true";
	}else{
		$(".list-com").append("");
		$(".images").append("");
		$(".tbody1").html("");
	}
	
}

/**点击台账时**/
function taizhang(){
	window.location.href='Food_ledger.html';
}

/**相关票据点击时**/
function ckImg1(tt){
	layer.open({
		type: 1,
		title: '查看票据',
		shadeClose: true,
		shade: 0.5,
		area: ['650px', '700px'],
		content: '\<div class="warpperBox"><\/div><script> photoBill();</script>'
	});
}

function photoBill(){
	 var html="";
	  html += "<div class='imgDiv' style='width: 600px;height: 610px; margin:20px;border:none;'>" +
		"<ul class='images' style='list-style: none;'>";
	  for(var j = 0; j < photo.length; j++) {
			html += "<li><img src='" + photo[j] + "'></li>";
		}
	     html +="</ul></div>";
	     $(".warpperBox").append(html);
			console.log($(".images"))
			$(".images").viewer({
				inline: true
			});
}

/**资质证件点击查看**/
$(".zzzj").on("click","img",function(){//主体图片查看
	var imgContent="",imgPhoto="";
	for(var i=0;i<$(".zzzj img").length;i++){
		var src=$(".zzzj img")[i].src;
		imgPhoto+='<li><img src='+src+'></li>'
	}
	imgContent='<div class="img-warp">'+
	'<div class="imgDiv">'+
	'<ul class="images">'+
	imgPhoto+
	'</ul>'+
	'</div>'+
	'</div>'
	layer.open({
		title: '资质证件查看'
		,content: imgContent
		,area: ['650px', '700px']
		,btn: []
		,cancel: function(){ 
			
		}
	});
	$('.images').viewer({
		inline:true
	});
	
})