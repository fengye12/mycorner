var a1 = "a11",
	a2 = "a1101";
var sskey="",ssmode="1",sssel="0",jaddress="",c_type="",c_id="",o_type="",pindex = "1",psize = "20",pname="",barcode="",ltype="",skey="",departmentid="",zoneCode="",goodsCode1="",keyWords="",foodType="",cskey="",foodType1="",pid="",gz="";
var cheType="";/**添加食品分类的传参**/
var jj=0;/**设置动态生成id的初始值**/
/**分页设置**/
var pcent = new CentPage();
var pcount = ""; //总条数
var ps = pcent.GetCentPage(pindex, pcount, psize);
var jsonParam="";//导出时需要传的参数
$("#page").html(ps);
function CentPageOper(spindex) {
	search(sssel, sskey, ssmode,barcode, jaddress, c_type, o_type, spindex, psize);
}

/**页面加载时**/
$(function() {
	var barcode1=getQueryString("barcode");
	var pname1=getQueryString("pname");
	var pid1=getQueryString("pid");
	var ycountry1=getQueryString("ycountry");
	departmentid=$.cookie("departmentid");
	zoneCode=$.cookie("dep_code");
	gz= sessionStorage.getItem("gz");
	console.log("gz:"+gz);
	/**判断url中传过来的值是否有值，如果有，就从url中取，如果没有就从缓存中取值**/
	if(barcode1==null||barcode1==""||barcode1==undefined){
		barcode = sessionStorage.getItem("barcode");
	}else{
		barcode = barcode1;
	}
	if(pname1==null||pname1==""||pname1==undefined){
		pname = sessionStorage.getItem("pname");
	}else{
		pname = pname1;
	}
	if(pid1==null||pid1==""||pid1==undefined){
		pid = sessionStorage.getItem("pid");
	}else{
		pid = pid1;
	}
	if(ycountry1==null||ycountry1==undefined){
		ycountry= sessionStorage.getItem("ycountry");
	}else{
		ycountry =ycountry1;
	}
	sessionStorage.setItem("pname", pname);
    sessionStorage.setItem("barcode", barcode);
    sessionStorage.setItem("ycountry", ycountry);
    sessionStorage.setItem("pid", pid);
 	console.log(barcode);
	 var htmlCt="";
     /**获取页面头部信息**/
	 if(pname!=null&&barcode!=null&&barcode!=""){
    	 htmlCt +="<a href='javascript:void(0);'>"+pname+"<span style='font-size:18px;'>（"+barcode+"）</span></a><a href='javascript:void(0);' onclick='gz1(this)' style='float:right;margin-right:20px;color:#56BBF9;'><s style='display:none;'>"+pname+"</s><i style='display:none;'>"+pid+"</i><span>"+gz+"</span></a>";
    	 $(".content-title").html(htmlCt);
         }else if(barcode==""){
        	 htmlCt +="<a href='javascript:void(0);'>"+pname+"</a><a href='javascript:void(0);' onclick='gz1(this)' style='float:right;margin-right:20px;color:#56BBF9;'><s style='display:none;'>"+pname+"</s><i style='display:none;'>"+pid+"</i><span>"+gz+"</span></a>";
        	 $(".content-title").html(htmlCt); 
         }else{
        	 $(".content-title").html("");
         }
	search(sssel, sskey, ssmode,barcode, jaddress, c_type, o_type, pindex, psize);
	getActiveN("a11", "a1101");//当前页标志
	//$("img.qh").trigger('click');
});

/**搜索**/
function search(sssel, sskey, ssmode,barcode, jaddress, c_type, o_type, spindex, psize) {
	pindex = spindex;
	$("table tbody").children().remove();
	$("table tbody").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;'><img src='../style/image/load.gif' alt='' /></td></tr>");
	 $("#daochu").css("display","none");
	 $("#mySelectS").css("display","none");
	var wxjson = new webjson("5"); //设置action值
	//新增param键值
	wxjson.AddParam("deptid", $.cookie('departmentid'));//监管单位id
	wxjson.AddParam("barcode", barcode);
	wxjson.AddParam("pid", pid);
	wxjson.AddParam("pname", pname);
	wxjson.AddParam("sssel", sssel);
	wxjson.AddParam("sskey", sskey);
	wxjson.AddParam("ssmode", ssmode);
	wxjson.AddParam("jaddress", jaddress);
	wxjson.AddParam("c_type", c_type);
	wxjson.AddParam("o_type", o_type);
	wxjson.AddParam("page_index", pindex);
	wxjson.AddParam("page_size", psize);
	WebRequestAsync(wxjson, searchCompany);
	jsonParam=wxjson.GetJsons();
}
function searchCompany(res){
	var html = "";
	var data = GetOjson(json_parse(res));
	console.log(data);
	pcount = data.paramcentcount;
	$(".totalNum").html("共"+pcount+"条");
	var ps = pcent.GetCentPage(pindex, pcount, psize);
	$("#page").html(ps);
	if(data.status == 0) {
		  if(pcount!="0"){
			$("#daochu").css("display","");
			$("#mySelectS").css("display","");
			}else{
			 $("#daochu").css("display","none");
			 $("#mySelectS").css("display","none");
			}
		for(var i = 0; i < data.param.length; i++){
			c_id=data.param[i].c_id;
			if(data.param[i].c_type == "0") {
				data.param[i].c_type = '生产企业';
			} else if(data.param[i].c_type=="1"){
				data.param[i].c_type = '销售经营企业';
			}else if(data.param[i].c_type=="2"){
				data.param[i].c_type = '餐饮服务企业';
			}else{
				data.param[i].c_type = '单位食堂';
			}
		   var o_type1=data.param[i].o_type;
		   var o_typeTotal="";
		   if(o_type1==""){
			   o_typeTotal="";
		   }else{
			   o_type1=data.param[i].o_type.split(",");
		   }
		   for(var j=0;j<o_type1.length;j++){
			if(o_type1[j] == "0") {
				o_typeTotal = o_typeTotal+'批发,';
			} else if(o_type1[j]=="1"){
				o_typeTotal = o_typeTotal+'零售,';
			}else if(o_type1[j]=="2"){
				o_typeTotal = o_typeTotal+'批发兼零售,';
			}else if(o_type1[j]=="3"){
				o_typeTotal = o_typeTotal+'网络经营,';
			}else if(o_type1[j]=="4"){
				o_typeTotal = o_typeTotal+'内设中央厨房,';
			}else if(o_type1[j]=="5"){
				o_typeTotal = o_typeTotal+'集体用餐配送,';
			}else{
				o_typeTotal = "";
			}
		   }
		   o_typeTotal=o_typeTotal.substr(0,o_typeTotal.length-1);
		   var attention="";
		   if(data.param[i].is_attention =="0"){
				attention="取消关注";
			}else{
				attention="关注";
			}
			html += "<tr>";
			html += '<td class="hs"><a href="Enterprise_archivesInfo.html?c_id='+c_id+'" target="_blank">' +data.param[i].cname +
			"</a></td><td class='hs'>" +data.param[i].license +
			"</td><td class='hs'>" +data.param[i].jaddress +
			"</td><td class='hs'>" +data.param[i].legal +
			"</td><td class='hs'>" +data.param[i].scompany +
			"</td><td class='hs'>" +data.param[i].c_type +
			"</td><td class='hs'>" +o_typeTotal +
			"</td><td class='hs'>" +data.param[i].cnumber +
			"</td><td class='hs'>" +data.param[i].dqtime+
			'<td class="hs ls"><a href="Enterprise_archivesInfo.html?c_id='+c_id+'" target="_blank">详情</a><span class="fg-line ls">|</span><span class="concern ls" data-cid="'+(data.param[i].c_id)+'">'+attention+'</span></td>';
		    html += "</tr>";
	}
	$("table tbody").html(html);
	autoH();
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else {
		$("table tbody").html("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;font-size:14px;'>没有相关数据</td></tr>");
		$("#daochu").css("display","none");
		$("#mySelectS").css("display","none");
	}
	autoH();
}

/**按enter键查询**/
$(".foodName").keydown(function(event){
 if(event.keyCode==13){
	$("#sea").click();
}
})

/**搜索**/
$("#sea").click(function(){
	pindex="1";
	sskey=$.trim($(".foodName").val());
	if(sskey=="请输入关键字进行查询"){
		sskey="";
	}
	sssel = $(".sel2").find("option:selected").val();
	ssmode = $(".sel1").find("option:selected").val();
	console.log("sskey:"+sskey+",sssel:"+sssel+",ssmode:"+ssmode);
	search(sssel, sskey, ssmode,barcode, jaddress, c_type, o_type, pindex, psize);
})

/**高级搜索**/
$("#confirBtn").click(function(){
	pindex="1";
	var provinceM="",provinceD="",cityM="",cityD="",areaM="",areaD="",roadM="",roadD="";
	sskey=$.trim($(".foodName").val());
	if(sskey=="请输入关键字进行查询"){
		sskey="";
	}
	sssel = $(".sel2").find("option:selected").val();
	ssmode = $(".sel1").find("option:selected").val();
	c_type=checkBoxFormat($("#qylx"));
	o_type=checkBoxFormat($("#jyfs"));
	jaddress=$("#inputChoose").val();//地址
	console.log(jaddress);
	console.log("sskey:"+sskey+",sssel:"+sssel+",ssmode:"+ssmode+",c_type:"+c_type+",o_type:"+o_type+",jaddress:"+jaddress+",barcode:"+barcode);
	search(sssel, sskey, ssmode,barcode, jaddress, c_type, o_type, pindex, psize);
})

/**点击查看**/
/**function ck(c){
	window.location.href='Enterprise_archivesInfo.html?c_id=' + escape(c_id);
}**/

/**设置高级搜索点击事件**/
$('#gjSearch').click(function(event){
    event.stopPropagation();
    if($('#form').css('display')=='none'){
      $('#form').slideDown(300);
      autoH();
    }else{
      $('#form').slideUp(300);
    }
 })

 /**绑定重置按钮事件**/
 $("#reset").click(function() {
	 /**$("#form").find("input[type='checkbox']:checked").removeAttr('checked', 'checked');
	 if($("select.sel-province").length && $("select.sel-province").length > 0){
		    $(".sel-province").get(0).selectedIndex=0;
		    $(".sel-city").html("<option value=''>选择市</option>");
		    $(".sel-district").html("<option value=''>选择区/县</option>");
		    $(".sel-street").html("<option value=''>选择街道</option>");
 }**/

	 $(".area-choose span").text("请选择地区");
	 $("#form").find("input[type='checkbox']:checked").removeAttr('checked', 'checked');
})

/**select选择框**/
// function select() {
// 	pindex="1";
// 	//获取下拉框选中项的text属性值
// 	var selectText = $("#mySelect").find("option:selected").text();
// 	//获取下拉框选中项的value属性值
// 	var selectValue = $("#mySelect").val();
// 	console.log(selectValue);
// 	psize = selectValue;
// 	CentPageOper(pindex);
// 	search(sssel, sskey, ssmode,barcode, jaddress, c_type, o_type, pindex, psize);
// }

/**导出**/
$("#daochu").click(function(){
	var excelName=pname+"相关企业表";
	var pattern = new RegExp('[\/:*?"<>|]');
	if(pattern.test(excelName)){
        for (var i = 0; i < excelName.length; i++) {
        	excelName = excelName.replace(pattern, '-');
        	console.log(excelName);
        }
    }
	var listType="foodEnterpriseList";
	var header="企业名称"+","+"营业执照"+","+"经营地址"+","+"法定代表人"+","+"监管单位"+","+"企业类型"+","+"经营方式"+","+"联系电话"+","+"许可证到期时间";
	if(pcount<1001){
		var exportExcelParam={
			excelName:escape(excelName),
			listType:listType,
			header:header,
			jsonParam:jsonParam
		}
		postExportExcel(dcUrl,exportExcelParam);
	}else{
		layer.open({
			title: '系统提示'
			,content: '当前数据量超过1000条，为了数据的安全，我们无法为您导出该数据，如需导出请联系客服。'
			,btn: ['确定']
			,yes: function(){
				layer.closeAll();
			}
		});
		return false;
	}
})

/**点击关注**/
function gz1(t){
	var pname1=$(t).children("s").text();
	goodsCode1=$(t).children("i").text();
	var text1=$(t).children("span").text();
	console.log(text1);
	if(text1=="关注"){
	 layer.open({
		title: '提示'
		,content: '\<div class="warpper"><div class="guanzhu"><div>为<span style="font-weight:bold;">'+pname1+'</span>选择分类<p style="float:right;" class="rs"></p></div><div><button class="creatType" onclick="creatType()">创建新分类</button><div class="creatName" style="display:none;"><input type="text" value="" placeholder="请输入新分类名称" /><button class="sbtn btn-exit" onclick="creatName()">取消</button><button class="sbtn" onclick="creatBaoc()">保存</button></div></div><div class="select"></div></div><\/div><script> addList();</script>'
		,area: ['560px', '420px']
		,btn: ['取消','确认']
		,yes: function(index, layero){			
			layer.close(index);
		}
	   ,btn2:function(index, layero){
			var cheType1=checkBoxTable($(".select"));//勾选的分类值
			console.log(cheType1);
			cheType=cheType1;
			console.log(cheType);
			var wxjson = new webjson("54"); //设置action值
			//新增param键值
			wxjson.AddParam("departmentid",departmentid);
			wxjson.AddParam("enterpriseid",goodsCode1);
			wxjson.AddParam("types",cheType1);
			wxjson.AddParam("flag","sp");
			WebRequestAsync(wxjson, qurDate);
		function qurDate(res){
			var data = GetOjson(json_parse(res));
			console.log(data);
			if(data.status == 0) {	
				$(t).children("span").html("取消关注");
    			text1="取消关注";
				layer.msg("关注成功!");
				sessionStorage.setItem("gz", text1);
			}else if(data.status == 9) {
				window.location.href = "index.html?loginOut=true";
			}else{
				$(t).children("span").html("关注");
    			text1="关注";
				layer.msg(data.info);
			}
		}

	    }
		,cancel: function(){ 
			//右上角关闭回调
			//return false 开启该代码可禁止点击该按钮关闭
		}
	});
 }else{
		var wxjson = new webjson("55"); //设置action值
		//新增param键值	
		wxjson.AddParam("departmentid",departmentid);
		wxjson.AddParam("enterpriseid",goodsCode1);
		WebRequestAsync(wxjson, qxGzData);
	function qxGzData(res){
		var data = GetOjson(json_parse(res));
		console.log(data);
		if(data.status == 0) {
			$(t).children("span").html("关注");
			text1="关注";
			layer.msg("取消成功！");
			sessionStorage.setItem("gz", text1);
		}else if(data.status == 9){
			window.location.href="index.html?loginOut=true";
		}else {
			$(t).children("span").html("取消关注");
			text1="取消关注";
			layer.msg(data.info);
		}
	}
 }
}

/**点击关注，弹框中显示的内容调用的方法**/
function addList(){
	var wxjson = new webjson("60"); //设置action值
	//新增param键值
	wxjson.AddParam("departmentid",departmentid);
	wxjson.AddParam("zoneCode",zoneCode);
	var res=WebRequest(wxjson);
	var data = GetOjson(json_parse(res));
	console.log(data);
	var html2="";
	if(data.status == 0) {	
		for(var i = 0; i < data.param.length; i++) {
		    foodType=data.param[i].typeName;
		    keyWords=data.param[i].keyWords;
		   // var selected=data.param[i].selected;
			html2 +='<div class="div-init foodType">';
			//if(selected.indexOf(foodType)>-1){
			/**if(foodType==selected){
			  html2 +='<input name="" type="checkbox" value="'+foodType+'" id="foodSelect'+i+'" checked/>';
			}else{**/
			  html2 +='<input name="" type="checkbox" value="'+data.param[i].cId+'" id="foodSelect'+i+'"/>';
			//}
			html2 +='<label class="label1 label4" for="foodSelect'+i+'">'+foodType+'</label></div>';
		    foodType1=foodType1+foodType+",";		    
		}
		 $(".select").html(html2);
		foodType1=foodType1.substr(0,foodType1.length-1);
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else{
	    $(".select").html("");
	}
}

/**关注中判断输入的分类是否和已存在的分类名称相同**/
function compare(){
	var inputs=$.trim($(".creatName input").val());//输入的值
	var ft=[];
	console.log("foodType1:"+foodType1);
	ft=foodType1.split(",");
	console.log("ft:"+ft);
	if(ft.length>0){
	 for(var i=0;i<ft.length;i++){
		console.log("数组："+ft[i]);
		    if(ft[i]==inputs){
			 $(".warpper p").html("此分类已存在，不能重复添加！");
			  $(".creatName").show();
			  $(".creatType").hide();
			  return true;
		}else if(inputs=="关注食品"){
			$(".warpper p").html("此分类已存在，不能重复添加！");
			$(".creatName").show();
			  $(".creatType").hide();
		  return true;
		}else{
			$(".warpper p").html("");
			  $(".creatType").show();
			  $(".creatName").hide();
			  $(".creatName input").val("");
		}
	}
}
}

/**关注中点击创建新分类**/
function creatType(){
	console.log("12");
	$(".creatType").hide();
	$(".creatName").show();
}

/**关注中创建新分类中取消按钮**/
function creatName(){
	$(".creatType").show();
	$(".creatName").hide();
	$(".creatName input").val("");
	$(".warpper p").css("display","none");
}

/**关注中创建新分类中保存按钮**/
function creatBaoc(){
	cskey=$.trim($(".creatName input").val());
	console.log(cskey);
	console.log(foodType1);
	if(cskey=="请输入新分类名称"||cskey==""){
		$(".warpper p").html("请输入新分类名称");
	}else if(compare()){
		return;
	}else{
	  	var wxjson = new webjson("61"); //设置action值
		//新增param键值	
		wxjson.AddParam("keywords","");	
		wxjson.AddParam("typename",cskey);
		wxjson.AddParam("departmentid",departmentid);
		wxjson.AddParam("type","INSERT");
		WebRequestAsync(wxjson, creatBaoDate);
	}
}

function creatBaoDate(res){
	var htmlL="";
	var data = GetOjson(json_parse(res));
	console.log(data);
	if(data.status == 0) {	
		htmlL +='<div class="div-init foodType">'+
	   '<input name="" type="checkbox" value="'+data.param[0].cId+'" id="foodSel'+jj+'"/>'+
	   '<label class="label1 label4" for="foodSel'+jj+'"><pre>'+cskey+'</pre></label></div>';
	   jj++;
	   $(".select").append(htmlL);
	   foodType1=foodType1+","+cskey;
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else{
	  $(".select").append("");
	}
}
/*关注*/
	$("table tbody").on("click",".concern",function(){
		var _this=$(this);
		if(_this.text() == "关注"){
			var wxjson = new webjson("53"); //设置action值
			//新增param键值
			wxjson.AddParam("enterpriseid", _this.data("cid"));//企业id
			wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
			var res=WebRequest(wxjson);
			var data = GetOjson(json_parse(res));
			console.log(data);
			if(data.status == "0"){
				var list="";
				$.each(data.param,function(i,item){
					// if(i < data.param.length-1){
						// var fl=false,paramLen=data.param.length-1;
						// if(data.param[paramLen].selected.length > 0){
						// 	var selArr=data.param[paramLen].selected.split(",");
						// 	// for(var i=0;i<selArr.length;i++){
						// 	// 	if(selArr[i] == item.c_id){
						// 	// 		fl=true;
						// 	// 	}
						// 	// }
						// 	if(selArr.indexOf(item.c_id) >= 0){
						// 		list+='<li data-id="'+item.c_id+'">'+
						// 		'<input name="" type="checkbox" value="" id="type'+i+'" checked />'+
						// 		'<label class="label1" for="type'+i+'">'+item.typename+'</label>'+
						// 		'</li>';
						// 	}else{
						// 		list+='<li data-id="'+item.c_id+'">'+
						// 		'<input name="" type="checkbox" value="" id="type'+i+'" />'+
						// 		'<label class="label1" for="type'+i+'">'+item.typename+'</label>'+
						// 		'</li>';
						// 	}
						// }else{
							list+='<li data-id="'+item.c_id+'">'+
							'<input name="" type="checkbox" value="" id="type'+i+'" />'+
							'<label class="label1" for="type'+i+'"><pre>'+item.typename+'</pre></label>'+
							'</li>';
						//}
					// }	
					
				})
				var cname1=_this.parents("tr").children("td").eq(0).text();
				var html='<div class="toast-warp">'+
				'<form>'+
				'<ul class="record-form">'+
				'<li>'+
				'<h3 class="h3-title2">为<b>'+cname1+'</b>选择分类</h3>'+
				'</li>'+
				'<li>'+
				'<span class="sbtn gz-add">创建新分类</span>'+
				'<div class="add-type">'+
				'<input type="text" value="" maxlength="20" placeholder="请输入分类名称" class="foodName" />'+
				'<span class="sbtn" id="cancel">取消</span>'+
				'<span class="sbtn" id="save">保存</span>'+
				'</div>'+
				'</li>'+
				'<li>'+
				'<ul class="type-list clearfix">'+
				list+
				// '<li>'+
				// '<input name="" type="checkbox" value="" id="type0" />'+
				// '<label class="label1" for="type0">特殊医学用途配方食品相关企业</label>'+
				// '</li>'+

				'</ul>'+
				'</li>'+
				'</ul>'+
				'</form>'+
				'</div>';
				layer.open({
					type:1
					,title: ' '
					,content: html
					,area: ['530px', 'auto']
					,btn: ['取消', '确认']
					,yes: function(index, layero){
						layer.close(index);
				    	//按钮【按钮二】的回调
				    	//return false 开启该代码可禁止点击该按钮关闭
					}
					,btn2: function(index, layero){
					
						var typesArr=[];
						$.each($(".type-list li"),function(){
							if($(this).find("input[type='checkbox']").prop("checked")){
								typesArr.push($(this).data("id"));
							}
						})
						console.log(typesArr);
						
							var wxjson = new webjson("54"); //设置action值
							//新增param键值
							wxjson.AddParam("enterpriseid", _this.data("cid"));//企业id
							wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
							wxjson.AddParam("flag", "qy");
							if(typesArr.length > 0){
								wxjson.AddParam("types", typesArr.join(","));//选中的类别id,拼接成逗号隔开的字符串"
							}else{
								wxjson.AddParam("types", "");//选中的类别id,拼接成逗号隔开的字符串"
							}
							
							var res=WebRequest(wxjson);
							var data2 = GetOjson(json_parse(res));
							if(data2.status == "0"){
								//companyList(sskey,ssmode,sssel,jaddress,ctype,otype,cstatus,yjstatus,pagenum,ecount);
								_this.text("取消关注");
								$.cookie('THE_SET_CONCERN', '取消关注', { path: '/' });
								layer.msg(data2.info);
								layer.close(index);
							}else if(data2.status == "9"){
								window.location.href="index.html?loginOut=true";
								return;
							}else{
								layer.msg(data2.info);
							}
							
						
					}
					,cancel: function(index, layero){
						 
				    	//右上角关闭回调
				    	//return false 开启该代码可禁止点击该按钮关闭
					}
				});

				
				$(".gz-add").on("click",function(){
					$(this).hide();
					$(this).next().show();
				})
				$("#cancel").on("click",function(){
					$(this).parent(".add-type").hide();
					$(this).parent(".add-type").prev().show();
					$(this).parent(".add-type").children(".foodName").val("");
				})
				$(".add-type .foodName").on("keydown",function(event){
					var event=event || window.event;
				    if(event.keyCode == "13") {//判断如果按下的是回车键则执行下面的代码
				    	return false;
				    }
				})
				$("#save").on("click",function(){//创建新分类
					var tname1=$(this).parent(".add-type").children(".foodName").val();
					console.log(tname1);
					var typesNameArr=[];
					$.each($(".type-list li"),function(){
						if($(this).find(".label1").text()){
							typesNameArr.push(Trim($(this).find(".label1").text()));
						}
					})
					console.log(typesNameArr);
					if(typesNameArr.indexOf(tname1) >= 0){
						layer.msg('企业分类名称不能重复！');
					}else{
						var wxjson = new webjson("49"); //设置action值 创建新分类
						//新增param键值
						wxjson.AddParam("c_id", "");//类别id
						wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
						wxjson.AddParam("typename", Trim(tname1));//:类别名称
						wxjson.AddParam("keywords", "");//搜索关键字，以空格隔开
						wxjson.AddParam("zone_code", $.cookie('dep_code'));//:当前监管单位code编码

						var res=WebRequest(wxjson);
						var data5 = GetOjson(json_parse(res));
						if(data5.status == "0"){
							//layer.msg(data.info);
							var wxjson = new webjson("53"); //设置action值
							//新增param键值
							wxjson.AddParam("enterpriseid", _this.data("cid"));//企业id
							wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
							var res=WebRequest(wxjson);
							var data = GetOjson(json_parse(res));
							console.log(data);
							if(data.status == "0"){//读取分类信息

								var list="";
								$.each(data.param,function(i,item){
									list+='<li data-id="'+item.c_id+'">'+
									'<input name="" type="checkbox" value="" id="type'+i+'" />'+
									'<label class="label1" for="type'+i+'"><pre>'+item.typename+'</pre></label>'+
									'</li>';	
									
								})
								$(".type-list").children().remove();
								$(".type-list").append(list);

							}else if(data.status == "9"){
								window.location.href="index.html?loginOut=true";
								return;
							}else{
								layer.msg(data.info);
							}
						}else if(data5.status == "9"){
							window.location.href="index.html?loginOut=true";
							return;
						}else{
							layer.msg(data5.info);
						}
					}
				})
			}else if(data.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else{
				layer.msg(data.info);
			}
			
		}else{//取消关注
			var wxjson = new webjson("55"); //设置action值
			//新增param键值
			wxjson.AddParam("enterpriseid", _this.data("cid"));//企业id
			wxjson.AddParam("departmentid", $.cookie('departmentid'));//监管单位id
			var res=WebRequest(wxjson);
			var data4 = GetOjson(json_parse(res));
			if(data4.status == "0"){
				//companyList(sskey,ssmode,sssel,jaddress,ctype,otype,cstatus,yjstatus,pagenum,ecount);
				_this.text("关注")
				$.cookie('THE_SET_CONCERN', '关注', { path: '/' });
				layer.msg(data4.info);
				//layer.close(index);
			}else if(data4.status == "9"){
				window.location.href="index.html?loginOut=true";
				return;
			}else{
				layer.msg(data4.info);
			}
		}
		
	})
