var a1 = "a11",a2 = "a1101",pname="",barcode="",jg_name="",date="",link="",gz="",departmentid="",zoneCode="",goodsCode1="",keyWords="",foodType="",cskey="",foodType1="",pid="";
var cheType="";/**添加食品分类的传参**/
var jj=0;/**设置动态生成id的初始值**/

function food(){
	  var wxjson = new webjson("40"); //设置action值
	 	//新增param键值
	    wxjson.AddParam("pname", pname); 
	 	wxjson.AddParam("bar_code", barcode);
	 	wxjson.AddParam("dept_id", jg_name);
	 	WebRequestAsync(wxjson, foodList);  
}

function foodList(res){
	res=res.replace(/"itemStyle":"/g, '"itemStyle":').replace(/","symbolSize/g, ',"symbolSize');
	var data1=unescape(res);
	data=JSON.parse(data1);
	console.log(data);
	if(data.status == 0) {
		date=data.datas.nodes;		
		console.log(date);
		link=data.datas.links;
		console.log(link);
		if(date!=undefined&&date!=null&&link!=undefined&&link!=null){
		var html1="<ul style='list-style: none;'><li><span class='dc'></span>断层企业</li><li><span class='lt'></span>流通企业</li><li><span class='sc'></span>生产企业</li><li><span class='cyfw'></span>餐饮服务企业</li><li><span class='dwst'></span>单位食堂企业</li></ul>";
		 $(".circul").html(html1);
		 /**流通图**/
        var myChart = echarts.init(document.getElementById('main'));
        option = {
            title: { text: '食品流通关系图' },
            tooltip: {
                /**formatter: function (x) {
                    return x.data.des;
                },**/
            	 trigger: 'item',  
            	 formatter: function(x){return x.data.name;},
                //formatter: '{b}',
                 show : true,   //默认显示
                 showContent:true, //是否显示提示框浮层
                 alwaysShowContent:false, //默认离开提示框区域隐藏，true为一直显示
                 showDelay:0,//浮层显示的延迟，单位为 ms，默认没有延迟，也不建议设置。在 triggerOn 为 'mousemove' 时有效。
                 hideDelay:200,//浮层隐藏的延迟，单位为 ms，在 alwaysShowContent 为 true 的时候无效。
                 enterable:false,//鼠标是否可进入提示框浮层中，默认为false，如需详情内交互，如添加链接，按钮，可设置为 true。
                 position:'right',//提示框浮层的位置，默认不设置时位置会跟随鼠标的位置。只在 trigger 为'item'的时候有效。
                 confine:false,//是否将 tooltip 框限制在图表的区域内。外层的 dom 被设置为 'overflow: hidden'，或者移动端窄屏，导致 tooltip 超出外界被截断时，此配置比较有用。
                 transitionDuration:0.4,
            },
            series: [
                {
                	coordinateSystem : null,//坐标系可选
                    xAxisIndex : 0, //x轴坐标 有多种坐标系轴坐标选项
                    yAxisIndex : 0, //y轴坐标 
                    type: 'graph',
                    layout: 'force',
                    symbolSize: 10,
                    roam: true,
                    nodeScaleRatio : 0.1,
                    edgeSymbol: ['circle', 'arrow'],
                    edgeSymbolSize: [4, 10],
                    edgeLabel: {
                        normal: {                     	
                            textStyle: {
                                fontSize: 20
                            }
                        }
                    },
                    force: {
                    	layoutAnimation : true,        
                        //edgeLength: [10, 90],
                        repulsion : 200,//节点之间的斥力因子。支持数组表达斥力范围，值越大斥力越大。
                        gravity : 0.05,//节点受到的向中心的引力因子。该值越大节点越往中心点靠拢。
                        edgeLength :200//边的两个节点之间的距离，这个距离也会受 repulsion。[10, 50] 。值越小则长度越长
                        
                    },
                    draggable: true,
                    itemStyle: {
                        normal: {
                            color: '#4b565b'
                            	
                        }
                    },
                    lineStyle: {
                        normal: {
                            width: 1,
                            color: '#5CB6F8'
                        }
                    },
                    edgeLabel: {
                        normal: {
                            show: false,
                            formatter: function (x) {
                                return x.data.name;
                            }
                        }
                    },
                    label: {
                        normal: {
                        	position : 'inside',//标签的位置。['50%', '50%'] [x,y]
                            show: true,
                            formatter:function(x){   //让series 中的文字进行换行  
                                return x.data.name; 
                            },  
                            textStyle: {
                            	
                            }
                        }
                    },
                    data:date,
                    links:link
                }
            ]
        };
        myChart.setOption(option);
		}else{
			$("#main").css({"text-align":"center","border":"none","font-size":"14px"});
			$("#main").html("没有相关数据");
		}
		
	}else{
		$("#main").css({"text-align":"center","border":"none","font-size":"14px"});
		$("#main").html(data.info);
	}
}

/**页面加载时**/
$(function() {
	var htmlCt="";
	jg_name=$.cookie('departmentid');//监管所id
	console.log(jg_name);
 	 getActiveN("a11", "a1101");//当前页标志
 	//$("img.qh").trigger('click');
 	 pname = sessionStorage.getItem("pname");
     barcode = sessionStorage.getItem("barcode");
     pid = sessionStorage.getItem("pid");
     departmentid=$.cookie("departmentid");
 	 zoneCode=$.cookie("dep_code");
 	 gz= sessionStorage.getItem("gz");
 	 console.log("gz:"+gz);
     /**获取页面头部信息**/
     if(pname!=null&&barcode!=null&&barcode!=""){
	 htmlCt +="<a href='javascript:void(0);'>"+pname+"<span style='font-size:18px;'>（"+barcode+"）</span></a><a href='javascript:void(0);' onclick='gz1(this)' style='float:right;margin-right:20px;color:#56BBF9;'><s style='display:none;'>"+pname+"</s><i style='display:none;'>"+pid+"</i><span>"+gz+"</span></a>";
	 $(".content-title").html(htmlCt);
     }else if(barcode==""){
    	 htmlCt +="<a href='javascript:void(0);'>"+pname+"</a><a href='javascript:void(0);' onclick='gz1(this)' style='float:right;margin-right:20px;color:#56BBF9;'><s style='display:none;'>"+pname+"</s><i style='display:none;'>"+pid+"</i><span>"+gz+"</span></a>";
    	 $(".content-title").html(htmlCt); 
     }else{
    	 $(".content-title").html("");
     }
     $("#main").html("<p style='margin:200px auto;width:100%;text-align:center;'><img src='../style/image/load.gif'></p>");
     food();
})

/**点击关注**/
function gz1(t){
	var pname1=$(t).children("s").text();
	goodsCode1=$(t).children("i").text();
	var text1=$(t).children("span").text();
	console.log(text1);
	if(text1=="关注"){
	 layer.open({
		title: '提示'
		,content: '\<div class="warpper"><div class="guanzhu"><div>为<span style="font-weight:bold;">'+pname1+'</span>选择分类<p style="float:right;" class="rs"></p></div><div><button class="creatType" onclick="creatType()">创建新分类</button><div class="creatName" style="display:none;"><input type="text" value="" placeholder="请输入新分类名称" /><button class="sbtn btn-exit" onclick="creatName()">取消</button><button class="sbtn" onclick="creatBaoc()">保存</button></div></div><div class="select"></div></div><\/div><script> addList();</script>'
		,area: ['560px', '500px']
		,btn: ['取消','确认']
		,yes: function(index, layero){
			layer.close(index);
		}
	    ,btn2:function(index, layero){
	    	var cheType1=checkBoxTable($(".select"));//勾选的分类值
	    	console.log(cheType1);
	    	cheType=cheType1;
	    	console.log(cheType);
	    	var wxjson = new webjson("54"); //设置action值
	    	//新增param键值
	    	wxjson.AddParam("departmentid",departmentid);
	    	wxjson.AddParam("enterpriseid",goodsCode1);
	    	wxjson.AddParam("types",cheType1);
	    	wxjson.AddParam("flag","sp");
	    	WebRequestAsync(wxjson, qurDate);
	    function qurDate(res){
	    	var data = GetOjson(json_parse(res));
	    	console.log(data);
	    	if(data.status == 0) {	
	    		$(t).children("span").html("取消关注");
    			text1="取消关注";
	    		layer.msg("关注成功!");
	    		sessionStorage.setItem("gz", text1);
	    	}else if(data.status == 9) {
	    		window.location.href = "index.html?loginOut=true";
	    	}else{
	    		$(t).children("span").html("关注");
    			text1="关注";
	    		layer.msg(data.info);
	    	}
	    }
	   }
		,cancel: function(){ 
			//右上角关闭回调
			//return false 开启该代码可禁止点击该按钮关闭
		}
	});
 }else{
		var wxjson = new webjson("55"); //设置action值
		//新增param键值	
		wxjson.AddParam("departmentid",departmentid);
		wxjson.AddParam("enterpriseid",goodsCode1);
		WebRequestAsync(wxjson, qxGzData);
	function qxGzData(res){
		var data = GetOjson(json_parse(res));
		console.log(data);
		if(data.status == 0) {
			$(t).children("span").html("关注");
			text1="关注";
			layer.msg("取消成功！");
			sessionStorage.setItem("gz", text1);
		}else if(data.status == 9){
			window.location.href="index.html?loginOut=true";
		}else {
			$(t).children("span").html("取消关注");
			text1="取消关注";
			layer.msg(data.info);
		}
	}
 }
}

/**点击关注，弹框中显示的内容调用的方法**/
function addList(){
	var wxjson = new webjson("60"); //设置action值
	//新增param键值
	wxjson.AddParam("departmentid",departmentid);
	wxjson.AddParam("zoneCode",zoneCode);
	var res=WebRequest(wxjson);
	var data = GetOjson(json_parse(res));
	console.log(data);
	var html2="";
	if(data.status == 0) {	
		for(var i = 0; i < data.param.length; i++) {
		    foodType=data.param[i].typeName;
		    keyWords=data.param[i].keyWords;
		   // var selected=data.param[i].selected;
			html2 +='<div class="div-init foodType">';
			//if(selected.indexOf(foodType)>-1){
			/**if(foodType==selected){
			  html2 +='<input name="" type="checkbox" value="'+foodType+'" id="foodSelect'+i+'" checked/>';
			}else{**/
			  html2 +='<input name="" type="checkbox" value="'+data.param[i].cId+'" id="foodSelect'+i+'"/>';
			//}
			html2 +='<label class="label1 label4" for="foodSelect'+i+'">'+foodType+'</label></div>';
		    foodType1=foodType1+foodType+",";		    
		}
		 $(".select").html(html2);
		foodType1=foodType1.substr(0,foodType1.length-1);
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else{
	    $(".select").html("");
	}
}
 
/**关注中判断输入的分类是否和已存在的分类名称相同**/
function compare(){
	var inputs=$.trim($(".creatName input").val());//输入的值
	var ft=[];
	console.log("foodType1:"+foodType1);
	ft=foodType1.split(",");
	console.log("ft:"+ft);
	if(ft.length>0){
	 for(var i=0;i<ft.length;i++){
		console.log("数组："+ft[i]);
		    if(ft[i]==inputs){
			 $(".warpper p").html("此分类已存在，不能重复添加！");
			  $(".creatName").show();
			  $(".creatType").hide();
			  return true;
		}else if(inputs=="关注食品"){
			$(".warpper p").html("此分类已存在，不能重复添加！");
			$(".creatName").show();
			  $(".creatType").hide();
		  return true;
		}else{
			$(".warpper p").html("");
			  $(".creatType").show();
			  $(".creatName").hide();
			  $(".creatName input").val("");
		}
	}
}
}

/**关注中点击创建新分类**/
function creatType(){
	console.log("12");
	$(".creatType").hide();
	$(".creatName").show();
}

/**关注中创建新分类中取消按钮**/
function creatName(){
	$(".creatType").show();
	$(".creatName").hide();
	$(".creatName input").val("");
	$(".warpper p").css("display","none");
}

/**关注中创建新分类中保存按钮**/
function creatBaoc(){
	cskey=$.trim($(".creatName input").val());
	console.log(cskey);
	console.log(foodType1);
	if(cskey=="请输入新分类名称"||cskey==""){
		$(".warpper p").html("请输入新分类名称");
	}else if(compare()){
		return;
	}else{
	  	var wxjson = new webjson("61"); //设置action值
		//新增param键值	
		wxjson.AddParam("keywords","");	
		wxjson.AddParam("typename",cskey);
		wxjson.AddParam("departmentid",departmentid);
		wxjson.AddParam("type","INSERT");
		WebRequestAsync(wxjson, creatBaoDate);
	}
}

function creatBaoDate(res){
	var htmlL="";
	var data = GetOjson(json_parse(res));
	console.log(data);
	if(data.status == 0) {	
		htmlL +='<div class="div-init foodType">'+
	   '<input name="" type="checkbox" value="'+data.param[0].cId+'" id="foodSel'+jj+'"/>'+
	   '<label class="label1 label4" for="foodSel'+jj+'"><pre>'+cskey+'</pre></label></div>';
	   jj++;
	   $(".select").append(htmlL);
	   foodType1=foodType1+","+cskey;
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else{
	  $(".select").append("");
	}
}
