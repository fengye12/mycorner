var a1 = "a11",
	a2 = "a1101";
var cid="",sskey="",ssmode="1",sssel="0",pnum="",bbtime="",bbid="",bbtype="",jytime="",departmentid="",zoneCode="",goodsCode1="",keyWords="",foodType="",cskey="",foodType1="",pindex = "1",psize = "20",pname="",barcode="",pid="",gz="";
var cheType="";/**添加食品分类的传参**/
var jj=0;/**设置动态生成id的初始值**/
/**分页设置**/
var pcent = new CentPage();
var pcount = ""; //总条数
var ps = pcent.GetCentPage(pindex, pcount, psize);
var jsonParam="";//导出时需要传的参数
$("#page").html(ps);
function CentPageOper(spindex) {
	search(cid, sskey, ssmode, sssel, pnum, bbtime, jytime,pname,spindex,psize,bbtype);
}

/**页面加载时**/
$(function() {
	 var htmlCt="";
	 pname = sessionStorage.getItem("pname");
     barcode = sessionStorage.getItem("barcode");
     pid = sessionStorage.getItem("pid");
     departmentid=$.cookie("departmentid");
 	 zoneCode=$.cookie("dep_code");
 	 gz= sessionStorage.getItem("gz");
 	 console.log("gz:"+gz);
     /**获取页面头部信息**/
        if(pname!=null&&barcode!=null&&barcode!=""){
    	 htmlCt +="<a href='javascript:void(0);'>"+pname+"<span style='font-size:18px;'>（"+barcode+"）</span></a><a href='javascript:void(0);' onclick='gz1(this)' style='float:right;margin-right:20px;color:#56BBF9;'><s style='display:none;'>"+pname+"</s><i style='display:none;'>"+pid+"</i><span>"+gz+"</span></a>";
    	 $(".content-title").html(htmlCt);
         }else if(barcode==""){
        	 htmlCt +="<a href='javascript:void(0);'>"+pname+"</a><a href='javascript:void(0);' onclick='gz1(this)' style='float:right;margin-right:20px;color:#56BBF9;'><s style='display:none;'>"+pname+"</s><i style='display:none;'>"+pid+"</i><span>"+gz+"</span></a>";
        	 $(".content-title").html(htmlCt); 
         }else{
        	 $(".content-title").html("");
         }
	search(cid, sskey, ssmode, sssel, pnum, bbtime, jytime,pname, pindex, psize,bbtype);
	getActiveN("a11", "a1101");//当前页标志
	//$("img.qh").trigger('click');
});

/**页面搜索**/
function search(cid, sskey, ssmode, sssel, pnum, bbtime, jytime,pname,spindex,psize,bbtype){
	pindex = spindex;
	$("table tbody").children().remove();
	$("table tbody").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;'><img src='../style/image/load.gif' alt='' /></td></tr>");
	$("#daochu").css("display","none");
	var wxjson = new webjson("9"); //设置action值
	//新增param键值
	wxjson.AddParam("pname", pname);
	wxjson.AddParam("sssel", sssel);
	wxjson.AddParam("sskey", sskey);
	wxjson.AddParam("ssmode", ssmode);
	wxjson.AddParam("cid", cid);
	wxjson.AddParam("pnum", pnum);
	wxjson.AddParam("bbtime", bbtime);
	wxjson.AddParam("jytime", jytime);
	wxjson.AddParam("bbtype", bbtype);
	wxjson.AddParam("page_index", pindex);
	wxjson.AddParam("page_size", psize);
	WebRequestAsync(wxjson, searchLedger);
	jsonParam=wxjson.GetJsons();
}
function searchLedger(res){
	var html = "";
	var data = GetOjson(json_parse(res));
	console.log(data);
	pcount = data.paramcentcount;
	var ps = pcent.GetCentPage(pindex, pcount, psize);
	$(".totalNum").html("共"+pcount+"条");
	$("#page").html(ps);
	if(data.status == 0) {
		   if(pcount!="0"){
				$("#daochu").css("display","");
				$("#mySelectS").css("display","");
				}else{
				 $("#daochu").css("display","none");
				 $("#mySelectS").css("display","none");
			//	 $("table tbody").html("没有相关数据显示！");
				}
		for(var i = 0; i < data.param.length; i++){
			//bbid=data.param[i].bbid;
			var cname1=escape(data.param[i].cname);
			if(data.param[i].bbtype == 0) {
				data.param[i].bbtype = '食品采购报备';
			} else {
				data.param[i].bbtype = '食品销售报备';
			}
			html += "<tr>";
			html += '<td class="hs"><a href="Enterprise_archivesInfo.html?c_id='+data.param[i].cid+'" target="_blank">' +data.param[i].cname +
			'</a><td class="hs">'+data.param[i].foodname+'</td>'+
			'<td class="hs">'+data.param[i].barcode+
			"</td><td class='hs'>" +data.param[i].bbtime +
			"</td><td class='hs'>" +data.param[i].djnum +
			"</td><td class='hs'>" +data.param[i].bbtype +
			'</td><td class="hs">' +data.param[i].jycname +
			"</td><td class='hs'>" +data.param[i].jytime ;
			//"</td><td class='hs'>" +data.param[i].pnum +"</td>"
			if(data.param[i].bbtype == '食品采购报备'){
			    html +="<td class='rs'>未索证</td>";
			}else{
				html +="<td style='color:#333;font-size:12px'>无需索证</td>";
			}
			// href="Food_ledgerList.html?bbid='+data.param[i].bbid+'&jyid='+data.param[i].jypk+'"

			html +='<td class="hs ls"><a style="display:inline-block; width:100%; cursor: pointer;" onclick=getDetail("'+data.param[i].bbid+'","'+data.param[i].jypk+'")>详情</a></td>';
		    html += "</tr>";
	}
	$("table tbody").html(html);
	autoH();
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else{
		$("#daochu").css("display","none");
		$("#mySelectS").css("display","none");
		$("table tbody").html("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;font-size:14px;'>没有相关数据</td></tr>");
	}
}

/**按enter键查询**/
$(".foodName").keydown(function(event){
 if(event.keyCode==13){
	$("#sea").click();
}
})

//搜索点击事件
$("#sea").click(function(){
	pindex="1";
	sskey=$.trim($(".foodName").val());
	if(sskey=="请输入关键字进行查询"){
		sskey="";
	}
	//获取精确查询或模糊查询
	ssmode = $(".sel1").find("option:selected").val();
	sssel = $(".sel2").find("option:selected").val();
	console.log("sskey:"+sskey+",sssel:"+sssel+",ssmode:"+ssmode);
	search(cid, sskey, ssmode, sssel, pnum, bbtime, jytime,pname, pindex, psize,bbtype);
})

//高级搜索点击事件
$("#confirBtn").click(function() {
	pindex="1";
	//报备日期验证bbDate
	var startDaobei = $("#bbDate").children("input.dateStart").val();
	var endDaobei = $("#bbDate").children("input.dateEnd").val();
	//交易日期验证jyDate
	var startJy = $("#jyDate").children("input.dateStart").val();
	var endJy = $("#jyDate").children("input.dateEnd").val();
	//交易数量
	var startPnum=$("#jyNum").children("input.startNum").val();
	if(startPnum=="数量下限"){
		startPnum="";
	}
	var endPnum=$("#jyNum").children("input.endNum").val();
	if(endPnum=="数量上限"){
		endPnum="";
	}
	if(startPnum > endPnum){
		layer.open({
			title: '系统提示'
			,content: '交易下限数量不能大于上限数量!'
			,btn: ['确定']
			,yes: function(){
				layer.closeAll();
			}
		});
		return false;
	}
	if(date()) {
		if(startDaobei == "" && endDaobei == "") {
			bbtime = "";
			console.log(bbtime);
		} else {
			bbtime = startDaobei + "," + endDaobei;
			console.log(bbtime);
		}
		if(startJy == "" && endJy == "") {
			jytime = "";
			console.log(jytime);
		} else {
			jytime = startJy + "," + endJy;
			console.log(jytime);
		}
		if(startPnum == "" && endPnum == "") {
			pnum = "";
			console.log(pnum);
		} else {
			pnum = startPnum + "," + endPnum;
			console.log(pnum);
		}
		sskey = $.trim($(".foodName").val());
		if(sskey == "请输入关键字进行查询") {
			sskey = "";
		}
		console.log(sskey);
		//获取精确查询或模糊查询
		ssmode = $(".sel1").find("option:selected").val();
		console.log("模糊查询：" + ssmode);
		sssel = $(".sel2").find("option:selected").val();
		console.log("所有类型：" + sssel);
		//获取checked的值
		bbtype = checkBoxFormat($("#jylx"));
		console.log(bbtype);
		search(cid, sskey, ssmode, sssel, pnum, bbtime, jytime,pname, pindex, psize,bbtype);
	};
})

/**点击查看**/
function ck(t){
	bbid=$(t).find("span").text();
	console.log(bbid);
	window.location.href='Food_ledgerList.html?bbid=' + escape(bbid);
}

/**交易数量限制，如果输入非数字，则替换为'' **/
$("#jyNum input").keyup(function () {
    this.value = this.value.replace(/[^\d]/g, '');
  })

/**select选择框**/
// function select() {
// 	pindex="1";
// 	//获取下拉框选中项的text属性值
// 	var selectText = $("#mySelect").find("option:selected").text();
// 	//获取下拉框选中项的value属性值
// 	var selectValue = $("#mySelect").val();
// 	console.log(selectValue);
// 	psize = selectValue;
// 	CentPageOper(pindex);
// 	search(cid, sskey, ssmode, sssel, pnum, bbtime, jytime,barcode, pindex, psize,bbtype);
// }

/**导出**/
$("#daochu").click(function(){
	var excelName=pname+"台账报备表";
	var pattern = new RegExp('[\/:*?"<>|]');
	if(pattern.test(excelName)){
        for (var i = 0; i < excelName.length; i++) {
        	excelName = excelName.replace(pattern, '-');
        	console.log(excelName);
        }
    }
	//var listType="ledgerList";
	//var header="商品名称"+","+"商品条码"+","+"报备日期"+","+"单据号"+","+"报备类型"+","+"交易对象"+","+"交易日期";
	var listType="ledgerCountList";
	var header="报备企业"+","+"商品名称"+","+"商品条码"+","+"报备日期"+","+"单据号"+","+"报备类型"+","+"交易对象"+","+"交易日期";
	if(pcount<1001){
		var exportExcelParam={
			excelName:escape(excelName),
			listType:listType,
			header:header,
			jsonParam:jsonParam
		}
		postExportExcel(dcUrl,exportExcelParam);
	}else{
		layer.open({
			title: '系统提示'
			,content: '当前数据量超过1000条，为了数据的安全，我们无法为您导出该数据，如需导出请联系客服。'
			,btn: ['确定']
			,yes: function(){
				layer.closeAll();
			}
		});
		return false;
	}
})
// getTDetail();
function getDetail(bbid,jyid){
	//iframe窗
	layer.open({
	  type: 2,
	  title:  [' 台账详情', 'background:#fff;'],
	  // closeBtn: 1, //不显示关闭按钮
	  shade: [0],
	  area: ['1000px', '650px'],
	  anim: 2,
	  content: ['StandingBook_check2.html?bbid='+bbid+'&jyid='+jyid, 'yes']//iframe的url，no代表不显示滚动条
	});
}

/**点击关注**/
function gz1(t){
	var pname1=$(t).children("s").text();
	goodsCode1=$(t).children("i").text();
	var text1=$(t).children("span").text();
	console.log(text1);
	if(text1=="关注"){
	 layer.open({
		title: '提示'
		,content: '\<div class="warpper"><div class="guanzhu"><div>为<span style="font-weight:bold;">'+pname1+'</span>选择分类<p style="float:right;" class="rs"></p></div><div><button class="creatType" onclick="creatType()">创建新分类</button><div class="creatName" style="display:none;"><input type="text" value="" placeholder="请输入新分类名称" /><button class="sbtn btn-exit" onclick="creatName()">取消</button><button class="sbtn" onclick="creatBaoc()">保存</button></div></div><div class="select"></div></div><\/div><script> addList();</script>'
		,area: ['560px', '500px']
		,btn: ['取消','确认']
		,yes: function(index, layero){		
			layer.close(index);
		}
	   ,btn2:function(index, layero){
			var cheType1=checkBoxTable($(".select"));//勾选的分类值
			console.log(cheType1);
			cheType=cheType1;
			console.log(cheType);
			var wxjson = new webjson("54"); //设置action值
			//新增param键值
			wxjson.AddParam("departmentid",departmentid);
			wxjson.AddParam("enterpriseid",goodsCode1);
			wxjson.AddParam("types",cheType1);
			wxjson.AddParam("flag","sp");
			WebRequestAsync(wxjson, qurDate);
		function qurDate(res){
			var data = GetOjson(json_parse(res));
			console.log(data);
			if(data.status == 0) {	
				$(t).children("span").html("取消关注");
    			text1="取消关注";
				layer.msg("关注成功!");
				sessionStorage.setItem("gz", text1);
			}else if(data.status == 9) {
				window.location.href = "index.html?loginOut=true";
			}else{
				$(t).children("span").html("关注");
    			text1="关注";
				layer.msg(data.info);
			}
		}
	   }
		,cancel: function(){ 
			//右上角关闭回调
			//return false 开启该代码可禁止点击该按钮关闭
		}
	});
 }else{
		var wxjson = new webjson("55"); //设置action值
		//新增param键值	
		wxjson.AddParam("departmentid",departmentid);
		wxjson.AddParam("enterpriseid",goodsCode1);
		WebRequestAsync(wxjson, qxGzData);
	function qxGzData(res){
		var data = GetOjson(json_parse(res));
		console.log(data);
		if(data.status == 0) {
			$(t).children("span").html("关注");
			text1="关注";
			layer.msg("取消成功！");
			sessionStorage.setItem("gz", text1);
		}else if(data.status == 9){
			window.location.href="index.html?loginOut=true";
		}else {
			$(t).children("span").html("取消关注");
			text1="取消关注";
			layer.msg(data.info);
		}
	}
 }
}

/**点击关注，弹框中显示的内容调用的方法**/
function addList(){
	var wxjson = new webjson("60"); //设置action值
	//新增param键值
	wxjson.AddParam("departmentid",departmentid);
	wxjson.AddParam("zoneCode",zoneCode);
	var res=WebRequest(wxjson);
	var data = GetOjson(json_parse(res));
	console.log(data);
	var html2="";
	if(data.status == 0) {	
		for(var i = 0; i < data.param.length; i++) {
		    foodType=data.param[i].typeName;
		    keyWords=data.param[i].keyWords;
		   // var selected=data.param[i].selected;
			html2 +='<div class="div-init foodType">';
			//if(selected.indexOf(foodType)>-1){
			/**if(foodType==selected){
			  html2 +='<input name="" type="checkbox" value="'+foodType+'" id="foodSelect'+i+'" checked/>';
			}else{**/
			  html2 +='<input name="" type="checkbox" value="'+data.param[i].cId+'" id="foodSelect'+i+'"/>';
			//}
			html2 +='<label class="label1 label4" for="foodSelect'+i+'">'+foodType+'</label></div>';
		    foodType1=foodType1+foodType+",";		    
		}
		 $(".select").html(html2);
		foodType1=foodType1.substr(0,foodType1.length-1);
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else{
	    $(".select").html("");
	}
}

/**关注中判断输入的分类是否和已存在的分类名称相同**/
function compare(){
	var inputs=$.trim($(".creatName input").val());//输入的值
	var ft=[];
	console.log("foodType1:"+foodType1);
	ft=foodType1.split(",");
	console.log("ft:"+ft);
	if(ft.length>0){
	 for(var i=0;i<ft.length;i++){
		console.log("数组："+ft[i]);
		    if(ft[i]==inputs){
			 $(".warpper p").html("此分类已存在，不能重复添加！");
			  $(".creatName").show();
			  $(".creatType").hide();
			  return true;
		}else if(inputs=="关注食品"){
			$(".warpper p").html("此分类已存在，不能重复添加！");
			$(".creatName").show();
			  $(".creatType").hide();
		  return true;
		}else{
			$(".warpper p").html("");
			  $(".creatType").show();
			  $(".creatName").hide();
			  $(".creatName input").val("");
		}
	}
}
}

/**关注中点击创建新分类**/
function creatType(){
	console.log("12");
	$(".creatType").hide();
	$(".creatName").show();
}

/**关注中创建新分类中取消按钮**/
function creatName(){
	$(".creatType").show();
	$(".creatName").hide();
	$(".creatName input").val("");
	$(".warpper p").css("display","none");
}

/**关注中创建新分类中保存按钮**/
function creatBaoc(){
	cskey=$.trim($(".creatName input").val());
	console.log(cskey);
	console.log(foodType1);
	if(cskey=="请输入新分类名称"||cskey==""){
		$(".warpper p").html("请输入新分类名称");
	}else if(compare()){
		return;
	}else{
	  	var wxjson = new webjson("61"); //设置action值
		//新增param键值	
		wxjson.AddParam("keywords","");	
		wxjson.AddParam("typename",cskey);
		wxjson.AddParam("departmentid",departmentid);
		wxjson.AddParam("type","INSERT");
		WebRequestAsync(wxjson, creatBaoDate);
	}
}

function creatBaoDate(res){
	var htmlL="";
	var data = GetOjson(json_parse(res));
	console.log(data);
	if(data.status == 0) {	
		htmlL +='<div class="div-init foodType">'+
	   '<input name="" type="checkbox" value="'+data.param[0].cId+'" id="foodSel'+jj+'"/>'+
	   '<label class="label1 label4" for="foodSel'+jj+'"><pre>'+cskey+'</pre></label></div>';
	   jj++;
	   $(".select").append(htmlL);
	   foodType1=foodType1+","+cskey;
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else{
	  $(".select").append("");
	}
}
