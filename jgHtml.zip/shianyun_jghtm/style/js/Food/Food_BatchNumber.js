var a1 = "a11",
	a2 = "a1101";
var barcode="",spid="",sskey="",pindex = "1",psize = "20",pname="",barcode="",ycountry="",departmentid="",zoneCode="",goodsCode1="",keyWords="",foodType="",cskey="",foodType1="",gz="";
var cheType="";/**添加食品分类的传参**/
var jj=0;/**设置动态生成id的初始值**/
var photo=[];//页面弹框中显示的图片
/**分页设置**/
var pcent = new CentPage();
var pcount = ""; //总条数
var ps = pcent.GetCentPage(pindex, pcount, psize);
$("#page").html(ps);
function CentPageOper(spindex) {
	search(barcode,spid,sskey, spindex, psize);
}

/**页面加载时**/
$(function() {
	var htmlCt="";
	var pid1=getQueryString("pid");
	var pname1=getQueryString("pname");
	var barcode1=getQueryString("barcode");
	var ycountry1=getQueryString("ycountry");
	gz= sessionStorage.getItem("gz");
	console.log("gz:"+gz);
	departmentid=$.cookie("departmentid");
	zoneCode=$.cookie("dep_code");
	console.log("gz:"+gz);
	if(pid1==null||pid1==""||pid1==undefined){
		spid = sessionStorage.getItem("pid");
	}else{
	    spid = pid1; 
	}
	if(barcode1==null||barcode1==undefined){
		barcode= sessionStorage.getItem("barcode");
	}else{
		barcode= barcode1; 
	}
	if(pname1==null||pname1==""||pname1==undefined){
		pname= sessionStorage.getItem("pname");
	}else{
		pname= pname1;
	}
	if(ycountry1==null||ycountry1==undefined){
		ycountry= sessionStorage.getItem("ycountry");
	}else{
		ycountry= ycountry1; 
	}
	sessionStorage.setItem("pname", pname);
    sessionStorage.setItem("barcode", barcode);
    sessionStorage.setItem("pid", spid);
    sessionStorage.setItem("ycountry", ycountry);
    /**获取页面头部信息**/
      if(pname!=null&&barcode!=null&&barcode!=""){
   	    htmlCt +="<a href='javascript:void(0);'>"+pname+"<span style='font-size:18px;'>（"+barcode+"）</span></a><a href='javascript:void(0);' onclick='gz1(this)' style='float:right;margin-right:20px;color:#56BBF9;'><s style='display:none;'>"+pname+"</s><i style='display:none;'>"+spid+"</i><span>"+gz+"</span></a>";
   	    $(".content-title").html(htmlCt);
        }else if(barcode==""){
        	htmlCt +="<a href='javascript:void(0);'>"+pname+"</a><a href='javascript:void(0);' onclick='gz1(this)' style='float:right;margin-right:20px;color:#56BBF9;'><s style='display:none;'>"+pname+"</s><i style='display:none;'>"+spid+"</i><span>"+gz+"</span></a>";
       	    $(".content-title").html(htmlCt);	
        }else{
       	 $(".content-title").html("");
        }
	search(barcode,spid,sskey, pindex, psize);
    getActiveN("a11", "a1101");//当前页标志
    //$("img.qh").trigger('click');
});

/**搜索**/
function search(barcode,spid,sskey, spindex, psize) {
	barcode = sessionStorage.getItem("barcode");
	pindex = spindex;
	$("table tbody").children().remove();
	$("table tbody").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;'><img src='../style/image/load.gif' alt='' /></td></tr>");
	var wxjson = new webjson("18"); //设置action值
	//新增param键值
	wxjson.AddParam("departmentid", departmentid);
	wxjson.AddParam("barcode", barcode);
	wxjson.AddParam("spid", spid);
	wxjson.AddParam("sskey", sskey);
	wxjson.AddParam("page_index", pindex);
	wxjson.AddParam("page_size", psize);
	WebRequestAsync(wxjson, searchNum);
}
function searchNum(res){
	var html = "";
	var data = GetOjson(json_parse(res));
	console.log(data);
	pcount = data.paramcentcount;
	var ps = pcent.GetCentPage(pindex, pcount, psize);
	$(".totalNum").html("共"+pcount+"条");
	$("#page").html(ps);
	if(data.status == 0) {	
	    ycountry =sessionStorage.getItem("ycountry");
	    console.log("pname:"+pname+" ,barcode:"+barcode+" ,ycountry:"+ycountry);	    
		/**国产食品**/
		if(ycountry=="中国"){
			if(pcount!="0"){
			$(".food_gn1").css("display","block");			
			}else{
				//$(".food_gn1").css("display","none");
				$(".food_gn tbody").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;'>没有相关数据</td></tr>");				
			}
			$(".food_jk1").css("display","none");
			
		for(var i = 0; i < data.param.length; i++){				
			if(data.param[i].bstatus == 0) {
				data.param[i].bstatus = '未上传';		
			} else if(data.param[i].bstatus == 1) {
				data.param[i].bstatus = '已上传';		
			} 
			html += "<tr>";
			html += "<td class='hs'>" +data.param[i].sccj + 
			"</td><td class='hs'>" +data.param[i].scdz + 
			"</td><td class='hs'>" +data.param[i].scpc + "</td>";
			if(data.param[i].bstatus == '已上传'){
			html += "<td><a href='#' class='ls' onclick='ck(this)'><span style='display:none;'>"+data.param[i].photos+"</span>已上传</a></td>";
			}else if(data.param[i].bstatus == '未上传'){
			html += "<td class='rs'>未上传</td>";	
			}
		    html += "</tr>";
	     }
	     $(".food_gn tbody").html(html);
	     autoH();
		}else{
	   /**进口食品或者原产国为空时**/
		  $(".food_gn1").css("display","none");
		 if(pcount!="0"){
		  $(".food_jk1").css("display","block");		  
		 }else{
			 //$(".food_jk1").css("display","none");
			 $(".food_jk1 tbody").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;'>没有相关数据</td></tr>");				 
		 }
	   for(var i = 0; i < data.param.length; i++){	
		  
		  if(data.param[i].bstatus == 0) {
				data.param[i].bstatus = '未上传';		
			} else if(data.param[i].bstatus == 1) {
				data.param[i].bstatus = '已上传';		
			} 
		html += "<tr>";
		html += "<td class='hs'>" +data.param[i].jkjsx + 
		"</td><td class='hs'>" +data.param[i].jydz + 
		"</td><td class='hs'>" +data.param[i].jxslxfs + 
		"</td><td class='hs'>" +data.param[i].sccj + 
		"</td><td class='hs'>" +data.param[i].scdz + 
		"</td><td class='hs'>" +data.param[i].scpc + "</td>";
		if(data.param[i].bstatus == '已上传'){
			html += "<td><a href='#' class='ls' onclick='ck(this)'><span style='display:none;'>"+data.param[i].photos+"</span>已上传</a></td>";
			}else if(data.param[i].bstatus == '未上传'){
			html += "<td class='rs'>未上传</td>";	
			}
	    html += "</tr>";
   }
    $(".food_jk tbody").html(html);
    autoH();
		}
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else {
		if(ycountry=="中国"){
			$("table tbody").children().remove();
			$(".food_gn1").css("display","block");	
			$(".food_gn1 tbody").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;font-size:14px;'>没有相关数据</td></tr>");	
		}else{
			$(".food_jk1").css("display","block");	
			$("table tbody").children().remove();
			$(".food_jk1 tbody").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;font-size:14px;'>没有相关数据</td></tr>");				 
		}
		//$(".food").append("没有相关数据");
	} 
	autoH();
}

function photos(){
	  var html="";
	  html += "<div class='imgDiv' style='width: 600px;height: 610px; margin:20px;border:none;'>" +
		"<ul class='images' style='list-style: none;'>";	  
	  for(var j = 0; j < photo.length; j++) {
			html += "<li><img src='" + photo[j] + "'></li>";
		}
	     html +="</ul></div>";
	     $(".warpperBox").append(html);
			console.log($(".images"))
			$(".images").viewer({
				inline: true
			});
}

/**为已上传绑定点击事件**/
function ck(t){
	photo=$(t).find("span").text();
	console.log(photo);
	if(photo.length>0){
		photo=photo.split(",");
		console.log(photo);
	}
	layer.open({
		type: 1,
		title: '查看已上传图片',
		shadeClose: true,
		shade: 0.5,
		area: ['650px', '700px'],
	//	content: '\<div class="imgDiv" style="width: 360px;height: 360px; margin: 10px;"><ul class="images" style="list-style: none;"><li><img src="../style/image/emma-watson-1.jpg" alt="Picture" style="display: none;" ></li><li><img src="../style/image/emma-watson-8.jpg" alt="Picture 2"style="display: none;"></li><li><img src="../style/image/emma-watson-3.jpg" alt="Picture 3"style="display: none;"></li></ul><\/div><script>$(".images").viewer({inline:true});</script>',
		content:'\<div class="warpperBox"><\/div><script> photos();</script>'
	//	btn: ['取消']
	});
}

/**按enter键查询**/
$(".search input").keydown(function(event){ 
 if(event.keyCode==13){ 
	$(".search button").click(); 
} 
})

/**点击查询**/
$(".search button").click(function(){
	pindex="1";
	sskey=$.trim($(".search input").val());
	if(sskey=="商品批号（精确查询）"){
		sskey="";
	}
	console.log("sskey:"+sskey);
	search(barcode,spid,sskey, pindex, psize);
})

/**截取字符串方法**/
 function getQueryString(name) {
 	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
 	var search = window.location.search.substr(1);
 	var href = window.location.href;
 	if(href.indexOf("?") >= 0) {
 		search = href.substr(href.indexOf("?") + 1);
 	}
 	var r = search.match(reg);
 	if(r != null) return unescape(r[2]);
 	return null;
 }

/**点击关注**/
function gz1(t){
	var pname1=$(t).children("s").text();
	goodsCode1=$(t).children("i").text();
	var text1=$(t).children("span").text();
	console.log(text1);
	if(text1=="关注"){
	 layer.open({
		title: '提示'
		,content: '\<div class="warpper"><div class="guanzhu"><div>为<span style="font-weight:bold;">'+pname1+'</span>选择分类<p style="float:right;" class="rs"></p></div><div><button class="creatType" onclick="creatType()">创建新分类</button><div class="creatName" style="display:none;"><input type="text" value="" placeholder="请输入新分类名称" /><button class="sbtn btn-exit" onclick="creatName()">取消</button><button class="sbtn" onclick="creatBaoc()">保存</button></div></div><div class="select"></div></div><\/div><script> addList();</script>'
		,area: ['560px', '500px']
		,btn: ['取消','确认']
		,yes: function(index, layero){			
			layer.close(index);
		}
	   ,btn2:function(index, layero){
			var cheType1=checkBoxTable($(".select"));//勾选的分类值
			console.log(cheType1);
			cheType=cheType1;
			console.log(cheType);
			var wxjson = new webjson("54"); //设置action值
			//新增param键值
			wxjson.AddParam("departmentid",departmentid);
			wxjson.AddParam("enterpriseid",goodsCode1);
			wxjson.AddParam("types",cheType1);
			wxjson.AddParam("flag","sp");
			WebRequestAsync(wxjson, qurDate);
		function qurDate(res){
			var data = GetOjson(json_parse(res));
			console.log(data);
			if(data.status == 0) {	
				$(t).children("span").html("取消关注");
    			text1="取消关注";
				layer.msg("关注成功!");
				sessionStorage.setItem("gz", text1);
			}else if(data.status == 9) {
				window.location.href = "index.html?loginOut=true";
			}else{
				$(t).children("span").html("关注");
    			text1="关注";
				layer.msg(data.info);
			}
		}
	   }
		,cancel: function(){ 
			//右上角关闭回调
			//return false 开启该代码可禁止点击该按钮关闭
		}
	});
 }else{
	 var wxjson = new webjson("55"); //设置action值
		//新增param键值	
		wxjson.AddParam("departmentid",departmentid);
		wxjson.AddParam("enterpriseid",goodsCode1);
		WebRequestAsync(wxjson, qxGzData);
	function qxGzData(res){
		var data = GetOjson(json_parse(res));
		console.log(data);
		if(data.status == 0) {
			$(t).children("span").html("关注");
			text1="关注";
			layer.msg("取消成功！");
			sessionStorage.setItem("gz", text1);
		}else if(data.status == 9){
			window.location.href="index.html?loginOut=true";
		}else {
			$(t).children("span").html("取消关注");
			text1="取消关注";
			layer.msg(data.info);
		}
	}
 }
}

/**点击关注，弹框中显示的内容调用的方法**/
function addList(){
	var wxjson = new webjson("60"); //设置action值
	//新增param键值
	wxjson.AddParam("departmentid",departmentid);
	wxjson.AddParam("zoneCode",zoneCode);
	var res=WebRequest(wxjson);
	var data = GetOjson(json_parse(res));
	console.log(data);
	var html2="";
	if(data.status == 0) {	
		for(var i = 0; i < data.param.length; i++) {
		    foodType=data.param[i].typeName;
		    keyWords=data.param[i].keyWords;
		   // var selected=data.param[i].selected;
			html2 +='<div class="div-init foodType">';
			//if(selected.indexOf(foodType)>-1){
			/**if(foodType==selected){
			  html2 +='<input name="" type="checkbox" value="'+foodType+'" id="foodSelect'+i+'" checked/>';
			}else{**/
			  html2 +='<input name="" type="checkbox" value="'+data.param[i].cId+'" id="foodSelect'+i+'"/>';
			//}
			html2 +='<label class="label1 label4" for="foodSelect'+i+'">'+foodType+'</label></div>';
		    foodType1=foodType1+foodType+",";		    
		}
		 $(".select").html(html2);
		foodType1=foodType1.substr(0,foodType1.length-1);
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else{
	    $(".select").html("");
	}
}

/**关注中判断输入的分类是否和已存在的分类名称相同**/
function compare(){
	var inputs=$.trim($(".creatName input").val());//输入的值
	var ft=[];
	console.log("foodType1:"+foodType1);
	ft=foodType1.split(",");
	console.log("ft:"+ft);
	if(ft.length>0){
	 for(var i=0;i<ft.length;i++){
		console.log("数组："+ft[i]);
		    if(ft[i]==inputs){
			 $(".warpper p").html("此分类已存在，不能重复添加！");
			  $(".creatName").show();
			  $(".creatType").hide();
			  return true;
		}else if(inputs=="关注食品"){
			$(".warpper p").html("此分类已存在，不能重复添加！");
			$(".creatName").show();
			  $(".creatType").hide();
		  return true;
		}else{
			$(".warpper p").html("");
			  $(".creatType").show();
			  $(".creatName").hide();
			  $(".creatName input").val("");
		}
	}
}
}

/**关注中点击创建新分类**/
function creatType(){
	console.log("12");
	$(".creatType").hide();
	$(".creatName").show();
}

/**关注中创建新分类中取消按钮**/
function creatName(){
	$(".creatType").show();
	$(".creatName").hide();
	$(".creatName input").val("");
	$(".warpper p").css("display","none");
}

/**关注中创建新分类中保存按钮**/
function creatBaoc(){
	cskey=$.trim($(".creatName input").val());
	console.log(cskey);
	console.log(foodType1);
	if(cskey=="请输入新分类名称"||cskey==""){
		$(".warpper p").html("请输入新分类名称");
	}else if(compare()){
		return;
	}else{
	  	var wxjson = new webjson("61"); //设置action值
		//新增param键值	
		wxjson.AddParam("keywords","");	
		wxjson.AddParam("typename",cskey);
		wxjson.AddParam("departmentid",departmentid);
		wxjson.AddParam("type","INSERT");
		WebRequestAsync(wxjson, creatBaoDate);
	}
}

function creatBaoDate(res){
	var htmlL="";
	var data = GetOjson(json_parse(res));
	console.log(data);
	if(data.status == 0) {	
		htmlL +='<div class="div-init foodType">'+
	   '<input name="" type="checkbox" value="'+data.param[0].cId+'" id="foodSel'+jj+'"/>'+
	   '<label class="label1 label4" for="foodSel'+jj+'"><pre>'+cskey+'</pre></label></div>';
	   jj++;
	   $(".select").append(htmlL);
	   foodType1=foodType1+","+cskey;
	}else if(data.status == 9){
		window.location.href="index.html?loginOut=true";
	}else{
	  $(".select").append("");
	}
}



