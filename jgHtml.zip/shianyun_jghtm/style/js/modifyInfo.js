/*
* @Author: anchen
* @Date:   2017-07-18 11:41:28
* @Last Modified by:   anchen
* @Last Modified time: 2017-08-14 16:50:29
*/
var userid=$.cookie('user_id');
$(function(){
        //获取链接参数：
        $(".right-num").hide();
        var part=GetQueryString("current1");
        var child=GetQueryString("current2");
        getActiveN(part,child);//当前导航

        getMessage(userid);
    })

    //获取用户信息
    function getMessage(userid){
            var wxjson = new webjson("14");
            wxjson.AddParam("userid", userid);//用户id组合
            WebRequestAsync(wxjson, sc);
            function sc(res){
                var data = GetOjson(json_parse(res));
                console.log(data);
                if(data.status == 0){
                  if(data.param.length>0){
                    $("#Newname").val(data.param[0].realname);
                    $("#workPhone").val(data.param[0].telnum);
                    $("#Phone").val(data.param[0].phonenum);
                    $("#newemail").val(data.param[0].email);
                    if(data.param[0].username){
                      if(data.param[0].phonenum){
                        $("#loginAccount").val(data.param[0].username+' 或 '+data.param[0].phonenum);
                      }else{
                      $("#loginAccount").val(data.param[0].username);

                      }
                    }

                  }

            }else if(data.status == 9){//超时重新登录
              window.location.href="index.html?loginOut=true";
              return;
          }else{
           layer.close(layer1)
           layer.msg(data.info);
       }
      }
    }

        //表单验证
        $(".confirm").click(function(){
         $("#newTips").html("");
          var Newname=$("#Newname").val();//姓名
          var oldPsw=$("#oldPsw").val();//登录密码
          var newPsw1=$("#newPsw1").val();//登录密码
          var newPsw2=$("#newPsw2").val();//登录密码

         var workPhone=$("#workPhone").val();//办公电话
         var Phone=$("#Phone").val();//手机号
         var newemail=$("#newemail").val();//邮箱

             var re = /^0\d{2,3}-?\d{7,8}$/;
             var re1 = /^(\w-*\.*)+@(\w-?)+(\.\w{2,})+$/;
             if(Newname==""){
               $("#newTips").html("请输入姓名");
             }else if(workPhone!="" && !(re.test(workPhone))){
             $("#newTips").html("请输入正确的办公电话");
         }else if(Phone!="" && (!(/^1[34578]\d{9}$/.test(Phone)))){
           $("#newTips").html("请输入正确的手机号");
         }else if(newemail!="" && !(re1.test(newemail))){
              $("#newTips").html("请输入正确的电子邮箱");
         }else if(newPsw1!="" && !(/^[a-zA-Z0-9_]{6,20}$/.test(newPsw1))){
           $("#newTips").html("密码长度由6-20位数字/字母/下划线组成");
         }else if(oldPsw==""){
             $("#newTips").html("请输入原密码");
         }else if(newPsw1!= newPsw2){
             $("#newTips").html("两次输入密码不一致");
         }else{
            creatAccount(Newname,oldPsw,newPsw1,workPhone,Phone,newemail);
         }

 })

//保存个人信息
//新建账号
function creatAccount(Newname,oldPsw,newPsw1,workPhone,Phone,newemail){
  var wxjson = new webjson("28"); //设置action值
  //新增param键值
  wxjson.AddParam("realname", Newname);
  wxjson.AddParam("userid", userid);
  wxjson.AddParam("pwd", newPsw1);
  wxjson.AddParam("ypwd", oldPsw);
  wxjson.AddParam("phonenum", Phone);
  wxjson.AddParam("telnum", workPhone);
  wxjson.AddParam("email", newemail);
  var res=WebRequestAsync(wxjson,successgetsave);
  function successgetsave(res){
     var data = GetOjson(json_parse(res));
      if(data.status == 0){
               $("#newTips").html("");
               layer.msg('修改成功');
                $.cookie('username',Newname, { expires: 30 });
                console.log(newPsw1)
                if(newPsw1=="" || newPsw1=="请输入"){
            setTimeout(function(){ window.history.back(-1);},2000);
          }else{
            setTimeout(function(){
            location.replace("index.html?loginOut=true");//禁止浏览器后退
            event.returnValue=false;
          },1000);

          }
          }else if(data.status == 9){//超时重新登录
            window.location.href="index.html?loginOut=true";
            return;
        }else{
          $("#newTips").html("");
         layer.msg(data.info);
     }
  }
}

       // 顶部导航
       $("#reload").click(function(){
        window.location.reload();
    })
