/**此方法设置日期的满足条件**/
function date(){
  //报备日期验证bbDate
  var startDaobei=$("#bbDate").children("input.dateStart").val();
  var endDaobei = $("#bbDate").children("input.dateEnd").val();
  //交易日期验证jyDate
  var startJy = $("#jyDate").children("input.dateStart").val();
  var endJy = $("#jyDate").children("input.dateEnd").val()
  if(startDaobei != "" && endDaobei != "" && new Date(startDaobei.replace(/-/g, "/")) > new Date(endDaobei.replace(/-/g, "/"))) {
    layer.open({
			title: '系统提示'
			,content: '报备开始日期不能大于结束日期!'
			,btn: ['确定']
			,yes: function(){
				layer.closeAll();
			}
		});
    return false;
   }else if(startJy != "" && endJy != "" && new Date(startJy.replace(/-/g, "/")) > new Date(endJy.replace(/-/g, "/"))) {
    layer.open({
			title: '系统提示'
			,content: '交易开始日期不能大于结束日期!'
			,btn: ['确定']
			,yes: function(){
				layer.closeAll();
			}
		});
      return false;
    }else{
      return true;
    }
}
//监控预警提交日期验证
function datenews(){
  //日期验证qydate
  var startQydate=$("#qydate").children("input.dateStart").val();
  var endQydate = $("#qydate").children("input.dateEnd").val();
  if(startQydate != "" && endQydate != "" && new Date(startQydate.replace(/-/g, "/")) > new Date(endQydate.replace(/-/g, "/"))) {
    layer.open({
      title: '系统提示'
      ,content: '开始日期不能大于结束日期!'
      ,btn: ['确定']
      ,yes: function(){
        layer.closeAll();
      }
    });
    return false;
   }else{
      return true;
    }
}
//格式化复选框提交方式
function checkBoxFormat(warpBox){
  var checked=warpBox.find("input[type='checkbox']:checked");
  var check=warpBox.find("input[type='checkbox']");
  if(checked.length == check.length || checked.length == 0){
    return '';
  }else{
    var str='';
    $.each(check,function(i,item){
      if($(this).is(':checked')){
        str=str+i+',';
      }
    })
    str=str.substr(0,str.length-1)
    return str;
  }
}
function dateLoad(){
  $( ".date" ).datepicker({
    dateFormat: 'yy-mm-dd',
    showOtherMonths: true,
    selectOtherMonths: true,
    showButtonPanel: true,
    showOn: "both",
    buttonImageOnly: true,
    buttonText: "",
    changeMonth: true,
    changeYear: true,
    maxDate:"d"
  });
}

function numberYz(th,e){//验证商品数量
  if(e != 8 && e != 37 && e != 38 && e != 39 &&  e != 40){
    var selPos=th.position();
    var vVal=th.val();
    var sVal="";
    sVal=th.val().replace(/[^0-9]/g,'');
    //th.val(th.val().replace(/[^0-9]/g,''));

    if(vVal != sVal){
      th.val(sVal);
      th.position(selPos-1);
    }

      //th.val(th.val().replace(/\D/g,''));

  }
}
/**日历设置**/
jQuery(function($){
  $.datepicker.regional['zh-CN'] = {
    clearText: '清除',
    clearStatus: '清除已选日期',
    closeText: '关闭',
    closeStatus: '不改变当前选择',
    prevText: '< 上月',
    prevStatus: '显示上月',
    prevBigText: '<<',
    prevBigStatus: '显示上一年',
    nextText: '下月>',
    nextStatus: '显示下月',
    nextBigText: '>>',
    nextBigStatus: '显示下一年',
    currentText: '今天',
    currentStatus: '显示本月',
    monthNames: ['一月','二月','三月','四月','五月','六月', '七月','八月','九月','十月','十一月','十二月'],
    monthNamesShort: ['一月','二月','三月','四月','五月','六月', '七月','八月','九月','十月','十一月','十二月'],
    monthStatus: '选择月份',
    yearStatus: '选择年份',
    weekHeader: '周',
    weekStatus: '年内周次',
    dayNames: ['星期日','星期一','星期二','星期三','星期四','星期五','星期六'],
    dayNamesShort: ['周日','周一','周二','周三','周四','周五','周六'],
    dayNamesMin: ['日','一','二','三','四','五','六'],
    dayStatus: '设置 DD 为一周起始',
    dateStatus: '选择 m月 d日, DD',
    dateFormat: 'yy-mm-dd',
    firstDay: 1,
    initStatus: '请选择日期',
    isRTL: false};
    $.datepicker.setDefaults($.datepicker.regional['zh-CN']);
  });
/**function resetForm(){
  $("#bbDate").children("input").val("");
  $("#jyDate").children("input").val("");
  $("#zlDate").children("input").val("");
  $("#bblx").find("input[type='checkbox']:checked").removeAttr('checked', 'checked');
  $("#zt").find("input[type='checkbox']:checked").removeAttr('checked', 'checked');
}**/
function resetForm(){
	$("#form").find("input").val("");
	$("#form").find("input[type='checkbox']:checked").removeAttr('checked', 'checked');
  if($(".area-content").length && $(".area-content").length > 0){
    $(".area-list").css("display","none");
        //alert($(".area-list").eq(0).html());
      $(".area-list").eq(0).css("display","block");
      $(".area-list").find(".li-dq").removeClass("currentli");
      $(".area-choose span").text("请选择地区");
      $(".area-nav a").eq(0).addClass("current").siblings().removeClass("current");
      $("#inputChoose").val("");
      $(".area-content").hide();
  }

}
$(function() {
  dateLoad();
  $("#reset").click(function() {
    resetForm();
   // $("#form").hide();
  })
  $('#gjSearch').click(function(event){
    event.stopPropagation();
    if($(".divselect ul").length && $(".divselect ul").length > 0){
      $(".divselect ul").slideUp("fast");
    }
    if($('#form').css('display')=='none'){
      $('#form').slideDown(300);
      autoH();
      var r=$(".warp-content")[0].offsetHeight;
      var l=$(".left-nav")[0].offsetHeight;
      var h=$(".warp-content")[0].offsetHeight+281;
      console.log("r:"+r+"l:"+l+"h:"+h)
      if(h>l){
        $(".left-nav").height(h)
      }

    }else{
      resetForm();
      $('#form').slideUp(300);
    }
  })
});
