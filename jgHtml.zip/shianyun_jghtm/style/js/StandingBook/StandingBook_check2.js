autoH();
var a1="a11",a2="a1103";//用于nav
var bbid="",jypk="";//台账报备id

function getQueryString(name) {//获取url传递的参数：name为需要获取的参数名称
   var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
   var search = window.location.search.substr(1);
   var href = window.location.href;
   if(href.indexOf("?") >= 0) {
      search = href.substr(href.indexOf("?") + 1);
   }
   var r = search.match(reg);
   if(r != null) return unescape(r[2]);
   return null;
}

if(!GetAddNew(getQueryString("bbid"))){//获取食品台账报备id
   bbid=getQueryString("bbid");
   jypk=getQueryString("jyid");
}

function foodAccountData(res){//食品的台账列表数据
   $("#foodAccountInfo").children().remove();
   $(".images").children().remove();
   var data = GetOjson(json_parse(res));
   if(data.status =="0"){
      var bbtype="食品销售报备";
      if(data.param[0].bbtype == "0"){
         bbtype="食品采购报备"
      }
      var c_id=data.param[0].cid;
      var cname1=escape(data.param[0].cname);
      $(".bb-header").children().remove();
      var header='<li>单据号： '+data.param[0].djnum+'</li>'+
      '<li>报备日期：'+data.param[0].bbtime+'</li>'+
      '<li>交易日期：'+data.param[0].jytime+'</li>'+
      '<li>报备企业：'+data.param[0].cname+'</li>'+
      '<li>交易对象：'+data.param[0].jycname+'</li>'+
      '<li>报备类型：'+bbtype+'</li>'
      $(".bb-header").html(header);
      var photos="";
      if(data.param[0].photos.length > 0){
         photos=data.param[0].photos.split(",");
         var images="<label>相关票据: </label>";
         for(var i=0;i<photos.length;i++){
            images+='<img src="'+photos[i]+'" alt="相关票据">';
            $(".xgpj").html(images);
         }
         autoH();
      }else{
    	  if(bbtype=="食品采购报备"){
         $(".xgpj").html('<label>相关票据: </label><span style="color:#EF2121;">未索票</span>');
    	  }else{
    		  $(".xgpj").html('<label>相关票据: </label>暂无');
    	  }
      }
      //资质证件
      var zjphoto="";
      if(data.param[0].zjphoto.length > 0){
         zjphoto=data.param[0].zjphoto.split(",");
         var imgHt="<label>资质证件: </label>";
         for(var i=0;i<zjphoto.length;i++){
            imgHt+='<img src="'+zjphoto[i]+'" alt="资质证件">';
            $(".zjzj").html(imgHt);
         }
         autoH();
      }else{
    	  if(bbtype=="食品采购报备"){
         $(".zjzj").html('<label>资质证件: </label><span style="color:#EF2121;">未索证</span>');
    	  }else{
    		  $(".zjzj").html('<label>资质证件: </label>暂无');
    	  }
      }

      $.each(data.datas.plist,function(i,item){
         var html="";
         html='<tr>'+
         '<td class="hs">'+item.pname+'</td>'+
         '<td class="hs">'+item.barcode+'</td>'+
         '<td class="hs">'+item.sctime+'</td>'+
         '<td class="hs">'+item.bzq+'</td>'+
         '<td class="hs">'+item.pnum+'</td>'+
         '<td class="hs">'+item.spec+'</td>';
         if(bbtype=="食品采购报备"){
         html +='<td class="hs" style="color:#EF2121;">未索证</td>';
         }else{
         html +='<td class="hs" style="color:#EF2121;">未上传</td>';
         }
         html +='</tr>';
         $("#foodAccountInfo").append(html);
      })
      autoH();
   }else if(data.status == "9"){
      window.location.href="index.html?loginOut=true";
      return;
   }else if(data.status== "10"){
      console.log(data.info);
   }else{
      $("#foodAccountInfo").append("<tr class='loading'><td colspan='11' style='padding:20px 0;text-align: center;'>"+data.info+"</td></tr>");
   }
}

function foodAccountInfo(bbid){//请求食品台账列表
   $("#foodAccountInfo").children().remove();
   $(".images").children().remove();
   $("#foodAccountInfo").append("<tr class='loading'><td colspan='11' style='padding:20px 0;text-align: center;'><img src='../style/image/load.gif' width='32px' height='32px' /></td></tr>");
   var wxjson = new webjson("10"); //设置action值
   //新增param键值
   wxjson.AddParam("bbid", bbid);
   WebRequestAsync(wxjson, foodAccountData);
}
$(function(){
   foodAccountInfo(bbid);//调用食品台账列表

   // getActiveN("a11", "a1103");//当前页标志

   $(".xgpj").on("click","img",function(){//相关票据查看
      var imgContent="",imgPhoto="";
      for(var i=0;i<$(".xgpj img").length;i++){
         var src=$(".xgpj img")[i].src;
         imgPhoto+='<li><img src='+src+' alt="相关票据"></li>'
      }
      imgContent='<div class="img-warp">'+
      '<div class="imgDiv">'+
      '<ul class="images">'+
      imgPhoto+
      '</ul>'+
      '</div>'+
      '</div>'
      layer.open({
         title: '相关票据查看'
         ,content: imgContent
         ,area: ['650px', '550px']
         ,btn: []
         ,cancel: function(){
            //右上角关闭回调
            //return false 开启该代码可禁止点击该按钮关闭
         }
      });
      $('.images').viewer({
         inline:true
      });
   })
   $(".zjzj").on("click","img",function(){//主体图片查看
      var imgContent="",imgPhoto="";
      for(var i=0;i<$(".zjzj img").length;i++){
         var src=$(".zjzj img")[i].src;
         imgPhoto+='<li><img src='+src+' alt="资质证件"></li>'
      }
      imgContent='<div class="img-warp">'+
      '<div class="imgDiv">'+
      '<ul class="images">'+
      imgPhoto+
      '</ul>'+
      '</div>'+
      '</div>'
      layer.open({
         title: '资质证件查看'
         ,content: imgContent
         ,area: ['650px', '550px']
         ,btn: []
         ,cancel: function(){
            //右上角关闭回调
            //return false 开启该代码可禁止点击该按钮关闭
         }
      });
      $('.images').viewer({
         inline:true
      });


   })
})