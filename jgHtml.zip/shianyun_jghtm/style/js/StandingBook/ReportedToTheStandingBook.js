var a1="a11",a2="a1103";//用于nav
var a="";
var cid="",sskey="",ssmode="1",sssel="0",pnum="",bbtime="",bbtype="",jytime="",pindex = "1",psize = "20" ,cname="";
/**分页设置**/
  var notReal=1;//标识页面。改变cenPage的总量
var pcent = new CentPage();
var pcount = 0; //总条数


var ps = pcent.GetCentPage(pindex, pcount, psize);
$("#page").html(ps);
function CentPageOper(spindex) {
	search(cid, sskey, ssmode, sssel, pnum, bbtime, jytime,spindex,psize,bbtype);
}
if(GetAddNew(getQueryString("sskey"))){//将url中传过来的值进行解码
	sskey="";
}else{
	sskey=getQueryString("sskey");
	$(".inputWraper .foodName").val(sskey);
}
/**页面加载时**/
$(function() {
	$(".total-num").text("共"+pcount+"条");
	getActiveN("a11","a1103");
	autoH();
	search(cid, sskey, ssmode, sssel, pnum, bbtime, jytime, pindex, psize,bbtype);
});

//获取url传递的参数：name为需要获取的参数名称
function getQueryString(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var search = window.location.search.substr(1);
	var href = window.location.href;
	if(href.indexOf("?") >= 0) {
		search = href.substr(href.indexOf("?") + 1);
	}
	var r = search.match(reg);
	if(r != null) return unescape(r[2]);
	return null;
}
// function select(){
// 	psize = $("#mySelect option:selected").val();
// 	pindex=1;
// 	search(cid, sskey, ssmode, sssel, pnum, bbtime, jytime, pindex, psize,bbtype);
// }

/**页面搜索**/
function search(cid, sskey, ssmode, sssel, pnum, bbtime, jytime,spindex,psize,bbtype){
	pindex = spindex;
	$("table tbody").children().remove();
	$("table tbody").append("<tr><td colspan='11' id='lock' class='loadimage' style='text-align:center;padding:20px 0;'><img src='../style/image/load.gif' alt='' /></td></tr>");
	var wxjson = new webjson("9"); //设置action值
	//新增param键值
	wxjson.AddParam("tzbb", "99");
	wxjson.AddParam("sssel", sssel);
	wxjson.AddParam("sskey", sskey);
	wxjson.AddParam("ssmode", ssmode);
	wxjson.AddParam("cid", cid);
	wxjson.AddParam("pnum", pnum);
	wxjson.AddParam("bbtime", bbtime);
	wxjson.AddParam("jytime", jytime);
	wxjson.AddParam("bbtype", bbtype);
	wxjson.AddParam("page_index", pindex);
	wxjson.AddParam("page_size", psize);
	WebRequestAsync(wxjson, searchLedger);
}
function searchLedger(res){
	autoH();
	var html = "";
	var data = GetOjson(json_parse(res));
	pcount = data.paramcentcount;
	if(pcount > 100000){
		$(".total-num").text("共"+(+pcount+300000)+"条");
	}else{
		$(".total-num").text("共"+pcount+"条");
	}
	var ps = pcent.GetCentPage(pindex, pcount, psize);
	$("#page").html(ps);
	$("#mySelectS").css("display","none");
	if(data.status == 0) {
		$("#mySelectS").css("display","");
		for(var i = 0; i < data.param.length; i++){
			var bbid=data.param[i].bbid;
			if(data.param[i].bbtype == 0) {
				data.param[i].bbtype = '食品采购报备'
			} else {
				data.param[i].bbtype = '食品销售报备'
			}
			/*if(data.param[i].pnum==0){
				continue
			}*/
			 a=escape(data.param[i].cname);
			html += "<tr>";
			html += '<td class="hs ls">'+data.param[i].cname+'</td>'+
			'<td class="hs ls">'+data.param[i].foodname+'</td>'+
			'<td class="hs ls">'+data.param[i].barcode+'</td>'+
//			"<td class='hs'><a href='#' class='ls'  onclick='getcid(this)'>" +data.param[i].cname +
//			"<span style='display:none'>" + data.param[i].cid +
			"</a></td><td class='hs'>" +data.param[i].bbtime +
			"</td><td class='hs'>" +data.param[i].djnum +
			"</td><td class='hs'>" +data.param[i].bbtype +
			'<td class="hs ls">'+data.param[i].jycname+'</td>'+
//			"</td><td class='hs'><a href='#' class='ls'  onclick='getjycid(this)'>" +data.param[i].jycname +
//			"<span style='display:none' class='span1'>" + data.param[i].jypk +
//			"</span><span style='display:none' class='span2'>"+data.param[i].cid+
//			"</span><span style='display:none' class='span3'>"+data.param[i].cname+
			"</a></td><td class='hs'>" +data.param[i].jytime ;
			//"</td><td class='hs'>" +data.param[i].pnum +"</td>"
			if(data.param[i].bbtype == '食品采购报备'){
			html +="<td style='color:#EF2121;'>未索证</td>";
			}else{
				html +="<td>无需索证</td>";
			}
			html +='<td class="hs ls"><a href="StandingBook_check.html?bbid='+data.param[i].bbid+'&jyid='+data.param[i].jypk+'&pid='+data.param[i].pid+'" target="_blank">详情</a></td>';
		    html += "</tr>";
	}
	$("table tbody").html(html);
	autoH();
	}else if(data.status == 9){
		window.location.href="index.html";
	}else{
		$("table tbody").children().remove();
		 $("#mySelectS").css("display","none");
		$("table tbody").append("<tr><td colspan='11' style='padding:20px 0;text-align: center;'>"+data.info+"</td></tr>")
	}
}

//搜索点击事件
$("#Search").click(function(){
	autoH();
	sskey= $.trim($(".foodName").val());
	if(sskey=="请输入关键字进行查询"){
		sskey="";
	}
	//获取精确查询或模糊查询
	ssmode = $("#ssmode").find("option:selected").val();
	sssel = $("#sssel").find("option:selected").val();

	search(cid, sskey, ssmode, sssel, pnum, bbtime, jytime, pindex, psize,bbtype);
})

//高级搜索点击事件
$("#confirBtn").click(function() {
	autoH();
	//报备日期验证bbDate
	var startDaobei = $("#bbDate").children("input.dateStart").val();
	var endDaobei = $("#bbDate").children("input.dateEnd").val();
	//交易日期验证jyDate
	var startJy = $("#jyDate").children("input.dateStart").val();
	var endJy = $("#jyDate").children("input.dateEnd").val();
	//交易数量
	var startPnum=$("#jyNum").children("input.startNum").val();
	if(startPnum=="数量下限"){
		startPnum="";
	}
	var endPnum=$("#jyNum").children("input.endNum").val();
	if(endPnum=="数量上限"){
		endPnum="";
	}
	if(date()) {
		if(startDaobei == "" && endDaobei == "") {
			bbtime = "";
		} else {
			bbtime = startDaobei + "," + endDaobei;
		}
		if(startJy == "" && endJy == "") {
			jytime = "";
		} else {
			jytime = startJy + "," + endJy;
		}
		if(startPnum == "" && endPnum == "") {
			pnum = "";
		} else {
			pnum = startPnum + "," + endPnum;
		}
		sskey = $(".foodName").val();
		if(sskey == "请输入关键字进行查询") {
			sskey = "";
		}
		//获取精确查询或模糊查询
		ssmode = $("#ssmode").find("option:selected").val();
		sssel = $("#sssel").find("option:selected").val();
		//获取checked的值
		bbtype = checkBoxFormat($("#jylx"));
		search(cid, sskey, ssmode, sssel, pnum, bbtime, jytime, pindex, psize,bbtype);
	};
})

/**交易数量限制，如果输入非数字，则替换为'' **/
$("#jyNum input").keyup(function () {
    this.value = this.value.replace(/[^\d]/g, '');
  })

/**select选择框**/
//function select() {
//	//获取下拉框选中项的text属性值
//	var selectText = $("#mySelect").find("option:selected").text();
//	//获取下拉框选中项的value属性值
//	var selectValue = $("#mySelect").val();
//	console.log(selectValue);
//	psize = selectValue;
//	CentPageOper(pindex);
//	search(cid, sskey, ssmode, sssel, pnum, bbtime, jytime, pindex, psize,bbtype);
//}

//function getcid(ttt) {
// cid= $(ttt).find('span').text();
//	console.log(cid);
//	window.location.href = 'Enterprise_archivesInfo.html?c_id=' + escape(cid);
//}
//function getjycid(ttt) {
// var jycid= $(ttt).find('.span1').text();
//  var cid= $(ttt).find('.span2').text();
//   var cname= $(ttt).find('.span3').text();
//	console.log(jycid);
//	window.location.href ='Enterprise_tradeObjectsInfo.html?jyid=' + escape(jypk)+'&cname='+ escape(cname)+'&c_id='+escape(cid);
//}
$(".foodName").keydown(function(event){
	var event=event || window.event;
	if(event.keyCode==13){
		$("#Search").click();
	}
})
autoH();


