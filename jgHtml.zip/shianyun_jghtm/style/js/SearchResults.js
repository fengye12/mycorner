var a1="a10",a2="a1000";//用于nav
//企业变量
var sskey=getQueryString("p");//按照单位名称、营业执照、法人、注册地址、联系人、联系电话、监管单位搜索，此值可以为空；
var sssel=0;//0：所有类型，1：单位名称，2：营业执照，3：法人，4：注册地址，5：联系人，6：联系电话，7：监管单位；
var jaddress="";//按照经营地址搜索，此值可以为空；
var c_type="";//按照企业类型搜索，此值可以为空；
var o_type="";//按照经营方式搜索，此值可以为空；
var cstatus="";//按照企业状态搜索，此值可以为空；
var yjstatus="";//按照预警状态搜索，此值可以为空；
//食品变量
var pname="";
var cid="";//按照企业id搜索所有该企业食品列表，此值可以为空；
var storage="";//按照贮存条件搜索，此值可以为空；
var ycountry="";//按照原产国搜索，此值可以为空；
var cstatus="";//按照食品状态搜索，此值可以为空；
//台帐报备变量
var cid="";//按照企业id搜索该企业所有台账报备列表，此值可以为空；
var pnum="";//按照商品种类数量搜索，此值可以为空；
var bbtime="";// 按照报备日期搜索，（参照日期格式搜索说明） ，此值可以为空；
var jytime="";//按照交易日期搜索，（参照日期格式搜索说明） ，此值可以为空；
var pindex="";
var psize="";
var cname="";
var ssmode="1", storage="",ycountry="", cstatus="",pindex="", psize="",pid="";
var qiye="";
var shipin="";
var taizhang="";
//获取url传递的参数：name为需要获取的参数名称
function getQueryString(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var search = window.location.search.substr(1);
	var href = window.location.href;
	if(href.indexOf("?") >= 0) {
		search = href.substr(href.indexOf("?") + 1);
	}
	var r = search.match(reg);
	if(r != null) return unescape(r[2]);
	return null;
}

//加载列表
$(function(){
	autoH();
	$(".foodName").val(getQueryString("p"));
	//后退链接
	var a= sskey.substr(sskey.length-1,1)
	if(a=="#"){
		sskey=sskey.substr(0,sskey.length - 1);
	}
	qy_search(sssel, sskey, jaddress, c_type,o_type, cstatus,yjstatus, pindex, psize);

})

//企业接口调用
function qy_search(sssel, sskey, jaddress, c_type,o_type, cstatus,yjstatus, spindex, psize) {
	pindex = spindex;
	$("#qyList").html("<tr><td colspan='11' class='loadimage'><img src='../style/image/load.gif' alt='' /></td></tr>");
    $("#spList").html("<tr><td colspan='7' class='loadimage'><img src='../style/image/load.gif' alt='' /></td></tr>");
	$("#tzList").html("<tr><td colspan='10' class='loadimage'><img src='../style/image/load.gif' alt='' /></td></tr>");
    var wxjson = new webjson("5"); //设置action值
	//新增param键值
	wxjson.AddParam("sssel", sssel);
	wxjson.AddParam("sskey", sskey);
	wxjson.AddParam("jaddress",jaddress);
	wxjson.AddParam("c_type",c_type);
	wxjson.AddParam("o_type", o_type);
	wxjson.AddParam("ycountry", ycountry);
	wxjson.AddParam("cstatus", cstatus);
	wxjson.AddParam("yjstatus",yjstatus);
	wxjson.AddParam("page_index", pindex);
	wxjson.AddParam("page_size", psize);
	WebRequestAsync(wxjson, qy_searchInfo);
}
function qy_searchInfo(res){
	var html = "";

	var data = GetOjson(json_parse(res));
	qiye=data.status;
	console.log(data);
	pcount = data.paramcentcount;

	if(data.status == 0 && data.param.length>4) {
		for(var i = 0; i <=4; i++){

			if(data.param[i].c_type == 0) {
				data.param[i].c_type = '食品生产企业'
			} else if(data.param[i].c_type == 1) {
				data.param[i].c_type = '食品销售经营者'
			}else if(data.param[i].c_type == 2){
				data.param[i].c_type = '餐饮服务经营者'
			}else if(data.param[i].c_type==3){
				data.param[i].c_type = '单位食堂'
			}
            if(data.param[i].o_type == 0) {
				data.param[i].o_type = '批发'
			} else if(data.param[i].o_type == 1) {
				data.param[i].o_type = '零售'
			}else if(data.param[i].o_type == 2){
				data.param[i].o_type = '批发兼零售'
			}else if(data.param[i].o_type==3){
				data.param[i].o_type = '网络经营'
			}else if(data.param[i].o_type==4){
				data.param[i].o_type = '内设中央厨房'
			}else if(data.param[i].o_type==5){
				data.param[i].o_type = '集体用餐配送'
			}
			if(data.param[i].cstatus == 0) {
				data.param[i].cstatus = '正常经营'
			} else if(data.param[i].cstatus == 1) {
				data.param[i].cstatus = '未注册'
			}else if(data.param[i].cstatus == 2){
				data.param[i].cstatus = '停产'
			}else if(data.param[i].cstatus==3){
				data.param[i].cstatus = '转让'
			}else if(data.param[i].cstatus==4){
				data.param[i].cstatus = '注销'
			}else{}


			html += "<tr>";
			html += "<td class='hs'>" +data.param[i].cname +
			"</td><td class='hs'>" +data.param[i].license +
			"</td><td class='hs'>" +data.param[i].jaddress +
			"</td><td class='hs'>" +data.param[i].legal +
			"</td><td class='hs'>" +data.param[i].scompany +
			"</td><td class='hs'>" +data.param[i].c_type +
			"</td><td class='hs'>" +data.param[i].o_type +
			"</td><td class='hs'>" +data.param[i].cnumber +
			"</td><td class='hs'>" +data.param[i].cstatus +
			"</td><td class='hs'>" +data.param[i].dqtime +
			'</td><td class="hs ls"><a href="Enterprise_archivesInfo.html?c_id='+data.param[i].c_id+'">详情</a>'+

			"</td>";
		    html += "</tr>";
		}
		$("#qy_div,#xg_gy").show()
		$("#qyList").html(html);
		$("#qy_more").css("display","");
	}else if(data.status == 0 && data.param.length<=4){
		for(var i = 0; i <data.param.length; i++){

			if(data.param[i].c_type == 0) {
				data.param[i].c_type = '食品生产企业'
			} else if(data.param[i].c_type == 1) {
				data.param[i].c_type = '食品销售经营者'
			}else if(data.param[i].c_type == 2){
				data.param[i].c_type = '餐饮服务经营者'
			}else if(data.param[i].c_type==3){
				data.param[i].c_type = '单位食堂'
			}
            if(data.param[i].o_type == 0) {
				data.param[i].o_type = '批发'
			} else if(data.param[i].o_type == 1) {
				data.param[i].o_type = '零售'
			}else if(data.param[i].o_type == 2){
				data.param[i].o_type = '批发兼零售'
			}else if(data.param[i].o_type==3){
				data.param[i].o_type = '网络经营'
			}else if(data.param[i].o_type==4){
				data.param[i].o_type = '内设中央厨房'
			}else if(data.param[i].o_type==5){
				data.param[i].o_type = '集体用餐配送'
			}
			if(data.param[i].cstatus == 0) {
				data.param[i].cstatus = '正常经营'
			} else if(data.param[i].cstatus == 1) {
				data.param[i].cstatus = '未注册'
			}else if(data.param[i].cstatus == 2){
				data.param[i].cstatus = '停产'
			}else if(data.param[i].cstatus==3){
				data.param[i].cstatus = '转让'
			}else if(data.param[i].cstatus==4){
				data.param[i].cstatus = '注销'
			}

			html += "<tr>";
			html += "<td class='hs'>" +data.param[i].cname +
			"</td><td class='hs'>" +data.param[i].license +
			"</td><td class='hs'>" +data.param[i].jaddress +
			"</td><td class='hs'>" +data.param[i].legal +
			"</td><td class='hs'>" +data.param[i].scompany +
			"</td><td class='hs'>" +data.param[i].c_type +
			"</td><td class='hs'>" +data.param[i].o_type +
			"</td><td class='hs'>" +data.param[i].cnumber +
			"</td><td class='hs'>" +data.param[i].cstatus +
			"</td><td class='hs'>" +data.param[i].dqtime +
			'</td><td class="hs ls"><a href="Enterprise_archivesInfo.html?c_id='+data.param[i].c_id+'">详情</a>'+
			"</td>";
		    html += "</tr>";
		}
		$("#qy_div,#xg_gy").show();
		$("#qyList").html(html);
		$("#qy_more").css("display","none");
	}else if(data.status == 9){
		window.location.href="index.html";
	}else if(data.status == 1){
		$("#qy_div,#xg_gy").hide()
	}else{
		$("#qyList").html("<tr><td colspan='11' class='loadimage'>"+data.info+"</td></tr>");
	}
	sp_search(sssel, sskey, ssmode, storage,ycountry, cstatus,pindex, psize);
//	autoH();
}
//企业详情跳转
// function getCid(ttt) {
//    var c_id = $(ttt).find('span').text();
// 	console.log(c_id);
// 	window.location.href = 'Enterprise_archivesInfo.html?c_id=' + escape(c_id);
// }

//食品接口调用
function sp_search(sssel, sskey, ssmode, storage,ycountry, cstatus,spindex, psize) {
	pindex = spindex;
	$("#spList").html("<tr><td colspan='7' class='loadimage'><img src='../style/image/load.gif' alt='' /></td></tr>");
	$("#tzList").html("<tr><td colspan='10' class='loadimage'><img src='../style/image/load.gif' alt='' /></td></tr>");
    var wxjson = new webjson("7"); //设置action值
	//新增param键值
	wxjson.AddParam("sskey", sskey);
	wxjson.AddParam("ssmode", ssmode);
	wxjson.AddParam("sssel",sssel);
	wxjson.AddParam("storage",storage);
	wxjson.AddParam("ycountry", ycountry);
	wxjson.AddParam("cstatus", cstatus);
	wxjson.AddParam("page_index", pindex);
	wxjson.AddParam("page_size", psize);
	WebRequestAsync(wxjson, sp_searchInfo);
}
function sp_searchInfo(res){
	var html = "";
	var data = GetOjson(json_parse(res));
	console.log(data);
	pcount = data.paramcentcount;
	shipin=data.status;
	if(data.status == 0  && data.param.length>4 ) {
		for(var i = 0; i <=4; i++){
			html += '<tr>';
			html += '<td class="hs">' +data.param[i].pname +
			'</td><td class="hs">' +data.param[i].barcode +
			'</td><td class="hs">'+data.param[i].ycountry +
			'</td><td class="hs">' +data.param[i].trademark +
			'</td><td class="hs">' +data.param[i].storage +
			'</td><td class="hs">' +data.param[i].xgqy +
			'</td><td class="hs ls"><a href="Food_info.html?pid='+data.param[i].pid+'&barcode='+data.param[i].barcode+'&pname='+escape(data.param[i].pname) +'&ycountry='+escape(data.param[i].ycountry)+'">详情</a></td>'
		    html += '</tr>';
		}
		$("#sp_div,#xg_sp").show();
		$("#spList").html(html);
	}else if(data.status == 0  && data.param.length>0 && data.param.length<=4){
		for(var i = 0; i < data.param.length; i++){
			html += "<tr>";
			html += "<td class='hs'>" +data.param[i].pname +
			"</td><td class='hs'>" +data.param[i].barcode +
			"</td><td class='hs'>" +data.param[i].ycountry +
			"</td><td class='hs'>" +data.param[i].trademark +
			"</td><td class='hs'>" +data.param[i].storage +
			"</td><td class='hs'>" +data.param[i].xgqy +
			'</td><td class="hs ls"><a href="Food_info.html?pid='+data.param[i].pid+'&barcode='+data.param[i].barcode+'&pname='+data.param[i].pname +'& ycountry='+data.param[i].ycountry+'">'+"详情"+'</a></td>'
//			"</td><td><a href='#' class='ls' id='sp_ls' onclick='getPid(this)'>"+"详情"+
//			 "<span style='display:none'>" + data.param[i].pid +
//			"</span></a></td>";
		    html += "</tr>";
		}
		$("#sp_div,#xg_sp").show();
		$("#spList").html(html);
		$("#sp_more").css("display","none");
	}else if(data.status == 9){
		window.location.href="index.html";
	}else if(data.status == 1){
		$("#sp_div,#xg_sp").hide()
	}else{
		$("#spList").html("<tr><td colspan='7' class='loadimage'>"+data.info+"</td></tr>");
	}
	tz_search(sskey, ssmode, sssel, pnum,bbtime, jytime,pindex, psize);}
//食品详情跳转
//function getPid(ttt) {
// var pid = $(ttt).find('span').text();
//	console.log(pid);
//	window.location.href = 'Food_info.html?pid=' + escape(pid);
//}
//台帐接口调用
function tz_search(sskey, ssmode, sssel, pnum,bbtime, jytime,spindex, psize) {
	pindex = spindex;
	$("#tzList").html("<tr><td colspan='10' class='loadimage'><img src='../style/image/load.gif' alt='' /></td></tr>");
    var wxjson = new webjson("9"); //设置action值
	//新增param键值
	wxjson.AddParam("sskey", sskey);
	wxjson.AddParam("ssmode", ssmode);
	wxjson.AddParam("sssel",sssel);
	wxjson.AddParam("pnum",pnum);
	wxjson.AddParam("bbtime", bbtime);
	wxjson.AddParam("jytime", jytime);
	wxjson.AddParam("page_index", pindex);
	wxjson.AddParam("page_size", psize);
	WebRequestAsync(wxjson, tz_searchInfo);
}
function tz_searchInfo(res){
	var html = "";
	var data = GetOjson(json_parse(res));
	console.log(data);
	pcount = data.paramcentcount;
	taizhang=data.status;
	if(data.status == 0  && data.param.length>4) {
		for(var i = 0; i <=4; i++){
			var bbid=data.param[i].bbid;
			if(data.param[i].bbtype == 0) {
				data.param[i].bbtype = '食品采购报备'
			} else {
				data.param[i].bbtype = '食品销售报备'
			}

			html += "<tr>";<!--报备企业	商品名称	商品条码	报备日期	单据号	报备类型	交易对象	交易日期	索证状态-->
			html += "<td class='hs'>" +data.param[i].cname +
			"</td><td class='hs'>" +data.param[i].foodname +
			"</td><td class='hs'>" +data.param[i].barcode +
			"</td><td class='hs'>" +data.param[i].bbtime +
			"</td><td class='hs'>" +data.param[i].djnum +
			"</td><td class='hs'>" +data.param[i].bbtype +
			"</td><td class='hs'>" +data.param[i].jycname +
			"</td><td class='hs'>" +data.param[i].jytime ;
			if(data.param[i].bbtype == '食品采购报备'){
				html+="<td class='hs' style='color:#EF2121;font-size:12px;'>未索证</td>";
				}else{
					html+="<td>无需索证</td>";
				}
			html+='<td class="hs ls"><a href="StandingBook_check.html?bbid='+data.param[i].bbid+'">详情</a>'+
			"</td>";
		    html += "</tr>";
	}
	$("#tz_div,#xg_tz").show();
	$("#tzList").html(html);
	autoH();
	}
	else if(data.status == 0 && data.param.length<=4){
		for(var i = 0; i <data.param.length; i++){
			var bbid=data.param[i].bbid;
			if(data.param[i].bbtype == 0) {
				data.param[i].bbtype = '食品采购报备'
			} else {
				data.param[i].bbtype = '食品销售报备'
			}

			html += "<tr>";
			html += "<td class='hs'>" +data.param[i].cname +
			"</td><td class='hs'>" +data.param[i].bbtime +
			"</td><td class='hs'>" +data.param[i].djnum +
			"</td><td class='hs'>" +data.param[i].bbtype +
			"</td><td class='hs'>" +data.param[i].jycname +
			"</td><td class='hs'>" +data.param[i].jytime +
			"</td><td class='hs'>" +data.param[i].pnum +
			'</td><td class="hs ls"><a href="StandingBook_check.html?bbid='+data.param[i].bbid+'">详情</a>'+
			"</td>";
		    html += "</tr>";
	}
	$("#tz_div,#xg_tz").show();
	$("#tzList").html(html);
	$("#tz_more").css("display","none");
	}
	else if(data.status == 9){
		window.location.href="index.html";
	}else if(data.status == 1){
		$("#tz_div,#xg_tz").hide()
	}else{
		$("#tzList").html("<tr><td colspan='10' class='loadimage'>"+data.info+"</td></tr>");
	}
}
//台帐详情跳转
// function getTZid(ttt) {
//    var bbid = $(ttt).find('span').text();

// 	window.location.href = 'StandingBook_check.html?bbid=' + escape(bbid);
// }


//企业查看更多
function qymore() {
	console.log(sskey);
	window.location.href = 'Enterprise_archives.html?sskey=' + escape(sskey);
}

//食品查看更多
function spmore() {
	console.log(sskey);
	window.location.href = 'Food_archives.html?sskey=' + escape(sskey);
}

//台帐查看更多
function tzmore() {
	console.log(sskey);
	window.location.href = 'ReportedToTheStandingBook.html?sskey=' + escape(sskey);
}

//页面查询
$("#Search").click(function(){
  sssel="0",jaddress="",c_type="",o_type="",cstatus="",yjstatus="",pindex="",psize="",ssmode="1",storage="",pnum="",jytime="";//清空
  sskey = $(".foodName").val();
  console.log(sskey)
  qy_search(sssel, sskey, jaddress, c_type,o_type, cstatus,yjstatus, pindex, psize);

})
$(".inputWraper input").on("keydown",function(event){//按下回车执行查询
	var event=event || window.event;
	if(event.keyCode == "13") {//判断如果按下的是回车键则执行下面的代码
	    $("#Search").click();
	}
})
//当没有查询数据出现提示
// function no_data(){
// 	if((qiye==1) && (shipin==1) && (taizhang==1)){
// 		$("#nodata").css("display","inline-block");
// 	}else{
// 		$("#nodata").css("display","nonek");
// 	}
// }
/**点击问号图标事件**/
$(".content-title .a3").click(function(){
	// $(this).parent().next("p").slideToggle(100);
	if($(this).is(":hover")){
  // console.log($(".selectedB .optionB").not($(this).next('.optionB')))
  $(".content-title p").not($(this).parent().next('p')).hide(20);
  $(this).parent().next('p').slideToggle(20);
}
})

 document.onclick = function(){
      $(".content-title p").hide();
    };
$('.content-title .a3').bind('click',function(e){
stopPropagation(e);
});
function stopPropagation(e) {
if (e.stopPropagation)
e.stopPropagation();
else
e.cancelBubble = true;
}