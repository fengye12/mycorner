/*
* @Author: anchen
* @Date:   2017-07-07 12:06:09
* @Last Modified by:   anchen
* @Last Modified time: 2017-08-24 13:10:11
*/

//用来关闭弹窗
var layer01;
var layer02;
var layer03;
var layer04;
  //enter/键触发登录

function on_return(e){
    var e=window.event || e;
     var k = e.keyCode || e.which;
 if(k==13){
 loginYz();//登录验证
}
}

window.history.forward();
function StopBack() { window.history.forward(); }
$('body').on('onload', function(event) {
 StopBack();
});
$('body').on('onpageshow', function(event) {
 if (event.persisted) StopBack();
});
function userYz(val,reid){//验证账号
    if(val=="注册账号/手机号" || val == ""){
    layer02=layer.tips('请填写注册账号或手机号', reid,{
     // time:10000000,
     tips: [1, 'red'],
   });
    return false;
  }else{
    layer.close(layer01);
    return true;
  }
}

function pwdYz(val,reid){//验证密码
  if (val=="请输入密码"|| val == ""){
   layer01=layer.tips('请输入密码', reid,{
    // time:10000000,
     tips: [1, 'red'],
  });
    return false;
  }else{
     layer.close(layer01);
     return true;
  }
}

function loginYz(){//验证登录
  var username=$("#userName").val();
  var pwd=$("#password").val();
  var flagU=userYz(username,'#userName');
  var flagP;
  if(flagU){
flagP=pwdYz(pwd,'#password');
  }
  if( flagU && flagP){
    login(username,pwd);
    return false;
  }else{
    return false;
  }
}

   function login(user, pwd) {//登录接口
    layer.close(layer01);
    layer03=layer.tips('玩命登录中...', '#login-btn',{
     time:10000000,
     tips: [2, '#000'],
   });
    var wxjson = new webjson("0");
    wxjson.AddParam("username", user);//用户名
    wxjson.AddParam("password", pwd);//密码
    if($("#autoL").prop("checked")){//是不是自动登录
     wxjson.AddParam("autologin", "1");
   }else{
    wxjson.AddParam("autologin", "0");
   }
   WebRequestAsync(wxjson, successLogin);

   //成功请求
   function successLogin(res){

     var data = GetOjson(json_parse(res));
     if (data.status == "0") {
       layer.close(layer01);
       $.cookie('user', user, { expires: 30 });
       if($("#autoL").prop("checked")){
         //自动登录存储uuid
         localStorage.setItem("uuid",data.param[0].uuid);
       }else{
        localStorage.removeItem("uuid");
      }
      //存储用户名
      $.cookie('user_id', data.param[0].user_id, { expires: 30 });
      $.cookie('departmentid', data.param[0].dept_id, { expires: 30 });
      $.cookie('dept_name', data.param[0].dept_name, { expires: 30 });
      $.cookie('user_type', data.param[0].user_type, { expires: 30 });
      $.cookie('username', data.param[0].username, { expires: 30 });
      $.cookie('dep_code', data.param[0].dept_code, { expires: 30 });

      location="home.html";
    }else{
      layer.close(layer01);
      layer04=layer.tips(data.info, '#login-btn',{
       time:100000,
       tips: [2, 'red'],
     });
    }
  }
}
 $(function(){
  window.history.forward();
  function StopBack() { window.history.forward(); }
  $('body').on('onload', function(event) {
   StopBack();
 });
  $('body').on('onpageshow', function(event) {
   if (event.persisted) StopBack();
 });

//获取链接参数
    var loginOut=GetQueryString("loginOut");
    var uuid=localStorage.getItem("uuid");
    //uuid存在，多选框选中
    if(uuid){
     $("#autoL").prop("checked", true);
   }
   //直接访问index.html且uuid存在自动登录
   if(loginOut!="undefined" && loginOut){
   }else{
    if(uuid){
      var username=$.cookie('user');
      var user_id=$.cookie('user_id')
     var wxjson = new webjson("1");
     wxjson.AddParam("user_id", user_id);
     wxjson.AddParam("username", username);
     wxjson.AddParam("uuid", uuid);
     var res= WebRequest(wxjson);
     var data = GetOjson(json_parse(res));
     if (data.status == "0") {
              //保存用户名和userid
              $.cookie('user_id', data.param[0].user_id, { expires: 30 });
              $.cookie('user', data.param[0].username, { expires: 30 });
              $.cookie('departmentid', data.param[0].dept_id, { expires: 30 });
              $.cookie('dept_name', data.param[0].dept_name, { expires: 30 });
              $.cookie('user_type', data.param[0].user_type, { expires: 30 });
              $.cookie('username', data.param[0].username, { expires: 30 });
               $.cookie('dep_code', data.param[0].dept_code, { expires: 30 });
              location="home.html";
            }else{
              layer.msg('自动登录失败,请手动登录');
            }
          }
        }

  //input失焦事件
  $(".login-form input").blur(function(){
   var $parent = $(this).parent();
      if($(this).is("#userName")){//验证用户名

        userYz($.trim($(this).val()),$parent);
      }
      if($(this).is("#password")){//验证密码
        pwdYz($.trim($(this).val()),$parent)
      }
    })

//input聚焦事件
    $(".login-form input").focus(function(event) {
      layer.close(layer03);
      layer.close(layer04);
      // console.log($(this).attr('name'))
      if($(this).attr('name')=='userName'){
        layer.close(layer02)
      }else{
         layer.close(layer01)
      }
      // layer.closeAll();
    });

    $("#login-btn").click(function(){//点击登录按钮
      loginYz();//登录验证
    })
})

