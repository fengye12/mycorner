var pagenum = 1;
var ecount = 20;
var cpage = new CentPage();
var cents = cpage.GetCentPage(pagenum,1000,ecount);
$("#page").html(cents);
	function CentPageOper(pnum){
    cents = cpage.GetCentPage(pnum,1000,ecount);
	$("#page").html(cents);
}
function select() {
	//获取下拉框选中项的text属性值
	var selectText = $("#mySelect").find("option:selected").text();
	//获取下拉框选中项的value属性值
	var selectValue = $("#mySelect").val();
	console.log(selectValue);
	//获取下拉框选中项的index属性值
	//var selectIndex = $("#mySelect").get(0).selectedIndex;
	psize = selectValue;
	pindex = 1;
//	search(djnum, spname, jytime, bbtime, cname, pindex, psize);
}
//高级搜索设置
$("#confirBtn").click(function(){
	date();
    spname = $(this).parents("#search").children(".foodName").val();//搜索框输入的值
    console.log(spname);
    //获取checked的值
    var str=""; 
    $("[name='checkbox'][checked]").each(function(){ 
    str+=$(this).val()+"/r/n"; 
    //alert($(this).val()); 
    }) 
  console.log(str); 
   //search(djnum, spname, jytime, bbtime, cname, pindex, psize);
    $("#form").hide();
})