/**截取字符串方法**/
 function getQueryString(name) {
 	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
 	var search = window.location.search.substr(1);
 	var href = window.location.href;
 	if(href.indexOf("?") >= 0) {
 		search = href.substr(href.indexOf("?") + 1);
 	}
 	var r = search.match(reg);
 	if(r != null) return unescape(r[2]);
 	return null;
 }

//格式化复选框提交方式
function checkBoxFormat(warpBox){
  var checked=warpBox.find("input[type='checkbox']:checked");
  var check=warpBox.find("input[type='checkbox']");
  if(checked.length == check.length || checked.length == 0){
    return '';
  }else{
    var str='';
    $.each(check,function(i,item){
      if($(this).is(':checked')){
        str=str+i+',';
      }
    })
    str=str.substr(0,str.length-1)
    return str;
  }
}


function checkBoxFormat2(warpBox){
  var checked=warpBox.find("input[type='checkbox']:checked");
  var check=warpBox.find("input[type='checkbox']");
  if(checked.length == 0){
    return '';
  }else{
    var str='';
    $.each(check,function(i,item){
      if($(this).is(':checked')){
        str=str+i+',';
      }
    })
    str=str.substr(0,str.length-1)
    return str;
  }
}
function comfireSearch(){
var startJy = $("#bbDate").children("input.dateStart").val();
  var endJy = $("#bbDate").children("input.dateEnd").val()
  if(startJy != "" && endJy != "" && new Date(startJy.replace(/-/g, "/")) > new Date(endJy.replace(/-/g, "/"))) {
    layer.msg('开始日期不能大于结束日期')
    return false;
   }else{
    getList();
   }
}
function comfireSearch2(){
var startJy = $("#bbDate").children("input.dateStart").val();
  var endJy = $("#bbDate").children("input.dateEnd").val()
  var start2 = $("#jyDate").children("input.dateStart").val();
  var end2 = $("#jyDate").children("input.dateEnd").val()
  if(startJy != "" && endJy != "" && new Date(startJy.replace(/-/g, "/")) > new Date(endJy.replace(/-/g, "/"))) {
    layer.msg('开始日期不能大于结束日期')
    return false;
   }else if(start2 != "" && end2 != "" && new Date(start2.replace(/-/g, "/")) > new Date(end2.replace(/-/g, "/"))){
    layer.msg('开始日期不能大于结束日期')
   }else{
    getList();
   }
}
//通过input中value值提交
function checkBoxTable(warpTable){
  var checkedTable=warpTable.find("input[type='checkbox']:checked");
  var checkTable=warpTable.find("input[type='checkbox']");
    var tabs='';
    $.each(checkTable,function(i,item){
      if($(this).is(':checked')){
    	  var inp=$(this).val();
    	  tabs=tabs+inp+',';
      }
    })
    tabs=tabs.substr(0,tabs.length-1)
    return tabs;
}

//导出调用的方法
function postExportExcel(URL, PARAMS) {
    var temp = document.createElement("form");
    temp.action = URL;
    temp.method = "post";
    temp.style.display = "none";
    for (var x in PARAMS) {
       console.log(PARAMS[x]);
       var opt = document.createElement("textarea");
       opt.name = x;
       opt.value = PARAMS[x];
       temp.appendChild(opt);
    }
    document.body.appendChild(temp);
    temp.submit();
  }
  $(function(){
    $(".circle").on("click",function(){
      if($(this).parents(".downcon").find(".downtext").css("display") == "none"){
        $(this).parents(".downcon").find(".downtext").css("display","block");
      }else{
        $(this).parents(".downcon").find(".downtext").css("display","none");
      }
    })
  })
  function getTime(){
  var start=$("#bbDate .dateStart").val();
  var end=$("#bbDate .dateEnd").val();
  if(start=="" && end !=""){
   return time=","+end;
  }else if(end == "" && start!=""){
  return time=start;
  }else if(end != "" && start!=""){
     return time= start+","+end
  }else{
    return time=""
  }
  }
   function getTime2(){
  var start=$("#jyDate .dateStart").val();
  var end=$("#jyDate .dateEnd").val();
  if(start=="" && end !=""){
   return time2=","+end;
  }else if(end == "" && start!=""){
  return time2=start;
  }else if(end != "" && start!=""){
     return time2= start+","+end
  }else{
    return time2=""
  }
  }
  
