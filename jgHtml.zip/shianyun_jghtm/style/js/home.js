
/*
* @Author: anchen
* @Date:   2017-07-27 18:15:10
* @Last Modified by:   anchen
* @Last Modified time: 2017-09-22 13:45:44
*/
var layer1;
var leftxAxis=[];
var leftrw=[];
var leftxz=[];
var a1="a10",a2="a1000";//用于nav
var rightxAxis=[];
var rightbbqy=[];
var rightbbzs=[];
var rightYear=[];
// var leftYear=[];
rightxAxis=[],
rightbbqy=[],
rightbbzs=[],
leftxAxis = [];
 leftxz = [];
 leftrw = [];
var myChartR = echarts.init(document.getElementById('mainR'));

         function setAnyChartFunR(){
              var amax=Math.max.apply(null, rightbbqy);
              amax=Math.ceil(amax);
              var length=amax.toString().length;
              var bai=1;
              for(var i=0;i<length-1;i++){
                bai=bai*10
              }
               var max;
              if(length>1){
              max=(+amax.toString().split('')[0]+1)*bai;
              }else{
            max=10;
              }
              var amax=Math.max.apply(null, rightbbzs);
              amax=Math.ceil(amax);
              var length=amax.toString().length;
              var bai=1;
              for(var i=0;i<length-1;i++){
                bai=bai*10
              }
               var max1;
              if(length>1){
              max1=(+amax.toString().split('')[0]+1)*bai;
              }else{
            max1=10;
              }
             var option = {
                 color: ['#f8a87d'],
                 tooltip : {
                     trigger: 'axis',
                 axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                     type : 'line'        // 默认为直线，可选为：'line' | 'shadow'
                 },
                                 formatter:function (params, ticket, callback) {
                                   var dataIndex=params[0].dataIndex;
                                   if(params.length>1){

                                     return rightYear[dataIndex]+'年'+params[0].axisValue+'<br><span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:#4ba3fc;"></span>'+params[0].seriesName+':'+params[0].value+'<br><span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:#f8a87d;"></span>'+params[1].seriesName+':'+params[1].value
                                   }else{
                                    if(params[0].seriesName=="报备企业"){
                                    return rightYear[dataIndex]+'年'+params[0].axisValue+'<br><span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:#4ba3fc;"></span>'+params[0].seriesName+':'+params[0].value
                                }else{
                                     return rightYear[dataIndex]+'年'+params[0].axisValue+'<br><span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:#f8a87d;"></span>'+params[0].seriesName+':'+params[0].value
                                   }
                                }
                 }

                 },
             legend: {
                 data:['报备企业','报备总量'],
                 left:"center",
                 tooltip:{
                  show:true
              },
              bottom: '10px',
              left: 'center'
          },
          grid: {
             left: '3%',
             right: '4%',
             bottom: '50px',
             top:'20',
             containLabel: true
         },
         xAxis : [
         {
             type : 'category',
             data : rightxAxis,
             splitNumber:8,
             axisTick: {
                                 show:false,//坐标轴刻度
                                 alignWithLabel: true
                             }
         }
         ],
         yAxis : [
         {
            type: 'value',
            name: '报备企业',
            nameLocation:'start',
            nameGap:25,
            splitNumber:5,
            max:max,
            interval:max/5,
            axisLine:{
                         show:false
                       },
            splitLine:{show: true},
            axisTick: {
                    show:false,//坐标轴刻度
                    alignWithLabel: true
                     },
            position: 'left',
            axisLabel: {
             formatter: '{value} '
         }
     },
     {
         type: 'value',
         name: '报备总量',
         nameLocation:'start',
         nameGap:25,
         splitNumber:5,
         max:max1,
         interval:max1/5,
         axisLine:{
                         show:false,

                       },
         axisTick: {
                 show:false,//坐标轴刻度
                 alignWithLabel: true
                  },
         position: 'right',
         splitLine:{show: true},
         axisLabel: {
             formatter: '{value}'
         }
     },
     ],
     series : [
     {
         name:'报备企业',
         type:'bar',
         barWidth: '25%',
         yAxis: 1,
         itemStyle:{normal:{color:'#4ba3fc'}},
         data:rightbbqy
     },
     {
         name:'报备总量',
         type:'line',
         yAxisIndex: 1,
         data:rightbbzs
     }
     ]
 };
          // 使用刚指定的配置项和数据显示图表。
          myChartR.on('legendselectchanged', function(params) {
                       if(params.selected.报备总量==false && params.selected.报备企业==false){
                        option.yAxis[0].show=false;
                        option.yAxis[1].show=false;
                       }else if(params.selected.报备总量==true && params.selected.报备企业==true){
                          option.yAxis[0].show=true;
                        option.yAxis[1].show=true;
                       }else if(params.selected.报备总量==true && params.selected.报备企业==false){
                          option.yAxis[0].show=false;
                        option.yAxis[1].show=true;
                       }else if(params.selected.报备总量==false && params.selected.报备企业==true){
                          option.yAxis[0].show=true;
                        option.yAxis[1].show=false;
                       }
                        myChartR.setOption(option);
                    });
           myChartR.setOption(option);
      }
         var myChart1 = echarts.init(document.getElementById('main'));
      function setAnyChartFun(){
          var amax=Math.max.apply(null, leftxz);
          amax=Math.ceil(amax);
          var length=amax.toString().length;
          var bai=1;
          for(var i=0;i<length-1;i++){
            bai=bai*10
          }
           var max;
          if(length>1){
          max=(+amax.toString().split('')[0]+1)*bai;
          }else{
        max=10;
          }
          var amax=Math.max.apply(null, leftrw);
          amax=Math.ceil(amax);
          var length=amax.toString().length;
          var bai=1;
          for(var i=0;i<length-1;i++){
            bai=bai*10
          }
           var max1;
          if(length>1){
          max1=(+amax.toString().split('')[0]+1)*bai;
          }else{
        max1=10;
          }
         var option = {
             color: ['#f8a87d'],
             tooltip : {
                 trigger: 'axis',
                     axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                         type : 'line'        // 默认为直线，可选为：'line' | 'shadow'
                     }
                 },
                 legend: {
                     data:['新增企业','入网企业'],
                     left:"center",
                     tooltip:{
                      show:true
                  },
                  bottom: '10px',
              },
              grid: {
                 left: '3%',
                 right: '4%',
                 bottom: '50px',
                 top:'20px',
                 containLabel: true
             },
             xAxis : [
             {
                 type : 'category',
                 data : leftxAxis,
                 splitNumber:8,
                 axisTick: {
                         show:false,//坐标轴刻度
                         alignWithLabel: true
                          },
             }
             ],
             yAxis : [
             {
                type: 'value',
                name: '新增企业',
                nameLocation:'start',
                splitLine:{show: true},
                 nameGap:25,
                 splitNumber:5,
                 interval:max/5,
                 max:max,
                 axisLine:{
                         show:false
                       },
            axisTick: {
                    show:false,//坐标轴刻度
                    alignWithLabel: true
                     },
                position: 'left',
                min:0,
                axisLabel: {
                 formatter: '{value} '
             }
         },
         {
             type: 'value',
             name: '入网企业',
             nameLocation:'start',
            nameGap:25,
            splitNumber:5,
            interval:max1/5,
            max:max1,
            splitLine:{show: true},
            axisLine:{
                         show:false
                       },
            axisTick: {
                    show:false,//坐标轴刻度
                    alignWithLabel: true
                     },
             min: 0,
             position: 'right',
             axisLabel: {
                 formatter: '{value}'
             }
         },
         ],
         series : [
         {
             name:'新增企业',
             type:'bar',
             barWidth: '60%',
             yAxis: 1,
             itemStyle:{normal:{color:'#4ba3fc'}},
             data:leftxz
         },
         {
             name:'入网企业',
             type:'line',
             yAxisIndex: 1,
             data:leftrw
         }
         ]
     };
     myChart1.on('legendselectchanged', function(params) {
                 if(params.selected.新增企业==false && params.selected.入网企业==false){
                  option.yAxis[1].show=false;
                    option.yAxis[0].show=false;
                 }else if(params.selected.新增企业==true && params.selected.入网企业==true){
                    option.yAxis[1].show=true;
                    option.yAxis[0].show=true;
                 }else if(params.selected.新增企业==true && params.selected.入网企业==false){
                    option.yAxis[0].show=true;
                    option.yAxis[1].show=false;
                 }else if(params.selected.新增企业==false && params.selected.入网企业==true){
                    option.yAxis[1].show=true;
                    option.yAxis[0].show=false;
                 }
                  myChart1.setOption(option);
                });
           myChart1.setOption(option);
          }
          $(window).resize(function() {
            location.reload();
        });
$(function(){
  setAnyChartFun();
  setAnyChartFunR();
totalDefault();
netAccessRate();
reportData();
getArea();
$(".kzt").attr("src","../style/image/kzt1.png");
$(".left-nav>ul>li:first-child span").css("color","#158cea");
$(".list-title:first-child").mouseenter(function(){
	$(this).children().find(".kzt").attr("src","../style/image/kzt1.png");
	$(this).children().find("span").css("color","#158cea");
})
$(".list-title:first-child").mouseleave(function(){
	$(this).children().find(".kzt").attr("src","../style/image/kzt1.png");
	$(this).children().find("span").css("color","#158cea");
})
})
//获取总数
function totalDefault(){
    var wxjson = new webjson("29");
    WebRequestAsync(wxjson, Overall_statistics);
function  Overall_statistics(res){
    var data = GetOjson(json_parse(res));
    if(data.status==0){
       if(data.param.length>0){
        $("#tjrq").text(data.param[0].tjrq);
        $("#qyzs").text(+data.param[0].tzzs+300000);
        $("#spzs").text(data.param[0].pjzs);
        $("#tzzs").text(data.param[0].bazs);
    }
    } else if(data.status == 9) {
        window.location.href="index.html?loginOut=true";
    } else {
       layer.closeAll();
       layer.msg(data.info);
    }
}
}

// 入网率
function netAccessRate(){
    myChart1.showLoading({
                    text : '数据获取中',
                    effect: 'whirling',
                    color:'#56b4f8'
                });
    var wxjson = new webjson("2");
    WebRequestAsync(wxjson,allEnterprise);
    function allEnterprise(res){
        var data = GetOjson(json_parse(res));
        if(data.status==0){
               myChart1.hideLoading();
            // if(data.datas.length>0){
                $("#all_rwl").text(data.datas.allqy[0].all_rwl);
                //console.log(data.datas.sc_qy[0]);
                $("#all_rwqy").text(data.datas.allqy[0].all_rwqy);
                // if(data.datas.allqy[0].all_rwqy!=0){
                  $("#all_rwqy").css({
                    color: '#158cea',
                    cursor: 'pointer'
                  });
                // }
                $("#all_zrxz").text(data.datas.allqy[0].all_zrxz);
                // if(data.datas.allqy[0].all_zrxz!=0){
                  $("#all_zrxz").css({
                    color: '#158cea',
                    cursor: 'pointer'
                  });
                // }
                $("#all_wrwqy").text(data.datas.allqy[0].all_wrwqy);
                $("#sc_rwl").text(data.datas.scqy[0].sc_rwl);
                $("#sc_bbl").text(data.datas.scqy[0].sc_bbl);
                $("#sc_rwqy").text(data.datas.scqy[0].sc_rwqy);
                $("#sc_wrwqy").text(data.datas.scqy[0].sc_wrwqy);
                $("#xs_rwl").text(data.datas.xsqy[0].xs_rwl);
                $("#xs_bbl").text(data.datas.xsqy[0].xs_bbl);
                $("#xs_rwqy").text(data.datas.xsqy[0].xs_rwqy);
                $("#xs_wrwqy").text(data.datas.xsqy[0].xs_wrwqy);
                $("#cy_rwl").text(data.datas.cyqy[0].cy_rwl);
                $("#cy_bbl").text(data.datas.cyqy[0].cy_bbl);
                $("#cy_rwqy").text(data.datas.cyqy[0].cy_rwqy);
                $("#cy_rwqy").text(data.datas.cyqy[0].cy_rwqy);
                $("#st_rwl").text(data.datas.stqy[0].st_rwl);
                $("#st_bbl").text(data.datas.stqy[0].st_bbl);
                $("#st_rwqy").text(data.datas.stqy[0].st_rwqy);
                $("#st_wrwqy").text(data.datas.stqy[0].st_wrwqy);
                $("#cy_rwl").text(data.datas.cyqy[0].cy_rwl);
                $("#cy_bbl").text(data.datas.cyqy[0].cy_bbl);
                $("#cy_rwqy").text(data.datas.cyqy[0].cy_rwqy);
                $("#cy_wrwqy").text(data.datas.cyqy[0].cy_wrwqy);
                var allData=data.datas.all_qy;
                leftxAxis=[];
                leftrw=[];
                leftxz=[];

                //链接
                rwhref();
                centerClick();
                bigHref();
                $.each(allData,function(index, el) {
                    leftxAxis.push(parseInt(allData[index].rq)+'日');
                    // leftYear.push(allData[index].rq.substring(0,3));
                    leftrw.push(allData[index].rwqy);
                    leftxz.push(allData[index].xzqy);
                    setAnyChartFun();
                });
        } else if(data.status == 9) {
            window.location.href="index.html?loginOut=true";
        } else {
           layer.closeAll();
           layer.msg(data.info);
        }
    }
}
 var myDate=new Date();
var month = ((myDate.getMonth()+1)<10?"0":"")+(myDate.getMonth()+1);
var todayDate=myDate.getFullYear()+"-"+month;
 $(".centerText").text(myDate.getFullYear()+'年'+month+'月');
 var bbtime=myDate.getFullYear()+"-"+month;

 //报备率
function reportData(){
        myChartR.showLoading({
                    text : '数据获取中',
                    effect: 'whirling',
                    color:'#56b4f8'
                });
    var wxjson = new webjson("3");
     wxjson.AddParam("sdate", bbtime );
     WebRequestAsync(wxjson,allReported);
     function allReported(res){
         var data = GetOjson(json_parse(res));
        if(data.status==0){
            myChartR.hideLoading();
            $("#all_bbqy").text(data.datas.all_ba[0].bbqy);
            $("#all_bbzs").text(data.datas.all_ba[0].bbzs);
            // if(data.datas.all_ba[0].bbqy!=0){
                  $("#all_bbqy").css({
                    color: '#158cea',
                    cursor: 'pointer'
                  });
                // }
            $("#all_wbbqy").text(data.datas.all_ba[0].wbbqy);
            $("#all_wbbqy").css({
                    color: '#158cea',
                    cursor: 'pointer'
                  });
            $("#all_bbl").text(data.datas.all_ba[0].bbl);
             rightbbqy=[];
             rightbbzs=[];
             rightxAxis=[];
             rightYear=[];
            var dataM=data.datas.all_ba;
            $.each(dataM, function(index, val) {
                rightxAxis.push(parseInt(dataM[index].yf.substring(4,7))+'月');
                // console.log(parseInt('10'));
                rightYear.push(dataM[index].yf.substring(0,4));
                rightbbqy.push(dataM[index].bbqy)
                rightbbzs.push(dataM[index].bbzs);
            });
            rightxAxis.reverse();
            rightYear.reverse();
            rightbbqy.reverse();
            rightbbzs.reverse();
            setAnyChartFunR();

            //点击链接
            bbhref();
        }else if(data.status == 9) {
            window.location.href="index.html?loginOut=true";
        } else {
           layer.closeAll();
           layer.msg(data.info);
        }
     }
}
var flag=0;
function getDate(originD){
return originD.substring(0,4)+'-'+originD.substring(5,7);
}

//比较两个日期大小
function copmpare(beginDate,endDate){
 var d1 = new Date(beginDate);
 var d2 = new Date(endDate);
  if(beginDate!=""&&endDate!=""&&d1 >=d2)
 {
    console.log(d1);
    console.log(d2);
    if(d1-d2==0){
        flag=1;
    }else{
       flag=0;
    }
  return false;
 }else{
    return true;
 }
}

//下个月
function nextMonth(){
    var now=getDate($(".centerText").text());
     var bzDate= new Date(now);
    if(copmpare(now,todayDate)){
        bzDate.setMonth(bzDate.getMonth()+1);
         bbtime=bzDate.getFullYear()+"-"+((bzDate.getMonth()+1)<10?"0":"")+(bzDate.getMonth()+1);
           var centerText=bzDate.getFullYear()+"年"+((bzDate.getMonth()+1)<10?"0":"")+(bzDate.getMonth()+1)+'月';
           $(".centerText").text(centerText);
           reportData();
           now=getDate($(".centerText").text());
           copmpare(now,todayDate);
               if(flag==1){
                   $(".nextgray").css('display', 'inline-block');
                   $(".next").hide();
           }else{
                  $(".nextgray").hide();
              $(".next").css('display', 'inline-block');
               }
    }else{
        flag=0;
         $(".nextgray").css('display', 'inline-block');
         $(".next").hide();
    }
}

//上个月
function beforeMonth(){
     flag=0;
    $(".nextgray").hide();
    $(".next").css('display', 'inline-block');
    var now=getDate($(".centerText").text());
    console.log(now)
    var bzDate= new Date(now);
    console.log(bzDate)
    bzDate.setMonth(bzDate.getMonth()-1);
    console.log(bzDate)
    bbtime=bzDate.getFullYear()+"-"+((bzDate.getMonth()+1)<10?"0":"")+(bzDate.getMonth()+1);
    var centerText=bzDate.getFullYear()+"年"+((bzDate.getMonth()+1)<10?"0":"")+(bzDate.getMonth()+1)+'月';
    $(".centerText").text(centerText);
    reportData();
}

//计算大小
function getSize(){
   var liwidth=$(".Big-icon").eq(0).width();
    var sliwidth=Math.round($(".Big-icon").eq(0).width()*0.83);
    var paddDate=Math.round((sliwidth-40)*0.5);
    $(".swiper-wrapper").height(liwidth);
    $(".swiper-slide").height(liwidth)
    $(".Small-icon").css({
        width: sliwidth,
        height: sliwidth,
        'padding-top':paddDate
    });
    $(".Big-icon").css({
        width: liwidth,
        height: liwidth,
    });
    $("#wrapperCenter").height(liwidth);
    $(".liSize").each(function(index, el) {
        $(this).css({
            height: liwidth
        });
    });
}

//区域分布
function getArea(){
        var wxjson = new webjson("4");
        WebRequestAsync(wxjson,regulatory);
        function regulatory(res){
        var data = GetOjson(json_parse(res));
        if(data.status==0){
            $(".swiper-container").empty();
            if(data.param.length>0){
            var swiperHtml='<div class="swiper-wrapper">';
            if(data.param.length>0){
             function compare(property) {
            return function(a, b) {
                var value1 = a[property];
                var value2 = b[property];
                return value1 - value2;
            }
        };
        var json2 = data.param.sort(compare("qyrws"));
            json2.reverse();
                $.each(data.param, function(i, val) {
                    swiperHtml=swiperHtml+'<div class="swiper-slide">'+
                       '<div class="liSize">';
                       var qyrwl=parseInt((val.qyrwl).slice(0, -1));
                       var qybbl=parseInt((val.qybbl).slice(0, -1));
                       var size=0;

                       getSize();
                       function getSize(){
                        if(qyrwl<=size){
                          swiperHtml+= '<div class="Big-icon yIcon'+size+'">';
                          return false;
                       }else{
                        size=size+5;
                        getSize();
                       }
                       }
                      //  if(qyrwl==0){
                    	 // swiperHtml+= '<div class="Big-icon yIcon0">';
                      //  }else if(qyrwl<5){
                      //    swiperHtml+= '<div class="Big-icon yIcon5">';
                      //  }else if(qyrwl<10){
                      //   swiperHtml+= '<div class="Big-icon yIcon10">';
                      //  }else if(qyrwl<15){
                      //   swiperHtml+= '<div class="Big-icon yIcon15">';
                      //  }else if(qyrwl<20){
                      //   swiperHtml+= '<div class="Big-icon yIcon20">';
                      //  }else if(qyrwl<25){
                      //   swiperHtml+= '<div class="Big-icon yIcon25">';
                      //  }else if(qyrwl<30){
                      //   swiperHtml+= '<div class="Big-icon yIcon30">';
                      //  }else if(qyrwl<35){
                      //   swiperHtml+= '<div class="Big-icon yIcon35">';
                      //  }else if(qyrwl<40){
                      //   swiperHtml+= '<div class="Big-icon yIcon40">';
                      //  }else if(qyrwl<45){
                      //   swiperHtml+= '<div class="Big-icon yIcon45">';
                      //  }else if(qyrwl<50){
                      //   swiperHtml+= '<div class="Big-icon yIcon50">';
                      //  }else if(qyrwl<55){
                      //   swiperHtml+= '<div class="Big-icon yIcon55">';
                      //  }else if(qyrwl<60){
                      //   swiperHtml+= '<div class="Big-icon yIcon60">';
                      //  }else if(qyrwl<65){
                      //   swiperHtml+= '<div class="Big-icon yIcon65">';
                      //  }else if(qyrwl<70){
                      //   swiperHtml+= '<div class="Big-icon yIcon70">';
                      //  }else if(qyrwl<75){
                      //   swiperHtml+= '<div class="Big-icon yIcon75">';
                      //  }else if(qyrwl<80){
                      //   swiperHtml+= '<div class="Big-icon yIcon80">';
                      //  }else if(qyrwl<85){
                      //   swiperHtml+= '<div class="Big-icon yIcon85">';
                      //  }else if(qyrwl<90){
                      //   swiperHtml+= '<div class="Big-icon yIcon90">';
                      //  }else if(qyrwl<95){
                      //   swiperHtml+= '<div class="Big-icon yIcon95">';
                      //  }else if(qyrwl<100){
                      //   swiperHtml+= '<div class="Big-icon yIcon100">';
                      //  }
                      var size2=0;
                      getSize2();
                      function getSize2(){
                        if(qybbl<=size2){
                          swiperHtml+='<div class="Small-icon bIcon'+size2+'">';
                          return false;
                       }else{
                        size2=size2+5;
                        getSize2();
                       }
                       }
                       // if(qybbl==0){
                    	  // swiperHtml+='<div class="Small-icon bIcon0">';
                       // }else if(qybbl<5){
                       //    swiperHtml+='<div class="Small-icon bIcon5">';
                       // }else if(qybbl<10){
                       //  swiperHtml+='<div class="Small-icon bIcon10">';
                       // }else if(qybbl<15){
                       //  swiperHtml+='<div class="Small-icon bIcon15">';
                       // }else if(qybbl<20){
                       //  swiperHtml+='<div class="Small-icon bIcon20">';
                       // }else if(qybbl<25){
                       //  swiperHtml+='<div class="Small-icon bIcon25">';
                       // }else if(qybbl<30){
                       //  swiperHtml+='<div class="Small-icon bIcon30">';
                       // }else if(qybbl<35){
                       //  swiperHtml+='<div class="Small-icon bIcon35">';
                       // }else if(qybbl<40){
                       //  swiperHtml+='<div class="Small-icon bIcon40">';
                       // }else if(qybbl<45){
                       //  swiperHtml+='<div class="Small-icon bIcon45">';
                       // }else if(qybbl<50){
                       //  swiperHtml+='<div class="Small-icon bIcon50">';
                       // }else if(qybbl<55){
                       //  swiperHtml+='<div class="Small-icon bIcon55">';
                       // }else if(qybbl<60){
                       //  swiperHtml+='<div class="Small-icon bIcon60">';
                       // }else if(qybbl<75){
                       //  swiperHtml+='<div class="Small-icon bIcon75">';
                       // }else if(qybbl<80){
                       //  swiperHtml+='<div class="Small-icon bIcon80">';
                       // }else if(qybbl<85){
                       //  swiperHtml+='<div class="Small-icon bIcon85">';
                       // }else if(qybbl<90){
                       //  swiperHtml+='<div class="Small-icon bIcon90">';
                       // }else if(qybbl<95){
                       //  swiperHtml+='<div class="Small-icon bIcon95">';
                       // }else if(qybbl<100){
                       //  swiperHtml+='<div class="Small-icon bIcon100">';
                       // }

                          swiperHtml+='<i class="jgname">'+data.param[i].jgsname+'</i>'+
                          '<i class="jgZs">'+data.param[i].qyrws+'</i>'+
                          '<i style="display:none" class="tqyrwl">'+data.param[i].qyrwl+'</i>'+
                          '<i style="display:none" class="tqybbl">'+data.param[i].qybbl+'</i>'+
                          '<i style="display:none" class="deptid">'+data.param[i].code+'</i>'+
                      '</div>'+
                  '</div>'+
              '</div>'+
            '</div>';
                });
            }
          }else{
            $("#hideMain").hide();
          }
var clientW=$("body").width();
if(clientW<1700){
  $(".swiper-container").append(swiperHtml);
  var mySwiper = new Swiper('.swiper-container',{
    slidesPerView: 7,
    slidesPerGroup : 7,
    // autoplay : 1000,

  onInit: function(swiper){
        swiper.swipeNext();

      }
  })
    console.log($(".swiper-wrapper .swiper-slide").length)
  if($(".swiper-wrapper .swiper-slide").length<=7){
    $("#beforeBtn").hide();
    $("#nextBtn").hide();
  }
}else{
  $(".swiper-container").append(swiperHtml);
  var mySwiper = new Swiper('.swiper-container',{
    slidesPerView: 9,
    slidesPerGroup : 9,
    // autoplay : 1000,

  onInit: function(swiper){
        swiper.swipeNext();

      }
  })
  console.log($(".swiper-wrapper .swiper-slide").length)
  if($(".swiper-wrapper .swiper-slide").length<=9){
    $("#beforeBtn").hide();
    $("#nextBtn").hide();
  }
}

getSize();
    // 中间swiper插件
$('#beforeBtn').click(function(){
mySwiper.swipePrev();
getClick();

})
$('#nextBtn').click(function(){
mySwiper.swipeNext();
getClick();
})
function getClick(){
  var first=$(".swiper-wrapper .swiper-slide:first");
  var last=$(".swiper-wrapper .swiper-slide:last");
  if(first.hasClass('swiper-slide-visible')){
    $("#beforeBtn img").attr('src', '../style/image/centerL1.png');
  }else{
    $("#beforeBtn img").attr('src', '../style/image/centerL.png');
  }
  if(last.hasClass('swiper-slide-visible')){
    console.log($("#nextBtn img"))
$("#nextBtn img").attr('src', '../style/image/centerR1.png');
  }else{
$("#nextBtn img").attr('src', '../style/image/centerR.png');
  }
}
        }else if(data.status==1){
           $("#hideMain").hide();
        }else if(data.status == 9) {
            window.location.href="index.html?loginOut=true";
        } else {
           layer.closeAll();
           layer.msg(data.info);
        }
}
}
$('.sliderCenter').append('<DIV class="hoverTips" style="BORDER-TOP: #333 0px solid; BORDER-RIGHT: #333 0px solid; WHITE-SPACE: nowrap; text-align:left;BORDER-BOTTOM: #333 0px solid; POSITION: absolute; COLOR: #fff; PADDING-BOTTOM: 5px; PADDING-TOP: 5px; FONT: 14px/21px Microsoft YaHei; PADDING-LEFT: 5px; LEFT: 278px; FILTER: background: rgb(0, 0, 0); BORDER-LEFT: #333 0px solid; Z-INDEX: 9999999; DISPLAY: none; TOP: 91px; PADDING-RIGHT: 5px; BACKGROUND-COLOR: #323232; background-color: rgba(50, 50, 50, 0.7);-webkit-transition: left 0.4s cubic-bezier(0.23, 1, 0.32, 1), top 0.4s cubic-bezier(0.23, 1, 0.32, 1); -moz-transition: left 0.4s cubic-bezier(0.23, 1, 0.32, 1), top 0.4s cubic-bezier(0.23, 1, 0.32, 1); -o-transition: left 0.4s cubic-bezier(0.23, 1, 0.32, 1), top 0.4s cubic-bezier(0.23, 1, 0.32, 1); transition: left 0.4s cubic-bezier(0.23, 1, 0.32, 1), top 0.4s cubic-bezier(0.23, 1, 0.32, 1); border-radius: 4px" ><i id="tname"></i><BR>入网企业:<i id="sumT"></i><BR>入网率: <i id="trwl">0</i><BR>报备率: <i id="tbbl"></i></DIV>');
$('body').on('mouseover', '.Small-icon', function(ev) {
      var oEvent=ev||event;
      var oDiv=$(this);
      var srollTop=$(document).scrollTop();
      var left=oEvent.clientX-400+'px';
      var top=oEvent.clientY-500+srollTop+'px';
      // var left=$(this).offset().left-279+'px';
      console.log('offsetX:'+oEvent.offsetX)
      console.log($(this).offset().left)
    $('.sliderCenter').find('.hoverTips').css({
        left: left,
        top: top
    });
    $('.sliderCenter').find('.hoverTips').css('display', 'block');
    var tname=$(this).find('.jgname').text();
    var jgZs=$(this).find('.jgZs').text();
    var tqyrwlc=$(this).find('.tqyrwl').text();
    var tqybbl=$(this).find('.tqybbl').text();
    $('.sliderCenter .hoverTips #tname').text(tname)
    $('.sliderCenter .hoverTips #trwl').text(tqyrwlc)
    $('.sliderCenter .hoverTips #tbbl').text(tqybbl)
    $('.sliderCenter .hoverTips #sumT').text(jgZs)
});
$('body').on('click', '.Small-icon', function(ev) {
var id=$(this).find('.deptid').text();
  window.open('netStatistics.html?de_id='+id,'_self');
});
$('body').on('mouseleave', '.Small-icon', function(ev) {
  $(".sliderCenter").find('.hoverTips').hide();
});
//点击查询跳转到搜索页
$("#Search").click(function() {
  if($(".inputB").val() == "") {
    var p = $(".inputB").val();
    window.location.href = 'SearchResults.html?p=' + escape(p);
  } else {
    var p = $(".inputB").val();
    window.location.href = 'SearchResults.html?p=' + escape(p);
  }
})
// enter事件
$(".inputB").keydown(function(e){
    var e=window.event || e;
     var k = e.keyCode || e.which;
 if(k==13){
  $("#Search").click();
}
})
getNumInfo();
function getNumInfo(){
for(var i=0;i<8;i++){
  var wxjson = new webjson("41");
  wxjson.AddParam("type", i);
  wxjson.AddParam("count", i);
  var res=WebRequest(wxjson);
  var data = GetOjson(json_parse(res));
  console.log(data.paramcentcount)
  if(data.paramcentcount==0){
  $(".triIcon").eq(i).find('.warning').hide();
  }else if(data.paramcentcount>99){
  $(".triIcon").eq(i).find('.warning').text("99+");
}else{
  $(".triIcon").eq(i).find('.warning').text(data.paramcentcount);
}
}
}

function rwhref(){
  $(".topLeft .total .data").on('click', 'p', function(event) {
    var neTitle=$.cookie('dept_name');
    var liTitle=$(this).find('i').eq(0).text();
    var zone_code=$.cookie('dep_code');
    var qyType="";
    var countWay=0;

   var FLAG;
   if(liTitle=="昨日新增"){
    FLAG="add";
   }else if(liTitle=="入网企业"){
    FLAG="alreadynet";
   }
   var sum=$(this).find('i').eq(1).text();
      var today=new Date();
       var Month=+today.getMonth()+1;
       var Datet=today.getDate();
       if(Month<10){
        Month='0'+Month;
       }
       if(Datet<10){
         Datet='0'+Datet;
       }
       var time=today.getFullYear()+'-'+Month+'-'+Datet;
  var objSting={"neTitle":neTitle,"liTitle":liTitle,"zone_code":zone_code,"qyType":qyType,"countWay":countWay,"time":time,"flag":FLAG,"sum":sum};
  objSting=JSON.stringify(objSting);
  if(sum!="0" && FLAG){
    window.open('look_company.html?objSting='+escape(objSting),'_self')
  }
  });
}
function bbhref(){
  console.log($(".topRight .total .data"))
  $(".topRight .total .data").on('click', 'p', function(event) {
    var neTitle=$.cookie('dept_name');
    var FLAG=$(this).find('i').eq(0).text();
    var sum=$(this).find('i').eq(2).text();
    var zone_code=$.cookie('departmentid');
    var qyType=-1;
   var today=new Date();
   var FLAG;


   var time=$(".topRight .centerText").text().split('年')[0]+'-'+$(".topRight .centerText").text().split('年')[1].split('月')[0];
    var chuanzf={'jgj':zone_code,'time':time,'qylx':qyType,'jgj_name':neTitle}
       chuanzf=JSON.stringify(chuanzf);
       if(sum!="0" && FLAG!="报备总量" ){
            window.open('look_company.html?chuanzf='+escape(chuanzf)+'&lx='+escape(FLAG),'_self')
       }
  });
}
function centerClick(){
  console.log($(".topContent .iconContent"))
  $(".topContent .iconContent").on('click', 'p', function(event) {
 var qyType=0;
 var qyTypeText=$.trim($(this).closest('.background').find('.showType').text());
 if(qyTypeText=="生产企业"){
     qyType=0;
 }else if(qyTypeText=="销售经营企业"){
     qyType=1;
 }else if(qyTypeText=="餐饮企业"){
     qyType=2;
 }else if(qyTypeText=="单位食堂"){
     qyType=3;
 }
 var sum=$(this).find('i').eq(1).text();

 var text=$(this).find('i').eq(0).text();
 if(sum!=0 && text=="入网率"){
 window.open('netStatistics.html?qyType='+qyType,'_self');
 }else if(sum!=0 && text=="报备率"){
window.open('ReportedCompany.html?qyType='+qyType,'_self');
 }else if(sum!=0 && text=="入网企业"){
    var neTitle=$.cookie('dept_name');
    // var liTitle=$(this).find('i').eq(0).text();
    var zone_code=$.cookie('dep_code');
    // var qyType="";
    var countWay=0;

   var FLAG;
   if(text=="昨日新增"){
    FLAG="add";
   }else if(text=="入网企业"){
    FLAG="alreadynet";
   }
   // var sum=$(this).find('i').eq(1).text();
      var today=new Date();
       var Month=+today.getMonth()+1;
       var Datet=today.getDate();
       if(Month<10){
        Month='0'+Month;
       }
       if(Datet<10){
         Datet='0'+Datet;
       }
       var time=today.getFullYear()+'-'+Month+'-'+Datet;
  var objSting={"neTitle":neTitle,"liTitle":text,"zone_code":zone_code,"qyType":qyType,"countWay":countWay,"time":time,"flag":FLAG,"sum":sum};
  objSting=JSON.stringify(objSting);
  if(sum!="0" && FLAG){
    window.open('look_company.html?objSting='+escape(objSting),'_self')
  }
 }
  });
}
function bigHref(){
  $("#all_rwl").click(function(event) {
    window.open("netStatistics.html",'_self');
  });
   $("#all_bbl").click(function(event) {
    window.open("ReportedCompany.html",'_self');
  });
}