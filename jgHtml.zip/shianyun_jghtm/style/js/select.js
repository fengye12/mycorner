//select下拉框
jQuery.divselect = function(divselectid,inputselectid) {
	var inputselect = $(inputselectid);
	var spanL=$(divselectid).width()-36;
	var ulL=$(divselectid).width()+2;
	$(divselectid+" span").width(spanL);
	$(divselectid+" ul").width(ulL).css("display","none");

	$(divselectid+" span").click(function(event){
		var event=event || window.event;
		event.stopPropagation();
		var offsetBottom=document.documentElement.clientHeight + $(document).scrollTop() - $(divselectid).offset().top-$(this).height();
		
		var ul = $(divselectid+" ul");
		if(offsetBottom < ul.height()){
			ul.css({"position":"absolute","left":"0","top":-ul.height()})
		}
		if(ul.css("display")=="none"){
			// alert(ul.html());
			$(".divselect ul").slideUp("fast");
			ul.slideDown("fast");

		}else{
			ul.slideUp("fast");
		}
	});
	$(divselectid+" ul li a").click(function(){
		var txt = $(this).text();
		$(divselectid+" span").html(txt);
		var value = $(this).attr("selectid");
		inputselect.val(value);
		$(divselectid+" ul").hide();
		
	});
	$(document).click(function(){
		$(divselectid+" ul").hide();
	});
};