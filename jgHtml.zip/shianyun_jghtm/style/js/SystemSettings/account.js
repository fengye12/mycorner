var userid=$.cookie("user_id");//用户id
var user_type=$.cookie('user_type')//用户类型
var layer1;//用于关闭弹窗
var ecount = 20;//一页数据条数
var cpage = new CentPage();//初始化分页
var pagenum = 1;//第几页
var paramcentcount=0;//总数据条数
var nowdeptid=" ";
 var sskey0="",ssmode0=1,sssel0=0,departmentid=$.cookie("departmentid"),usertype0="";//sskey0:按照组名 、描述搜索，此值可以为空;ssmode:0：精确搜索，1：模糊搜索;sssel0:0：所有类型，1：组名，2：描述;groupid0:用户组id
var PageISLock = 0;//界面搜索锁
var a1="a15",a2="a1500";//用于navLeft，当前导航

$(function(){
getActiveN("a15","a1500");
sskey0=$("#search .foodName").val();
if(sskey0=="执法证号/姓名/手机号/办公电话"){
    sskey0=""
}
 ssmode0= $("#ssmode ").val();
 sssel0= $("#sssel ").val();
 getUserList(sskey0,ssmode0,sssel0,departmentid,usertype0,pagenum,ecount)
})

//enter事件
$(".foodName").keydown(function(event){
 if(event.keyCode==13){
	$("#Search").click();
}
})
// ### 查看详细
$('#userList').on('click', '.watch', function(event) {
  var suserid=$(this).find('.userid').text();
  // var isHistoryApi = !!(window.history && history.pushState);
  // if(isHistoryApi){
  // var newURL = "?keyValue=" + escape($("#search .foodName").val());
  // history.pushState(null, "", newURL);
  // window.open("sys_accountDetail.html?userid="+suserid,'_self')
  // }else{
 window.open("sys_accountDetail.html?userid="+suserid,'_blank')
  // }

});

// 停用/启用
$('#userList').on('click', '.stop', function(event) {
  var opmode,title,userids;
  var userids=$(this).find(".userid").text();
  if($(this).text().indexOf("停用")>-1){
    title="确定要停用该账号吗？"
  }else{
      title="确定要启用该账号吗？"
  }
 layer1=layer.confirm(title, {
  title:'提示',
    btn: ['确定','取消'],
    scrollbar:false,
    shadeClose:true,
  }, function(){
          var wxjson = new webjson("16");
          wxjson.AddParam("userids", userids);//用户id组合
          wxjson.AddParam("opmode", 'stoporuse');//操作模式：删除
          wxjson.AddParam("values", "");//只有操作模式为setgroup时值为用户组id
          WebRequestAsync(wxjson, sc);
          function sc(res){
              var data = GetOjson(json_parse(res));
              console.log(data);
              if(data.status == 0){

                layer.close(layer1);
               layer.msg(data.info);
              getUserList(sskey0,ssmode0,sssel0,departmentid,usertype0,pagenum,ecount)
          }else if(data.status == 9){//超时重新登录
            window.location.href="index.html?loginOut=true";
            return;
        }else{
         layer.close(layer1)
         layer.msg(data.info);
     }
    }
  }
)
});

// 删除
$('#userList').on('click', '.delete', function(event) {
  var userids=$(this).find('.userid').text();
   layer1=layer.confirm('确定删除该账号吗？', {
    title:'提示',
      btn: ['确定','取消'],
      scrollbar:false,
      shadeClose:true,
    }, function(){
            var wxjson = new webjson("16");
            wxjson.AddParam("userids", userids);//用户id组合
            wxjson.AddParam("opmode", "del");//操作模式：删除
            wxjson.AddParam("values", "");//只有操作模式为setgroup时值为用户组id
            WebRequestAsync(wxjson, sc);
            function sc(res){
                var data = GetOjson(json_parse(res));
                console.log(data);
                if(data.status == 0){
                  layer.close(layer1);
                 layer.msg('删除成功');
                getUserList(sskey0,ssmode0,sssel0,departmentid,usertype0,pagenum,ecount)
            }else if(data.status == 9){//超时重新登录
              window.location.href="index.html?loginOut=true";
              return;
          }else{
           layer.close(layer1)
           layer.msg(data.info);
       }
      }
    }
  )
});

 /**分页设置**/
function CentPageOper(pnum){
    cents = cpage.GetCentPage(pnum,paramcentcount,ecount);
    $("#page").html(cents);
    pagenum=pnum;
    getUserList(sskey0,ssmode0,sssel0,departmentid,usertype0,pagenum,ecount)
}

//select/切换
// function select(){
//     ecount = $("#mySelect option:selected").val();
//     pagenum=1;
//    getUserList(sskey0,ssmode0,sssel0,departmentid,usertype0,pagenum,ecount)
// }

//搜索
$("#Search").click(function() {
sskey0=$("#search .foodName").val();
if(sskey0=="执法证号/姓名/手机号/办公电话"){
    sskey0=""
}
 pagenum=1;
 ssmode0= $("#ssmode ").val();
 sssel0= $("#sssel ").val();

 getUserList(sskey0,ssmode0,sssel0,departmentid,usertype0,pagenum,ecount)
})

//新增用户
$("body").on('click','#new_zh',function(){
  layer1=layer.open({
    type:1,
    title:'新增账号',
    area: ['570px', '600px'], //宽高
    content:'<form id="alertMessage0" class="alertMessage0 clearfix"></form><script>getDefaultGroup()</script>',
              btn: ['创建账号', '关闭'],
              scrollbar:false,
              // shadeClose:true,
              yes:function(){
                $("#newTips").html();
                 var Neworgan=$("#Neworgan").val();//所属机关
                 var Newname=$("#Newname").val();//姓名
                 var newAccount=$("#newAccount").val();//执法证号
                 var newPsw=$("#newPsw").val();//登录密码
                 var Newtype=$("#Newtype").val();//用户类型
                 // console.log(/^[\u4e00-\u9fa5]{6,20}$/.test(newAccount))
                var dutyWork=$("#dutyWork").val();//职务
                var workPhone=$("#workPhone").val();//办公电话
                var Phone=$("#Phone").val();//手机号
                var loginAccount=$("#loginAccount").val();//登录账号
                var newemail=$("#newemail").val();//邮箱
                var sel_departmentid=$("#Neworgan").val();
                    var re = /^0\d{2,3}-?\d{7,8}$/;
                    var re1 = /^(\w-*\.*)+@(\w-?)+(\.\w{2,})+$/;
                    if(Neworgan==""|| Newname==""|| newAccount==""){
                      $("#newTips").html("*为必填项");
                    }else if(workPhone!="" && !(re.test(workPhone))){
                    $("#newTips").html("请输入正确的电话号码");
                }else if(Phone!="" && (!(/^1[34578]\d{9}$/.test(Phone)))){
                  $("#newTips").html("请输入正确的手机号");
                }else if(newemail!="" && !(re1.test(newemail))){
                     $("#newTips").html("请输入正确的电子邮箱");
                }else if(!(/^[a-zA-Z0-9_]{6,20}$/.test(newPsw))){
                  $("#newTips").html("密码长度由6-20位数字/字母/下划线组成");
                }else if(newPsw=="" || Newtype==""){
                    $("#newTips").html("*为必填项");
                }else{
                   creatAccount(Neworgan,Newname,newAccount,newPsw,Newtype,dutyWork,workPhone,Phone,loginAccount,newemail,sel_departmentid);
                }

         },
     });
});

// //展示新增内容

function getDefaultGroup(){
var organList="";
var orginListL="";
var CkeckedL="";
          var wxjson = new webjson("22");
          wxjson.AddParam("departmentid",departmentid);//用户id组合
          wxjson.AddParam("nowdeptid",nowdeptid);//用户id组合
          wxjson.AddParam("flag",'yes');//用户id组合
          WebRequestAsync(wxjson, successGroup);
          function successGroup(res){
            console.log(res)
              var data = GetOjson(json_parse(res));
              console.log(data);
              if(data.status == 0){
                if(data.param.length>0){
                  for(var i=0;i<data.param.length;i++){
                    organList+='<option value="'+data.param[i].departmentid+'">'+data.param[i].department+'</option>';
                    orginListL+= '<li class="op-item" src="'+data.param[i].departmentid+'">'+data.param[i].department+'</li>';
                    CkeckedL=data.param[0].department;
                  }
                  $("#Neworgan").append(organList);
                  $("#AssselS .optionB").append(orginListL);
                  $("#AssselS .selected-item").text(CkeckedL);
                }
          }else if(data.status == 9){//超时重新登录
            window.location.href="index.html?loginOut=true";
            return;
        }else{
         layer.close(layer1)
         layer.msg(data.info);
     }
    }
  var html="";
  html='<div class="layui-form-item">'
          +'<label class="layui-form-label"><i class="nessary">*</i>所属机关</label>'
          +'<div class="layui-input-block">'
          +'<select placeholder="请选择"  class="layui-input ieselect" id="Neworgan" style="display:none">'
          +'</select>'
          +'<div class="selectedB" id="AssselS" >'+
          '<div class="sel-wrap">'+
          '<span class="selected-item">所有类型</span>'+
          '</div>'+
          '<ul class="optionB">'+
              // '<li class="op-item">所有类型</li>'+
              // '<li class="op-item">执法证号</li>'+
              // '<li class="op-item">姓名</li>'+
              // '<li class="op-item">手机号</li>'+
              // '<li class="op-item">办公室电话</li>'+
          '</ul>'+
                         '</div>'
          +'</div>'
          +'</div>'
          +'<div class="clearfix">'
          +'<div class="double">'
          +'<div class="layui-form-item">'
          +'<label class="layui-form-label"><i class="nessary">*</i>姓名</label>'
          +'<div class="layui-input-block">'
          +'<input type="text" name="" placeholder="请输入" autocomplete="off" class="layui-input" id="Newname">'
          +'</div>'
          +'</div>'
          +'</div>'
           +'<div  class="double">'
          +'<div class="layui-form-item">'
          +'<label class="layui-form-label"><i class="nessary">*</i>执法证号</label>'
          +'<div class="layui-input-block">'
          +'<input type="text" name="" placeholder="请输入" autocomplete="off" class="layui-input" id="newAccount" maxlength="50">'
          +'</div>'
          +'</div>'
          +'</div>'
          +'</div>'
          +'<div class="layui-form-item">'
          +'<label class="layui-form-label">职务</label>'
          +'<div class="layui-input-block">'
          +'<input type="text" name="" placeholder="请输入" autocomplete="off" class="layui-input" id="dutyWork" maxlength="50">'
          +'</div>'
          +'</div>'
          +'<div class="clearfix">'
          +'<div class="double">'
          +'<div class="layui-form-item">'
          +'<label class="layui-form-label">办公电话</label>'
          +'<div class="layui-input-block">'
          +'<input type="text" name="" placeholder="请输入" autocomplete="off" class="layui-input" id="workPhone">'
          +'</div>'
          +'</div>'
          +'</div>'
          +'<div class="double">'
          +'<div class="layui-form-item">'
          +'<label class="layui-form-label">手机号</label>'
          +'<div class="layui-input-block">'
          +'<input type="text" name="" placeholder="请输入" autocomplete="off" class="layui-input"  id="Phone">'
          +'</div>'
          +'</div>'
          +'</div>'
          +'</div>'
          +'<div class="layui-form-item">'
          +'<label class="layui-form-label">邮箱</label>'
          +'<div class="layui-input-block">'
          +'<input type="text" name="" placeholder="请输入" autocomplete="off" class="layui-input" id="newemail" maxlength="50">'
          +'</div>'
          +'</div>'
          +'<div class="line">'
          +'<div class="layui-form-item">'
          +'<label class="layui-form-label">登陆账号</label>'
          +'<div class="layui-input-block">'
          +'<input type="text" name="" placeholder="执法证号 或 手机号" autocomplete="off" class="layui-input"  id="loginAccount" readonly  maxlength="50">'
          +'</div>'
          +'</div>'
          +'<div class="layui-form-item">'
          +'<label class="layui-form-label"><i class="nessary">*</i>登陆密码</label>'
          +'<div class="layui-input-block">'
          +'<input type="password" name="" placeholder="请输入" autocomplete="off" class="layui-input" id="newPsw" maxlength="50">'
          +'</div>'
          +'</div>'
          +'<div class="layui-form-item">'
          +'<label class="layui-form-label"><i class="nessary">*</i>用户类型</label>'
          +'<div class="layui-input-block">'
          +'<select  placeholder="请输入"  class="layui-input ieselect" id="Newtype" style="display:none">'
          +'<option value="0">管理员</option>'
          +'<option value="1">普通用户</option>'
          +'</select>'
          +'<div class="selectedB" id="AssmodeS" >'+
          '<div class="sel-wrap" style="height:38px">'+
          '<span class="selected-item" style="height:36px">管理员</span>'+
          '</div>'+
          '<ul class="optionB" style="top:38px">'+
              '<li class="op-item" src="0">管理员</li>'+
              '<li class="op-item" src="1">普通用户</li>'+
          '</ul>'+
                         '</div>'
          +'</div>'
          +'</div>'
          +'</div>'
          +'<p id="newTips"style="text-align:center;color:red;"></p>'
           $("#alertMessage0").append(html);
           // $("#Neworgan").append(organList);
           // $("#AssselS .optionB").append(orginListL);

           //模拟select
             $(".selectedB").on('click', '.sel-wrap', function(event) {
               if($(this).is(":hover")){
                 console.log($(".selectedB .optionB").not($(this).next('.optionB')))
                 $(".selectedB .optionB").not($(this).next('.optionB')).hide(20);
                 $(this).next('.optionB').slideToggle(20);
               }
              return false;
            });

             $("#AssselS").on('click', '.op-item', function(event) {
               $(this).closest('.selectedB').find('.selected-item').text($(this).text());
               console.log($(this).attr('src'));
                $("#Neworgan").val($(this).attr('src'))
               $(this).closest('.optionB').slideUp(20);
             });
              $("#AssmodeS").on('click', '.op-item', function(event) {
                $(this).closest('.selectedB').find('.selected-item').text($(this).text());
               $("#Newtype").val($(this).attr('src'))
                $(this).closest('.optionB').slideUp(20);
              });


            document.onclick = function(){
              $(".optionB").hide();
            };
}

//新建账号
function creatAccount(Neworgan,Newname,newAccount,newPsw,Newtype,dutyWork,workPhone,Phone,loginAccount,newemail,sdepartmentid){
  var wxjson = new webjson("15"); //设置action值
  //新增param键值
  wxjson.AddParam("userid","");
  wxjson.AddParam("departmentid",sdepartmentid);
  wxjson.AddParam("username",newAccount);
  wxjson.AddParam("realname", Newname);
  wxjson.AddParam("pwd", newPsw);
  wxjson.AddParam("usertype", Newtype);
  wxjson.AddParam("phonenum", Phone);
  wxjson.AddParam("telnum", workPhone);
  wxjson.AddParam("duties", dutyWork);
  wxjson.AddParam("email", newemail);
  var res=WebRequestAsync(wxjson,successgetsave);
  function successgetsave(res){
     var data = GetOjson(json_parse(res));
      if(data.status == 0){
               layer.close(layer1);
               layer.msg('保存成功');
               getUserList(sskey0,ssmode0,sssel0,departmentid,usertype0,pagenum,ecount)
          }else if(data.status == 9){//超时重新登录
            window.location.href="index.html?loginOut=true";
            return;
        }else{
         // layer.close(layer1)
         layer.msg(data.info);
     }
  }
}

//读取用户列表
function getUserList(sskey,ssmode,sssel,departmentid,usertype,page_index,page_size){
    if(PageISLock == 1) {
        return;
    }
    PageISLock = 1;
    $("#userList").empty();
    $("#userList").append("<tr class='loading'><td colspan='11' style='padding:20px 0; text-align:center'><img src='../style/image/load.gif' width='32px' height='32px' /></td></tr>");
        var wxjson = new webjson("13"); //设置action值
        //新增param键值
        wxjson.AddParam("sskey",sskey);
        wxjson.AddParam("ssmode", ssmode);
        wxjson.AddParam("sssel", sssel);
        wxjson.AddParam("userid", userid);
        wxjson.AddParam("departmentid", departmentid);
        wxjson.AddParam("usertype", usertype);
        wxjson.AddParam("page_index", page_index);
        wxjson.AddParam("page_size", page_size);
        var res=WebRequestAsync(wxjson,successgetUserList);
          function successgetUserList(res){
               PageISLock = 0;
           var data = GetOjson(json_parse(res));
           $("#page").empty();
           $("#mySelectS").hide();
            $('#gl').empty();

           paramcentcount=data.paramcentcount;
           if(data.status==0){
              $("#userList").empty();

            var data = GetOjson(json_parse(res));
            console.log(data)
            var html="";

            if(data.param.length>0){
              // autoH();

              var cents = cpage.GetCentPage(pagenum,paramcentcount,ecount);
              $("#page").html(cents);
                for(var i=0;i<data.param.length;i++){
                  var cstatus=data.param[i].cstatus;
                  var textStatus;
                  if(cstatus==0){
                    textStatus="启用"
                  }else if(cstatus==1){
                    textStatus="停用"
                  }
                    html+='<tr  class="hs"><td  width="10%">'
                    +'<span  class="modify watch">查看<i class="userid">'+data.param[i].userid+'</i></span>'
                    if(user_type==0){
                      html+='|<span class="modify stop">'+textStatus+'<i class="userid">'+data.param[i].userid+'</i></span>'
                    +'<span class="modify delete" style="display:none;">删除<i class="userid">'+data.param[i].userid+'</i></span>'
                    }

                    html+='</td><td width="10%">'+data.param[i].realname+'</td>'
                    +'<td  class="max-width" width="10%">'+data.param[i].username+'</td>'
                    +'<td width="10%">'+data.param[i].department+'</td>'
                    +'<td  width="10%">'+data.param[i].duties+'</td>'
                    +'<td width="10%">'+data.param[i].telnum+'</td>'
                    +'<td   width="10%">'+data.param[i].phonenum+'</td>'
                    +'<td  width="10%">'+data.param[i].email+'</td>';
                    if(data.param[i].usertype==0){
                      html+='<td cwidth="10%">管理员</td>'
                    }else{
                      html+='<td width="10%">普通用户</td>'
                    }

                   html+='</tr>';
                }
            }
            $("#userList").append(html);
            if(user_type==0){
              $('#gl').empty();
              $('#gl').append('<span id="new_zh">新增账号</span>');
            }
            $("#mySelectS").show();
            autoH();
        }else if(data.status==1){
          if(user_type==0){
            $('#gl').empty();
            $('#gl').append('<span id="new_zh">新增账号</span>');
          }
            $("#userList").empty();
            $("#userList").append("<tr class='loading'><td colspan='11' style='padding:20px 0;text-align:center'>没有查到相关数据</td></tr>");
        }else if(data.status == 9){
              window.location.href="index.html?loginOut=true";
              return;
          }else{
            // $('#new_zh').remove();
          $("#userList").empty();
          layer.msg(data.info)
        }

        }
    }
    $("body").on('blur', '#newAccount', function(event) {
      var phone=$('body #Phone').val();
      if(phone){
        $('body #loginAccount').val("");
          var text=$(this).val();
          if(text){
            $('body #loginAccount').val(text+' 或 '+phone)
          }else{
            $('body #loginAccount').val(phone)
          }

      }else{
         var text=$(this).val();
       $('body #loginAccount').val(text)
      }

    });
    $("body").on('blur', '#Phone', function(event) {
      var zhifa=$("body #newAccount").val();
      var text=$(this).val();
      if(text){
         if(zhifa){
           $('body #loginAccount').val(zhifa+' 或 '+text)
         }else{
          $('body #loginAccount').val(text)
         }
       }else{
         $('body #loginAccount').val(zhifa)
       }




    });
