// var lowerUrl="http://192.168.2.110:8097/request/belongtreeaction?code=";
// var areaUrl="http://192.168.2.110:8097/request/treeaction?deptid=";
var departmentid=$.cookie("departmentid");//当前机关id
var user_type=$.cookie('user_type')//用户类型
var layer1;//用于关闭弹窗
var ecount = 20;//一页数据条数
var cpage = new CentPage();//初始化分页
var pagenum = 1;//第几页
var paramcentcount=0;//总数据条数
 var sskey0="",ssmode0=1,sssel0=0;//sskey0:按照组名 、描述搜索，此值可以为空;ssmode:0：精确搜索，1：模糊搜索;sssel0:0：所有类型，1：组名，2：描述;groupid0:用户组id
var PageISLock = 0;//界面搜索锁
var selectedArea="";//行政区域
var selectedId="";//行政区域id
var selectedPId="";//行政区域id
var selectedLowerArea="";//下辖区域
var selectedlowerId="";//下辖区域id
var showArea="";//下辖区域显示文字
var a1="a15",a2="a1501";//用于navLeft，当前导航
$(function(){
getActiveN("a15","a1501");

  //模拟select
    $(".selectedB").on('click', '.sel-wrap', function(event) {
      var listH=$("#mySelectS").find(".optionB").height();
      if($(this).is(":hover")){
        console.log($(".selectedB .optionB").not($(this).next('.optionB')))
        $(".selectedB .optionB").not($(this).next('.optionB')).hide(20);
        $(this).next('.optionB').slideToggle(20);
      }
      if($(this).next(".selectedB").find(".optionB").css("display") != "none"){
        var offsetBottom=document.documentElement.clientHeight + $(document).scrollTop() - $(this).offset().top-$(this).height();
        if(offsetBottom < listH){
          console.log($(this).height())
          $("#mySelectS").find(".optionB").css({"left":"0","top":-listH})
        }
      }
      return false;
    });

    $("#ssselS").on('click', '.op-item', function(event) {
      $(this).closest('.selectedB').find('.selected-item').text($(this).text());
      if($(this).text()=="所有类型"){
       $("#sssel").val(0)
      }else if($(this).text()=="机关编号"){
        $("#sssel").val(1)
      }else if($(this).text()=="机关名称"){
        $("#sssel").val(2)
      }
      $(this).closest('.optionB').slideUp(20);
    });
     $("#ssmodeS").on('click', '.op-item', function(event) {
       $(this).closest('.selectedB').find('.selected-item').text($(this).text());
       if($(this).text()=="模糊查询"){
        $("#ssmode").val(1)
       }else if($(this).text()=="精准查询"){
         $("#ssmode").val(0)
       }
       $(this).closest('.optionB').slideUp(20);
     });

    var selectText="20条/页";
    $("#mySelectS").on('click', '.op-item', function(event) {
      $("#mySelectS").find('.selected-item').text($(this).text());
      if(selectText != $(this).text()){
        pagenum=1;
        selectText=$(this).text();
        if($(this).text()=="10条/页"){
          ecount=10;
        }else if($(this).text()=="20条/页"){
          ecount=20;
        }else if($(this).text()=="30条/页"){
          ecount=30;
        }else if($(this).text()=="40条/页"){
          ecount=40;
        }else if($(this).text()=="50条/页"){
          ecount=50;
        }else{
        }
        getUserList(sskey0,ssmode0,sssel0,pagenum,ecount)
      }

      $(this).closest('.optionB').slideUp(20);
    });

   document.onclick = function(){
     $(".optionB").hide();
   };
 // 加载机关列表
 getUserList(sskey0,ssmode0,sssel0,pagenum,ecount)
})

//enter事件
$(".foodName").keydown(function(event){
 if(event.keyCode==13){
	$("#Search").click();
}
})

 /**分页设置**/
function CentPageOper(pnum){
    cents = cpage.GetCentPage(pnum,paramcentcount,ecount);
    $("#page").html(cents);
    pagenum=pnum;
     getUserList(sskey0,ssmode0,sssel0,pagenum,ecount)

}

//select/切换
// function select(){
//     ecount = $("#mySelect option:selected").val();
//     pagenum=1;
//      getUserList(sskey0,ssmode0,sssel0,pagenum,ecount)

// }

//搜索
$("#Search").click(function() {
sskey0=$(".foodName").val();
if(sskey0=="机关编号/机关名称"){
    sskey0=""
}
 pagenum=1;
 ssmode0= $("#ssmode ").val();
 sssel0= $("#sssel ").val();

 getUserList(sskey0,ssmode0,sssel0,pagenum,ecount)

})

var edit;
var self_departmentid=" ";
//编辑用户
$("#userList").on('click', '.modify', function(event) {
  edit=$(this).text();
  self_departmentid=$(this).find("i").text();
  layer1=layer.open({
    type:1,
    title:'编辑机关信息',
    area: ['550px', '420px'], //宽高
    content:'<form id="alertMessage1" class="alertMessage1"></form><script>addhtml();</script>',
              btn: ['保存', '取消'],
              scrollbar:false,
              // shadeClose:true,
              yes:function(){
                  $("#organInfo").html("");
                 var organName=$("#organName").val();
                 var Neworgan=$("#Neworgan").val();
                 // if(!Neworgan){
                 //  Neworgan="";
                 // }
                 var organCode=$("#organCode").val();
                 var selectedA=$("#selectedA").val();
                 var lowerArea=$("#lowerArea").val();
                 if(organName==""){
                   $("#organInfo").html("请输入机关名称")
                 }else if(Neworgan==""){
                   $("#organInfo").html("请选择隶属机关")
                 }else if(organCode==""){
                   $("#organInfo").html("请输入机关编号")
                 }else if(!(/[a-zA-Z0-9-]{6,20}/.test(organCode))){
                  $("#organInfo").html("机关编号为6-20位数字或字母组成")
                 }else if(selectedA==""){
                   $("#organInfo").html("请选择行政区域")
                 }else{
                   saveOrganINfo(self_departmentid,organCode,organName,Neworgan,selectedId,selectedlowerId);
                 }
         },
     });
});
//新增用户
$("body").on('click','#new_zh',function(){
  edit="";
  self_departmentid=" ";
  selectedArea="";//行政区域
  selectedId="";
  selectedLowerArea="";
  selectedlowerId="";
  layer1=layer.open({
    type:1,
    title:'新增机关',
    area: ['550px', '420px'], //宽高
    content:'<form id="alertMessage1" class="alertMessage1"></form><script>addhtml();</script>',
              btn: ['保存', '取消'],
              scrollbar:false,
              shadeClose:true,
              yes:function(){
                 $("#organInfo").html();
                var organName=$("#organName").val();
                var Neworgan=$("#Neworgan").val();
                var organCode=$("#organCode").val();
                var selectedA=$("#selectedA").val();
                var lowerArea=$("#lowerArea").val();
                if(organName==""){
                  $("#organInfo").html("请输入机关名称")
                }else if(Neworgan==""){
                  $("#organInfo").html("请选择隶属机关")
                }else if(organCode==""){
                  $("#organInfo").html("请输入机关编号")
                }else if(!(/[a-zA-Z0-9-]{6,20}/.test(organCode))){
                  $("#organInfo").html("机关编号为6-20位数字或字母组成")
                 }else if(selectedA==""){
                  $("#organInfo").html("请选择行政区域")
                }else{
                  saveOrganINfo("",organCode,organName,Neworgan,selectedId,selectedlowerId);
                }
         },
     });
});

function saveOrganINfo(self_departmentid,organCode,organName,Neworgan,selectedId,selectedlowerId){
  var wxjson = new webjson("25"); //设置action值
  //新增param键值
  wxjson.AddParam("departmentid",self_departmentid);
  wxjson.AddParam("departmentbh",organCode);
  wxjson.AddParam("dept_listname",showArea);

  wxjson.AddParam("department", organName);
  wxjson.AddParam("pdepartmentid", Neworgan);
  wxjson.AddParam("areaid", selectedId);
  wxjson.AddParam("subareasids", selectedlowerId);

  WebRequestAsync(wxjson,successgetsave);
  function successgetsave(res){
     var data = GetOjson(json_parse(res));
      if(data.status == 0){
        layer.closeAll();
               layer.msg('保存成功');
             getUserList(sskey0,ssmode0,sssel0,pagenum,ecount)
          }else if(data.status == 9){//超时重新登录
            window.location.href="index.html?loginOut=true";
            return;
        }else{
         // layer.close(layer1)
         layer.msg(data.info);
     }
  }
}

// 选择行政区域
$("body").on('click', '#selectedA', function(event) {
  layer1=layer.open({
    type:1,
    title:'行政区域',
    area: ['550px', '550px'], //宽高
    content:'<form class="alertMessage1" id="alertM"><div class="searchBox"><div class="layui-form-item"><label class="layui-form-label">行政区域</label><div class="layui-input-block"><input type="text" name="" placeholder="请输入关键字进行查询" id="search_condition" autocomplete="off" class="layui-input"></div></div><span class="search" id="searchG" onclick="search_ztree()">查询</span></div></form><div id="organInfo"></div><script>initG()</script>',
              btn: ['保存', '取消'],
              scrollbar:false,
              // shadeClose:true,
              yes:function(){
                  var treeObj = $.fn.zTree.getZTreeObj("dep_tree");
                  var selects=treeObj.getCheckedNodes();

                  if(selects.length==0){
                     layer.msg('请先选择行政区域',{time: 2000 });
                  }else{
                     var level=+selects[0].level+1;
                    selectedArea=selects[0].name;
                    selectedId=selects[0].id;
                    selectedPId=selects[0].pId;
                     selectedLowerArea="";//下辖区域
                    selectedlowerId="";//下辖区域id
                    showArea="";

                    $("#lowerArea").val("")
                    $("#selectedA").val(selectedArea)
                     layer.close(layer1);
                     var sNodes=treeObj.transformToArray(selects[0].children);

                     for(var i=0;i<sNodes.length;i++){
                      if(sNodes[i].level==level){
                        showArea+=sNodes[i].name+','
                      }
                     }
                     showArea = showArea.slice(0, -1);
                     $("#lowerArea").val(showArea)
                     $.ajax({
                        url:lowerUrl+selectedId,
                       async: false,
                       data: 'json',
                       method: 'POST',
                       contentType: 'application/json;charset=UTF-8',
                        success:function(data){
                          //解析data，遍历获取的map集合
                          for (var p in data) {
                              if (data.hasOwnProperty(p)) {
                                  var value = data[p];

                              }
                          }
                          console.log(data)
                        zNodesL=data;
                        if(zNodesL.length==0){
                           layer.msg("没有相关下辖区域");
                        }
                       for(var i=0;i<zNodesL.length;i++){
                        selectedLowerArea+=zNodesL[i].name+',';
                        selectedlowerId+=zNodesL[i].id+',';
                       }
                       selectedlowerId = selectedlowerId.slice(0, -1);
                       selectedLowerArea = selectedLowerArea.slice(0, -1);
                       // $("#lowerArea").val("")

                        },
                        error:function(res){
                          layer.msg("加载城市列表失败");
                        }
                      });
                  }
         },
     });
});

//新增机关
function addhtml(){
  var html="";
    html+='<div class="layui-form-item">'
  +'<label class="layui-form-label">机关名称</label>'
  +'<div class="layui-input-block">'
  +'<input type="text" name="" placeholder="请输入" autocomplete="off" class="layui-input" id="organName" maxlength="50">'
  +'</div></div><div class="layui-form-item">'
  +'<label class="layui-form-label">隶属机关</label>'
  +'<div class="layui-input-block">'
  +'<select  placeholder="请选择" class="layui-input ieselect" id="Neworgan" style="display:none">'
  +'</select>'
  +'<div class="selectedB" id="AssselS" >'+
  '<div class="sel-wrap">'+
  '<span class="selected-item">所有类型</span>'+
  '</div>'+
  '<ul class="optionB">'+
      // '<li class="op-item">所有类型</li>'+
      // '<li class="op-item">执法证号</li>'+
      // '<li class="op-item">姓名</li>'+
      // '<li class="op-item">手机号</li>'+
      // '<li class="op-item">办公室电话</li>'+
  '</ul>'+
                 '</div>'
  +'</div></div>'
  +'<div class="double double1"><div class="layui-form-item">'
  +'<label class="layui-form-label">机关编号</label>'
  +'<div class="layui-input-block">'
  +'<input type="text" name="" placeholder="请输入" autocomplete="off" class="layui-input" id="organCode" maxlength="50"></div></div></div>'
  +'<div class="double double2"><div class="layui-form-item">'
  +'<label class="layui-form-label">行政区域</label>'
  +'<div class="layui-input-block">'
  +'<input type="text" name="" placeholder="请选择" readonly unselectable="on" id="selectedA" autocomplete="off" class="layui-input">'
  +'</div></div></div><div class="layui-form-item">'
  +'<label class="layui-form-label">下辖地区</label>'
  +'<div class="layui-input-block">'
  +'<textarea placeholder="请选择"  class="organSelect" id="lowerArea" readonly unselectable="on" ></textarea>'
  +'</div></div> '
  +'<div id="organInfo"></div>';

 $("#alertMessage1").append(html);
 getDefaultGroup();
 //模拟select
   $(".selectedB").on('click', '.sel-wrap', function(event) {
     if($(this).is(":hover")){
       console.log($(".selectedB .optionB").not($(this).next('.optionB')))
       $(".selectedB .optionB").not($(this).next('.optionB')).hide(20);
       $(this).next('.optionB').slideToggle(20);
     }
    return false;
  });

   $("#AssselS").on('click', '.op-item', function(event) {
     $(this).closest('.selectedB').find('.selected-item').text($(this).text());
     console.log($(this).attr('src'));
      $("#Neworgan").val($(this).attr('src'))
     $(this).closest('.optionB').slideUp(20);
   });


  document.onclick = function(){
    $(".optionB").hide();
  };
}
// //展示地区选择

function getDefaultGroup(){
  var orginListL="";
  var CkeckedL="";
         var wxjson = new webjson("22");
         wxjson.AddParam("departmentid", departmentid);//用户id组合
         wxjson.AddParam("nowdeptid", self_departmentid);//用户id组合
         if(edit.indexOf('编辑')>-1){
          wxjson.AddParam("flag",'no');
        }else{
          wxjson.AddParam("flag",'yes');
        }
         WebRequestAsync(wxjson, successGroup);
         function successGroup(res){
             var data = GetOjson(json_parse(res));
             console.log(data);
             if(data.status == 0){
               if(data.param.length>0){
                  var organList;
                 for(var i=0;i<data.param.length;i++){
                   organList+='<option value="'+data.param[i].departmentzone_code+'">'+data.param[i].department+'</option>';
                   orginListL+= '<li class="op-item" src="'+data.param[i].departmentzone_code+'">'+data.param[i].department+'</li>';
                   CkeckedL=data.param[0].department;
                 }
                 $("#Neworgan").append(organList);
                 $("#AssselS .optionB").append(orginListL);
                 $("#AssselS .selected-item").text(CkeckedL);
                   if(edit.indexOf('编辑')>-1){
                     var wxjson = new webjson("24"); //设置action值
                     //新增param键值
                     wxjson.AddParam("departmentid",self_departmentid);

                     WebRequestAsync(wxjson,successget);
                     function successget(res){
                        var data = GetOjson(json_parse(res));
                         if(data.status == 0){
                          if(data.param.length>0){
                            $("#organName").val(data.param[0].department);
                            $("#Neworgan").val(data.param[0].pdepartmentid);
                             $("#AssselS .selected-item").text(data.param[0].pdepartment);
                            $("#organCode").val(data.param[0].departmentbh);
                            $("#selectedA").val(data.param[0].areaname);
                            $("#lowerArea").val(data.param[0].dept_listname);
                             selectedArea=data.param[0].areaname//行政区域
                             selectedId=data.param[0].areaid;//行政区域id
                             // selectedPId="";//行政区域id
                             selectedLowerArea=data.param[0].subareas;//下辖区域
                             selectedlowerId=data.param[0].subareasids;;//下辖区域id
                          }

                             }else if(data.status == 9){//超时重新登录
                               window.location.href="index.html?loginOut=true";
                               return;
                           }else{
                            // layer.close(layer1)
                            layer.msg(data.info);
                        }
                     }
                 }

               }
         }else if(data.status == 9){//超时重新登录
           window.location.href="index.html?loginOut=true";
           return;
       }else{
        layer.close(layer1)
        layer.msg(data.info);
    }
   }


}

//初始化行政区域z-tree
function initG(){
  var htmlAT='<ul id="dep_tree" class="ztree"></ul>';
  $("#alertM").append(htmlAT)
  var setting = {
      check: {
          enable: true,
          chkStyle: "radio",
          radioType: "all"

      },
      data: {
          simpleData: {
              enable: true
          }
      },
        view: {
          fontCss: setFontCss_ztree
      },
  };
  var zNodes;
   $.ajax({
      url:areaUrl+departmentid,
     async: false,
     data: 'json',
     method: 'POST',
     contentType: 'application/json;charset=UTF-8',
      success:function(data){
        //解析data，遍历获取的map集合
        for (var p in data) {
            if (data.hasOwnProperty(p)) {
                var value = data[p];
            }
        }
      zNodes=data;
      },
      error:function(res){
        layer.msg("网络不给力！");
      }
    });
   // status = nodes[i].checked;//获取勾选状态
   //                 status=(!status);//取反，若当前节点被勾选，则取消勾选，否则勾选
   //                 treeObj.checkNode(nodes[i],status,true);
    $.fn.zTree.init($("#dep_tree"), setting, zNodes);
    if(selectedId){
      var treeObj = $.fn.zTree.getZTreeObj("dep_tree");
      var checkNode=treeObj.getNodesByParam("id",selectedId, null);
      var status="";
      // var status =checkNode[0].checked;
      // status=(!status);
       treeObj.checkNode(checkNode[0],status,true);
      var parentNode = checkNode[0].getParentNode();
      var parentNodes = getParentNodes_ztree('dep_tree', parentNode);
      treeObj.expandNode(parentNodes, true, false, true);
      treeObj.expandNode(parentNode, true, false, true);
    }
}

// 选择下辖区域
$("body").on('click', '#lowerArea', function(event) {
  if(selectedId){
  layer1=layer.open({
    type:1,
    title:'下辖区域',
    area: ['550px', '550px'], //宽高
    content:'<form class="alertMessage1" id="alertL"><div class="searchBox"><div class="layui-form-item"><label class="layui-form-label">下辖区域</label><div class="layui-input-block"><input type="text" name="" placeholder="请输入关键字进行查询" id="search_conditionL" autocomplete="off" class="layui-input"></div></div><span class="search" id="searchL" onclick="search_ztreeL()">查询</span></div></form><script>initL()</script>',
              btn: ['保存', '取消'],
              scrollbar:false,
              // shadeClose:true,
              yes:function(){
                  var treeObj = $.fn.zTree.getZTreeObj("dep_treeL");
                  var selects=treeObj.getCheckedNodes();
                  if(selects.length==0){
                     layer.msg('请先选择下辖区域',{time: 2000 });
                  }else{

                    selectedLowerArea="";
                    selectedlowerId="";
                    var sNodes=treeObj.transformToArray(treeObj.getNodes());
                     showArea="";
                    for(var i=0;i<sNodes.length;i++){
                     if(sNodes[i].level==0 && sNodes[i].checked && allcheck(sNodes[i])){
                      allcheck(sNodes[i])
                       showArea+=sNodes[i].name+','
                     }else if(sNodes[i].level==0 && sNodes[i].checked && (allcheck(sNodes[i])==false)){
                      showArea+=sNodes[i].name+'(部分),'
                     }
                    }
                    showArea = showArea.slice(0, -1);
                    for(var i=0;i<selects.length;i++){
                      selectedLowerArea=selectedLowerArea+selects[i].name+",";
                      selectedlowerId=selectedlowerId+selects[i].id+","
                    }
                    selectedLowerArea = selectedLowerArea.slice(0, -1);
                    selectedlowerId = selectedlowerId.slice(0, -1);
                    // $("#lowerArea").val("")
                    $("#lowerArea").val(showArea)
                     layer.close(layer1);
                  }
                  function allcheck(fatherCode){
                    var treeObj = $.fn.zTree.getZTreeObj("dep_treeL");
                    var nodes =treeObj.transformToArray(fatherCode.children);
                    var flag=1;
                    for(var i=0;i<nodes.length;i++){
                      if(nodes[i].checked){
                      }else{
                        flag=0;
                        return false;
                      }
                    }
                    if(flag==0){
                      return false;
                    }else if(flag==1){
                      return true;
                    }
                    console.log(nodes)
                  }
         },
     });
}else{
  layer.msg("请先选择行政区域")
}
});

// //展示地区选择
// function getDefaultGroupL(){


// }
//初始化行政区域z-tree
function initL(){
  var html='<ul id="dep_treeL" class="ztree"></ul>';
  $("#alertL").append(html);

  var settingL = {
      check: {
          enable: true,
          chkStyle: "checkbox",
         // chkboxType: { "Y": "s", "N": "s" },
         // radioType:"all"
      },
      data: {
          simpleData: {
              enable: true
          }
      },
        view: {
          fontCss: setFontCss_ztree
      },
  };
  var zNodesL;
   $.ajax({
      url:lowerUrl+selectedId,
     async: false,
     data: 'json',
     method: 'POST',
     contentType: 'application/json;charset=UTF-8',
      success:function(data){
        //解析data，遍历获取的map集合
        for (var p in data) {
            if (data.hasOwnProperty(p)) {
                var value = data[p];

            }
        }
        console.log(data)
      zNodesL=data;
      if(zNodesL.length==0){
         layer.msg("没有相关下辖区域");
      }
      },
      error:function(res){
        layer.msg("网络不给力！");
      }
    });

    $.fn.zTree.init($("#dep_treeL"), settingL, zNodesL);
    var treeObj = $.fn.zTree.getZTreeObj("dep_treeL");
    if(selectedlowerId){
      var selAnodes=selectedlowerId.split(',');
      if(selAnodes.length>0){
         var treeObj = $.fn.zTree.getZTreeObj("dep_treeL");
        for(var i=0;i<selAnodes.length;i++){
           var checkNode=treeObj.getNodesByParam("id",selAnodes[i], null);
           // var status =checkNode[0].checked;
           // status=(!status);
           var status="";
            treeObj.checkNode(checkNode[0],status,false);
           var parentNode = checkNode[0].getParentNode();
           var parentNodes = getParentNodes_ztree('dep_treeL', parentNode);
           treeObj.expandNode(parentNodes, true, false, true);
           treeObj.expandNode(parentNode, true, false, true);
        }
      }
    }
}

/**
     * 展开树
     * @param treeId
     */
    function expand_ztree(treeId){
        var treeObj = $.fn.zTree.getZTreeObj(treeId);
        treeObj.expandAll(true);
    }

    /**
     * 收起树：只展开根节点下的一级节点
     * @param treeId
     */
    function close_ztree(treeId){
        var treeObj = $.fn.zTree.getZTreeObj(treeId);
        var nodes = treeObj.transformToArray(treeObj.getNodes());
        var nodeLength = nodes.length;
        for (var i = 0; i < nodeLength; i++) {
            if (nodes[i].id == '0') {
                //根节点：展开
                treeObj.expandNode(nodes[i], true, true, false);
            } else {
                //非根节点：收起
                treeObj.expandNode(nodes[i], false, true, false);
            }
        }
    }

    /**
     * 搜索树，高亮显示并展示【模糊匹配搜索条件的节点s】
     * @param treeId
     * @param searchConditionId 文本框的id
     */
    function search_ztree(){
        searchByFlag_ztree('dep_tree', 'search_condition',"");
    }
    function search_ztreeL(){
        searchByFlag_ztree('dep_treeL', 'search_conditionL',"");
    }

    /**
     * 搜索树，高亮显示并展示【模糊匹配搜索条件的节点s】
     * @param treeId
     * @param searchConditionId     搜索条件Id
     * @param flag                  需要高亮显示的节点标识
     */
    function searchByFlag_ztree(treeId, searchConditionId, flag){
        //<1>.搜索条件
        var searchCondition = $('#' + searchConditionId).val();
        //<2>.得到模糊匹配搜索条件的节点数组集合
        var highlightNodes = new Array();
        if (searchCondition != "") {
            var treeObj = $.fn.zTree.getZTreeObj(treeId);
            highlightNodes = treeObj.getNodesByParamFuzzy("name", searchCondition, null);
        }
        //<3>.高亮显示并展示【指定节点s】
        if(highlightNodes.length==0){
          layer.msg('没有查到相关数据',{time: 2000 });
        }else{
        highlightAndExpand_ztree(treeId, highlightNodes, flag);

        }
    }

    /**
     * 高亮显示并展示【指定节点s】
     * @param treeId
     * @param highlightNodes 需要高亮显示的节点数组
     * @param flag           需要高亮显示的节点标识
     */

    function highlightAndExpand_ztree(treeId, highlightNodes, flag){
        var treeObj = $.fn.zTree.getZTreeObj(treeId);
        //<1>. 先把全部节点更新为普通样式
        var treeNodes = treeObj.transformToArray(treeObj.getNodes());
        for (var i = 0; i < treeNodes.length; i++) {
            treeNodes[i].highlight = false;
            treeObj.updateNode(treeNodes[i]);
        }
        //<2>.收起树, 只展开根节点下的一级节点
        close_ztree(treeId);
        //<3>.把指定节点的样式更新为高亮显示，并展开
        if (highlightNodes != null) {
            for (var i = 0; i < highlightNodes.length; i++) {
                if (flag != null && flag != "") {
                    if (highlightNodes[i].flag == flag) {
                        //高亮显示节点，并展开
                        highlightNodes[i].highlight = true;
                        treeObj.updateNode(highlightNodes[i]);
                        //高亮显示节点的父节点的父节点....直到根节点，并展示
                        var parentNode = highlightNodes[i].getParentNode();
                        var parentNodes = getParentNodes_ztree(treeId, parentNode);
                        treeObj.expandNode(parentNodes, true, false, true);
                        treeObj.expandNode(parentNode, true, false, true);
                    }
                } else {
                    //高亮显示节点，并展开
                    highlightNodes[i].highlight = true;
                    treeObj.updateNode(highlightNodes[i]);
                    //高亮显示节点的父节点的父节点....直到根节点，并展示
                    var parentNode = highlightNodes[i].getParentNode();
                    var parentNodes = getParentNodes_ztree(treeId, parentNode);
                    treeObj.expandNode(parentNodes, true, false, true);
                    treeObj.expandNode(parentNode, true, false, true);
                }
            }
        }
    }

    /**
     * 递归得到指定节点的父节点的父节点....直到根节点
     */
    function getParentNodes_ztree(treeId, node){
        if (node != null) {
            var treeObj = $.fn.zTree.getZTreeObj(treeId);
            var parentNode = node.getParentNode();
            return getParentNodes_ztree(treeId, parentNode);
        } else {
            return node;
        }
    }

    //设置节点样式
    function setFontCss_ztree(treeId, treeNode) {
        if (treeNode.id == 0) {
            //根节点
            return {color:"#333", "font-weight":"bold"};
        } else if (treeNode.isParent == false){
            //叶子节点
            return (!!treeNode.highlight) ? {color:"#ff0000", "font-weight":"bold"} : {color:"#333", "font-weight":"normal"};
        } else {
            //父节点
            return (!!treeNode.highlight) ? {color:"#ff0000", "font-weight":"bold"} : {color:"#333", "font-weight":"normal"};
        }
    }


//读取用户列表
function getUserList(sskey,ssmode,sssel,page_index,page_size){
    if(PageISLock == 1) {
        return;
    }
    PageISLock = 1;
    $("#userList").empty();
    $("#userList").append("<tr class='loading'><td colspan='11' style='padding:20px 0;text-align:center'><img src='../style/image/load.gif' width='32px' height='32px' /></td></tr>");
        var wxjson = new webjson("23"); //设置action值
        //新增param键值
        wxjson.AddParam("sskey",sskey);
        wxjson.AddParam("departmentid",departmentid);
        wxjson.AddParam("ssmode", ssmode);
        wxjson.AddParam("sssel", sssel);
        wxjson.AddParam("page_index", page_index);
        wxjson.AddParam("page_size", page_size);
        var res=WebRequestAsync(wxjson,successgetUserList);
    }
    function successgetUserList(res){
         PageISLock = 0;
     var data = GetOjson(json_parse(res));
     paramcentcount=data.paramcentcount;
     $("#page").empty();
      $("#mySelectS").hide();
      $("#gl").empty();
     if(data.status==0){
        // $(".qx").prop('checked', false)
        $("#userList").empty();


      var data = GetOjson(json_parse(res));
      console.log(data)
      var html="";
      if(data.param.length>0){
        // autoH();
        $("#thead").empty();
          if(user_type==0){
          $("#thead").append('<th>操作</th><th>机关编号</th><th>机关名称</th><th>隶属机关</th><th>行政区域</th><th>下辖地区</th>');
        }else{
          $("#thead").append('<th>机关编号</th><th>机关名称</th><th>隶属机关</th><th>行政区域</th><th>下辖地区</th>');
        }

        var cents = cpage.GetCentPage(pagenum,paramcentcount,ecount);
        $("#page").html(cents);
          for(var i=0;i<data.param.length;i++){
             html+='<tr class="hs">';
             if(user_type==0){
              html+='<td width="15%"><span class="modify edit">编辑<i class="departmentid" style="display:none;">'+data.param[i].departmentid+'</i></span></td>';
             }

            html+='<td width="10%">'+data.param[i].departmentbh+'</td>'
            +'<td width="15%">'+data.param[i].department+'</td>'
            +'<td width="15%">'+data.param[i].pdepartment+'</td>'
            +'<td width="15%">'+data.param[i].areaname+'</td>'
            +'<td ><div style="width:100%; overflow: hidden;white-space: nowrap;text-overflow: ellipsis;" id="tableLastTd">'+data.param[i].dept_listname+'</div></td>'
            +'</tr>'
          }

          $("#gl").empty();
          if(user_type==0){
          $("#gl").append('<span id="new_zh">新增机关</span>');
        }
          $("#userList").append(html)
          autoH();
          $("#mySelectS").show();
      }

  }else if(data.status==1){
     $("#gl").empty();
          if(user_type==0){
          $("#gl").append('<span id="new_zh">新增机关</span>');
        }
      $("#userList").empty();
      $("#userList").append("<tr class='loading'><td colspan='11' style='padding:20px 0;text-align:center'>没有查到相关数据</td></tr>");
  }else if(data.status == 9){
        window.location.href="index.html?loginOut=true";
        return;
    }else{
    $("#userList").empty();
    layer.msg(data.info)
  }

  }

