var userid="";//用户id
var user_type=$.cookie('user_type')//用户类型
var departmentid=$.cookie('departmentid')
var a1="a15",a2="a1500";//用于navLeft，当前导航
var layer1;
var ecount = $("#mySelect").val();//一页数据条数
var cpage = new CentPage();//初始化分页
var pagenum = 1;//第几页
var paramcentcount=0;//总数据条数
var nowdeptid=" ";
$(function(){

getActiveN("a15","a1500");
userid=GetQueryString("userid");
getuserInfo('.inputWrapper',userid);
getRecord(pagenum,ecount);
})
 /**分页设置**/
function CentPageOper(pnum){
    ecount = $("#mySelect").val();
    cents = cpage.GetCentPage(pnum,paramcentcount,ecount);
    $("#page").html(cents);
    pagenum=pnum;
   getRecord(pagenum,ecount);
}

//select/切换
function select(){
    ecount = $("#mySelect option:selected").val();
    pagenum=1;
   getRecord(pagenum,ecount);
 }

//获取用户信息
function getuserInfo(alertMessage0,userid){
        var wxjson = new webjson("14");
        wxjson.AddParam("userid", userid);//用户id组合
        WebRequestAsync(wxjson, sc);
        function sc(res){
            var data = GetOjson(json_parse(res));
            console.log(data);
            if(data.status == 0){
              if(data.param.length>0){
                console.log($(alertMessage0).find(".bascicM0"))
                if(alertMessage0.indexOf('alertMessage0')>-1){
                  console.log(data.param[0].departmentid)
                  $("#Neworgan").val(data.param[0].departmentid);
                  $("#ssselS .selected-item").text(data.param[0].department);
                }else{
                  $(alertMessage0).find(".bascicM0").val(data.param[0].department);
                }

                $(alertMessage0).find(".bascicM1").val(data.param[0].realname);
                $(alertMessage0).find(".bascicM2").val(data.param[0].username);
                $(alertMessage0).find(".bascicM3").val(data.param[0].duties);
                $(alertMessage0).find(".bascicM4").val(data.param[0].telnum);
                $(alertMessage0).find(".bascicM5").val(data.param[0].email);
                $(alertMessage0).find(".bascicM6").val(data.param[0].phonenum);
                if(data.param[0].username){
                  if(data.param[0].phonenum){
                    $(alertMessage0).find(".bascicM7").val(data.param[0].username+" 或 "+data.param[0].phonenum);
                  }else{
                    $(alertMessage0).find(".bascicM7").val(data.param[0].username);
                  }
                }

                if(alertMessage0.indexOf('alertMessage0')>-1){
                  $(alertMessage0).find(".bascicM8").val(data.param[0].usertype);
                  if(data.param[0].usertype==0){
                  $(alertMessage0).find("#ssmodeS .selected-item").text('管理员');

                  }else{
                  $(alertMessage0).find("#ssmodeS .selected-item").text('普通用户');

                  }
                }else{
                 if(data.param[0].usertype==0){
                 $(alertMessage0).find(".bascicM8").val("管理员");
                 }else if(data.param[0].usertype==1){
                    $(alertMessage0).find(".bascicM8").val("普通用户");
                 }
                }

                $(alertMessage0).find(".bascicM9").val("      ");
                if(user_type==0){
                  $("#editor").empty();
                   $("#editor").append('<span class="editSpan" id="edit_zh">编辑</span>')
                }

              }
        }else if(data.status == 9){//超时重新登录
          window.location.href="index.html?loginOut=true";
          return;
      }else{
       layer.close(layer1)
       layer.msg(data.info);
   }
  }
}
//编辑用户
$("body").on('click','#edit_zh',function(){
  layer.open({
    type:1,
    title:'编辑账号',
    area: ['550px', '620px'], //宽高
    content:'<form id="alertMessage0" class="alertMessage0 clearfix"><script>getDefaultGroup()</script></form>',
              btn: ['保存修改', '关闭'],
              scrollbar:false,
              shadeClose:true,
              yes:function(){
                var alertMessage0='#alertMessage0';
                var Neworgan= $(alertMessage0).find(".bascicM0").val();
                 var Newname=$(alertMessage0).find(".bascicM1").val();
                 var newAccount=$(alertMessage0).find(".bascicM2").val();
                 var dutyWork=$(alertMessage0).find(".bascicM3").val();
                 var workPhone=$(alertMessage0).find(".bascicM4").val();
                 var Phone=$(alertMessage0).find(".bascicM6").val();
                 var newemail=$(alertMessage0).find(".bascicM5").val();
                 var Newtype=$(alertMessage0).find(".bascicM8").val();
                 var loginAccount="";
                 // var newPsw=$(alertMessage0).find(".bascicM7").val();
                 var loginAccount=$(alertMessage0).find(".bascicM8").val();
                 var newPsw=$(alertMessage0).find(".bascicM9").val();
                     var re = /^0\d{2,3}-?\d{7,8}$/;
                     var re1 = /^(\w-*\.*)+@(\w-?)+(\.\w{2,})+$/;
                     if(Neworgan==""|| Newname==""|| newAccount==""){
                       $("#moTips").html("*为必填项");
                     }else if(workPhone!="" && (!(re.test(workPhone)))){
                     $("#moTips").html("请输入正确的电话号码");
                 }else if(Phone!="" && (!(/^1[34578]\d{9}$/.test(Phone)))){
                   $("#moTips").html("请输入正确的手机号");
                 }else if(newemail!="" && !(re1.test(newemail))){
                      $("#moTips").html("请输入正确的电子邮箱");
                 }else if(newPsw!="      " && !(/^[a-zA-Z0-9_]{6,20}$/.test(newPsw))){
                   $("#moTips").html("密码长度由6-20位数字/字母/下划线组成");
                 }else if(newPsw=="" || Newtype==""){
                     $("#moTips").html("*为必填项");
                 }else{
                  if(newPsw=="      "){
                    newPsw="";
                  }
                    creatAccount(Neworgan,Newname,newAccount,newPsw,Newtype,dutyWork,workPhone,Phone,loginAccount,newemail,Neworgan);

                 }
         },
     });
});

//修改账号
function creatAccount(Neworgan,Newname,newAccount,newPsw,Newtype,dutyWork,workPhone,Phone,loginAccount,newemail,departmentid){
  var wxjson = new webjson("15"); //设置action值
  //新增param键值
  wxjson.AddParam("userid",userid);
  wxjson.AddParam("departmentid",departmentid);
  wxjson.AddParam("username",newAccount);
  wxjson.AddParam("realname", Newname);
  wxjson.AddParam("pwd", newPsw);
  wxjson.AddParam("usertype", Newtype);
  wxjson.AddParam("phonenum", Phone);
  wxjson.AddParam("telnum", workPhone);
  wxjson.AddParam("duties", dutyWork);
  wxjson.AddParam("email", newemail);
  var res=WebRequestAsync(wxjson,successgetsave);
  function successgetsave(res){
     var data = GetOjson(json_parse(res));
      if(data.status == 0){
               layer.close(layer1);
               layer.msg('保存成功');
              location.reload();
          }else if(data.status == 9){//超时重新登录
            window.location.href="index.html?loginOut=true";
            return;
        }else{
         // layer.close(layer1)
         layer.msg(data.info);
     }
  }
}
// //展示内容
function getDefaultGroup(){
  var organList="";
  var html="";
  html='<div class="layui-form-item">'
          +'<label class="layui-form-label"><i class="nessary">*</i>所属机关</label>'
          +'<div class="layui-input-block">'
          +'<select placeholder="请输入"  class="layui-input bascicM0 ieselect" id="Neworgan" style="display:none">'
          +'</select>'
          +'<div class="selectedB" id="ssselS" >'+
          '<div class="sel-wrap">'+
          '<span class="selected-item"></span>'+
          '</div>'+
          '<ul class="optionB">'+
              // '<li class="op-item">所有类型</li>'+
              // '<li class="op-item">执法证号</li>'+
              // '<li class="op-item">姓名</li>'+
              // '<li class="op-item">手机号</li>'+
              // '<li class="op-item">办公室电话</li>'+
          '</ul>'+
                         '</div>'
          +'</div>'
          +'</div>'
          +'<div class="clearfix">'
          +'<div class="double">'
          +'<div class="layui-form-item">'
          +'<label class="layui-form-label"><i class="nessary">*</i>姓名</label>'
          +'<div class="layui-input-block">'
          +'<input type="text" name="" placeholder="请输入" autocomplete="off" class="layui-input bascicM1" maxlength="50">'
          +'</div>'
          +'</div>'
          +'</div>'
           +'<div  class="double">'
          +'<div class="layui-form-item">'
          +'<label class="layui-form-label"><i class="nessary">*</i>执法证号</label>'
          +'<div class="layui-input-block">'
          +'<input type="text" name="" placeholder="请输入" style="background:#eee" autocomplete="off" class="layui-input bascicM2" id="newAccount" readonly unselectable="on" maxlength="50">'
          +'</div>'
          +'</div>'
          +'</div>'
          +'</div>'
          +'<div class="layui-form-item">'
          +'<label class="layui-form-label">职务</label>'
          +'<div class="layui-input-block">'
          +'<input type="text" name="" placeholder="请输入" autocomplete="off" class="layui-input bascicM3" maxlength="50">'
          +'</div>'
          +'</div>'
          +'<div class="clearfix">'
          +'<div class="double">'
          +'<div class="layui-form-item">'
          +'<label class="layui-form-label">办公电话</label>'
          +'<div class="layui-input-block">'
          +'<input type="text" name="" placeholder="请输入" autocomplete="off" class="layui-input bascicM4">'
          +'</div>'
          +'</div>'
          +'</div>'
          +'<div class="double">'
          +'<div class="layui-form-item">'
          +'<label class="layui-form-label">手机号</label>'
          +'<div class="layui-input-block">'
          +'<input type="text" name="" placeholder="请输入" autocomplete="off" class="layui-input bascicM6" id="Phone">'
          +'</div>'
          +'</div>'
          +'</div>'
          +'</div>'
          +'<div class="layui-form-item">'
          +'<label class="layui-form-label">邮箱</label>'
          +'<div class="layui-input-block">'
          +'<input type="text" name="" placeholder="请输入" autocomplete="off" class="layui-input bascicM5" maxlength="50">'
          +'</div>'
          +'</div>'
          +'<div class="line">'
          +'<div class="layui-form-item">'
          +'<label class="layui-form-label">登陆账号</label>'
          +'<div class="layui-input-block">'
          +'<input type="text" name="" style="background:#eee"  placeholder="执法账号 或 手机号"  readonly unselectable="on" autocomplete="off" class="layui-input bascicM7 " id="loginAccount" maxlength="50">'
          +'</div>'
          +'</div>'
          +'<div class="layui-form-item">'
          +'<label class="layui-form-label"><i class="nessary">*</i>登陆密码</label>'
          +'<div class="layui-input-block">'
          +'<input type="password" name="" placeholder="请输入" autocomplete="off" class="layui-input bascicM9" maxlength="50">'
          +'</div>'
          +'</div>'
          +'<div class="layui-form-item">'
          +'<label class="layui-form-label"><i class="nessary">*</i>用户类型</label>'
          +'<div class="layui-input-block">'
          +'<select  placeholder="请输入"  class="layui-input bascicM8 ieselect" id="Newtype" style="display:none">'
          +'<option value="0">管理员</option>'
          +'<option value="1">普通用户</option>'
          +'</select>'
          +'<div class="selectedB" id="ssmodeS" >'+
          '<div class="sel-wrap">'+
          '<span class="selected-item">管理员</span>'+
          '</div>'+
          '<ul class="optionB">'+
              '<li class="op-item" src="0">管理员</li>'+
              '<li class="op-item" src="1">普通用户</li>'+
          '</ul>'+
                         '</div>'
          +'</div>'
          +'</div>'
          +'</div>'
          +'<div id="moTips"></div>'
           $("#alertMessage0").append(html);

             //模拟select
               $(".selectedB").on('click', '.sel-wrap', function(event) {
                 if($(this).is(":hover")){
                   console.log($(".selectedB .optionB").not($(this).next('.optionB')))
                   $(".selectedB .optionB").not($(this).next('.optionB')).hide(20);
                   $(this).next('.optionB').slideToggle(20);
                 }
                return false;
              });

               $("#ssselS").on('click', '.op-item', function(event) {
                 $(this).closest('.selectedB').find('.selected-item').text($(this).text());
                 console.log($(this).attr('src'));
                  $("#Neworgan").val($(this).attr('src'))
                 $(this).closest('.optionB').slideUp(20);
               });
                $("#ssmodeS").on('click', '.op-item', function(event) {
                  $(this).closest('.selectedB').find('.selected-item').text($(this).text());
                 $("#Newtype").val($(this).attr('src'))
                  $(this).closest('.optionB').slideUp(20);
                });


              document.onclick = function(){
                $(".optionB").hide();
              };

         var wxjson = new webjson("22");
         wxjson.AddParam("departmentid", departmentid);//用户id组合
         wxjson.AddParam("nowdeptid", nowdeptid);//用户id组合
         wxjson.AddParam("flag",'yes');//用户id组合
         WebRequestAsync(wxjson, successGroup);
         function successGroup(res){
           console.log(res)
             var data = GetOjson(json_parse(res));
             console.log(data);
             if(data.status == 0){
              var divSe="";
               if(data.param.length>0){
                 for(var i=0;i<data.param.length;i++){
                   organList+='<option value="'+data.param[i].departmentid+'">'+data.param[i].department+'</option>';
                   divSe+= '<li class="op-item" src="'+data.param[i].departmentid+'">'+data.param[i].department+'</li>';
                 }
                 $("#Neworgan").append(organList);
                 $("#ssselS .optionB").append(divSe);
                 getuserInfo('#alertMessage0',userid)
               }
         }else if(data.status == 9){//超时重新登录
           window.location.href="index.html?loginOut=true";
           return;
       }else{
        layer.close(layer1)
        layer.msg(data.info);
    }
   }


}

//操作记录
function getRecord(pagenum,ecount){
  $("#userList").empty();
  $("#userList").append("<tr class='loading'><td colspan='11' style='padding:20px 0;text-align:center;'><img src='../style/image/load.gif' width='32px' height='32px' /></td></tr>");
        var wxjson = new webjson("21");
        wxjson.AddParam("userid", userid);//用户id组合
        wxjson.AddParam("page_index", pagenum);//
        wxjson.AddParam("page_size", ecount);//
        WebRequestAsync(wxjson, sc);
        function sc(res){
            var data = GetOjson(json_parse(res));
            console.log(data);
             paramcentcount=data.paramcentcount;
             $("#page").empty();
             $("#mySelect").hide();
             $("#button").empty();
            if(data.status == 0){
               $("#userList").empty();
             if(data.param.length>0){


               var cents = cpage.GetCentPage(pagenum,paramcentcount,ecount);
               $("#page").html(cents);
              var html="";
              for(var i=0;i<data.param.length;i++){
                html+='<tr class="hs">'
                      +'<td>'+data.param[i].opmodel+'</td>'
                      +'<td>'+data.param[i].optype+'</td>'
                      +'<td>'+data.param[i].optime+'</td>'
                      +'<td>'+data.param[i].fwip;;+'</td>'
                      +'</tr>'
              }
              $("#mySelect").show();
              $("#userList").append(html);
              $("#button").append('<span class="editSpan" id="btnExport"><a style="color:##159AEF" id="btnExporta">导出</a></span>')
              autoH();
             }else{
              // $("#button").hide();
              $("#userList").empty();
               $("#userList").append("<tr class='loading'><td colspan='11' style='padding:20px 0;text-align:center'>没有查到相关数据</td></tr>");
             }
        }else if(data.status==1){
           // $("#button").hide();
          $("#userList").empty();
           $("#userList").append("<tr class='loading'><td colspan='11' style='padding:20px 0;text-align:center'>没有查到相关数据</td></tr>");
        }else if(data.status == 9){//超时重新登录
          window.location.href="index.html?loginOut=true";
          return;
      }else{
        // $("#button").hide();
       // layer.close(layer1)
       layer.msg(data.info);
   }
  }
}

//导出
$('body').on('click', '#btnExporta', function(event) {
$(this).attr('href',exportUrl)
});

//弹窗账号显示
$("body").on('blur', '#newAccount', function(event) {
  var phone=$('body #Phone').val();
  if(phone){
    $('body #loginAccount').val("");
      var text=$(this).val();
      if(text){
        $('body #loginAccount').val(text+' 或 '+phone)
      }else{
        $('body #loginAccount').val(phone)
      }

  }else{
     var text=$(this).val();
   $('body #loginAccount').val(text)
  }

});
$("body").on('blur', '#Phone', function(event) {
  var zhifa=$("body #newAccount").val();
  var text=$(this).val();
  if(text){
     if(zhifa){
       $('body #loginAccount').val(zhifa+' 或 '+text)
     }else{
      $('body #loginAccount').val(text)
     }
   }else{
     $('body #loginAccount').val(zhifa)
   }




});